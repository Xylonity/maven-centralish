package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layer.impl.IconBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.render.TooltipRenderer;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import net.minecraft.class_241;

public class FocusIconBackground implements IconBackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        int positionX = (int) context.getTooltipPosition().field_1343 - 1 + context.getPaddingX();
        int positionY = (int) context.getTooltipPosition().field_1342 + context.getPaddingY();

        int slotSizeX = positionX + Constants.getIconSize(context);
        int slotSizeY = positionY + Constants.getIconSize(context);

        int x0 = positionX;
        int y0 = positionY;
        int x1 = slotSizeX;
        int y1 = slotSizeY;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        int color = (((int) (40 + 30 * Math.sin(TooltipRenderer.COUNTER * 2.5))) << 24) | 0xFFFFFF;

        // Background
        context.getGraphics().method_25294(x0, y0, x1, y1, 0x8018181C);

        // Top left
        context.getGraphics().method_25294(x0, y0 - 1, x0 + 5, y0, color);
        context.getGraphics().method_25294(x0 - 1, y0 - 1, x0, y0 + 5, color);

        // Bottom left
        context.getGraphics().method_25294(x0, y1 + 1, x0 + 5, y1, color);
        context.getGraphics().method_25294(x0 - 1, y1 - 5, x0, y1 + 1, color);

        // Top right
        context.getGraphics().method_25294(x1 - 5, y0 - 1, x1 + 1, y0, color);
        context.getGraphics().method_25294(x1 + 1, y0, x1, y0 + 5, color);

        // Bottom right
        context.getGraphics().method_25294(x1 - 5, y1, x1 + 1, y1 + 1, color);
        context.getGraphics().method_25294(x1 + 1, y1 - 5, x1, y1, color);
    }

}