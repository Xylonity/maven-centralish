package dev.xylonity.tooltipoverhaul.client.style.divider;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.DividerLineLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public class StaticDividerLine implements DividerLineLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        int y = (int) position.field_1342;
        int x = (int) position.field_1343;
        int paddingX = context.getPaddingX();
        int width = (int) context.getTooltipSize().field_1343;

        class_4587 pose = context.getGraphics().method_51448();
        Matrix4f matrix = pose.method_23760().method_23761();
        class_289 tesselator = class_289.method_1348();
        class_287 buf = tesselator.method_1349();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        buf.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        int baseColor = ColorUtils.getDividerLineColor(context);
        int r = (baseColor >>> 16) & 0xFF;
        int g = (baseColor >>> 8) & 0xFF;
        int b = baseColor & 0xFF;

        buf.method_22918(matrix, x - paddingX - 2, y + 1, 0).method_1336(r, g, b, 255).method_1344();
        buf.method_22918(matrix, x + width - paddingX + 1, y + 1, 0).method_1336(r, g, b, 255).method_1344();
        buf.method_22918(matrix, x + width - paddingX + 1, y, 0).method_1336(r, g, b, 255).method_1344();
        buf.method_22918(matrix, x - paddingX - 2, y, 0).method_1336(r, g, b, 255).method_1344();

        class_286.method_43433(buf.method_1326());
    }
}