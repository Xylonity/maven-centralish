package dev.xylonity.tooltipoverhaul.client.layer;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import java.awt.*;
import net.minecraft.class_241;

@FunctionalInterface
public interface ITooltipLayer {

    LayerDepth getLayerDepth();

    default void render(TooltipContext context, class_241 position) {
        ;;
    }

    default void renderInternal(TooltipContext context) {
        render(context, context.getTooltipPosition());
    }

}
