package dev.xylonity.tooltipoverhaul.client.util;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.mixin.KeyMappingAccessor;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_5151;
import net.minecraft.class_5684;
import net.minecraft.class_8000;
import java.util.List;

public class EquippedContextCalculator {

    public static @Nullable TooltipContext from(class_332 graphics, class_327 font, int mouseX, int mouseY, class_8000 tooltipPositioner, class_1799 fromStack, int screenWidth, int screenHeight) {

        class_3675.class_306 compareKey = ((KeyMappingAccessor) TooltipOverhaulKeyMappings.COMPARE_TOOLTIP).tooltipoverhaul$key();
        boolean isKeyDown = false;
        if (!compareKey.equals(class_3675.field_16237)) {
            isKeyDown = class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), compareKey.method_1444());
        }

        if (!isKeyDown) {
            return null;
        }

        class_310 minecraft = class_310.method_1551();
        class_1657 player = minecraft.field_1724;

        if (!(fromStack.method_7909() instanceof class_5151 equippableStack) || player == null) {
            return null;
        }

        class_1799 equippedArmorStack = player.method_31548().method_7372(equippableStack.method_7685().method_5927());
        if (equippedArmorStack.method_7960() || class_1799.method_31577(fromStack, equippedArmorStack)) {
            return null;
        }

        List<class_5684> componentList = TextUtils.getTooltipComponentsFrom(equippedArmorStack, font, screenWidth, 2.2f);

        return new TooltipContext(graphics, font, componentList, mouseX, mouseY, screenWidth, screenHeight, tooltipPositioner, equippedArmorStack, false);
    }

}
