package dev.xylonity.tooltipoverhaul.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.config.ConfigManager;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.config.wrapper.ConfigEntry;
import org.joml.Matrix4f;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5244;
import net.minecraft.class_5481;
import net.minecraft.class_6382;
import net.minecraft.class_757;

public class TooltipOverhaulConfigScreen extends class_437 {

    private final class_437 parent;
    private ConfigPanel panel;
    private class_342 searchBox;
    private float searchHoverProgress = 0f;

    private static final int HEADER_HEIGHT = 64;

    public TooltipOverhaulConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Tooltip Overhaul Config"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int panelTop = HEADER_HEIGHT + 8;
        int panelBottom = this.field_22790 - 40;
        int panelHeight = Math.max(0, panelBottom - panelTop);

        this.panel = new ConfigPanel(20, panelTop, this.field_22789 - 40, panelHeight);
        this.method_37063(this.panel);

        int searchWidth = 240;
        int searchX = this.panel.method_46426() + 10;
        int searchY = HEADER_HEIGHT - 26;

        this.searchBox = new CenteredEditBox(this.field_22793, searchX, searchY, searchWidth, 20, class_2561.method_43470("Search"));
        this.searchBox.method_47404(class_2561.method_43470("Search settings..."));
        this.searchBox.method_1863(this::onSearchChanged);

        this.searchBox.method_1858(false);
        this.searchBox.method_1868(0xFFE8E8E8);
        this.searchBox.method_1860(0xFF777777);

        this.method_37063(this.searchBox);

        for (Field field : TooltipsConfig.class.getDeclaredFields()) {
            ConfigEntry meta = field.getAnnotation(ConfigEntry.class);
            if (meta == null) {
                continue;
            }

            field.setAccessible(true);
            this.panel.addConfigEntry(field, meta);
        }

        int buttonWidth = 120;
        int buttonHeight = 20;
        int spacing = 10;
        int totalWidth = buttonWidth * 2 + spacing;
        int startX = (this.field_22789 - totalWidth) / 2;
        int buttonY = this.field_22790 - 28;

        // DONE
        this.method_37063(
                new ConfigPanel.ModernButton(startX, buttonY, buttonWidth, buttonHeight, class_5244.field_24334, (b) -> {
                    saveConfig();
                    this.field_22787.method_1507(this.parent);
                })

        );

        // CANCEL
        this.method_37063(
                new ConfigPanel.ModernButton(startX + buttonWidth + spacing, buttonY, buttonWidth, buttonHeight, class_2561.method_43470("Cancel"), (b) -> {
                    this.field_22787.method_1507(this.parent);
                })

        );

        this.panel.applySearch("");
    }

    private void onSearchChanged(String text) {
        if (this.panel != null) {
            this.panel.applySearch(text);
        }

    }

    private void saveConfig() {
        if (this.panel != null) {
            this.panel.applyToFields();
            ConfigManager.save(TooltipsConfig.class);
        }

    }

    @Override
    public void method_25393() {
        if (this.searchBox != null) {
            this.searchBox.method_1865();
        }

        if (this.panel != null) {
            this.panel.tickPanel();
        }

        super.method_25393();
    }

    @Override
    public void method_25419() {
        saveConfig();
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF101010);

        renderHeader(graphics);
        renderSearchBackground(graphics, mouseX, mouseY);

        renderFooterSeparator(graphics);

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void renderFooterSeparator(class_332 graphics) {
        int lineW = (int) (this.field_22789 * 0.80f);
        int x0 = (this.field_22789 - lineW) / 2;
        int x1 = x0 + lineW;

        int y = this.field_22790 - 36;
        int h = 1;

        int red = 0x4D;
        int green = 0x4D;
        int blue = 0x4D;

        int centerX = x0 + (lineW / 2);

        class_4587 pose = graphics.method_51448();
        Matrix4f matrix = pose.method_23760().method_23761();
        class_289 tesselator = class_289.method_1348();
        class_287 buffer = tesselator.method_1349();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Left
        buffer.method_22918(matrix, x0, y + h, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, centerX, y + h, 0).method_1336(red, green, blue, 255).method_1344();
        buffer.method_22918(matrix, centerX, y, 0).method_1336(red, green, blue, 255).method_1344();
        buffer.method_22918(matrix, x0, y, 0).method_1336(red, green, blue, 0).method_1344();

        // Right
        buffer.method_22918(matrix, centerX, y + h, 0).method_1336(red, green, blue, 255).method_1344();
        buffer.method_22918(matrix, x1, y + h, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, x1, y, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, centerX, y, 0).method_1336(red, green, blue, 255).method_1344();

        class_286.method_43433(buffer.method_1326());

        //RenderSystem.disableBlend();
    }

    private void renderHeader(class_332 graphics) {
        for (int i = 0; i < HEADER_HEIGHT; i++) {
            int alpha = Math.max(0, 80 - (i * 2));
            if (alpha <= 0) {
                continue;
            }

            int color = (alpha << 24);
            graphics.method_25294(0, i, this.field_22789, i + 1, color);
        }

        String brandTitle = "Tooltip Overhaul";
        int brandTitleWidth = this.field_22793.method_1727(brandTitle);
        int brandTitleX = this.field_22789 - 18 - brandTitleWidth;
        int brandTitleY = 10;
        graphics.method_51433(this.field_22793, brandTitle, brandTitleX, brandTitleY, 0xFFFFFFFF, false);

        String brandSubtitle = "Every tooltip, more modern, sharper, cleaner.";
        int brandSubtitleWidth = this.field_22793.method_1727(brandSubtitle);
        int brandSubtitleX = this.field_22789 - 18 - brandSubtitleWidth;
        int brandSubtitleY = brandTitleY + 12;
        graphics.method_51433(this.field_22793, brandSubtitle, brandSubtitleX, brandSubtitleY, 0xFFAAAAAA, false);
    }

    private void renderSearchBackground(class_332 graphics, int mouseX, int mouseY) {
        if (this.searchBox == null) return;

        int boxX = this.searchBox.method_46426();
        int boxY = this.searchBox.method_46427();
        int boxW = this.searchBox.method_25368();
        int boxH = this.searchBox.method_25364();

        boolean hovered = mouseX >= boxX && mouseX <= boxX + boxW && mouseY >= boxY && mouseY <= boxY + boxH;
        boolean active = hovered || this.searchBox.method_25370();

        float step = 0.1f;
        if (active) {
            searchHoverProgress = Math.min(1.0f, searchHoverProgress + step);
        }
        else {
            searchHoverProgress = Math.max(0.0f, searchHoverProgress - step);
        }

        graphics.method_25294(boxX, boxY, boxX + boxW, boxY + boxH, 0x35353535);

        int baseBorder = 2;
        int extraBorder = Math.round(searchHoverProgress * 2.0f);
        int borderW = baseBorder + extraBorder;

        int idleBorder = 0x40FFFFFF;
        int hoverBorder = 0xFF4A9EFF;
        int borderColor = (searchHoverProgress > 0f) ? hoverBorder : idleBorder;

        graphics.method_25294(boxX, boxY, boxX + borderW, boxY + boxH, borderColor);

        if (searchHoverProgress > 0f) {
            int gradientW = Math.min(120, boxW / 3);
            int maxA = (int) (0x40 * searchHoverProgress);

            class_4587 pose = graphics.method_51448();
            Matrix4f matrix = pose.method_23760().method_23761();
            class_289 tesselator = class_289.method_1348();
            class_287 bufferBuilder = tesselator.method_1349();

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(class_757::method_34540);

            bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

            int x0 = boxX;
            int x1 = boxX + gradientW;
            int y0 = boxY;
            int y1 = boxY + boxH;

            bufferBuilder.method_22918(matrix, x0, y1, 0).method_1336(0x4A, 0x9E, 0xFF, maxA).method_1344();
            bufferBuilder.method_22918(matrix, x1, y1, 0).method_1336(0x4A, 0x9E, 0xFF, 0).method_1344();
            bufferBuilder.method_22918(matrix, x1, y0, 0).method_1336(0x4A, 0x9E, 0xFF, 0).method_1344();
            bufferBuilder.method_22918(matrix, x0, y0, 0).method_1336(0x4A, 0x9E, 0xFF, maxA).method_1344();

            class_286.method_43433(bufferBuilder.method_1326());
        }

    }

    static class ConfigPanel extends class_339 {

        private final List<ValueEntry> allEntries = new ArrayList<>();
        private final List<ValueEntry> visibleEntries = new ArrayList<>();

        private double scrollAmount = 0.0;
        private double targetScroll = 0.0;
        private static final int ROW_GAP = 4;

        private boolean draggingScrollbar = false;
        private int dragThumbOffsetY = 0;

        private ValueEntry focusedEntry = null;

        public ConfigPanel(int x, int y, int width, int height) {
            super(x, y, width, height, class_2561.method_43473());
        }

        public void tickPanel() {
            for (ValueEntry valueEntry : this.visibleEntries) {
                if (valueEntry.valueWidget instanceof class_342 box) {
                    box.method_1865();
                }

            }

        }

        public void addConfigEntry(Field field, ConfigEntry meta) {
            ValueEntry entry = new ValueEntry(field, meta);
            this.allEntries.add(entry);
            this.visibleEntries.add(entry);

            recalcLayout();
        }

        public void applySearch(String query) {
            this.visibleEntries.clear();

            ValueEntry prevFocused = this.focusedEntry;
            this.focusedEntry = null;

            if (query == null || query.isBlank()) {
                this.visibleEntries.addAll(this.allEntries);
            }
            else {
                String queryLowerCase = query.toLowerCase();
                for (ValueEntry valueEntry : this.allEntries) {
                    if (valueEntry.matches(queryLowerCase)) {
                        this.visibleEntries.add(valueEntry);
                    }
                }

            }

            if (prevFocused != null && this.visibleEntries.contains(prevFocused)) {
                this.focusedEntry = prevFocused;
                this.focusedEntry.setFocused(true);
            }
            else if (prevFocused != null) {
                prevFocused.setFocused(false);
            }

            recalcLayout();
        }

        public void applyToFields() {
            for (ValueEntry entry : this.allEntries) {
                entry.applyToField();
            }
        }

        private int getContentWidth() {
            return this.field_22758 - 20;
        }

        private int getRowLeft() {
            return this.method_46426() + 10;
        }

        private void recalcLayout() {
            int rowWidth = getContentWidth();
            for (ValueEntry e : this.visibleEntries) {
                e.recalculateHeight(rowWidth);
            }
            clampScroll();
        }

        private int getTotalContentHeight() {
            int total = 4;
            boolean first = true;
            for (ValueEntry e : this.visibleEntries) {
                if (!first) {
                    total += ROW_GAP;
                }

                total += e.getHeight();
                first = false;
            }

            return total;
        }

        private void clampScroll() {
            int innerHeight = this.field_22759;
            int contentHeight = getTotalContentHeight();
            if (contentHeight <= innerHeight) {
                scrollAmount = 0.0;
                targetScroll = 0.0;
            }
            else {
                if (targetScroll < 0.0) {
                    targetScroll = 0.0;
                }

                double maxScroll = contentHeight - innerHeight;
                if (targetScroll > maxScroll) {
                    targetScroll = maxScroll;
                }

                if (scrollAmount < 0.0) {
                    scrollAmount = 0.0;
                }
                if (scrollAmount > maxScroll) {
                    scrollAmount = maxScroll;
                }

            }

        }

        private boolean isInside(double mouseX, double mouseY) {
            return mouseX >= this.method_46426() && mouseX <= this.method_46426() + this.field_22758 && mouseY >= this.method_46427() && mouseY <= this.method_46427() + this.field_22759;
        }

        private boolean hasScrollableContent() {
            return getTotalContentHeight() > this.field_22759;
        }

        private ScrollbarGeom getScrollbarGeom() {
            int contentHeight = getTotalContentHeight();
            int left = this.method_46426();
            int top = this.method_46427();
            int right = left + this.field_22758;

            int barWidth = 6;
            int trackX0 = right - barWidth;
            int trackX1 = right;

            double maxScroll = Math.max(0.0, contentHeight - this.field_22759);
            double scrollRatio = (maxScroll <= 0.0) ? 0.0 : (scrollAmount / maxScroll);
            double visibleRatio = (double) this.field_22759 / (double) contentHeight;

            int thumbH = (int) (this.field_22759 * visibleRatio);
            if (thumbH < 24) {
                thumbH = 24;
            }
            if (thumbH > this.field_22759) {
                thumbH = this.field_22759;
            }

            int thumbY = top + (int) ((this.field_22759 - thumbH) * scrollRatio);

            return new ScrollbarGeom(trackX0, trackX1, top, top + this.field_22759, thumbY, thumbY + thumbH, thumbH, maxScroll);
        }

        @Override
        protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
            if (!this.field_22764) {
                return;
            }

            if (!draggingScrollbar && scrollAmount != targetScroll) {
                double diff = targetScroll - scrollAmount;
                if (Math.abs(diff) < 0.5) {
                    scrollAmount = targetScroll;
                }
                else {
                    scrollAmount += diff * 0.2;
                }

                clampScroll();
            }

            int left = this.method_46426();
            int top = this.method_46427();
            int right = left + this.field_22758;
            int bottom = top + this.field_22759;

            guiGraphics.method_25294(left, top, right, bottom, 0xFF111111);

            guiGraphics.method_44379(left, top, right, bottom);

            int rowLeft = getRowLeft();
            int rowWidth = getContentWidth();
            int currentY = top + 4 - (int) scrollAmount;

            int index = 0;
            boolean first = true;
            for (ValueEntry valueEntry : this.visibleEntries) {
                int rowHeight = valueEntry.getHeight();
                if (!first) {
                    currentY += ROW_GAP;
                }

                int rowTop = currentY;
                int rowBottom = rowTop + rowHeight;

                if (rowBottom >= top && rowTop <= bottom) {
                    boolean mouseInPanel = mouseX >= left && mouseX <= right && mouseY >= top && mouseY <= bottom;
                    boolean hovered = mouseInPanel && mouseX >= rowLeft && mouseX <= rowLeft + rowWidth && mouseY >= rowTop && mouseY <= rowBottom;

                    valueEntry.render(guiGraphics, index, rowTop, rowLeft, rowWidth, rowHeight, mouseX, mouseY, hovered, partialTick);
                }

                currentY += rowHeight;
                index++;
                first = false;
            }

            guiGraphics.method_44380();

            renderScrollbar(guiGraphics);
        }

        private void renderScrollbar(class_332 guiGraphics) {
            if (!hasScrollableContent()) {
                return;
            }

            ScrollbarGeom scrollbarGeom = getScrollbarGeom();

            // The line itself
            guiGraphics.method_25294(scrollbarGeom.trackX0, scrollbarGeom.trackTop, scrollbarGeom.trackX1, scrollbarGeom.trackBottom, 0x80000000);

            // Thumb
            guiGraphics.method_25294(scrollbarGeom.trackX0, scrollbarGeom.thumbTop, scrollbarGeom.trackX1, scrollbarGeom.thumbBottom, 0xFF4A9EFF);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double delta) {
            if (!this.field_22764) {
                return false;
            }
            if (!isInside(mouseX, mouseY)) {
                return false;
            }
            if (!hasScrollableContent()) {
                return false;
            }

            draggingScrollbar = false;

            this.targetScroll -= delta * 20.0;
            clampScroll();

            return true;
        }

        private void clearFocus() {
            if (this.focusedEntry != null) {
                this.focusedEntry.setFocused(false);
                this.focusedEntry = null;
            }

        }

        private void setFocus(ValueEntry entry) {
            if (this.focusedEntry == entry) {
                return;
            }

            if (this.focusedEntry != null) {
                this.focusedEntry.setFocused(false);
            }

            this.focusedEntry = entry;
            if (this.focusedEntry != null) {
                this.focusedEntry.setFocused(true);
            }

        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (!this.field_22764 || !this.field_22763) {
                return false;
            }
            if (!isInside(mouseX, mouseY)) {
                return false;
            }

            if (hasScrollableContent()) {
                ScrollbarGeom scrollbarGeom = getScrollbarGeom();

                if (mouseX >= scrollbarGeom.trackX0 && mouseX <= scrollbarGeom.trackX1) {
                    if (mouseY >= scrollbarGeom.thumbTop && mouseY <= scrollbarGeom.thumbBottom) {
                        draggingScrollbar = true;
                        dragThumbOffsetY = (int) mouseY - scrollbarGeom.thumbTop;
                        return true;
                    }
                    else {
                        double time = (mouseY - scrollbarGeom.trackTop) / (double) (scrollbarGeom.trackBottom - scrollbarGeom.trackTop);
                        time = Math.max(0.0, Math.min(1.0, time));

                        double desired = time * scrollbarGeom.maxScroll - (this.field_22759 * 0.5);
                        this.targetScroll = Math.max(0.0, Math.min(scrollbarGeom.maxScroll, desired));

                        this.scrollAmount = this.targetScroll;
                        clampScroll();

                        return true;
                    }

                }

            }

            int top = this.method_46427();

            int rowLeft = getRowLeft();
            int rowWidth = getContentWidth();
            int currentY = top + 4 - (int) scrollAmount;

            boolean first = true;
            for (ValueEntry entry : this.visibleEntries) {
                int rowHeight = entry.getHeight();
                if (!first) {
                    currentY += ROW_GAP;
                }

                int rowTop = currentY;
                int rowBottom = rowTop + rowHeight;

                if (mouseY >= rowTop && mouseY <= rowBottom && mouseX >= rowLeft && mouseX <= rowLeft + rowWidth) {
                    if (entry.mouseClicked(mouseX, mouseY, button)) {
                        setFocus(entry);
                        return true;
                    }

                    clearFocus();

                    return true;
                }

                currentY += rowHeight;
                first = false;
            }

            clearFocus();

            return false;
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            if (!this.field_22764 || !this.field_22763) {
                return false;
            }

            if (draggingScrollbar && hasScrollableContent()) {
                ScrollbarGeom scrollbarGeom = getScrollbarGeom();

                int trackSpan = (scrollbarGeom.trackBottom - scrollbarGeom.trackTop) - scrollbarGeom.thumbHeight;
                if (trackSpan <= 0) {
                    return true;
                }

                int desiredThumbTop = (int) mouseY - dragThumbOffsetY;
                int minThumbTop = scrollbarGeom.trackTop;
                int maxThumbTop = scrollbarGeom.trackBottom - scrollbarGeom.thumbHeight;

                desiredThumbTop = Math.max(minThumbTop, Math.min(maxThumbTop, desiredThumbTop));
                double t = (desiredThumbTop - minThumbTop) / (double) (maxThumbTop - minThumbTop);

                this.targetScroll = t * scrollbarGeom.maxScroll;
                this.scrollAmount = this.targetScroll;

                clampScroll();

                return true;
            }

            if (this.focusedEntry != null) {
                if (this.focusedEntry.mouseDragged(mouseX, mouseY, button, dragX, dragY)) {
                    return true;
                }

            }

            return false;
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            if (draggingScrollbar) {
                draggingScrollbar = false;
                return true;
            }

            if (this.focusedEntry != null) {
                return this.focusedEntry.mouseReleased(mouseX, mouseY, button);
            }

            return false;
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (this.focusedEntry != null && this.focusedEntry.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }

            return super.method_25404(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean method_25400(char codePoint, int modifiers) {
            if (this.focusedEntry != null && this.focusedEntry.charTyped(codePoint, modifiers)) {
                return true;
            }

            return super.method_25400(codePoint, modifiers);
        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

        private record ScrollbarGeom(int trackX0, int trackX1, int trackTop, int trackBottom, int thumbTop, int thumbBottom, int thumbHeight, double maxScroll) { ;; }

        private static class ValueEntry {

            private final Field field;
            private final class_2561 label;
            private final String commentText;
            private final class_339 valueWidget;
            private final boolean colorField;
            private final String searchIndex;

            private float hoverProgress = 0f;
            private int height = 40;

            private final Random particleRng;
            private final ArrayList<HoverParticle> hoverParticles = new ArrayList<>();
            private long lastParticleSpawnMs = 0L;
            private long lastParticleUpdateMs = 0L;

            private static final int PARTICLE_CAP = 22;

            private static class HoverParticle {
                float x;
                float y;
                float vx;
                float baseY;
                float amp;
                float freq;
                float phase;
                float size;
                int red;
                int green;
                int blue;
                float lifeMs;
                float ageMs;

                HoverParticle(float x, float y, float vx, float baseY, float amp, float freq, float phase, float size, int red, int green, int blue, float lifeMs) {
                    this.x = x; this.y = y;
                    this.vx = vx;
                    this.baseY = baseY;
                    this.amp = amp;
                    this.freq = freq;
                    this.phase = phase;
                    this.size = size;
                    this.red = red;
                    this.green = green;
                    this.blue = blue;
                    this.lifeMs = lifeMs;
                    this.ageMs = 0f;
                }

            }

            public ValueEntry(Field field, ConfigEntry meta) {
                this.field = field;

                this.colorField = isColorField(field, meta);

                String prettyLabel = buildLabel(meta, field.getName());
                this.label = class_2561.method_43470(prettyLabel);

                this.commentText = meta.comment().trim();
                String raw = field.getName()
                        + " " + field.getName().replace('_', ' ')
                        + " " + prettyLabel
                        + " " + meta.category()
                        + " " + this.commentText;

                this.searchIndex = normalizeForSearch(raw);

                this.valueWidget = createWidget();

                int seed = (field.getName() + "|" + meta.category() + "|" + meta.note()).hashCode();
                this.particleRng = new Random(seed);

                this.lastParticleUpdateMs = System.currentTimeMillis();
            }

            public int getHeight() {
                return this.height;
            }

            public void setFocused(boolean focused) {
                this.valueWidget.method_25365(focused);
                if (this.valueWidget instanceof class_342 box) {
                    box.method_25365(focused);
                }

            }

            public void recalculateHeight(int rowWidth) {
                class_310 minecraft = class_310.method_1551();

                int PAD_TOP = 6;
                int LABEL_GAP = 3;
                int LINE_H = minecraft.field_1772.field_2000;

                int widgetW = this.valueWidget.method_25368();
                int labelXRelative = 8;
                int available = rowWidth - widgetW - 10 - labelXRelative - 16;
                int commentMaxWidth = Math.min(available, (int) (rowWidth * 0.45f));

                int commentLines = 0;
                if (!this.commentText.isEmpty() && commentMaxWidth > 40) {
                    commentLines = minecraft.field_1772.method_1728(class_2561.method_43470(this.commentText), commentMaxWidth).size();
                }

                int height = PAD_TOP + Math.max(this.valueWidget.method_25364(), LINE_H);

                if (commentLines > 0) {
                    height += LABEL_GAP + (commentLines * LINE_H);
                }

                this.height = height;
            }

            private static boolean isColorField(Field field, ConfigEntry meta) {
                String name = field.getName().toLowerCase();
                if (name.contains("color") || name.contains("colour") || name.contains("palette")) {
                    return true;
                }

                if (meta != null) {
                    String note = meta.note().toLowerCase();
                    String comment = meta.comment().toLowerCase();
                    if (note.contains("color") || note.contains("colour") || note.contains("hex") || comment.contains("color") || comment.contains("palette") || comment.contains("argb")) {
                        return true;
                    }

                }

                return false;
            }

            private static String buildLabel(ConfigEntry meta, String fieldName) {
                String prettyName = prettifyName(fieldName);
                String category = meta.category().trim();
                if (!category.isEmpty()) {
                    String catPretty = prettifyName(category);
                    return catPretty + " › " + prettyName;
                }

                return prettyName;
            }

            private static String prettifyName(String name) {
                String lower = name.toLowerCase().replace('$', ' ').replace('_', ' ');
                String[] parts = lower.split("\\s+");
                StringBuilder out = new StringBuilder();
                for (String part : parts) {
                    if (part.isEmpty()) {
                        continue;
                    }
                    if (out.length() > 0) {
                        out.append(' ');
                    }

                    out.append(Character.toUpperCase(part.charAt(0)));
                    if (part.length() > 1) {
                        out.append(part.substring(1));
                    }

                }

                return out.toString();
            }

            private class_339 createWidget() {
                class_310 minecraft = class_310.method_1551();
                Class<?> type = field.getType();
                try {
                    if (type == boolean.class) {
                        boolean value = field.getBoolean(null);
                        return new ModernCheckbox(0, 0, 20, 20, class_2561.method_43473(), value);
                    }

                    if (type == int.class && this.colorField) {
                        int value = field.getInt(null);

                        class_342 box = new ModernEditBox(minecraft.field_1772, 0, 0, 100, 20, class_2561.method_43473());
                        box.method_1880(64);
                        box.method_1852(formatColor(value));

                        return box;
                    }

                    String value = String.valueOf(field.get(null));
                    boolean isMultiColor = type == String.class && value.contains(",") && (value.contains("0x") || value.contains("#"));

                    int boxWidth = isMultiColor ? 260 : 180;

                    class_342 box = new ModernEditBox(minecraft.field_1772, 0, 0, boxWidth, 20, class_2561.method_43473());
                    box.method_1880(512);
                    box.method_1852(value);

                    return box;
                }
                catch (Exception expection) {
                    class_342 box = new ModernEditBox(class_310.method_1551().field_1772, 0, 0, 180, 20, class_2561.method_43473());
                    box.method_1880(512);
                    box.method_1852("");

                    return box;
                }

            }

            private static String formatColor(int argb) {
                return String.format("#%08X", argb);
            }

            public boolean matches(String query) {
                String normalizedQuery = normalizeForSearch(query);
                if (normalizedQuery.isEmpty()) {
                    return true;
                }

                for (String token : normalizedQuery.split(" ")) {
                    if (token.isEmpty()) {
                        continue;
                    }
                    if (!this.searchIndex.contains(token)) {
                        return false;
                    }

                }

                return true;
            }

            private static String normalizeForSearch(String string) {
                if (string == null) {
                    return "";
                }

                String out = string.toLowerCase();
                out = out.replace('_', ' ')
                        .replace('-', ' ')
                        .replace('.', ' ')
                        .replace('/', ' ');

                out = out.trim().replaceAll("\\s+", " ");

                return out;
            }


            public boolean mouseClicked(double mouseX, double mouseY, int button) {
                return this.valueWidget.method_25402(mouseX, mouseY, button);
            }

            public boolean mouseReleased(double mouseX, double mouseY, int button) {
                return this.valueWidget.method_25406(mouseX, mouseY, button);
            }

            public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
                return this.valueWidget.method_25403(mouseX, mouseY, button, dragX, dragY);
            }

            public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
                return this.valueWidget.method_25404(keyCode, scanCode, modifiers);
            }

            public boolean charTyped(char codePoint, int modifiers) {
                return this.valueWidget.method_25400(codePoint, modifiers);
            }

            public void applyToField() {
                try {
                    Class<?> type = field.getType();

                    if (type == boolean.class) {
                        if (this.valueWidget instanceof class_4286 cb) {
                            field.setBoolean(null, cb.method_20372());
                        }

                        return;
                    }

                    if (!(this.valueWidget instanceof class_342 box)) {
                        return;
                    }

                    String raw = box.method_1882();
                    String trimmed = raw.trim();

                    if (type == String.class) {
                        field.set(null, raw);
                        return;
                    }

                    if (trimmed.isEmpty()) {
                        return;
                    }

                    if (type == int.class) {
                        int current = field.getInt(null);
                        int value = this.colorField ? parseColorInt(trimmed, current) : parseIntFlexible(trimmed, current);

                        field.setInt(null, value);
                    }
                    else if (type == long.class) {
                        long current = field.getLong(null);
                        long value = parseLongFlexible(trimmed, current);

                        field.setLong(null, value);
                    }
                    else if (type == float.class) {
                        try {
                            field.setFloat(null, Float.parseFloat(trimmed));
                        }
                        catch (NumberFormatException ignored) {
                            ;;
                        }
                    }
                    else if (type == double.class) {
                        try {
                            field.setDouble(null, Double.parseDouble(trimmed));
                        }
                        catch (NumberFormatException ignored) {
                            ;;
                        }

                    }

                }
                catch (Exception ignored) {
                    ;;
                }

            }

            private static int parseIntFlexible(String text, int fallback) {
                try {
                    String string = text.trim();
                    if (string.startsWith("0x") || string.startsWith("0X") || string.startsWith("#")) {
                        if (string.startsWith("#")) {
                            string = "0x" + string.substring(1);
                        }

                        return Integer.decode(string);
                    }

                    return Integer.parseInt(string);
                }
                catch (Exception ignored) {
                    return fallback;
                }

            }

            private static long parseLongFlexible(String txt, long fallback) {
                try {
                    String string = txt.trim();
                    if (string.startsWith("0x") || string.startsWith("0X") || string.startsWith("#")) {
                        if (string.startsWith("#")) {
                            string = "0x" + string.substring(1);
                        }

                        return Long.decode(string);
                    }

                    return Long.parseLong(string);
                }
                catch (Exception ignored) {
                    return fallback;
                }

            }

            private static int parseColorInt(String txt, int fallback) {
                try {
                    String string = txt.trim();
                    if (string.isEmpty()) {
                        return fallback;
                    }

                    if (string.startsWith("#")) {
                        string = string.substring(1);
                    }
                    if (string.startsWith("0x") || string.startsWith("0X")) {
                        string = string.substring(2);
                    }

                    if (string.length() == 6) {
                        long rgb = Long.parseLong(string, 16) & 0xFFFFFFL;
                        long argb = 0xFF000000L | rgb;

                        return (int) argb;
                    }

                    long argb = Long.parseLong(string, 16);
                    return (int) argb;
                }
                catch (Exception ignored) {
                    return fallback;
                }

            }

            public void render(class_332 guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovered, float partialTick) {
                class_310 minecraft = class_310.method_1551();

                float step = 0.1f;
                hoverProgress = hovered ? Math.min(1.0f, hoverProgress + step) : Math.max(0.0f, hoverProgress - step);

                int baseAlpha = (index % 2 == 0) ? 0x28 : 0x20;
                int extraAlpha = (int) (0x30 * hoverProgress);
                int totalAlpha = Math.min(255, baseAlpha + extraAlpha);
                int bgColor = (totalAlpha << 24) | 0x353535;
                guiGraphics.method_25294(left, top, left + width, top + height, bgColor);

                int gradientWidth = Math.min(120, width / 3);
                if (hoverProgress > 0f) {
                    int maxAlpha = (int) (0x40 * hoverProgress);

                    for (int x = 0; x < gradientWidth; x++) {
                        float t = (float) x / (float) gradientWidth;
                        int a = (int) (maxAlpha * (1.0f - t));
                        if (a <= 0) continue;

                        int color = (a << 24) | 0x4A9EFF;
                        int x1 = left + x;
                        guiGraphics.method_25294(x1, top, x1 + 1, top + height, color);
                    }

                }

                int baseBorderWidth = 2;
                int extraBorder = Math.round(hoverProgress * 2.0f);
                int borderWidth = baseBorderWidth + extraBorder;

                int idleColor = 0x40FFFFFF;
                int hoverColor = 0xFF4A9EFF;
                int borderColor = (hoverProgress > 0f) ? hoverColor : idleColor;
                guiGraphics.method_25294(left, top, left + borderWidth, top + height, borderColor);

                guiGraphics.method_25294(left, top + height - 1, left + width, top + height, 0x20000000);

                updateHoverParticles(top, height);
                if (hoverProgress > 0.15f) {
                    spawnHoverParticles(left, top, width, height, borderWidth, gradientWidth, hoverProgress);
                }

                renderHoverParticles(guiGraphics, hoverProgress);

                int labelX = left + 8;
                int labelY = top + 6;

                guiGraphics.method_51439(minecraft.field_1772, this.label, labelX + 1, labelY + 1, 0x80000000, false);
                guiGraphics.method_51439(minecraft.field_1772, this.label, labelX, labelY, 0xFFFFFFFF, false);

                int widgetWidth = this.valueWidget.method_25368();
                int widgetHeight = this.valueWidget.method_25364();
                int widgetX = left + width - widgetWidth - 10;
                int widgetY = top + (height - widgetHeight) / 2;

                this.valueWidget.method_46421(widgetX);
                this.valueWidget.method_46419(widgetY);

                if (this.colorField && field.getType() == int.class) {
                    try {
                        int color = field.getInt(null);
                        int previewSize = 18;
                        int previewRight = widgetX - 8;
                        int previewLeft = previewRight - previewSize;
                        int previewTop = top + (height - previewSize) / 2;

                        drawCheckerboard(guiGraphics, previewLeft, previewTop, previewSize, previewSize);
                        guiGraphics.method_25294(previewLeft, previewTop, previewRight, previewTop + previewSize, color);

                        guiGraphics.method_25294(previewLeft - 1, previewTop - 1, previewRight + 1, previewTop, 0xFF606060);
                        guiGraphics.method_25294(previewLeft - 1, previewTop + previewSize, previewRight + 1, previewTop + previewSize + 1, 0xFF303030);
                        guiGraphics.method_25294(previewLeft - 1, previewTop - 1, previewLeft, previewTop + previewSize + 1, 0xFF606060);
                        guiGraphics.method_25294(previewRight, previewTop - 1, previewRight + 1, previewTop + previewSize + 1, 0xFF303030);
                    }
                    catch (IllegalAccessException ignored) {
                        ;;
                    }

                }

                this.valueWidget.method_25394(guiGraphics, mouseX, mouseY, partialTick);

                if (this.valueWidget instanceof class_342 box) {
                    renderInlineColorBars(guiGraphics, box);
                }

                // Description
                if (!this.commentText.isEmpty()) {
                    int available = widgetX - labelX - 16;
                    int commentMaxWidth = Math.min(available, (int) (width * 0.45f));

                    if (commentMaxWidth > 40) {
                        int lineHeight = minecraft.field_1772.field_2000;
                        int commentY = labelY + minecraft.field_1772.field_2000 + 3;

                        List<class_5481> lines = minecraft.field_1772.method_1728(class_2561.method_43470(this.commentText), commentMaxWidth);
                        int availableHeight = (top + height) - commentY;
                        int maxLines = Math.max(1, availableHeight / lineHeight);

                        int drawn = 0;
                        for (class_5481 line : lines) {
                            if (drawn >= maxLines) {
                                break;
                            }

                            guiGraphics.method_51430(minecraft.field_1772, line, labelX, commentY, 0xFFA0A0A0, false);
                            commentY += lineHeight;

                            drawn++;
                        }

                    }

                }

            }

            private static List<Integer> extractColorsFromText(String text) {
                if (text == null) {
                    return Collections.emptyList();
                }

                String string = text.trim();
                if (string.isEmpty()) {
                    return Collections.emptyList();
                }

                ArrayList<Integer> out = new ArrayList<>();

                Pattern prefixed = Pattern.compile("(?:#|0x|0X)([0-9a-fA-F]{8}|[0-9a-fA-F]{6})");
                Matcher matcher = prefixed.matcher(string);
                while (matcher.find()) {
                    String hex = matcher.group(1);
                    Integer color = parseHexColorToken(hex);

                    if (color != null) {
                        out.add(color);
                    }

                }

                if (out.isEmpty()) {
                    Pattern bare = Pattern.compile("(?<![0-9a-fA-F])([0-9a-fA-F]{8}|[0-9a-fA-F]{6})(?![0-9a-fA-F])");
                    Matcher matcher2 = bare.matcher(string);
                    while (matcher2.find()) {
                        String token = matcher2.group(1);
                        boolean hasLetter = token.chars().anyMatch(ch -> (ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f'));
                        if (!hasLetter) {
                            continue;
                        }

                        Integer color = parseHexColorToken(token);
                        if (color != null) {
                            out.add(color);
                        }

                    }

                }

                return out;
            }

            private static Integer parseHexColorToken(String hex) {
                try {
                    if (hex.length() == 6) {
                        int rgb = (int) (Long.parseLong(hex, 16) & 0xFFFFFFL);
                        return 0xFF000000 | rgb;
                    }
                    if (hex.length() == 8) {
                        return (int) (Long.parseLong(hex, 16) & 0xFFFFFFFFL);
                    }

                    return null;
                }
                catch (Exception ignored) {
                    return null;
                }

            }

            private void renderInlineColorBars(class_332 g, class_342 box) {
                List<Integer> colors = extractColorsFromText(box.method_1882());
                if (colors.isEmpty()) {
                    return;
                }

                int max = Math.min(colors.size(), 8);

                int bx = box.method_46426();
                int by = box.method_46427();
                int bw = box.method_25368();
                int bh = box.method_25364();

                int padRight = 3;
                int padY = 3;

                int barW = 4;
                int gap = 2;

                int stripW = max * barW + (max - 1) * gap;

                int x1 = bx + bw - padRight;
                int x0 = x1 - stripW;

                int y0 = by + padY;
                int y1 = by + bh - padY;

                for (int i = 0; i < max; i++) {
                    int c = colors.get(i);

                    int px0 = x0 + i * (barW + gap);
                    int px1 = px0 + barW;

                    drawMiniChecker(g, px0, y0, barW, (y1 - y0));

                    g.method_25294(px0, y0, px1, y1, c);
                }

            }

            private void drawMiniChecker(class_332 graphics, int x, int y, int w, int h) {
                int cs = 2;
                for (int yy = 0; yy < h; yy += cs) {
                    for (int xx = 0; xx < w; xx += cs) {
                        boolean light = ((xx / cs) + (yy / cs)) % 2 == 0;

                        int col = light ? 0xFFB0B0B0 : 0xFF7A7A7A;
                        int dx = Math.min(cs, w - xx);
                        int dy = Math.min(cs, h - yy);

                        graphics.method_25294(x + xx, y + yy, x + xx + dx, y + yy + dy, col);
                    }
                }

            }

            private void updateHoverParticles(int rowTop, int rowHeight) {
                long now = System.currentTimeMillis();
                long timeMs = Math.min(33L, Math.max(0L, now - lastParticleUpdateMs));
                lastParticleUpdateMs = now;

                float dateTime = (float) timeMs;

                for (int i = hoverParticles.size() - 1; i >= 0; i--) {
                    HoverParticle particle = hoverParticles.get(i);
                    particle.ageMs += dateTime;

                    particle.x += particle.vx * dateTime;

                    particle.y = particle.baseY + (float) Math.sin(particle.phase + particle.ageMs * particle.freq) * particle.amp;

                    if (particle.ageMs >= particle.lifeMs) {
                        hoverParticles.remove(i);

                        continue;
                    }

                    if (particle.y < rowTop - 6 || particle.y > rowTop + rowHeight + 6) {
                        hoverParticles.remove(i);
                    }

                }

            }

            private void spawnHoverParticles(int left, int top, int width, int height, int borderW, int gradientW, float hoverProgress) {
                long now = System.currentTimeMillis();

                int minInterval = 35;
                int maxInterval = 85;
                int interval = (int) (maxInterval - (maxInterval - minInterval) * hoverProgress);

                if (now - lastParticleSpawnMs < interval) {
                    return;
                }

                lastParticleSpawnMs = now;

                if (hoverParticles.size() >= PARTICLE_CAP) {
                    return;
                }

                int count = (hoverProgress > 0.6f && particleRng.nextFloat() < 0.55f) ? 2 : 1;

                for (int n = 0; n < count && hoverParticles.size() < PARTICLE_CAP; n++) {
                    float spawnX = left + borderW - 1 + particleRng.nextFloat() * 2.0f;
                    float spawnY = top + 6 + particleRng.nextFloat() * (height - 12);

                    float vx = (0.02f + particleRng.nextFloat() * 0.045f);

                    float amp  = 0.6f + particleRng.nextFloat() * 1.2f;
                    float frequency = 0.010f + particleRng.nextFloat() * 0.010f;
                    float phase = particleRng.nextFloat() * 6.28318f;

                    float size = 1.0f + particleRng.nextFloat() * 1.2f;
                    float life = 420f + particleRng.nextFloat() * 360f;

                    boolean white = particleRng.nextFloat() < 0.28f;
                    int red;
                    int green;
                    int blue;
                    if (white) {
                        red = 235;
                        green = 245;
                        blue = 255;
                        vx *= 1.08f;
                    }
                    else {
                        red = 0x4A; green = 0x9E; blue = 0xFF;
                    }

                    hoverParticles.add(new HoverParticle(spawnX, spawnY, vx, spawnY, amp, frequency, phase, size, red, green, blue, life));
                }

            }

            private void renderHoverParticles(class_332 graphics, float hoverProgress) {
                if (hoverParticles.isEmpty()) {
                    return;
                }

                float intensity = Math.min(1.0f, 0.65f + hoverProgress * 0.55f);

                for (HoverParticle particle : hoverParticles) {
                    float time = particle.ageMs / particle.lifeMs;
                    float fade = 1.0f - time;
                    fade = fade * fade;

                    int alpha = (int) (fade * 190f * intensity);
                    if (alpha <= 2) {
                        continue;
                    }

                    int color = (alpha << 24) | (particle.red << 16) | (particle.green << 8) | particle.blue;

                    int x0 = (int) particle.x;
                    int y0 = (int) particle.y;
                    int size = Math.max(1, (int) (particle.size));

                    graphics.method_25294(x0, y0, x0 + size, y0 + size, color);

                    int trailA = alpha / 3;
                    if (trailA > 0) {
                        int trail = (trailA << 24) | (particle.red << 16) | (particle.green << 8) | particle.blue;
                        graphics.method_25294(x0 - 1, y0, x0, y0 + size, trail);
                    }
                }

            }

            private void drawCheckerboard(class_332 graphics, int x, int y, int width, int height) {
                int checkerSize = 4;
                for (int cy = 0; cy < height; cy += checkerSize) {
                    for (int cx = 0; cx < width; cx += checkerSize) {
                        boolean isLight = ((cx / checkerSize) + (cy / checkerSize)) % 2 == 0;

                        int color = isLight ? 0xFFCCCCCC : 0xFF999999;
                        int drawWidth = Math.min(checkerSize, width - cx);
                        int drawHeight = Math.min(checkerSize, height - cy);

                        graphics.method_25294(x + cx, y + cy, x + cx + drawWidth, y + cy + drawHeight, color);
                    }

                }

            }

        }

        private static class ModernCheckbox extends class_4286 {

            public ModernCheckbox(int x, int y, int w, int h, class_2561 msg, boolean selected) {
                super(x, y, w, h, msg, selected);
            }

            @Override
            public void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
                boolean hovered = this.method_25367();

                int x0 = this.method_46426();
                int y0 = this.method_46427();
                int x1 = x0 + this.method_25368();
                int y1 = y0 + this.method_25364();

                int backgroundColor = 0xFF181818;
                g.method_25294(x0, y0, x1, y1, backgroundColor);

                int border = hovered ? 0xFF4A9EFF : 0xFF3A3A3A;
                g.method_25294(x0, y0, x1, y0 + 1, border);
                g.method_25294(x0, y1 - 1, x1, y1, border);
                g.method_25294(x0, y0, x0 + 1, y1, border);
                g.method_25294(x1 - 1, y0, x1, y1, border);

                if (this.method_20372()) {
                    int inset = 4;
                    int inner = 0xFF4A9EFF;
                    g.method_25294(x0 + inset, y0 + inset, x1 - inset, y1 - inset, inner);
                }
            }

        }

        private static class ModernEditBox extends class_342 {

            private float animationProgress = 0f;

            public ModernEditBox(net.minecraft.class_327 font, int x, int y, int w, int h, class_2561 msg) {
                super(font, x, y, w, h, msg);

                this.method_1858(false);
                this.method_1868(0xFFE8E8E8);
                this.method_1860(0xFF777777);
                this.method_1880(512);
            }

            @Override
            public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
                int x0 = this.method_46426();
                int y0 = this.method_46427();
                int x1 = x0 + this.method_25368();
                int y1 = y0 + this.method_25364();

                boolean hovered = mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1;
                boolean active = hovered || this.method_25370();

                float step = 0.16f;
                animationProgress = active ? Math.min(1f, animationProgress + step) : Math.max(0f, animationProgress - step);

                graphics.method_25294(x0, y0, x1, y1, 0xFF161616);
                graphics.method_25294(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 0xFF1E1E1E);

                int borderIdle = 0xFF3A3A3A;
                int borderFocus = 0xFF4A9EFF;
                int border = (animationProgress > 0f) ? borderFocus : borderIdle;

                graphics.method_25294(x0, y0, x1, y0 + 1, border);
                graphics.method_25294(x0, y1 - 1, x1, y1, border);
                graphics.method_25294(x0, y0, x0 + 1, y1, border);
                graphics.method_25294(x1 - 1, y0, x1, y1, border);

                int lh = class_310.method_1551().field_1772.field_2000;
                int offY = Math.max(0, (this.field_22759 - lh) / 2);
                int padX = 6;

                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(padX, offY + 1, 0);

                super.method_48579(graphics, mouseX - padX, mouseY - offY, partialTick);

                graphics.method_51448().method_22909();
            }

        }

        static class ModernButton extends class_4185 {

            private float animationProgress = 0f;

            public ModernButton(int x, int y, int w, int h, class_2561 msg, class_4241 onPress) {
                super(x, y, w, h, msg, onPress, class_4185.field_40754);
            }

            @Override
            public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
                int x0 = this.method_46426();
                int y0 = this.method_46427();
                int x1 = x0 + this.method_25368();
                int y1 = y0 + this.method_25364();

                boolean hovered = mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1;
                boolean active = hovered || this.method_25370();

                float step = 0.16f;
                animationProgress = active ? Math.min(1f, animationProgress + step) : Math.max(0f, animationProgress - step);

                int backgroundOuter = 0xFF141414;
                int backgroundInner = hovered ? 0xFF1E1E1E : 0xFF191919;

                graphics.method_25294(x0, y0, x1, y1, backgroundOuter);
                graphics.method_25294(x0 + 1, y0 + 1, x1 - 1, y1 - 1, backgroundInner);

                int baseBorder = 2;
                int extraBorder = Math.round(animationProgress * 2.0f);
                int borderW = baseBorder + extraBorder;

                int idleBorder = 0x40FFFFFF;
                int hoverBorder = 0xFF4A9EFF;
                int borderColor = (animationProgress > 0f) ? hoverBorder : idleBorder;

                graphics.method_25294(x0, y0, x0 + borderW, y1, borderColor);

                if (animationProgress > 0f) {
                    int gradientW = Math.min(90, this.method_25368() / 3);
                    int maxA = (int) (0x40 * animationProgress);

                    for (int x = 0; x < gradientW; x++) {
                        float time = (float) x / (float) gradientW;
                        int alpha = (int) (maxA * (1.0f - time));
                        if (alpha <= 0) {
                            continue;
                        }

                        int color = (alpha << 24) | 0x4A9EFF;
                        graphics.method_25294(x0 + x, y0, x0 + x + 1, y1, color);
                    }

                }

                int outline = hovered ? 0xFF2E2E2E : 0xFF242424;
                graphics.method_25294(x0, y0, x1, y0 + 1, outline);
                graphics.method_25294(x0, y1 - 1, x1, y1, outline);
                graphics.method_25294(x0, y0, x0 + 1, y1, outline);
                graphics.method_25294(x1 - 1, y0, x1, y1, outline);

                int txt = this.field_22763 ? 0xFFE8E8E8 : 0xFF777777;
                int ty = y0 + (this.field_22759 - 8) / 2;

                graphics.method_27534(class_310.method_1551().field_1772, this.method_25369(), x0 + this.field_22758 / 2, ty, txt);
            }

        }

    }

    private static class CenteredEditBox extends class_342 {

        public CenteredEditBox(net.minecraft.class_327 font, int x, int y, int width, int height, class_2561 text) {
            super(font, x, y, width, height, text);
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            int leftHeight = class_310.method_1551().field_1772.field_2000;
            int offset = Math.max(0, (this.field_22759 - leftHeight) / 2);

            graphics.method_51448().method_22903();
            graphics.method_51448().method_46416(8, offset + 1, 0);

            super.method_48579(graphics, mouseX, mouseY - offset, partialTick);

            graphics.method_51448().method_22909();
        }

    }

}