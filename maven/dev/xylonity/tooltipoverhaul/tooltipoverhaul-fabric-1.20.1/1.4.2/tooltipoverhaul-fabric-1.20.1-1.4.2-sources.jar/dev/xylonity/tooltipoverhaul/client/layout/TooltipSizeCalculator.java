package dev.xylonity.tooltipoverhaul.client.layout;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5684;

public class TooltipSizeCalculator {

    private final TooltipContext context;

    public TooltipSizeCalculator(TooltipContext context) {
        this.context = context;
    }

    public class_241 calculate() {

        boolean hasIcon = context.hasIcon();
        boolean hasRating = RenderUtils.hasRating(context);
        boolean hasDividerLine = context.hasDividerLine();

        List<class_5684> components = context.getComponents();
        class_327 font = context.getFont();

        int paddingX = context.getPaddingX();
        int paddingY = context.getPaddingY();

        // Offset to the right if the icon is active
        int iconOffset = hasIcon ? (Constants.getIconSize(context) + Constants.getIconTitleSeparation(context)) : 0;

        // Computes approximated width and height using the component amount
        int width = components.get(0).method_32664(font) + paddingX * 2 + iconOffset;
        int height = components.get(0).method_32661() + paddingY * 2;
        for (int i = 0; i < components.size(); i++) {
            if (i > 0) {
                height += components.get(i).method_32661();
                width = Math.max(width, components.get(i).method_32664(font) + paddingX * 2);
            }

        }

        // Computes the new width if the rating is larger than the tooltip's width and adds extra height in case the icon is not present
        if (hasRating) {
            class_2561 rating = TextUtils.getRatingText(context);
            width = Math.max(width, font.method_27525(rating) + paddingX * 2 + iconOffset);

            if (!hasIcon) {
                height += class_5684.method_32662(rating.method_30937()).method_32661();
            }
        }

        // If the tooltip has an icon active, subtracts the title component height (which is approximately 10)
        if (hasIcon) {
            height += Constants.getIconSize(context) - 10;
        }

        //
        if (hasDividerLine && components.size() > 1) {
            if (hasIcon) {
                height += Constants.getDividerLineFullPadding(context);
            }
            else {
                height += Constants.getDividerLineFullPadding(context);
            }

        }

        return new class_241(width, height);
    }

    public class_241 adjustSize() {

        class_241 newSize = context.getTooltipSize();

        boolean isMainTooltip = context.isMainTooltip();
        TooltipContext otherContext = context.getOtherTooltipContext();

        class_241 otherContextPosition = otherContext != null ? otherContext.getTooltipPosition() : null;
        class_241 otherContextSize = otherContext != null ? otherContext.getTooltipSize() : null;

        if (isMainTooltip) {
            if (otherContextPosition != null && otherContextSize != null) {
                if (otherContextPosition.field_1343 == context.getPaddingX() && context.getTooltipPosition().field_1343 + context.getTooltipSize().field_1343 > context.getScreenWidth()) {
                    newSize = new class_241(context.getScreenWidth() - context.getPaddingX() - context.getTooltipPosition().field_1343, newSize.field_1342);
                }
            }

        }
        else {

        }

        return newSize;
    }

}
