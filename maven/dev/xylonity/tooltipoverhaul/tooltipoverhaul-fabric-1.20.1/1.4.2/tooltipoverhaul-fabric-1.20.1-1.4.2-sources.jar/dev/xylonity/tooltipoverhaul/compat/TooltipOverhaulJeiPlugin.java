package dev.xylonity.tooltipoverhaul.compat;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.compat.jei.JeiHoverHolder;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.class_2960;

@JeiPlugin
public final class TooltipOverhaulJeiPlugin implements IModPlugin {

    private static final class_2960 UID = new class_2960(TooltipOverhaul.MOD_ID, "jei_plugin");

    @Override
    public class_2960 getPluginUid() {
        return UID;
    }

    @Override
    public void onRuntimeAvailable(IJeiRuntime runtime) {
        JeiHoverHolder.init(runtime);
    }

}