package dev.xylonity.tooltipoverhaul.client.command;

import com.mojang.brigadier.CommandDispatcher;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class ReloadCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247(TooltipOverhaul.MOD_ID)
                        .then(class_2170.method_9247("reload")
                                .executes(context -> {
                                    try {
                                        TooltipOverhaul.LOGGER.info("Manual resources reload triggered by command");

                                        CustomFrameManager.reset();
                                        CustomFrameManager.initialize();

                                        context.getSource().method_9226(() -> class_2561.method_43471("tooltipoverhaul.reload_resources.success"), false);

                                        return 1;
                                    }
                                    catch (Exception e) {
                                        TooltipOverhaul.LOGGER.error("Failed to reload via command: {}", e.getMessage(), e);

                                        context.getSource().method_9213(class_2561.method_43471("tooltipoverhaul.reload_resources.fail"));

                                        return 0;
                                    }
                                })
                        )
        );

    }

}