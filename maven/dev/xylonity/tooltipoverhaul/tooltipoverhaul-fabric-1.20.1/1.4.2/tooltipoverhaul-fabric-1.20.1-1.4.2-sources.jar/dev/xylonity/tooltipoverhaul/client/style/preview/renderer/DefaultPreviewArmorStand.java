package dev.xylonity.tooltipoverhaul.client.style.preview.renderer;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewRendererLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import dev.xylonity.tooltipoverhaul.compat.modernfix.ModernFixCompat;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1531;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_7833;
import net.minecraft.class_898;

public class DefaultPreviewArmorStand implements PreviewRendererLayer {

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {

        int sizeX = RenderUtils.calculateSecondPanelSize(context, TextAxis.X);
        int sizeY = RenderUtils.calculateSecondPanelSize(context, TextAxis.Y);
        int y0 = (int) startPosition.field_1342;
        int x1 = (int) endPosition.field_1343;

        context.translate((x1 + sizeX / 2f + 2), (y0 + sizeY / 1.15f) + 2, 0);

        context.multiply(class_7833.field_40714, -30);
        context.multiply(class_7833.field_40716, -45);

        context.multiply(class_7833.field_40716, (((System.currentTimeMillis() - context.getStartTime()) / 20f) % 360) * AnimationUtils.getSecondPanelRendererSpeed(context));

        float scale = Math.min(sizeX, sizeY / 2f) / 1.25f;

        context.scale(-scale, -scale, scale);

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 != null && context.getStack().method_7909() instanceof class_1738 armorItem) {
            class_1531 armorStand = new class_1531(class_1299.field_6131, minecraft.field_1687);
            armorStand.method_6907(true);

            for (class_1304 equipmentSlot : class_1304.values()) {
                armorStand.method_5673(equipmentSlot, class_1799.field_8037);
            }
            armorStand.method_5673(armorItem.method_7685(), context.getStack());

            class_308.method_34742();
            class_898 renderer = class_310.method_1551().method_1561();
            renderer.method_3948(false);
            renderer.method_3954(armorStand, 0, 0, 0, 0, 1, context.getPose(), context.getBuffer(), 0xF000F0);
            renderer.method_3948(true);
        }

    }

}
