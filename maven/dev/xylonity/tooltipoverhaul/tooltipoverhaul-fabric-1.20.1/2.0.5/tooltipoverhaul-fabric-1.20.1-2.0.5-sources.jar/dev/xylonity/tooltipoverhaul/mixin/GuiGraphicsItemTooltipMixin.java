package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.util.TooltipLinesContext;
import dev.xylonity.tooltipoverhaul.compat.emi.EmiStackContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5632;

@Mixin(class_332.class)
public class GuiGraphicsItemTooltipMixin {

    @Inject(
            method = "renderTooltip(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;II)V",
            at = @At("HEAD")
    )
    private void tooltipoverhaul$captureStack(class_327 font, class_1799 stack, int mouseX, int mouseY, CallbackInfo ci) {
        EmiStackContext.set(stack);
    }

    @Inject(
            method = "renderTooltip(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;II)V",
            at = @At("RETURN")
    )
    private void tooltipoverhaul$clearStack(class_327 font, class_1799 stack, int mouseX, int mouseY, CallbackInfo ci) {
        EmiStackContext.clear();
    }

    @Inject(
            method = "renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V",
            at = @At("HEAD")
    )
    private void tooltipoverhaul$captureLinesStack(class_327 font, List<class_2561> lines, Optional<class_5632> image, int mouseX, int mouseY, CallbackInfo ci) {
        TooltipLinesContext.begin(lines);
    }

    @Inject(
            method = "renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V",
            at = @At("RETURN")
    )
    private void tooltipoverhaul$clearLinesStack(class_327 font, List<class_2561> lines, Optional<class_5632> image, int mouseX, int mouseY, CallbackInfo ci) {
        TooltipLinesContext.clear();
    }

}
