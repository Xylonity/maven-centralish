package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.util.TooltipLinesContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Mixin(class_437.class)
public class ScreenTooltipLinesMixin {

    @Inject(method = "getTooltipFromItem", at = @At("RETURN"))
    private static void tooltipoverhaul$captureLines(class_310 minecraft, class_1799 stack, CallbackInfoReturnable<List<class_2561>> cir) {
        TooltipLinesContext.capture(stack, cir.getReturnValue());
    }

}
