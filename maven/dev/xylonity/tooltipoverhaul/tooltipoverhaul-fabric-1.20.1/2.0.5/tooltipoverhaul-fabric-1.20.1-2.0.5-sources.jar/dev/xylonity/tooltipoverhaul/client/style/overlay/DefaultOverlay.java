package dev.xylonity.tooltipoverhaul.client.style.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.layer.impl.OverlayLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import java.io.InputStream;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

public class DefaultOverlay implements OverlayLayer {

    private static final int BLOCK_DIMENSION = 44;

    private static final Map<class_2960, TextureMetadata> TEXTURES = new ConcurrentHashMap<>();

    @Override
    public void render(TooltipContext context, class_241 position) {

        final String rawTexturePath = RenderUtils.getOverlayLocation(context);
        if (rawTexturePath == null || rawTexturePath.isBlank() || rawTexturePath.isEmpty()) {
            return;
        }

        final class_2960 textureLocation = TooltipOverhaul.rawPathOf(rawTexturePath);
        final TextureMetadata textureMetadata = getTextureMetadata(textureLocation);

        final int textureWidth = textureMetadata.width();
        final int textureHeight = textureMetadata.height();
        final int frameAmount = textureMetadata.frames();

        final int idx = frameAmount > 1 ? (int) ((System.currentTimeMillis() / Constants.getOverlayFrameTime()) % frameAmount) : 0;
        final int frameOffset = idx * Constants.getOverlayFrameDimension();

        final int x = (int) position.field_1343;
        final int y = (int) position.field_1342;
        int width = (int) context.getTooltipSize().field_1343;
        final int height = (int) context.getTooltipSize().field_1342;

        final int baseOffset = -25;

        final int leftX = x + baseOffset;
        final int rightX = x + width - 20;
        final int topY = y + baseOffset + 1;
        final int bottomY = y + height - 20;

        final int centerX = leftX + (width / 2) + 2;
        final int centerY = topY + (height / 2) + 3;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // LEFT
        context.getGraphics().method_25290(textureLocation, leftX, centerY, 0, BLOCK_DIMENSION + frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // RIGHT
        context.getGraphics().method_25290(textureLocation, rightX, centerY, BLOCK_DIMENSION * 2, BLOCK_DIMENSION + frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // TOP LEFT
        context.getGraphics().method_25290(textureLocation, leftX, topY, 0, frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // TOP RIGHT
        context.getGraphics().method_25290(textureLocation, rightX, topY, BLOCK_DIMENSION * 2, frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // BOTTOM LEFT
        context.getGraphics().method_25290(textureLocation, leftX, bottomY, 0, BLOCK_DIMENSION * 2 + frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // BOTTOM RIGHT
        context.getGraphics().method_25290(textureLocation, rightX, bottomY, BLOCK_DIMENSION * 2, BLOCK_DIMENSION * 2 + frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // TOP
        context.getGraphics().method_25290(textureLocation, centerX, topY, BLOCK_DIMENSION, frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        // BOTTOM
        context.getGraphics().method_25290(textureLocation, centerX, bottomY, BLOCK_DIMENSION, BLOCK_DIMENSION * 2 + frameOffset, BLOCK_DIMENSION, BLOCK_DIMENSION, textureWidth, textureHeight);

        RenderSystem.disableBlend();
    }

    private static TextureMetadata getTextureMetadata(class_2960 texture) {
        final int frameDimension = Constants.getOverlayFrameDimension();
        return TEXTURES.computeIfAbsent(texture, tex -> {
            try {
                final Optional<class_3298> resource = class_310.method_1551().method_1478().method_14486(tex);
                if (resource.isEmpty()) {
                    return new TextureMetadata(frameDimension, frameDimension, 1);
                }

                try (InputStream inputStream = resource.get().method_14482(); class_1011 img = class_1011.method_4309(inputStream)) {
                    final int width = img.method_4307();
                    final int heigth = img.method_4323();

                    if (width < frameDimension) {
                        TooltipOverhaul.LOGGER.warn("Texture width {} is smaller than expected {} for {}", width, frameDimension, tex);
                    }

                    if (heigth % frameDimension != 0) {
                        TooltipOverhaul.LOGGER.warn("Texture height {} is not a multiple of {} for {} (animation may look off)", heigth, frameDimension, tex);
                    }

                    return new TextureMetadata(width, heigth, Math.max(1, heigth / frameDimension));
                }

            }
            catch (Exception exception) {
                TooltipOverhaul.LOGGER.error("Failed to read texture {}: {}", tex, exception.toString());
                return new TextureMetadata(frameDimension, frameDimension, 1);
            }

        });

    }

    private record TextureMetadata(
            int width,
            int height,
            int frames
    ) {
        ;;
    }

}