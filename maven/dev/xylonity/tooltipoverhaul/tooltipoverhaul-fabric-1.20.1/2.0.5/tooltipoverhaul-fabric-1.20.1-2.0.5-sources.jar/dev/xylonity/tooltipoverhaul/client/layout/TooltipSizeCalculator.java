package dev.xylonity.tooltipoverhaul.client.layout;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5684;

public class TooltipSizeCalculator {

    private final TooltipContext context;

    public TooltipSizeCalculator(TooltipContext context) {
        this.context = context;
    }

    public class_241 calculate() {
        if (context.getLayoutStyle() == TooltipLayout.Style.COMPACT) {
            return calculateCompact();
        }

        final boolean hasIcon = TooltipLayout.hasHeaderIcon(context);
        final boolean hasRating = RenderUtils.hasRating(context);
        final boolean hasDividerLine = context.hasDividerLine();

        final List<class_5684> components = context.getComponents();
        final class_327 font = context.getFont();

        final int paddingX = context.getPaddingX();
        final int paddingY = context.getPaddingY();

        // Offset to the right if the icon is active
        final int iconOffset = TooltipLayout.titleInset(context);

        // Computes approximated width and height using the component amount
        int width = components.get(0).method_32664(font) + paddingX * 2 + iconOffset;
        int height = components.get(0).method_32661() + paddingY * 2;
        for (int i = 0; i < components.size(); i++) {
            if (i > 0) {
                height += components.get(i).method_32661();
                width = Math.max(width, components.get(i).method_32664(font) + paddingX * 2);
            }

        }

        // Computes the new width if the rating is larger than the tooltip's width and adds extra height in case the icon is not present
        if (hasRating) {
            final class_2561 rating = TextUtils.getRatingText(context);
            width = Math.max(width, font.method_27525(rating) + paddingX * 2 + iconOffset);

            if (!hasIcon) {
                height += class_5684.method_32662(rating.method_30937()).method_32661();
            }

        }

        // If the tooltip has an icon active, the header already holds the title and rating so the title height comes out
        if (hasIcon) {
            height += TooltipLayout.headerHeight(context) - components.get(0).method_32661();
            width = Math.max(width, Constants.getIconSize(context) + paddingX * 2);
        }

        //
        if (hasDividerLine && components.size() > 1) {
            if (hasIcon) {
                height += Constants.getDividerLineFullPadding(context);
            }
            else {
                height += Constants.getDividerLineFullPadding(context);
            }

        }

        return new class_241(width, height);
    }

    private class_241 calculateCompact() {
        final List<class_5684> components = context.getComponents();
        final class_327 font = context.getFont();
        final int padding = context.getPaddingX() * 2;
        int bodyWidth = 0;
        int bodyHeight = 0;
        for (int i = 1; i < components.size(); i++) {
            bodyWidth = Math.max(bodyWidth, components.get(i).method_32664(font));
            bodyHeight += components.get(i).method_32661();
        }

        int width = Math.max(components.get(0).method_32664(font) + TooltipLayout.titleInset(context), bodyWidth) + padding;
        // Lets short names fit naturally without making the panel too wide for long mod names
        int footerWidth = Math.min(font.method_1727(context.getCompactModName()), 96);
        if (RenderUtils.hasRating(context)) {
            if (footerWidth > 0) {
                footerWidth += TooltipLayout.footerTextGap();
            }

            footerWidth += font.method_27525(TextUtils.getRatingText(context));
        }

        width = Math.max(width, footerWidth + padding);

        final int height = TooltipLayout.compactBodyTop(context) + bodyHeight + context.getPaddingY();
        return new class_241(width, height + TooltipLayout.footerHeight(context));
    }

    public class_241 adjustSize() {

        class_241 newSize = context.getTooltipSize();

        final boolean isMainTooltip = context.isMainTooltip();
        final TooltipContext otherContext = context.getOtherTooltipContext();

        final class_241 otherContextPosition = otherContext != null ? otherContext.getTooltipPosition() : null;
        final class_241 otherContextSize = otherContext != null ? otherContext.getTooltipSize() : null;

        if (isMainTooltip) {
            if (otherContextPosition != null && otherContextSize != null) {
                if (otherContextPosition.field_1343 == context.getPaddingX() && context.getTooltipPosition().field_1343 + context.getTooltipSize().field_1343 > context.getScreenWidth()) {
                    newSize = new class_241(context.getScreenWidth() - context.getPaddingX() - context.getTooltipPosition().field_1343, newSize.field_1342);
                }

            }

        }
        else {

        }

        return newSize;
    }

}
