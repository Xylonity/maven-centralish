package dev.xylonity.tooltipoverhaul.client.style.text;

import com.mojang.blaze3d.platform.GlStateManager;
import dev.xylonity.tooltipoverhaul.client.layer.LayerDepth;
import dev.xylonity.tooltipoverhaul.client.layer.impl.TextLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.*;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5683;
import net.minecraft.class_5684;

public class DefaultText implements TextLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        final List<class_5684> components = context.getComponents();

        class_327 font = context.getFont();
        final class_4587 poseStack = context.getPose();
        class_332 graphics = context.getGraphics();

        final boolean hasIcon = TooltipLayout.hasHeaderIcon(context);
        final boolean hasDividerLine = context.hasDividerLine();
        final boolean hasRating = RenderUtils.hasRating(context);

        final int paddingX = context.getPaddingX();
        final int paddingY = context.getPaddingY();

        int x = (int) (position.field_1343 + paddingX);
        int y = (int) (position.field_1342 + paddingY + 1);

        // Some tooltips (Origins recipe badges, info icons, etc.) may provide a single non-text component as the tooltip content
        // In those cases, treating the first component as a "title" would skip it (because the content loop starts at index 1),
        // causing the tooltip to appear blank. So I only treat the first component as a title if it's actually a text component
        final boolean treatFirstAsTitle = !components.isEmpty() && (components.get(0) instanceof class_5683);
        final int startIndex = treatFirstAsTitle ? 1 : 0;

        // Rendering the title first (along with the rating text if present)
        if (treatFirstAsTitle && context.getLayoutStyle() == TooltipLayout.Style.COMPACT) {
            final class_5684 title = components.get(0);
            final int titleX = x + TooltipLayout.titleInset(context);
            final int titleY = y + (TooltipLayout.headerHeight(context) - title.method_32661()) / 2;
            title.method_32665(font, titleX + computeTitleAlignment(context, title, titleX), titleY, poseStack.method_23760().method_23761(), graphics.method_51450());
            renderCompactFooter(context, position);
            y = (int) position.field_1342 + TooltipLayout.compactBodyTop(context);
        }
        else if (treatFirstAsTitle) {
            final class_5684 titleComponent = components.get(0);
            if (titleComponent != null) {
                // If the icon is present, move the content to the side
                final int extraX = hasIcon ? TooltipLayout.titleInset(context) : 0;
                final int textBlockHeight = titleComponent.method_32661() + TooltipLayout.ratingHeight(context);

                // Title and rating are centered together next to the icon, whatever size it has
                final int titleY = hasIcon ? y + (TooltipLayout.headerHeight(context) - textBlockHeight) / 2 : y;

                // Title text
                titleComponent.method_32665(font, x + extraX + computeTitleAlignment(context, titleComponent, x + extraX), titleY, poseStack.method_23760().method_23761(), graphics.method_51450());

                if (hasRating) {
                    final class_2561 rating = TextUtils.getRatingText(context);
                    context.getGraphics().method_51439(font, rating, x + extraX + computeRatingAlignment(context, rating, x + extraX), titleY + titleComponent.method_32661(), 0xEDDE76, false);
                }

                // The header already starts one pixel down, so the body lands right where it did
                y += hasIcon ? TooltipLayout.headerHeight(context) - 2 : textBlockHeight;
            }

            // Extra space after the icon
            if (hasIcon) {
                y += Constants.getIconTitleSeparation(context);
            }

            if (hasDividerLine && components.size() > 1) {
                if (hasIcon) {
                    y += Constants.getDividerLineFullPadding(context);
                }
                else {
                    y += Constants.getDividerLineFullPadding(context);
                }

            }

        }

        final int contentStartY = y;
        final int contentBottom = (int) (position.field_1342 + context.getTooltipSize().field_1342) - paddingY - TooltipLayout.footerHeight(context);

        // If there is a scrolling state active, enables the GL scissor
        if (TooltipScrollState.isIsActive()) {

            graphics.method_51452();

            final class_310 minecraft = class_310.method_1551();
            final int guiScale = (int) minecraft.method_22683().method_4495();

            final int scissorLeft = x;
            final int scissorRight = (int) position.field_1343 + (int) context.getTooltipSize().field_1343 - paddingX;
            final int scissorBottom = contentBottom;

            final int windowHeight = minecraft.method_22683().method_4506();
            final int scaledLeft = scissorLeft * guiScale;
            final int scaledTop = windowHeight - (scissorBottom * guiScale);
            final int scaledWidth = (scissorRight - scissorLeft) * guiScale;
            final int scaledHeight = (scissorBottom - contentStartY) * guiScale;

            GlStateManager._enableScissorTest();
            GlStateManager._scissorBox(scaledLeft, scaledTop, scaledWidth, scaledHeight);

            y -= TooltipScrollState.getScroll();
        }

        // Renders the content of the tooltip (scrollable or not)
        for (int i = startIndex; i < components.size(); i++) {
            final class_5684 component = components.get(i);

            // Renders the lines if they're available in the viewport
            if (!TooltipScrollState.isIsActive() ||
                    (y + component.method_32661() >= contentStartY &&
                            y <= contentBottom)) {

                // Some extra components (like celestisynth's weapons) may extract drawings out of the tooltip margins
                final boolean custom = !(component instanceof class_5683);
                if (custom) {
                    graphics.method_51452();
                    poseStack.method_22903();
                    poseStack.method_46416(0, 0, LayerDepth.CUSTOM_COMPONENT.getZ() - getLayerDepth().getZ());
                }

                component.method_32665(font, x, y, poseStack.method_23760().method_23761(), graphics.method_51450());

                // Some custom components rely on buffered text being flushed before their image pass, so when the scissor is disabled,
                // a flush may not happen otherwise
                graphics.method_51452();

                component.method_32666(font, x, y, graphics);

                if (custom) {
                    graphics.method_51452();
                    poseStack.method_22909();
                }

            }

            y += component.method_32661();
        }

        // Disables the GL scissor
        if (TooltipScrollState.isIsActive()) {
            graphics.method_51452();
            GlStateManager._disableScissorTest();
        }

    }

    private void renderCompactFooter(TooltipContext context, class_241 position) {
        if (TooltipLayout.footerHeight(context) == 0) {
            return;
        }

        final class_327 font = context.getFont();
        final class_332 graphics = context.getGraphics();
        final int x = (int) (position.field_1343 + context.getPaddingX());
        final int right = (int) (position.field_1343 + context.getTooltipSize().field_1343) - context.getPaddingX();
        int y = (int) (position.field_1342 + context.getTooltipSize().field_1342) - context.getPaddingY() - TooltipLayout.footerTextHeight(context) + 2;
        int availableWidth = right - x;
        if (RenderUtils.hasRating(context)) {
            final class_2561 rating = TextUtils.getRatingText(context);
            final int ratingX = right - font.method_27525(rating);
            graphics.method_51439(font, rating, ratingX, y, 0xEDDE76, false);
            availableWidth = ratingX - x - TooltipLayout.footerTextGap();
        }

        String name = context.getCompactModName();
        if (name.isEmpty() || availableWidth <= 0) {
            return;
        }

        if (font.method_1727(name) > availableWidth) {
            final String ellipsis = "\u2026";
            final int ellipsisWidth = font.method_1727(ellipsis);
            if (availableWidth < ellipsisWidth) {
                return;
            }

            name = font.method_27523(name, availableWidth - ellipsisWidth) + ellipsis;
        }

        final int color = ColorUtils.getCompactModNameColor(context);
        graphics.method_51439(font, class_2561.method_43470(name), x, y, color, false);
    }

    private int computeTitleAlignment(TooltipContext context, class_5684 component, int startX) {
        return computeAlignment(context, PositionUtils.getTitleTextAlignment(context), component.method_32664(context.getFont()), startX);
    }

    private int computeRatingAlignment(TooltipContext context, class_2561 component, int startX) {
        return computeAlignment(context, PositionUtils.getRatingTextAlignment(context), context.getFont().method_27525(component), startX);
    }

    private int computeAlignment(TooltipContext context, String alignment, int textWidth, int startX) {
        final int left = (int) context.getTooltipPosition().field_1343 + context.getPaddingX();
        final int right = (int) (context.getTooltipPosition().field_1343 + context.getTooltipSize().field_1343) - context.getPaddingX();
        return switch (alignment) {
            case "middle" -> {
                if (PositionUtils.alignmentIgnoresIcon(context)) {
                    yield Math.max(0, (left + right) / 2 - textWidth / 2 - startX);
                }

                yield (right - startX) / 2 - textWidth / 2;
            }
            case "right" -> right - startX - textWidth;
            default -> 0;
        };

    }

}