package dev.xylonity.tooltipoverhaul.client.style.vignette;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layer.impl.VignetteLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.effect.internal.EffectClip;
import dev.xylonity.tooltipoverhaul.client.style.vignette.parser.VignetteEntry;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public final class LinearVignette implements VignetteLayer {

    private final VignetteEntry entry;

    public LinearVignette(VignetteEntry entry) {
        this.entry = entry;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final float width = context.getTooltipSize().field_1343, height = context.getTooltipSize().field_1342;
        if (!Float.isFinite(entry.radius()) || entry.radius() <= 0) {
            return;
        }

        final float left = position.field_1343 - context.getPaddingX() - 1, top = position.field_1342 - context.getPaddingY();
        final float right = position.field_1343 + width + context.getPaddingX(), bottom = position.field_1342 + height + context.getPaddingY();
        final float offsetX = height * entry.extraPositionX() / 100f, offsetY = width * entry.extraPositionY() / 100f;

        context.flush();

        final EffectClip clip = new EffectClip(context, position);
        final float x0 = clip.left() + offsetX, x1 = clip.left() + clip.width() + offsetX;
        final float y0 = clip.top() + offsetY, y1 = clip.top() + clip.height() + offsetY;

        RenderSystem.enableBlend();

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        RenderSystem.setShader(class_757::method_34540);
        try {
            final Matrix4f pose = context.getPose().method_23760().method_23761();
            final class_287 buffer = class_289.method_1348().method_1349();

            buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

            final String anchor = entry.position();
            final int alpha = ColorUtils.alpha(entry.color());
            final float depthY = Math.min(bottom - top, (bottom - top) * entry.radius());
            final float depthX = Math.min(right - left, (right - left) * entry.radius());
            if (anchor.startsWith("top") || anchor.equals("middle")) {
                final float edge = top + offsetY;
                vertical(buffer, pose, x0, x1, y0, edge, alpha);
                vertical(buffer, pose, x0, x1, edge, edge + depthY, 0);
            }

            if (anchor.startsWith("bottom") || anchor.equals("middle")) {
                final float edge = bottom + offsetY;
                vertical(buffer, pose, x0, x1, y1, edge, alpha);
                vertical(buffer, pose, x0, x1, edge, edge - depthY, 0);
            }

            if (anchor.equals("left")) {
                final float edge = left + offsetX;
                horizontal(buffer, pose, y0, y1, x0, edge, alpha);
                horizontal(buffer, pose, y0, y1, edge, edge + depthX, 0);
            }

            if (anchor.equals("right")) {
                final float edge = right + offsetX;
                horizontal(buffer, pose, y0, y1, x1, edge, alpha);
                horizontal(buffer, pose, y0, y1, edge, edge - depthX, 0);
            }

            clip.draw(buffer.method_1326());
        }
        finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();

            RenderSystem.disableBlend();
        }

    }

    private void vertical(class_287 buffer, Matrix4f pose, float x0, float x1, float edgeY, float innerY, int innerAlpha) {
        final int alpha = ColorUtils.alpha(entry.color());
        vertex(buffer, pose, x0, edgeY, alpha);
        vertex(buffer, pose, x0, innerY, innerAlpha);
        vertex(buffer, pose, x1, innerY, innerAlpha);
        vertex(buffer, pose, x1, edgeY, alpha);
    }

    private void horizontal(class_287 buffer, Matrix4f pose, float y0, float y1, float edgeX, float innerX, int innerAlpha) {
        final int alpha = ColorUtils.alpha(entry.color());
        vertex(buffer, pose, edgeX, y0, alpha);
        vertex(buffer, pose, innerX, y0, innerAlpha);
        vertex(buffer, pose, innerX, y1, innerAlpha);
        vertex(buffer, pose, edgeX, y1, alpha);
    }

    private void vertex(class_287 buffer, Matrix4f pose, float x, float y, int alpha) {
        buffer.method_22918(pose, x, y, 0).method_1336(ColorUtils.red(entry.color()), ColorUtils.green(entry.color()), ColorUtils.blue(entry.color()), alpha).method_1344();
    }

}