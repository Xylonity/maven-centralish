package dev.xylonity.tooltipoverhaul.client.util;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

/**
 * Resolves the stack of tooltips drawn from plain lines, to avoid showing up the same itemstack icon on nested tooltips
 */
public final class TooltipLinesContext {

    private static Lines lastLines;
    private static class_1799 stack = class_1799.field_8037;

    public static void capture(class_1799 source, List<class_2561> lines) {
        lastLines = new Lines(lines, source);
    }

    /**
     * Called before some lines get rendered as a tooltip
     */
    public static void begin(List<class_2561> lines) {
        final Lines captured = lastLines;
        stack = captured != null && captured.lines() == lines ? captured.stack() : class_1799.field_8037;
    }

    /**
     * The stack is consumed on read so it can't leak into another tooltip
     */
    public static class_1799 consume() {
        final class_1799 result = stack;
        stack = class_1799.field_8037;
        return result;
    }

    public static void clear() {
        stack = class_1799.field_8037;
    }

    private record Lines(
            List<class_2561> lines,
            class_1799 stack
    ) {
        ;;
    }

}