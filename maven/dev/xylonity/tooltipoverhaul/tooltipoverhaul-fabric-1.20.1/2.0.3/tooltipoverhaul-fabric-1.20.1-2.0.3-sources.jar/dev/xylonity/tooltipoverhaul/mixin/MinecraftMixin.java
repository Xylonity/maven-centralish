package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.render.PinnedTooltipState;
import dev.xylonity.tooltipoverhaul.client.render.FadeRenderType;
import dev.xylonity.tooltipoverhaul.client.style.preview.renderer.PreviewEntityCache;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftMixin {

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void tooltipoverhaul$onSetScreen(class_437 screen, CallbackInfo ci) {
        PinnedTooltipState.screenChanged(screen);
        TooltipScrollState.reset();
        PreviewEntityCache.clear();
        FadeRenderType.reset();
    }

    @Inject(method = "updateLevelInEngines", at = @At("HEAD"))
    private void tooltipoverhaul$onLevelChanged(class_638 level, CallbackInfo ci) {
        PreviewEntityCache.clear();
        FadeRenderType.reset();
    }

}
