package dev.xylonity.tooltipoverhaul.client.style.icon;

import dev.xylonity.tooltipoverhaul.client.layer.impl.IconLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.render.TooltipRenderer;
import dev.xylonity.tooltipoverhaul.client.style.icon.animation.IconAnimation;
import dev.xylonity.tooltipoverhaul.client.style.icon.animation.IconAnimationFactory;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.compat.modernfix.ModernFixCompat;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_7833;

public class DefaultIcon implements IconLayer {

    private static final float ANIMATION_DURATION = 0.6f;
    private static final float ICON_SCALE = 1.35f;

    @Override
    public void render(TooltipContext context, class_241 position) {

        final float positionX = context.getTooltipPosition().field_1343 + TooltipLayout.iconX(context);
        final float positionY = context.getTooltipPosition().field_1342 + TooltipLayout.iconY(context);

        context.push(() -> {

            context.translate(positionX + Constants.getIconSize(context) / 2f, positionY + Constants.getIconSize(context) / 2f, context.getLayerDepth().getZ());
            final float layoutScale = Constants.getIconSize(context) / 22f;
            context.scale(layoutScale, layoutScale, layoutScale);

            final IconAnimation animationType = IconAnimation.fromString(RenderUtils.getIconAppearAnimation(context));

            final float elapsed = TooltipRenderer.ICON_COUNTER;
            final float progress = Math.min(elapsed / ANIMATION_DURATION, 1.0f);

            // Entry animation before a continuous rotation is applied
            if (elapsed < ANIMATION_DURATION) {
                applyEntryAnimation(context, animationType, progress);
            }
            else {
                applyContinuousRotation(context, animationType, elapsed);
            }

            if (ModernFixCompat.SHOULD_RETURN_ORIGINAL_RENDER) {
                ModernFixCompat.push();
                try {
                    RenderUtils.renderItem(context, class_310.method_1551().field_1724, class_310.method_1551().field_1687, context.getStack(), 0);
                }
                finally {
                    ModernFixCompat.pop();
                }

            }
            else {
                RenderUtils.renderItem(context, class_310.method_1551().field_1724, class_310.method_1551().field_1687, context.getStack(), 0);
            }

        });

    }

    private void applyEntryAnimation(TooltipContext context, IconAnimation type, float progress) {
        if (type == IconAnimation.ROTATE || type == IconAnimation.ROTATE_ZOOM) {
            context.multiply(class_7833.field_40716, 180);
        }

        IconAnimationFactory.get(type).apply(context, progress, ICON_SCALE);
    }

    private void applyContinuousRotation(TooltipContext context, IconAnimation type, float elapsed) {
        context.scale(ICON_SCALE, ICON_SCALE, ICON_SCALE);

        final float rotationSpeed = RenderUtils.getIconRotatingSpeed(context);
        if (rotationSpeed > 0) {
            final float additionalRotation = (elapsed - ANIMATION_DURATION) * (360f / (6.0f / rotationSpeed));
            context.multiply(class_7833.field_40716, additionalRotation % 360);
        }

    }

}
