package dev.xylonity.tooltipoverhaul.client.screen.config;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.playClickSound;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.*;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Search box field
 */
final class SearchBox extends class_342 {

    private float focusAnimation;
    private final int accent;

    SearchBox(class_327 font, int x, int y, int width, int height, int accent) {
        super(font, x, y, width, height, class_2561.method_43470("Search"));
        this.accent = accent;
        method_1858(false);
        method_1868(0xFFCCCCCC);
        method_1860(0xFF555555);
        method_1880(128);
        method_47404(class_2561.method_43471("tooltipoverhaul.config.search"));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && !method_1882().isEmpty() && mouseX >= method_46426() + method_25368() - 12 && mouseX < method_46426() + method_25368() && mouseY >= method_46427() && mouseY < method_46427() + method_25364()) {
            method_1852("");
            playClickSound();
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        final int x0 = method_46426();
        final int y0 = method_46427();
        final int width = method_25368();
        final int height = method_25364();
        final int x1 = x0 + width;
        final int y1 = y0 + height;
        final boolean engaged = mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1 || method_25370();
        focusAnimation = engaged ? Math.min(1f, focusAnimation + 0.12f) : Math.max(0f, focusAnimation - 0.06f);

        final int borderTarget = method_25370() ? accent & 0x00FFFFFF : dimAccent(accent);
        drawCard(graphics, x0, y0, x1, y1, 0xFF151517, 0xFF000000 | mixRgb(0x26262A, borderTarget, focusAnimation));

        final int[] channels = rgb(accent);
        int iconColor = 0xFF000000 | ((int) (0x48 + (channels[0] - 0x48) * focusAnimation) << 16) | ((int) (0x48 + (channels[1] - 0x48) * focusAnimation) << 8) | (int) (0x48 + (channels[2] - 0x48) * focusAnimation);
        ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.SEARCH, x0 + 5, y0 + (height - ConfigIconButton.Icon.SEARCH.height) / 2, iconColor);

        final class_310 client = class_310.method_1551();
        if (!method_1882().isEmpty()) {
            final boolean clearHovered = mouseX >= x1 - 12 && mouseX < x1 && mouseY >= y0 && mouseY < y1;
            graphics.method_51433(client.field_1772, "\u00d7", x1 - 9, y0 + (height - client.field_1772.field_2000) / 2 + 1, clearHovered ? accent : 0xFF666666, false);
        }

        final int textPaddingX = 20;
        final int offsetY = (height - client.field_1772.field_2000) / 2 + 1;
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(textPaddingX, offsetY, 0);
        super.method_48579(graphics, mouseX - textPaddingX, mouseY - offsetY, partialTick);

        graphics.method_51448().method_22909();
    }

}
