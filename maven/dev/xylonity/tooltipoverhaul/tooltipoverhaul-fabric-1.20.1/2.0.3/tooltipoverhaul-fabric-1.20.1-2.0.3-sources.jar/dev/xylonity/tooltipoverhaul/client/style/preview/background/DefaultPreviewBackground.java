package dev.xylonity.tooltipoverhaul.client.style.preview.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import net.minecraft.class_241;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;

public class DefaultPreviewBackground implements PreviewBackgroundLayer {

    @Override
    @SuppressWarnings("deprecation")
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        context.getGraphics().method_51741(() -> renderBackground(context, startPosition, endPosition));
    }

    private void renderBackground(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        final int x0 = (int) startPosition.field_1343;
        final int y0 = (int) startPosition.field_1342;
        final int x1 = (int) endPosition.field_1343;
        final int y1 = (int) endPosition.field_1342;
        if (x0 - x1 < 2 || y1 - y0 < 2) {
            return;
        }

        final int backgroundColor = ColorUtils.getBackgroundColor(context);
        RenderUtils.fillBackgroundShape(context.getGraphics(), x1, y0, x0, y1, backgroundColor, RenderUtils.getPreviewPanelBackgroundCornerType(context));

        if (RenderUtils.hasPreviewPanelSideTriangles(context)) {
            for (int row = 1; row < y1 - y0 - 1; row++) {
                final int outset = PreviewPanelDecorations.triangleOutset(y1 - y0, row);
                if (outset <= 0) {
                    continue;
                }

                context.getGraphics().method_25294(x1 - outset - 1, y0 + row, x1 - 1, y0 + row + 1, backgroundColor);
                context.getGraphics().method_25294(x0 + 1, y0 + row, x0 + outset + 1, y0 + row + 1, backgroundColor);
            }

        }

    }

}
