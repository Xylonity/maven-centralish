package dev.xylonity.tooltipoverhaul.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.screen.config.EffectEditorScreen;
import dev.xylonity.tooltipoverhaul.client.screen.config.FrameEditorScreen;
import dev.xylonity.tooltipoverhaul.client.screen.config.TooltipOverhaulConfigScreen;
import dev.xylonity.tooltipoverhaul.client.style.animation.TooltipAnimator;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import dev.xylonity.tooltipoverhaul.compat.proxy.ScreenTypeProxy;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_5684;
import net.minecraft.class_8001;

/**
 * Pinned item tooltips that survive closing and reopening inventory screens
 */
public final class PinnedTooltipState {

    private static final int BADGE_HEIGHT = 16;

    private static class_437 owner;

    private static class_1799 hovered = class_1799.field_8037;
    private static List<class_5684> hoveredComponents = List.of();

    private static final List<Pin> pins = new ArrayList<>();

    private static long lastHover;
    private static class_1657 pinnedPlayer;
    private static Pin dragging;
    private static int consumedButton = -1;
    private static double dragX, dragY;

    private static boolean allowed(class_437 screen) {
        final boolean inventoryLike = screen instanceof class_465<?> || ScreenTypeProxy.isJei(screen)
                || ScreenTypeProxy.isEmi(screen) || ScreenTypeProxy.isFtbQuests(screen) || ScreenTypeProxy.isFtbLibrary(screen);
        return class_310.method_1551().field_1724 != null && inventoryLike && !(screen instanceof FrameEditorScreen)
                && !(screen instanceof EffectEditorScreen) && !(screen instanceof TooltipOverhaulConfigScreen);
    }

    private static void attach(class_437 screen) {
        if (owner == screen) {
            return;
        }

        owner = screen;
        hovered = class_1799.field_8037;
        hoveredComponents = List.of();
        lastHover = 0;
        dragging = null;
        consumedButton = -1;
    }

    public static void capture(TooltipContext context) {
        final class_437 screen = class_310.method_1551().field_1755;
        if (!allowed(screen) || context.getStack().method_7960()) {
            return;
        }

        attach(screen);
        hovered = context.getStack();
        hoveredComponents = context.getComponents();
        lastHover = System.nanoTime();
    }

    public static void clear() {
        owner = null;
        hovered = class_1799.field_8037;
        hoveredComponents = List.of();
        pins.clear();
        lastHover = 0;
        pinnedPlayer = null;
        dragging = null;
        consumedButton = -1;
    }

    /**
     * Changes input ownership without discarding the pinned items
     */
    public static void screenChanged(class_437 screen) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            clear();
            return;
        }

        attach(allowed(screen) ? screen : null);
    }

    private static void unpin(Pin pin) {
        pins.remove(pin);
        if (dragging == pin) {
            dragging = null;
        }

        if (pins.isEmpty()) {
            pinnedPlayer = null;
        }

    }

    private static void pinHovered() {
        final class_310 client = class_310.method_1551();
        while (pins.size() >= Math.max(1, TooltipsConfig.MAX_PINNED_TOOLTIPS)) {
            unpin(pins.get(0));
        }

        pinnedPlayer = client.field_1724;
        pins.add(new Pin(hovered.method_7972(), List.copyOf(hoveredComponents), 24 + pins.size() * 16, 40 + pins.size() * 16));
    }

    private static Pin pinAt(double mx, double my) {
        final class_310 client = class_310.method_1551();
        if (!allowed(client.field_1755)) {
            return null;
        }

        for (int i = pins.size() - 1; i >= 0; i--) {
            if (pins.get(i).contains(mx, my)) {
                return pins.get(i);
            }

        }

        return null;
    }

    private static boolean toggle(double mx, double my) {
        final class_310 client = class_310.method_1551();
        if (!allowed(client.field_1755)) {
            return false;
        }

        attach(client.field_1755);

        final Pin over = pinAt(mx, my);
        if (over != null) {
            unpin(over);
            return true;
        }

        if (!hovered.method_7960() && System.nanoTime() - lastHover <= 250_000_000L) {
            pinHovered();
            return true;
        }

        if (!pins.isEmpty()) {
            unpin(pins.get(pins.size() - 1));
            return true;
        }

        return false;
    }

    private static double mouseX(class_310 client) {
        return client.field_1729.method_1603() * client.method_22683().method_4486() / client.method_22683().method_4480();
    }

    private static double mouseY(class_310 client) {
        return client.field_1729.method_1604() * client.method_22683().method_4502() / client.method_22683().method_4507();
    }

    public static boolean key(int key, int scanCode, int action) {
        final class_310 client = class_310.method_1551();
        if (!allowed(client.field_1755) || action != GLFW.GLFW_PRESS) {
            return false;
        }

        if (!TooltipOverhaulKeyMappings.PIN_TOOLTIP.method_1417(key, scanCode)) {
            return false;
        }

        if (client.field_1755.method_25399() instanceof class_342) {
            return false;
        }

        return toggle(mouseX(client), mouseY(client));
    }

    public static boolean mouseButton(double mx, double my, int button, int action) {
        if (action == GLFW.GLFW_RELEASE && consumedButton == button) {
            consumedButton = -1;
            dragging = null;
            return true;
        }

        if (action != GLFW.GLFW_PRESS) {
            return false;
        }

        if (TooltipOverhaulKeyMappings.PIN_TOOLTIP.method_1433(button) && toggle(mx, my)) {
            consumedButton = button;
            return true;
        }

        final Pin pin = pinAt(mx, my);
        if (pin == null) {
            return false;
        }

        consumedButton = button;

        if (button == 0 && my < pin.top) {
            if (mx >= pin.right - 16) {
                unpin(pin);
            }
            else {
                pins.remove(pin);
                pins.add(pin);
                dragging = pin;
                dragX = mx - pin.x;
                dragY = my - pin.y;
            }

        }

        return true;
    }

    public static boolean scroll(double mx, double my, double delta) {
        final Pin pin = pinAt(mx, my);
        if (pin == null) {
            return false;
        }

        final TooltipScrollState.Snapshot previous = TooltipScrollState.snapshot();
        try {
            TooltipScrollState.restore(pin.scrolling);
            TooltipScrollState.onRawScroll(delta);
            pin.scrolling = TooltipScrollState.snapshot();
        }
        finally {
            TooltipScrollState.restore(previous);
        }

        return true;
    }

    public static void render(class_332 graphics, int mouseX, int mouseY) {
        final class_310 client = class_310.method_1551();
        if (pins.isEmpty() || !allowed(client.field_1755)) {
            return;
        }

        if (pinnedPlayer != null && pinnedPlayer != client.field_1724) {
            pins.clear();
            pinnedPlayer = null;
            dragging = null;
            return;
        }

        attach(client.field_1755);

        if (dragging != null) {
            dragging.x = (float) (mouseX - dragX);
            dragging.y = (float) (mouseY - dragY);
        }

        for (final Pin pin : new ArrayList<>(pins)) {
            render(graphics, pin);
        }

    }

    private static void render(class_332 graphics, Pin pin) {
        final class_310 client = class_310.method_1551();
        final int width = client.method_22683().method_4486(), height = client.method_22683().method_4502();
        final TooltipScrollState.Snapshot previous = TooltipScrollState.snapshot();
        final float previousCounter = TooltipRenderer.COUNTER;
        final float previousIconCounter = TooltipRenderer.ICON_COUNTER;

        graphics.method_51448().method_22903();
        try {
            graphics.method_51448().method_46416(0, 0, 3000);

            TooltipScrollState.restore(pin.scrolling);

            TooltipRenderer.COUNTER = Math.max(0, System.nanoTime() - pin.pinnedAtNano) / 1_000_000_000f;
            TooltipRenderer.ICON_COUNTER = TooltipRenderer.COUNTER;
            final List<class_5684> components = liveComponents(graphics, pin, width, height);
            final TooltipContext context = new TooltipContext(graphics, client.field_1772, components, 0, 0, width,
                    Math.max(30, height - 24), class_8001.field_41687, pin.stack, false);

            context.setPinned(true);

            final TooltipRenderer renderer = new TooltipRenderer(context);
            renderer.init();
            if (!renderer.canRender()) {
                return;
            }

            final float tooltipWidth = context.getTooltipSize().field_1343;
            final float tooltipHeight = context.getTooltipSize().field_1342;
            for (int pass = 0; pass < 2; pass++) {
                context.setTooltipPosition(new class_241(pin.x, pin.y));
                bounds(context, pin, tooltipWidth, tooltipHeight);
                pin.x += Math.max(4 - pin.left, Math.min(0, width - 4 - pin.right));
                pin.y += Math.max(BADGE_HEIGHT + 6 - pin.top, Math.min(0, height - 4 - pin.bottom));
            }

            context.setTooltipPosition(new class_241(pin.x, pin.y));
            bounds(context, pin, tooltipWidth, tooltipHeight);

            graphics.method_44379((int) pin.left - 8, (int) pin.top - BADGE_HEIGHT - 10, (int) pin.right + 8, (int) pin.bottom + 8);
            RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, class_310.field_1703);
            graphics.method_44380();

            TooltipAnimator.render(context, false, 1);

            graphics.method_51452();

            graphics.method_51448().method_46416(0, 0, 2600);

            // Badge above the tooltip
            final int badgeTop = (int) pin.top - BADGE_HEIGHT - 2;
            final int badgeBottom = (int) pin.top - 2;
            graphics.method_25294((int) pin.left, badgeTop, (int) pin.right, badgeBottom, 0xF0343B4A);
            graphics.method_25294((int) pin.left + 1, badgeTop + 1, (int) pin.right - 1, badgeBottom - 1, 0xF0222833);
            graphics.method_51433(client.field_1772, client.field_1772.method_27523(class_2561.method_43471("tooltipoverhaul.pinned.title").getString(), Math.max(1, (int) (pin.right - pin.left - 25))), (int) pin.left + 4, badgeTop + 4, 0xFFBFD7F4, false);
            graphics.method_51433(client.field_1772, "x", (int) pin.right - 11, badgeTop + 4, 0xFFFFFFFF, false);

            pin.scrolling = TooltipScrollState.snapshot();
        }
        catch (RuntimeException exception) {
            TooltipOverhaul.LOGGER.warn("Could not render pinned tooltip", exception);
            unpin(pin);
        }
        finally {
            graphics.method_51452();
            graphics.method_51448().method_22909();
            TooltipRenderer.COUNTER = previousCounter;
            TooltipRenderer.ICON_COUNTER = previousIconCounter;
            TooltipScrollState.restore(previous);
        }

    }

    /**
     * Updates the pinned tooltip per tick
     */
    private static List<class_5684> liveComponents(class_332 graphics, Pin pin, int width, int height) {
        try {
            List<class_5684> components = TextUtils.getTooltipComponentsFrom(pin.stack, class_310.method_1551().field_1772, width, 2.2f);
            components = TooltipOverhaul.PLATFORM.gatherTooltipComponents(graphics, pin.stack, components, class_310.method_1551().field_1772, (int) pin.x, (int) pin.y, width, height, class_8001.field_41687);
            if (!components.isEmpty()) {
                pin.components = List.copyOf(components);
                pin.refreshWarningShown = false;
                return components;
            }

        }
        catch (RuntimeException exception) {
            if (!pin.refreshWarningShown) {
                TooltipOverhaul.LOGGER.warn("Could not refresh pinned tooltip contents", exception);
                pin.refreshWarningShown = true;
            }

        }

        return pin.components;
    }

    private static void bounds(TooltipContext context, Pin pin, float width, float height) {
        pin.left = pin.x - 4; pin.top = pin.y - 4; pin.right = pin.x + width + 4; pin.bottom = pin.y + height + 4;
        if (TooltipLayout.hasExternalIcon(context)) {
            final float ix = pin.x + TooltipLayout.iconX(context), iy = pin.y + TooltipLayout.iconY(context);
            pin.left = Math.min(pin.left, ix - 4); pin.top = Math.min(pin.top, iy - 4);
            pin.right = Math.max(pin.right, ix + Constants.getIconSize(context) + 4);
            pin.bottom = Math.max(pin.bottom, iy + Constants.getIconSize(context) + 4);
        }

    }

    private static final class Pin {

        private final class_1799 stack;
        private List<class_5684> components;
        private final long pinnedAtNano;
        private boolean refreshWarningShown;
        private float x, y;
        private float left, top, right, bottom;
        private TooltipScrollState.Snapshot scrolling = new TooltipScrollState.Snapshot(0, 0, false, 0, 0, 0);

        private Pin(class_1799 stack, List<class_5684> components, float x, float y) {
            this.stack = stack;
            this.components = components;
            this.pinnedAtNano = System.nanoTime();
            this.x = x;
            this.y = y;
        }

        private boolean contains(double mx, double my) {
            return mx >= left && mx <= right && my >= top - BADGE_HEIGHT - 2 && my <= bottom;
        }

    }

}
