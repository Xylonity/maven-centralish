package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.IconBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import net.minecraft.class_241;

public class DetachedIconPlate implements IconBackgroundLayer {

    private final IconBackgroundLayer background;

    public DetachedIconPlate(IconBackgroundLayer background) {
        this.background = background;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int x = (int) position.field_1343 + TooltipLayout.iconX(context);
        final int y = (int) position.field_1342 + TooltipLayout.iconY(context);
        final int size = Constants.getIconSize(context);
        final int[] colors = ColorUtils.getRenderedInnerOverlayColors(context);
        final boolean badge = context.getLayoutStyle() == TooltipLayout.Style.BADGE;
        final boolean squareCorners = IconBorder.hasSquareCorners(context);

        context.getGraphics().method_25294(x - 1, y - 1, x + size + 1, y + size + 1, ColorUtils.getBackgroundColor(context));
        if (background != null) {
            context.push(() -> background.render(context, position));
        }

        for (int row = 0; row < size; row++) {
            final int color = ColorUtils.getInnerOverlayColorAtY(context, colors, y + row + 0.5f);
            context.getGraphics().method_25294(x - 1, y + row, x, y + row + 1, color);
            context.getGraphics().method_25294(x + size, y + row, x + size + 1, y + row + 1, color);
        }

        final int innerCorner = squareCorners ? 1 : 0;
        context.getGraphics().method_25294(x - innerCorner, y - 1, x + size + innerCorner, y, ColorUtils.getInnerOverlayColorAtY(context, colors, y - 0.5f));
        context.getGraphics().method_25294(x - innerCorner, y + size, x + size + innerCorner, y + size + 1, ColorUtils.getInnerOverlayColorAtY(context, colors, y + size + 0.5f));

        // Outer black edge
        final int blackEnd = badge ? (int) position.field_1343 - 3 : x + size;
        final int outerCorner = squareCorners ? 2 : 0;
        context.getGraphics().method_25294(x - outerCorner, y - 2, blackEnd + (badge ? 0 : outerCorner), y - 1, 0xFF000000);
        if (!squareCorners) {
            context.getGraphics().method_25294(x - 1, y - 1, x, y, 0xFF000000);
            context.getGraphics().method_25294(x - 1, y + size, x, y + size + 1, 0xFF000000);
        }

        context.getGraphics().method_25294(x - 2, y - outerCorner, x - 1, y + size + outerCorner, 0xFF000000);
        context.getGraphics().method_25294(x - outerCorner, y + size + 1, blackEnd + (badge ? 0 : outerCorner), y + size + 2, 0xFF000000);

        if (!badge) {
            if (!squareCorners) {
                context.getGraphics().method_25294(x + size, y - 1, x + size + 1, y, 0xFF000000);
                context.getGraphics().method_25294(x + size, y + size, x + size + 1, y + size + 1, 0xFF000000);
            }

            context.getGraphics().method_25294(x + size + 1, y - outerCorner, x + size + 2, y + size + outerCorner, 0xFF000000);
        }

    }

}
