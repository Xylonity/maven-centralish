package dev.xylonity.tooltipoverhaul.client.screen.config;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.buttonBorder;
import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;

/**
 * Small textured pixel icons with accessible names (per resource location)
 */
final class ConfigIconButton extends class_4185 {

    enum Icon {

        ADD("icon_add", 9, 9),
        ALIGN("icon_align", 9, 9),
        COPY("icon_copy", 9, 9),
        EXPAND("icon_expand", 9, 9),
        MENU("icon_menu", 9, 9, 1, 1),
        PLAY("icon_play", 9, 9, 1, 1),
        QUESTION("icon_question", 9, 9),
        REPEAT("icon_repeat", 9, 11, 1, 1),
        RESIZE_PANEL("icon_resize_panel", 11, 9),
        SEARCH("icon_search", 9, 9),
        TEMPLATES("icon_templates", 9, 9),
        TRASH("icon_trash", 9, 9);

        final class_2960 texture;
        final int width;
        final int height;
        final int offsetX;
        final int offsetY;

        Icon(String name, int width, int height) {
            this(name, width, height, 0, 0);
        }

        Icon(String name, int width, int height, int offsetX, int offsetY) {
            this.texture = name == null ? null : TooltipOverhaul.pathOf("textures/gui/" + name + ".png");
            this.width = width;
            this.height = height;
            this.offsetX = offsetX;
            this.offsetY = offsetY;
        }

    }

    private final Icon icon;
    private final int accent;

    ConfigIconButton(int x, int y, int width, Icon icon, class_2561 label, class_4241 action, int accent) {
        super(x, y, width, 18, label, action, field_40754);
        this.icon = icon;
        this.accent = accent;
        method_47400(class_7919.method_47407(label));
    }

    @Override
    protected void method_48579(class_332 graphics, int mx, int my, float delta) {
        drawCard(graphics, method_46426(), method_46427(), method_46426() + field_22758, method_46427() + field_22759, method_25367() ? 0xFF24242B : 0xFF161618, buttonBorder(accent, method_25367() ? 1f : 0f));
        final int x = method_46426() + (field_22758 - icon.width) / 2;
        final int y = method_46427() + (field_22759 - icon.height) / 2;
        final int color = !field_22763 ? 0xFF55555D : method_25367() ? accent : 0xFFC6C6D0;
        drawIcon(graphics, icon, x, y, color);
    }

    static void drawIcon(class_332 graphics, Icon icon, int x, int y, int color) {
        final float[] saved = RenderSystem.getShaderColor().clone();
        final float red = ((color >> 16) & 0xFF) / 255f;
        final float green = ((color >> 8) & 0xFF) / 255f;
        final float blue = (color & 0xFF) / 255f;
        final float alpha = ((color >>> 24) & 0xFF) / 255f;

        graphics.method_51452();

        RenderSystem.setShaderColor(saved[0] * red, saved[1] * green, saved[2] * blue, saved[3] * alpha);
        try {
            graphics.method_25290(icon.texture, x + icon.offsetX, y + icon.offsetY, 0, 0, icon.width, icon.height, icon.width, icon.height);

            graphics.method_51452();
        }
        finally {
            RenderSystem.setShaderColor(saved[0], saved[1], saved[2], saved[3]);
        }

    }

    static void drawDiamond(class_332 graphics, int cx, int cy, int color) {
        for (int row = -3; row <= 3; row++) {
            final int half = 3 - Math.abs(row);
            graphics.method_25294(cx - half, cy + row, cx + half + 1, cy + row + 1, color);
        }

    }

}