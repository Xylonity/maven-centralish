package dev.xylonity.tooltipoverhaul.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_1921;

public final class FadeRenderType extends class_1921 {

    private static final Map<class_1921, class_1921> CACHE = new IdentityHashMap<>();

    public static void reset() {
        CACHE.clear();
    }

    private FadeRenderType(class_1921 original) {
        super("tooltipoverhaul_fade_" + original, original.method_23031(), original.method_23033(), original.method_22722(), original.method_23037(), true,
                () -> {
                    original.method_23516();
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                },
                () -> {
                    RenderSystem.disableBlend();
                    original.method_23518();
                });

    }

    public static class_1921 remap(class_1921 original) {
        if (original instanceof FadeRenderType) {
            return original;
        }

        // Foil items request the glint layer and the base layer at the same time and this RT cancels the latter,
        // so ignoring the vanilla render type (which also supports transparencies) would do the trick
        if (original.toString().contains("glint")) {
            return original;
        }

        final class_1921 cached = CACHE.get(original);
        if (cached != null) {
            return cached;
        }

        if (CACHE.size() >= 256) {
            CACHE.clear();
        }

        final class_1921 faded = new FadeRenderType(original);
        CACHE.put(original, faded);
        return faded;
    }

}
