package dev.xylonity.tooltipoverhaul.client.style.divider;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layer.impl.DividerLineLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public final class GradientOrnamentDividerLine implements DividerLineLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int width = Math.max(0, (int) context.getTooltipSize().field_1343 - context.getPaddingX() * 2);
        final int left = (int) position.field_1343;
        final int right = left + width;
        final int y = (int) position.field_1342;
        final int center = left + width / 2;
        final int color = ColorUtils.getDividerLineColor(context);
        final int red = (color >>> 16) & 0xFF;
        final int green = (color >>> 8) & 0xFF;
        final int blue = color & 0xFF;
        final int alpha = (color >>> 24) & 0xFF;

        if (width < 9) {
            context.getGraphics().method_25294(left, y, right, y + 1, color);
            return;
        }

        context.flush();

        final Matrix4f matrix = context.getGraphics().method_51448().method_23760().method_23761();
        final class_287 buffer = class_289.method_1348().method_1349();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Left
        buffer.method_22918(matrix, left, y + 1, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, center - 3, y + 1, 0).method_1336(red, green, blue, alpha).method_1344();
        buffer.method_22918(matrix, center - 3, y, 0).method_1336(red, green, blue, alpha).method_1344();
        buffer.method_22918(matrix, left, y, 0).method_1336(red, green, blue, 0).method_1344();

        // Right
        buffer.method_22918(matrix, center + 4, y + 1, 0).method_1336(red, green, blue, alpha).method_1344();
        buffer.method_22918(matrix, right, y + 1, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, right, y, 0).method_1336(red, green, blue, 0).method_1344();
        buffer.method_22918(matrix, center + 4, y, 0).method_1336(red, green, blue, alpha).method_1344();

        class_286.method_43433(buffer.method_1326());

        // +
        context.getGraphics().method_25294(center - 1, y, center + 2, y + 1, color);
        context.getGraphics().method_25294(center, y - 1, center + 1, y, color);
        context.getGraphics().method_25294(center, y + 1, center + 1, y + 2, color);
    }

}
