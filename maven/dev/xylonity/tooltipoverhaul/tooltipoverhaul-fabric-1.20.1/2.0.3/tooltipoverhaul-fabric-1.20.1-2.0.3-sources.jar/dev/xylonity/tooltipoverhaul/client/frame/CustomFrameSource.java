package dev.xylonity.tooltipoverhaul.client.frame;

import javax.annotation.Nullable;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * One effective resourcepack document and its optional copy (replacement)
 */
public record CustomFrameSource(
        class_2960 location,
        Path file,
        @Nullable class_3298 resource,
        boolean primary
) {

    public boolean customized() {
        return Files.exists(file);
    }

    public String packName() {
        return resource == null ? "" : resource.method_14480();
    }

    public void prepareSave() throws IOException {
        CustomFrameStorage.prepareSave(this);
    }

    public Reader openReader() throws IOException {
        if (customized()) {
            return Files.size(file) == 0 ? new StringReader("{\"frames\":[]}") : Files.newBufferedReader(file, StandardCharsets.UTF_8);
        }

        if (resource != null) {
            return resource.method_43039();
        }

        if (primary) {
            return new StringReader("{\"frames\":[]}");
        }

        throw new FileNotFoundException(location.toString());
    }

    void initializePrimary() throws IOException {
        if (!primary || customized()) {
            return;
        }

        Files.createDirectories(file.getParent());
        if (resource == null) {
            Files.writeString(file, "{\n  \"frames\": []\n}\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        }
        else {
            try (final InputStream input = resource.method_14482()) {
                Files.copy(input, file);
            }

        }

    }

    public Path restoreOriginal() throws IOException {
        if (resource == null || !customized()) {
            throw new IOException("No customized resource to restore");
        }

        try (final Reader reader = resource.method_43039()) {
            CustomFrameStorage.read(reader);
        }

        final Path backup = Files.createTempFile(file.getParent(), file.getFileName() + ".restored-", ".bak");
        try {
            Files.move(file, backup, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (AtomicMoveNotSupportedException ignored)  {
            Files.move(file, backup, StandardCopyOption.REPLACE_EXISTING);
        }

        Files.deleteIfExists(CustomFrameStorage.defaultsFile(this));

        return backup;
    }

}