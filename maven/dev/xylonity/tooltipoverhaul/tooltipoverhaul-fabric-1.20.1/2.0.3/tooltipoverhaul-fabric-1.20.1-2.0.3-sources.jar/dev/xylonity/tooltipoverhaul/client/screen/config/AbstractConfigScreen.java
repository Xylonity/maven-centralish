package dev.xylonity.tooltipoverhaul.client.screen.config;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Common screen shared by the complete configuration screen family
 */
abstract class AbstractConfigScreen extends class_437 {

    private static final int MODAL_LAYER_Z = 4000;

    protected final class_437 parent;
    protected final int accent;

    protected final class_310 minecraft = class_310.method_1551();

    protected final long openedAt = class_156.method_658();

    protected final ConfigModalHost modals = new ConfigModalHost();

    protected AbstractConfigScreen(class_2561 title, class_437 parent, int accent) {
        super(title);
        this.parent = parent;
        this.accent = accent;
    }

    @Override
    protected final void method_25426() {
        modals.clear();
        initScreen();
    }

    /**
     * Builds the concrete screen after shared transient state has been reset
     */
    protected abstract void initScreen();

    protected final void renderScreenShell(class_332 graphics, String description) {
        ConfigScreenStyle.renderBackground(graphics, field_22789, field_22790, ConfigScreenStyle.HEADER_HEIGHT, accent);
        ConfigScreenStyle.renderBrandedHeader(graphics, field_22793, field_22789, field_22785.getString(), description, openedAt);
    }

    protected final void returnToParent() {
        field_22787.method_1507(parent);
    }

    protected final void addCenteredFooterButtons(int buttonWidth, int gap, FooterAction... actions) {
        final int totalWidth = buttonWidth * actions.length + gap * Math.max(0, actions.length - 1);
        final int startX = (field_22789 - totalWidth) / 2;
        final int buttonY = field_22790 - 26;
        for (int index = 0; index < actions.length; index++) {
            final FooterAction action = actions[index];
            final FlatButton button = new FlatButton(startX + index * (buttonWidth + gap), buttonY, buttonWidth, 18, action.label(),
                    ignored -> action.press().run(), accent, action.primary()).withEntranceDelay(action.entranceDelay());
            method_37063(button);
        }

    }

    /**
     * Renders the modal above the screen own overlays
     */
    protected final void renderModalLayer(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(0, 0, MODAL_LAYER_Z);
        try {
            modals.render(graphics, mouseX, mouseY, partialTick);
        }
        finally {
            graphics.method_51448().method_22909();
        }

    }

    @Override
    public final boolean method_25402(double mouseX, double mouseY, int button) {
        return modals.mouseClicked(mouseX, mouseY, button) || handleMouseClicked(mouseX, mouseY, button);
    }

    protected boolean handleMouseClicked(double mouseX, double mouseY, int button) {
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public final boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return modals.mouseDragged(mouseX, mouseY, button, deltaX, deltaY) || handleMouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    protected boolean handleMouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public final boolean method_25406(double mouseX, double mouseY, int button) {
        return modals.mouseReleased(mouseX, mouseY, button) || handleMouseReleased(mouseX, mouseY, button);
    }

    protected boolean handleMouseReleased(double mouseX, double mouseY, int button) {
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public final boolean method_25401(double mouseX, double mouseY, double delta) {
        return modals.mouseScrolled(mouseX, mouseY, delta) || handleMouseScrolled(mouseX, mouseY, delta);
    }

    protected boolean handleMouseScrolled(double mouseX, double mouseY, double delta) {
        return super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public final boolean method_25404(int key, int scanCode, int modifiers) {
        return modals.keyPressed(key, scanCode, modifiers) || handleKeyPressed(key, scanCode, modifiers);
    }

    protected boolean handleKeyPressed(int key, int scanCode, int modifiers) {
        return super.method_25404(key, scanCode, modifiers);
    }

    @Override
    public final boolean method_25400(char character, int modifiers) {
        return modals.charTyped(character, modifiers) || handleCharTyped(character, modifiers);
    }

    protected boolean handleCharTyped(char character, int modifiers) {
        return super.method_25400(character, modifiers);
    }

    @Override
    public final void method_25393() {
        tickBeforeModals();
        modals.tick();
        tickScreen();
    }

    protected void tickBeforeModals() {
        ;;
    }

    protected void tickScreen() {
        super.method_25393();
    }

    protected record FooterAction(
            class_2561 label,
            Runnable press,
            boolean primary,
            int entranceDelay
    ) {

        protected FooterAction(class_2561 label, Runnable press, boolean primary) {
            this(label, press, primary, 0);
        }

    }

}