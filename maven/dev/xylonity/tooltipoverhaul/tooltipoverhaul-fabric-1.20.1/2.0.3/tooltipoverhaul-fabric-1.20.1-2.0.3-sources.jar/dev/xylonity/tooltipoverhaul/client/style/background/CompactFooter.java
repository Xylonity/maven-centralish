package dev.xylonity.tooltipoverhaul.client.style.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.BackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_332;

public class CompactFooter implements BackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int footerHeight = TooltipLayout.footerHeight(context);
        if (footerHeight == 0) {
            return;
        }

        final class_332 graphics = context.getGraphics();
        final int x = (int) position.field_1343;
        final int bottom = (int) (position.field_1342 + context.getTooltipSize().field_1342);
        final int right = (int) (position.field_1343 + context.getTooltipSize().field_1343);
        final int top = bottom - footerHeight + TooltipLayout.footerTopGap(context);
        final int[] colors = ColorUtils.getRenderedInnerOverlayColors(context);
        graphics.method_25296(x - 2, top, right + 1, bottom + 1, ColorUtils.mulAlpha(colors[1], 0.05f), ColorUtils.mulAlpha(colors[2], 0.12f));
        if (context.hasDividerLine()) {
            graphics.method_25294(x + context.getPaddingX(), top, right - context.getPaddingX(), top + 1, ColorUtils.mulAlpha(colors[2], 0.35f));
        }

    }

}