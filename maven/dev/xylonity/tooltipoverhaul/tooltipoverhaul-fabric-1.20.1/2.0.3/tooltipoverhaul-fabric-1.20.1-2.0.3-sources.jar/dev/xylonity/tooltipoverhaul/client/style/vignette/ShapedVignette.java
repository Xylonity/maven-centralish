package dev.xylonity.tooltipoverhaul.client.style.vignette;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.VignetteLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.vignette.parser.VignetteEntry;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.PositionUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public final class ShapedVignette implements VignetteLayer {

    private final VignetteEntry entry;

    public ShapedVignette(VignetteEntry entry) {
        this.entry = entry;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final float width = context.getTooltipSize().field_1343, height = context.getTooltipSize().field_1342;
        final float radius = width * entry.radius();
        if (!Float.isFinite(radius) || radius <= 0) {
            return;
        }

        final float x = position.field_1343 + PositionUtils.getVignettePosition(context, entry, TextAxis.X) + height * entry.extraPositionX() / 100f;
        final float y = position.field_1342 + PositionUtils.getVignettePosition(context, entry, TextAxis.Y) + width * entry.extraPositionY() / 100f;

        context.enableScissor((int) position.field_1343 - context.getPaddingX() - 1, (int) position.field_1342 - context.getPaddingY(), (int) (position.field_1343 + width) + context.getPaddingX(), (int) (position.field_1342 + height) + context.getPaddingY());

        context.translate(x, y, 0);

        context.flush();

        RenderSystem.enableBlend();

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(class_757::method_34540);
        try {
            final Matrix4f pose = context.getPose().method_23760().method_23761();
            final class_287 buffer = class_289.method_1348().method_1349();

            buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

            if (entry.type().equals("ring")) {
                band(buffer, pose, radius, 0.6f, 0.8f, 0, ColorUtils.alpha(entry.color()));
                band(buffer, pose, radius, 0.8f, 1f, ColorUtils.alpha(entry.color()), 0);
            }
            else {
                band(buffer, pose, radius, 0, 1, ColorUtils.alpha(entry.color()), 0);
            }

            class_286.method_43433(buffer.method_1326());
        }
        finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();

            RenderSystem.disableBlend();

            context.getGraphics().method_44380();
        }

    }

    private void band(class_287 buffer, Matrix4f pose, float radius, float inner, float outer, int innerAlpha, int outerAlpha) {
        final int segments = entry.type().equals("diamond") ? 4 : 64;
        final float aspect = entry.type().equals("ellipse") ? 0.5f : 1f;
        for (int i = 0; i < segments; i++) {
            final double from = i * Math.PI * 2 / segments, to = (i + 1) * Math.PI * 2 / segments;
            final float ax = (float) Math.cos(from) * radius, ay = (float) Math.sin(from) * radius * aspect;
            final float bx = (float) Math.cos(to) * radius, by = (float) Math.sin(to) * radius * aspect;
            vertex(buffer, pose, ax * inner, ay * inner, innerAlpha);
            vertex(buffer, pose, ax * outer, ay * outer, outerAlpha);
            vertex(buffer, pose, bx * outer, by * outer, outerAlpha);
            vertex(buffer, pose, bx * inner, by * inner, innerAlpha);
        }

    }

    private void vertex(class_287 buffer, Matrix4f pose, float x, float y, int alpha) {
        buffer.method_22918(pose, x, y, 0).method_1336(ColorUtils.red(entry.color()), ColorUtils.green(entry.color()), ColorUtils.blue(entry.color()), alpha).method_1344();
    }

}