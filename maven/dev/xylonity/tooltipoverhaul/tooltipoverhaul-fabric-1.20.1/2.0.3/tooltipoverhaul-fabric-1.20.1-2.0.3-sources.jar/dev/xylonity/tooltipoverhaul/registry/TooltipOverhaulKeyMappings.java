package dev.xylonity.tooltipoverhaul.registry;

import dev.xylonity.tooltipoverhaul.client.screen.config.TooltipOverhaulConfigScreen;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class TooltipOverhaulKeyMappings {

    public static final class_304 PIN_TOOLTIP = new class_304(
            "tooltipoverhaul.binds.pin_tooltip", class_3675.field_16237.method_1444(), "tooltipoverhaul.binds.category");

    public static final class_304 COMPARE_TOOLTIP = new class_304(
            "tooltipoverhaul.binds.compare_bind",
            class_3675.field_31951,
            "tooltipoverhaul.binds.category"
    );

    public static final class_304 OPEN_CONFIG = new class_304(
            "tooltipoverhaul.binds.open_config",
            class_3675.field_16237.method_1444(),
            "tooltipoverhaul.binds.category"
    );

    public static boolean handleConfigShortcut(class_310 client, int key, int scanCode) {
        if (client.field_1755 != null || !OPEN_CONFIG.method_1417(key, scanCode)) {
            return false;
        }

        client.method_1507(new TooltipOverhaulConfigScreen(null, TooltipsConfig.class));

        return true;
    }

    public static boolean handleConfigMouseShortcut(class_310 client, int button) {
        if (client.field_1755 != null || !OPEN_CONFIG.method_1433(button)) {
            return false;
        }

        client.method_1507(new TooltipOverhaulConfigScreen(null, TooltipsConfig.class));

        return true;
    }

}
