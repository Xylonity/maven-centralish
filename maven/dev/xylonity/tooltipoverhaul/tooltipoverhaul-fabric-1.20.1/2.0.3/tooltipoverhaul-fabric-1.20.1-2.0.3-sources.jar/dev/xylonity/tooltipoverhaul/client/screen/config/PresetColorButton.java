package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.config.parser.ConfigColorParser;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1074;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.*;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.formatHex;

final class PresetColorButton extends class_339 {

    private static final String CUSTOM = "custom";

    private final List<String> presets;
    private final int accent;
    private final ConfigModalHost modals;
    private final int screenWidth;
    private final int screenHeight;
    private String value;
    private float hoverAnimation;

    PresetColorButton(int x, int y, int width, int height, List<String> presets, String current, int accent, ConfigModalHost modals, int screenWidth, int screenHeight) {
        super(x, y, width, height, class_2561.method_43473());
        this.presets = List.copyOf(presets);
        this.accent = accent;
        this.modals = modals;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.value = current;
    }

    String getValue() {
        return value;
    }

    void setValue(String value) {
        this.value = value;
    }

    private boolean isPreset() {
        return presets.contains(value.trim().toLowerCase(Locale.ROOT));
    }

    private int currentArgb() {
        return isPreset() ? 0xFFFFFFFF : ConfigColorParser.parseColor(value.trim());
    }

    private static String presetLabel(String preset) {
        final String key = "tooltipoverhaul.config.frames.option." + preset;
        return class_1074.method_4663(key) ? class_1074.method_4662(key) : prettify(preset);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || button != 0 || !method_25361(mouseX, mouseY)) {
            return false;
        }

        final List<SelectionPopup.Option> choices = new ArrayList<>();
        for (final String preset : presets) {
            choices.add(new SelectionPopup.Option(preset, presetLabel(preset), "", class_1799.field_8037));
        }

        choices.add(new SelectionPopup.Option(CUSTOM, class_1074.method_4662("tooltipoverhaul.config.custom_color"), isPreset() ? "" : value.trim(), class_1799.field_8037));

        final String selected = isPreset() ? value.trim().toLowerCase(Locale.ROOT) : CUSTOM;
        modals.open(new SelectionPopup(screenWidth, screenHeight, class_2561.method_43471("tooltipoverhaul.config.frames.choose"), choices, selected::equals, this::select, false, accent));

        method_25354(class_310.method_1551().method_1483());

        return true;
    }

    private void select(String selected) {
        if (!selected.equals(CUSTOM)) {
            value = selected;
            return;
        }

        modals.open(new ColorLevelPicker(method_46426(), method_46427() + method_25364(), HEADER_HEIGHT + 4, screenWidth, screenHeight, accent, currentArgb(), false, argb -> value = formatHex(argb, false)));
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        final int x0 = method_46426();
        final int y0 = method_46427();
        final int width = method_25368();
        final int height = method_25364();
        final boolean hovering = mouseX >= x0 && mouseX < x0 + width && mouseY >= y0 && mouseY < y0 + height;
        hoverAnimation = hovering ? Math.min(1f, hoverAnimation + 0.15f) : Math.max(0f, hoverAnimation - 0.1f);
        drawCard(graphics, x0, y0, x0 + width, y0 + height, 0xFF18181A, buttonBorder(accent, hoverAnimation));

        final class_310 client = class_310.method_1551();
        final boolean preset = isPreset();
        String text = preset ? presetLabel(value.trim().toLowerCase(Locale.ROOT)) : value.trim().toUpperCase(Locale.ROOT);
        final int iconGap = 3;
        final int swatchSpace = preset ? 0 : 12 + iconGap;
        final int maximumLabelWidth = width - ConfigIconButton.Icon.EXPAND.width - iconGap - swatchSpace - 12;
        if (client.field_1772.method_1727(text) > maximumLabelWidth) {
            final int ellipsisWidth = client.field_1772.method_1727("\u2026");
            text = client.field_1772.method_27523(text, Math.max(4, maximumLabelWidth - ellipsisWidth)) + "\u2026";
        }

        final int contentWidth = swatchSpace + client.field_1772.method_1727(text) + iconGap + ConfigIconButton.Icon.EXPAND.width;
        int contentX = x0 + (width - contentWidth) / 2;
        if (!preset) {
            drawColorSwatch(graphics, contentX, y0 + (height - 12) / 2, 12, currentArgb(), accent, hovering, 0xFF);
            contentX += swatchSpace;
        }

        graphics.method_51433(client.field_1772, text, contentX, y0 + (height - client.field_1772.field_2000) / 2 + 1, 0xFFD0D0D0, false);
        ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.EXPAND, contentX + client.field_1772.method_1727(text) + iconGap, y0 + (height - ConfigIconButton.Icon.EXPAND.height) / 2, 0xFFD0D0D0);
    }

    @Override
    protected void method_47399(class_6382 output) {
        ;;
    }

}
