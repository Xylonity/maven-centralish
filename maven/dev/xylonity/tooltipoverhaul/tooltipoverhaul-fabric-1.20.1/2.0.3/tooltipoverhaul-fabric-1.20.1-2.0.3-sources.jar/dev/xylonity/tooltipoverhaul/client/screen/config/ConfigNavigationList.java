package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import javax.annotation.Nullable;
import net.minecraft.class_1074;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_5481;
import net.minecraft.class_6382;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawNotchedBorder;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.dimAccent;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.withAlpha;

/**
 * Navigation rail used by configuration categories
 */
class ConfigNavigationList<T> extends class_339 {

    private static final int TOP_PAD = 18;
    private static final long INDICATOR_MOVE_DURATION = 360L;
    private static final long INDICATOR_EXPAND_DURATION = 280L;

    private List<T> items;
    private final Adapter<T> adapter;
    private final int accent;
    private final Consumer<Integer> onSelect;
    private final @Nullable BiConsumer<Integer, Integer> onReorder;
    private final Map<T, Float> hoverAnimations = new IdentityHashMap<>();

    private int selected = -1;
    private boolean dimmed;
    private double scroll;

    private long revealStart = -1L;
    private float indicatorY = Float.NaN;
    private float indicatorStartY = Float.NaN;
    private float indicatorTargetY = Float.NaN;
    private long indicatorMoveStart;
    private long indicatorExpandStart;

    private int pressedIndex = -1;
    private double pressX;
    private double pressY;
    private double dragX;
    private double dragY;
    private boolean draggingEntry;
    private boolean draggingScrollbar;
    private double scrollbarDragOffset;
    private boolean reorderingEnabled = true;

    ConfigNavigationList(int x, int y, int width, int height, class_2561 title, int accent, List<T> items, Adapter<T> adapter, Consumer<Integer> onSelect) {
        this(x, y, width, height, title, accent, items, adapter, onSelect, null);
    }

    ConfigNavigationList(int x, int y, int width, int height, class_2561 title, int accent, List<T> items, Adapter<T> adapter, Consumer<Integer> onSelect, @Nullable BiConsumer<Integer, Integer> onReorder) {
        super(x, y, width, height, title);
        this.items = items;
        this.adapter = adapter;
        this.accent = accent;
        this.onSelect = onSelect;
        this.onReorder = onReorder;
    }

    void setBounds(int x, int y, int width, int height) {
        method_46421(x);
        method_46419(y);
        method_25358(width);
        this.field_22759 = height;
        clampScroll();
    }

    void setItems(List<T> items) {
        this.items = items;
        hoverAnimations.clear();
        reveal();
        selected = class_3532.method_15340(selected, -1, items.size() - 1);
        clampScroll();
    }

    void setSelectedIndex(int index) {
        final int next = class_3532.method_15340(index, -1, items.size() - 1);
        if (selected != next) {
            selected = next;
        }

    }

    int selectedIndex() {
        return selected;
    }

    void setDimmed(boolean dimmed) {
        this.dimmed = dimmed;
    }

    void setReorderingEnabled(boolean reorderingEnabled) {
        this.reorderingEnabled = reorderingEnabled;
        if (!reorderingEnabled) {
            cancelDrag();
        }

    }

    void reveal() {
        revealStart = -1L;
        resetIndicator();
    }

    void resetScroll() {
        scroll = 0;
    }

    void revealSelected() {
        if (selected < 0 || selected >= items.size()) {
            return;
        }

        final double middle = offsetOf(selected) + rowHeight(selected) / 2.0;
        scroll = class_3532.method_15350(middle - field_22759 / 2.0, 0, maxScroll());
    }

    void tickDrag() {
        if (!draggingEntry || pressedIndex < 0) {
            return;
        }

        if (dragX < method_46426() || dragX >= method_46426() + field_22758 || dragY < method_46427() || dragY >= method_46427() + field_22759) {
            return;
        }

        if (dragY < method_46427() + TOP_PAD + 16) {
            scroll = Math.max(0, scroll - 6);
        }

        if (dragY > method_46427() + field_22759 - 16) {
            scroll = Math.min(maxScroll(), scroll + 6);
        }

    }

    boolean isDraggingEntry() {
        return draggingEntry;
    }

    void cancelDrag() {
        pressedIndex = -1;
        draggingEntry = false;
        draggingScrollbar = false;
    }

    private int rowHeight(int index) {
        return adapter.rowHeight(items.get(index), index, Math.max(1, field_22758 - 12));
    }

    private int offsetOf(int index) {
        int offset = TOP_PAD;
        for (int i = 0; i < Math.min(index, items.size()); i++) {
            offset += rowHeight(i);
        }

        return offset;
    }

    private int contentHeight() {
        return offsetOf(items.size()) + 4;
    }

    private double maxScroll() {
        return Math.max(0, contentHeight() - field_22759);
    }

    private void clampScroll() {
        scroll = class_3532.method_15350(scroll, 0, maxScroll());
    }

    private @Nullable ConfigScroll.Geometry scrollbarGeometry() {
        return ConfigScroll.fromContent(method_46427(), method_46427() + field_22759, contentHeight(), scroll);
    }

    private int indexAt(double screenY) {
        final double contentY = screenY - method_46427() + scroll;
        int rowY = TOP_PAD;
        for (int i = 0; i < items.size(); i++) {
            int rowHeight = rowHeight(i);
            if (contentY >= rowY && contentY < rowY + rowHeight) {
                return i;
            }

            rowY += rowHeight;
        }

        return -1;
    }

    private int dropIndex(double x, double y) {
        if (pressedIndex < 0 || x < method_46426() || x >= method_46426() + field_22758 - 8 || y < method_46427() + TOP_PAD - 2 || y >= method_46427() + field_22759 - 2) {
            return -1;
        }

        return ConfigReorderLayout.destinationIndex(rowHeights(), pressedIndex, y - method_46427() + scroll, TOP_PAD);
    }

    private int visualY(int itemIndex, int gapIndex) {
        if (!draggingEntry) {
            return method_46427() + offsetOf(itemIndex) - (int) scroll;
        }

        return method_46427() + ConfigReorderLayout.itemOffset(rowHeights(), itemIndex, pressedIndex, gapIndex, TOP_PAD) - (int) scroll;
    }

    private List<Integer> rowHeights() {
        final List<Integer> heights = new ArrayList<>(items.size());
        for (int i = 0; i < items.size(); i++) {
            heights.add(rowHeight(i));
        }

        return heights;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (!field_22764) {
            return;
        }

        final long now = class_156.method_658();
        if (revealStart < 0L) {
            revealStart = now;
        }

        clampScroll();
        final int x0 = method_46426();
        final int y0 = method_46427();
        final int x1 = x0 + field_22758;
        final int y1 = y0 + field_22759;

        graphics.method_25294(x0, y0, x1, y1, 0xFF101010);

        for (int i = 0; i < 4; i++) {
            graphics.method_25294(x0, y0 + i, x1, y0 + i + 1, (Math.max(0, 30 - i * 8)) << 24);
        }

        drawNotchedBorder(graphics, x0, y0, x1, y1, 0xFF1C1C20);

        final float dim = dimmed ? 0.35f : 1f;
        graphics.method_51439(class_310.method_1551().field_1772, method_25369(), x0 + 8, y0 + 6, withAlpha(0x585858, (int) (0xFF * dim)), false);

        final int gapIndex = draggingEntry ? dropIndex(mouseX, mouseY) : -1;
        final int draggedHeight = pressedIndex >= 0 && pressedIndex < items.size() ? rowHeight(pressedIndex) : 0;

        graphics.method_44379(x0, y0 + TOP_PAD, x1, y1 - 2);
        renderIndicator(graphics, gapIndex, dim, now);

        int position = 0;
        for (int i = 0; i < items.size(); i++) {
            if (draggingEntry && i == pressedIndex) {
                continue;
            }

            if (draggingEntry && position == gapIndex) {
                final int gapY = method_46427() + ConfigReorderLayout.gapOffset(rowHeights(), pressedIndex, gapIndex, TOP_PAD) - (int) scroll;
                renderDropGap(graphics, gapY, draggedHeight);
            }

            final int rowY = visualY(i, gapIndex);
            renderRow(graphics, i, rowY, mouseX, mouseY, dim, false);
            position++;
        }

        if (draggingEntry && gapIndex == items.size() - 1) {
            final int gapY = method_46427() + ConfigReorderLayout.gapOffset(rowHeights(), pressedIndex, gapIndex, TOP_PAD) - (int) scroll;
            renderDropGap(graphics, gapY, draggedHeight);
        }

        if (items.isEmpty()) {
            final String empty = class_1074.method_4662("tooltipoverhaul.config.empty");
            graphics.method_51433(class_310.method_1551().field_1772, empty, x0 + (field_22758 - class_310.method_1551().field_1772.method_1727(empty)) / 2, (y0 + y1) / 2 - 4, 0xFF555555, false);
        }

        graphics.method_44380();

        ConfigScroll.render(graphics, x1, scrollbarGeometry(), accent, mouseX, mouseY, draggingScrollbar);

        if (draggingEntry && pressedIndex >= 0 && pressedIndex < items.size()) {
            final int floatingX = class_3532.method_15340(mouseX + 10, 2, Math.max(2, class_310.method_1551().method_22683().method_4486() - field_22758 - 2));
            int floatingY = class_3532.method_15340(mouseY - draggedHeight / 2, 2, class_310.method_1551().method_22683().method_4502() - draggedHeight - 2);
            graphics.method_51448().method_22903();

            graphics.method_51448().method_46416(0, 0, 500);
            renderRow(graphics, pressedIndex, floatingY, floatingX, floatingY, 1f, true, floatingX);

            graphics.method_51448().method_22909();
        }

    }

    private void renderIndicator(class_332 graphics, int gapIndex, float dim, long now) {
        if (selected < 0 || selected >= items.size() || (draggingEntry && selected == pressedIndex)) {
            resetIndicator();
            return;
        }

        final int selectedY = visualY(selected, gapIndex) - method_46427() + (int) scroll;
        if (Float.isNaN(indicatorY)) {
            indicatorY = indicatorStartY = indicatorTargetY = selectedY;
            indicatorMoveStart = indicatorExpandStart = now;
        }
        else if (Math.abs(selectedY - indicatorTargetY) > 0.01f) {
            indicatorStartY = indicatorY;
            indicatorTargetY = selectedY;
            indicatorMoveStart = now;
            indicatorExpandStart = now + INDICATOR_MOVE_DURATION;
        }

        final float move = class_3532.method_15363((now - indicatorMoveStart) / (float) INDICATOR_MOVE_DURATION, 0f, 1f);
        indicatorY = AnimationUtils.lerp(indicatorStartY, indicatorTargetY, AnimationUtils.easeInOutCubic(move));
        final float expand = AnimationUtils.easeOutCubic(class_3532.method_15363((now - indicatorExpandStart) / (float) INDICATOR_EXPAND_DURATION, 0f, 1f));
        final int indicatorWidth = 2 + Math.round((field_22758 - 8) * expand);
        final int y = method_46427() + Math.round(indicatorY) - (int) scroll;
        float entrance = entranceProgress(selected, now);
        graphics.method_25294(method_46426() + 3, y, Math.min(method_46426() + field_22758 - 3, method_46426() + 3 + indicatorWidth), y + rowHeight(selected) - 2, withAlpha(0x242428, (int) (0xFF * dim * entrance)));
    }

    private void resetIndicator() {
        indicatorY = indicatorStartY = indicatorTargetY = Float.NaN;
        indicatorMoveStart = indicatorExpandStart = 0;
    }

    private void renderDropGap(class_332 graphics, int y, int gapHeight) {
        final int top = y + 2;
        final int bottom = y + gapHeight - 4;
        if (bottom <= top) {
            return;
        }

        graphics.method_25294(method_46426() + 6, top, method_46426() + field_22758 - 8, bottom, withAlpha(dimAccent(accent), 0x18));
        drawNotchedBorder(graphics, method_46426() + 6, top, method_46426() + field_22758 - 8, bottom, withAlpha(dimAccent(accent), 0x80));
    }

    private void renderRow(class_332 graphics, int index, int rowY, int mouseX, int mouseY, float dim, boolean floating) {
        renderRow(graphics, index, rowY, mouseX, mouseY, dim, floating, method_46426());
    }

    private void renderRow(class_332 graphics, int index, int rowY, int mouseX, int mouseY, float dim, boolean floating, int originX) {
        final T item = items.get(index);
        final int rowHeight = rowHeight(index);
        if (!floating && (rowY + rowHeight < method_46427() + TOP_PAD || rowY > method_46427() + field_22759)) {
            return;
        }

        final long now = class_156.method_658();
        final float entrance = floating ? 1f : entranceProgress(index, now);
        final int slide = floating ? 0 : (int) ((1f - entrance) * -12f);
        final int left = originX + 3 + slide;
        final int right = originX + field_22758 - 3 + slide;
        final boolean isSelected = index == selected;
        boolean hovered = !dimmed && mouseX >= left && mouseX < right && mouseY >= rowY && mouseY < rowY + rowHeight - 2;
        final float hover = hoverAnimations.getOrDefault(item, 0f);
        final float nextHover = hover + ((hovered ? 1f : 0f) - hover) * 0.15f;
        hoverAnimations.put(item, nextHover);
        final float hoverEase = AnimationUtils.smoothstep(0f, 1f, nextHover);
        final int alpha = (int) (0xFF * entrance * dim);

        if (floating) {
            ConfigScreenStyle.drawCard(graphics, left, rowY, right, rowY + rowHeight - 2, 0xF022222A, dropIndex(dragX, dragY) >= 0 ? accent : 0xFF777783);
        }
        else if (!isSelected) {
            final int bgAlpha = (int) ((0x12 + 0x18 * hoverEase) * entrance * dim);
            graphics.method_25294(left, rowY, right, rowY + rowHeight - 2, (bgAlpha << 24) | 0x1A1A1A);
        }

        if (alpha < 0x10) {
            return;
        }

        final int leading = adapter.leadingWidth(item, index);
        final int trailing = adapter.trailingWidth(item, index);

        adapter.renderLeading(graphics, item, index, left + 5, rowY, rowHeight, alpha, isSelected, hovered);
        adapter.renderTrailing(graphics, item, index, right - 5, rowY, rowHeight, alpha, isSelected, hovered);

        final class_310 minecraft = class_310.method_1551();
        final int labelX = left + 7 + leading;
        final int labelRight = right - 7 - trailing;
        final class_2561 description = adapter.description(item, index);
        final int labelColor = isSelected ? 0xE8E8E8 : hovered ? 0xC8C8C8 : 0x808080;
        if (!description.getString().isEmpty()) {
            graphics.method_51433(minecraft.field_1772, minecraft.field_1772.method_27523(adapter.label(item, index).getString(), Math.max(4, labelRight - labelX)), labelX, rowY + 5, withAlpha(labelColor, alpha), false);
            graphics.method_51433(minecraft.field_1772, minecraft.field_1772.method_27523(description.getString(), Math.max(4, labelRight - labelX)), labelX, rowY + 16, withAlpha(0x777780, alpha), false);
        }
        else {
            final class_2561 label = adapter.label(item, index);
            if (adapter.wrapLabel(item, index)) {
                final List<class_5481> lines = new ArrayList<>(minecraft.field_1772.method_1728(label, Math.max(4, labelRight - labelX)));
                final int blockHeight = Math.max(minecraft.field_1772.field_2000, lines.size() * minecraft.field_1772.field_2000 + Math.max(0, lines.size() - 1));
                int labelY = rowY + (rowHeight - 2 - blockHeight) / 2;
                for (final class_5481 line : lines) {
                    graphics.method_51430(minecraft.field_1772, line, labelX, labelY, withAlpha(labelColor, alpha), false);
                    labelY += minecraft.field_1772.field_2000 + 1;
                }

            }
            else {
                final int labelY = rowY + (rowHeight - 2 - minecraft.field_1772.field_2000) / 2 + 1;
                if (minecraft.field_1772.method_27525(label) <= labelRight - labelX) {
                    graphics.method_51439(minecraft.field_1772, label, labelX, labelY, withAlpha(labelColor, alpha), false);
                }
                else {
                    method_49605(graphics, minecraft.field_1772, label, labelX, rowY, labelRight, rowY + rowHeight - 2, withAlpha(labelColor, alpha));
                }

            }

        }

    }

    private float entranceProgress(int index, long now) {
        return AnimationUtils.easeOutCubic(class_3532.method_15363((now - revealStart - index * 40L) / 180f, 0f, 1f));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22764 || !field_22763 || dimmed || mouseX < method_46426() || mouseX >= method_46426() + field_22758 || mouseY < method_46427() || mouseY >= method_46427() + field_22759) {
            return false;
        }

        final ConfigScroll.Geometry bar = scrollbarGeometry();
        if (button == 0 && bar != null && mouseX >= method_46426() + field_22758 - 8) {
            if (mouseY >= bar.thumbTop() && mouseY < bar.thumbTop() + bar.thumbHeight()) {
                draggingScrollbar = true;
                scrollbarDragOffset = mouseY - bar.thumbTop();
            }
            else {
                scroll = ConfigScroll.valueFromMouse(mouseY, bar, maxScroll());
            }

            return true;
        }

        final int index = indexAt(mouseY);
        if (button == 0 && index >= 0) {
            selected = index;
            onSelect.accept(index);

            method_25354(class_310.method_1551().method_1483());

            if (onReorder != null && reorderingEnabled) {
                pressedIndex = index;
                pressX = dragX = mouseX;
                pressY = dragY = mouseY;
                draggingEntry = false;
            }

            return true;
        }

        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingScrollbar && button == 0) {
            final ConfigScroll.Geometry bar = scrollbarGeometry();
            if (bar != null) {
                scroll = ConfigScroll.valueFromDrag(mouseY, scrollbarDragOffset, bar, maxScroll());
            }

            return true;
        }

        if (pressedIndex >= 0 && button == 0) {
            dragX = mouseX;
            dragY = mouseY;
            draggingEntry |= Math.hypot(mouseX - pressX, mouseY - pressY) > 3;
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (draggingScrollbar && button == 0) {
            draggingScrollbar = false;
            return true;
        }

        if (pressedIndex >= 0 && button == 0) {
            final int from = pressedIndex;
            final int target = dropIndex(mouseX, mouseY);
            final boolean wasDragging = draggingEntry;
            pressedIndex = -1;
            draggingEntry = false;
            if (wasDragging && target >= 0 && target != from && onReorder != null) {
                onReorder.accept(from, target);
                selected = class_3532.method_15340(target, -1, items.size() - 1);
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        if (!field_22764 || mouseX < method_46426() || mouseX >= method_46426() + field_22758 || mouseY < method_46427() || mouseY >= method_46427() + field_22759 || maxScroll() <= 0) {
            return false;
        }

        scroll = class_3532.method_15350(scroll - delta * 18, 0, maxScroll());
        return true;
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        ;;
    }

    interface Adapter<T> {

        class_2561 label(T item, int index);

        default class_2561 description(T item, int index) {
            return class_2561.method_43473();
        }

        default int rowHeight(T item, int index, int contentWidth) {
            return description(item, index).getString().isEmpty() ? 22 : 28;
        }

        default int leadingWidth(T item, int index) {
            return 0;
        }

        default int trailingWidth(T item, int index) {
            return 0;
        }

        default boolean wrapLabel(T item, int index) {
            return false;
        }

        default void renderLeading(class_332 graphics, T item, int index, int x, int y, int rowHeight, int alpha, boolean selected, boolean hovered) {
            ;;
        }

        default void renderTrailing(class_332 graphics, T item, int index, int right, int y, int rowHeight, int alpha, boolean selected, boolean hovered) {
            ;;
        }

    }

}
