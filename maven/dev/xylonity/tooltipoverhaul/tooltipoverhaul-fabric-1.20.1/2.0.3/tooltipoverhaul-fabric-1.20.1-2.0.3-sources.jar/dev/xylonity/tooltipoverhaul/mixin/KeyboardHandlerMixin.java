package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.render.PinnedTooltipState;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;

@Mixin(class_309.class)
public abstract class KeyboardHandlerMixin {

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void tooltipoverhaul$pin(long window, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        if (window == class_310.method_1551().method_22683().method_4490() && PinnedTooltipState.key(key, scanCode, action)) {
            ci.cancel();
            return;
        }

        if (window == class_310.method_1551().method_22683().method_4490() && action == GLFW.GLFW_PRESS && TooltipOverhaulKeyMappings.handleConfigShortcut(class_310.method_1551(), key, scanCode)) {
            ci.cancel();
        }

    }

}
