package dev.xylonity.tooltipoverhaul.client.style.divider;

import dev.xylonity.tooltipoverhaul.client.layer.impl.DividerLineLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;

public final class OrnamentDividerLine implements DividerLineLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int width = Math.max(0, (int) context.getTooltipSize().field_1343 - context.getPaddingX() * 2);
        final int left = (int) position.field_1343;
        final int right = left + width;
        final int y = (int) position.field_1342;
        final int center = left + width / 2;
        final int color = ColorUtils.getDividerLineColor(context);
        if (width < 9) {
            context.getGraphics().method_25294(left, y, right, y + 1, color);
            return;
        }

        context.getGraphics().method_25294(left, y, center - 3, y + 1, color);
        context.getGraphics().method_25294(center + 4, y, right, y + 1, color);

        // +
        context.getGraphics().method_25294(center - 1, y, center + 2, y + 1, color);
        context.getGraphics().method_25294(center, y - 1, center + 1, y, color);
        context.getGraphics().method_25294(center, y + 1, center + 1, y + 2, color);
    }

}
