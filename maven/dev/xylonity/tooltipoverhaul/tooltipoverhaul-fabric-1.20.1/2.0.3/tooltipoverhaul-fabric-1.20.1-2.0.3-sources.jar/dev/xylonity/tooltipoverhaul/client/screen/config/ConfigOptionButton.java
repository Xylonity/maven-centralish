package dev.xylonity.tooltipoverhaul.client.screen.config;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.*;

final class ConfigOptionButton<T> extends class_339 {

    private final List<T> options;
    private final int accent;
    private final Function<T, String> id;
    private final Function<T, String> label;
    private final Consumer<T> onChange;
    private final Runnable beforeOpen;
    private final ConfigModalHost modals;
    private final int screenWidth;
    private final int screenHeight;
    private int index;
    private float hoverAnimation;

    ConfigOptionButton(int x, int y, int width, int height, List<T> options, T current, int accent, Function<T, String> id, Function<T, String> label, Consumer<T> onChange, Runnable beforeOpen, ConfigModalHost modals, int screenWidth, int screenHeight) {
        super(x, y, width, height, class_2561.method_43473());
        if (options.isEmpty()) {
            throw new IllegalArgumentException("A configuration option button needs at least one option");
        }

        this.options = List.copyOf(options);
        this.accent = accent;
        this.id = id;
        this.label = label;
        this.onChange = onChange;
        this.beforeOpen = beforeOpen;
        this.modals = modals;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        setCurrent(current);
    }

    T getCurrent() {
        return options.get(index);
    }

    void setCurrent(Object value) {
        for (int i = 0; i < options.size(); i++) {
            if (Objects.equals(options.get(i), value)) {
                index = i;
                return;
            }

        }

    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || button != 0 || !method_25361(mouseX, mouseY)) {
            return false;
        }

        beforeOpen.run();

        final List<SelectionPopup.Option> choices = options.stream()
                .map(value -> new SelectionPopup.Option(id.apply(value), label.apply(value), "", class_1799.field_8037))
                .toList();
        modals.open(new SelectionPopup(screenWidth, screenHeight,
                class_2561.method_43471("tooltipoverhaul.config.frames.choose"), choices,
                value -> id.apply(getCurrent()).equals(value), this::select, false, accent));

        method_25354(class_310.method_1551().method_1483());

        return true;
    }

    private void select(String selectedId) {
        for (int i = 0; i < options.size(); i++) {
            final T option = options.get(i);
            if (id.apply(option).equals(selectedId)) {
                index = i;
                onChange.accept(option);
                return;
            }

        }

    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        final int x0 = method_46426();
        final int y0 = method_46427();
        final int width = method_25368();
        final int height = method_25364();
        final boolean hovering = mouseX >= x0 && mouseX < x0 + width && mouseY >= y0 && mouseY < y0 + height;
        hoverAnimation = hovering ? Math.min(1f, hoverAnimation + 0.15f) : Math.max(0f, hoverAnimation - 0.1f);
        final int border = buttonBorder(accent, hoverAnimation);
        drawCard(graphics, x0, y0, x0 + width, y0 + height, 0xFF18181A, border);

        final class_310 client = class_310.method_1551();
        final T value = getCurrent();
        String text = label.apply(value);
        final int iconGap = 3;
        final int maximumLabelWidth = width - ConfigIconButton.Icon.EXPAND.width - iconGap - 12;
        if (client.field_1772.method_1727(text) > maximumLabelWidth) {
            final int ellipsisWidth = client.field_1772.method_1727("\u2026");
            text = client.field_1772.method_27523(text, Math.max(4, maximumLabelWidth - ellipsisWidth)) + "\u2026";
        }

        final int textColor = "inherit".equals(id.apply(value)) ? 0xFF666666 : 0xFFD0D0D0;
        final int contentWidth = client.field_1772.method_1727(text) + iconGap + ConfigIconButton.Icon.EXPAND.width;
        final int contentX = x0 + (width - contentWidth) / 2;
        graphics.method_51433(client.field_1772, text, contentX, y0 + (height - client.field_1772.field_2000) / 2 + 1, textColor, false);
        ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.EXPAND, contentX + client.field_1772.method_1727(text) + iconGap, y0 + (height - ConfigIconButton.Icon.EXPAND.height) / 2, textColor);
    }

    @Override
    protected void method_47399(class_6382 output) {
        ;;
    }

}
