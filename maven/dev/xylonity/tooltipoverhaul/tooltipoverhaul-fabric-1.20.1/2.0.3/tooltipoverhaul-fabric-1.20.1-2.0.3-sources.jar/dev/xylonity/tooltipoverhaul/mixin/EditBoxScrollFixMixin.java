package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.screen.config.StyledEditBox;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * This should fix a white box randomly appearing at the right of some edit boxes
 */
@Mixin(class_342.class)
abstract class EditBoxScrollFixMixin {

    @Shadow private String value;
    @Shadow private int cursorPos;
    @Shadow private int highlightPos;
    @Shadow private int displayPos;
    @Shadow @Final private class_327 font;

    @Shadow public abstract int getInnerWidth();

    @Inject(method = "setHighlightPos", at = @At("TAIL"))
    private void tooltipoverhaul$keepCursorVisible(int position, CallbackInfo ci) {
        if (!(((Object) this) instanceof StyledEditBox) || cursorPos != highlightPos) {
            return;
        }

        int guard = 0;
        while (guard++ < 64 && cursorPos - displayPos > font.method_27523(value.substring(displayPos), getInnerWidth()).length()) {
            displayPos++;
        }

    }

    @Inject(method = "renderHighlight", at = @At("HEAD"), cancellable = true)
    private void tooltipoverhaul$skipHighlight(class_332 graphics, int minX, int minY, int maxX, int maxY, CallbackInfo ci) {
        if (((Object) this) instanceof StyledEditBox && cursorPos == highlightPos) {
            ci.cancel();
        }

    }

}
