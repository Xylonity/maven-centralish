package dev.xylonity.tooltipoverhaul.client.style.shadow;

import dev.xylonity.tooltipoverhaul.client.layer.impl.ShadowLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import net.minecraft.class_241;

public class DefaultShadow implements ShadowLayer {

    public static final int COLOR = 0x80000000;

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int x0 = (int) position.field_1343 - 1;
        final int y0 = (int) position.field_1342;
        final int x1 = (int) (position.field_1343 + context.getTooltipSize().field_1343 + 4);
        final int y1 = (int) (position.field_1342 + context.getTooltipSize().field_1342 + 4);

        final PreviewPanelDecorations.BackgroundCornerType corner = PreviewPanelDecorations.BackgroundCornerType.fromString(RenderUtils.getBackgroundCornerType(context));
        RenderUtils.fillBackgroundShape(context.getGraphics(), x0, y0, x1, y1, COLOR, corner);
    }

}
