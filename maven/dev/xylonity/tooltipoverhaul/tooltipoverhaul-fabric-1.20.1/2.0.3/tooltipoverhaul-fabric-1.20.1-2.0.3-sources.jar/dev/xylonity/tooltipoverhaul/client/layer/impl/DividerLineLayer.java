package dev.xylonity.tooltipoverhaul.client.layer.impl;

import dev.xylonity.tooltipoverhaul.client.layer.ITooltipLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.layer.LayerDepth;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_5684;

public interface DividerLineLayer extends ITooltipLayer {

    @Override
    default void renderInternal(TooltipContext context) {
        context.push(() -> {
            context.translate(0, 0, getLayerDepth().getZ());
            context.setLayerDepth(getLayerDepth());

            final boolean hasIcon = TooltipLayout.hasHeaderIcon(context);
            final boolean hasRating = RenderUtils.hasRating(context);

            int y = (int) context.getTooltipPosition().field_1342 + context.getPaddingY();
            final int x = (int) context.getTooltipPosition().field_1343 + context.getPaddingX();

            if (hasIcon || context.getLayoutStyle() == TooltipLayout.Style.COMPACT) {
                final int dividerLinetopPadding = Constants.getDividerLineTopPadding(context);
                y += TooltipLayout.headerHeight(context) + dividerLinetopPadding;
                if (dividerLinetopPadding > 1) {
                    y += Constants.getDividerLineHeight(context);
                }

            }
            else {
                final int titleHeight = context.getComponents().get(0).method_32661();
                y += titleHeight;

                // If there is a rating text present, adds its height
                if (hasRating) {
                    final class_2561 rating = TextUtils.getRatingText(context);
                    y += class_5684.method_32662(rating.method_30937()).method_32661();
                }

                y += Constants.getDividerLineTopPadding(context);

            }

            render(context, new class_241(x, y));
        });

    }

    @Override
    default LayerDepth getLayerDepth() {
        return LayerDepth.DIVIDER_LINE;
    }

}
