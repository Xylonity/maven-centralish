package dev.xylonity.tooltipoverhaul.client.screen.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.categoryLabel;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.withAlpha;

/**
 * Configuration navigation rail
 */
final class ConfigCategorySidebar extends ConfigNavigationList<ConfigCategorySidebar.Item> {

    private final List<Item> categories;

    ConfigCategorySidebar(int x, int y, int width, int height, int accent, Map<String, Integer> categoryCounts, int total, Consumer<String> onSelect) {
        this(x, y, width, height, accent, buildItems(categoryCounts, total), onSelect);
    }

    private ConfigCategorySidebar(int x, int y, int width, int height, int accent, List<Item> categories, Consumer<String> onSelect) {
        super(x, y, width, height,
                class_2561.method_43470(class_1074.method_4662("tooltipoverhaul.config.categories").toUpperCase(Locale.ROOT)),
                accent, categories, new Adapter<>() {
                    @Override
                    public class_2561 label(Item item, int index) {
                        return class_2561.method_43470(item.label());
                    }

                    @Override
                    public int rowHeight(Item item, int index, int contentWidth) {
                        return 22;
                    }

                    @Override
                    public int trailingWidth(Item item, int index) {
                        return class_310.method_1551().field_1772.method_1727(Integer.toString(item.count())) + 4;
                    }

                    @Override
                    public void renderTrailing(class_332 graphics, Item item, int index, int right, int y, int rowHeight, int alpha, boolean selected, boolean hovered) {
                        final String count = Integer.toString(item.count());
                        final int color = selected ? accent & 0x00FFFFFF : 0x505050;
                        graphics.method_51433(class_310.method_1551().field_1772, count, right - class_310.method_1551().field_1772.method_1727(count),
                                y + (rowHeight - 2 - class_310.method_1551().field_1772.field_2000) / 2 + 1, withAlpha(color, alpha), false);
                    }

                }, index -> onSelect.accept(categories.get(index).key()));

        this.categories = categories;

        setSelectedIndex(0);
    }

    void setSelectedKey(String key) {
        for (int i = 0; i < categories.size(); i++) {
            if (Objects.equals(categories.get(i).key(), key)) {
                setSelectedIndex(i);
                return;
            }

        }

        setSelectedIndex(0);
    }

    private static List<Item> buildItems(Map<String, Integer> categoryCounts, int total) {
        final List<Item> items = new ArrayList<>();

        items.add(new Item(null, class_1074.method_4662("tooltipoverhaul.config.category.all"), total));

        for (final Map.Entry<String, Integer> entry : categoryCounts.entrySet()) {
            items.add(new Item(entry.getKey(), categoryLabel(entry.getKey()), entry.getValue()));
        }

        return items;
    }

    record Item(
            String key,
            String label,
            int count
    ) {
        ;;
    }

}
