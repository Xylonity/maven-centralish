package dev.xylonity.tooltipoverhaul.client.style.divider;

import dev.xylonity.tooltipoverhaul.client.layer.impl.DividerLineLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;

public final class PatternDividerLine implements DividerLineLayer {

    private final int dash;
    private final int gap;

    public PatternDividerLine(int dash, int gap) {
        this.dash = dash;
        this.gap = gap;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int width = Math.max(0, (int) context.getTooltipSize().field_1343 - context.getPaddingX() * 2);
        final int count = Math.max(1, (width + gap) / (dash + gap));
        final int length = Math.min(width, count * (dash + gap) - gap);
        final int left = (int) position.field_1343 + (width - length) / 2;
        final int y = (int) position.field_1342;
        final int color = ColorUtils.getDividerLineColor(context);
        for (int offset = 0; offset < length; offset += dash + gap) {
            context.getGraphics().method_25294(left + offset, y, left + Math.min(length, offset + dash), y + 1, color);
        }

    }

}
