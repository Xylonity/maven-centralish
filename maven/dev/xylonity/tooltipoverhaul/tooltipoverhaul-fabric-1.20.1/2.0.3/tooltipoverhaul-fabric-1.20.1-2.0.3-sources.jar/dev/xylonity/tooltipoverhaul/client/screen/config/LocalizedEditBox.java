package dev.xylonity.tooltipoverhaul.client.screen.config;

import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

final class LocalizedEditBox extends StyledEditBox {

    private final class_327 font;

    LocalizedEditBox(class_327 font, int width, int accent) {
        super(font, 0, 0, width, 18, class_2561.method_43473(), accent);
        this.font = font;
    }

    private boolean showsTranslation() {
        final String key = method_1882();
        return !method_25370() && !key.isBlank() && class_1074.method_4663(key);
    }

    @Override
    protected int fieldBackgroundColor() {
        return showsTranslation() ? 0xFF29292E : super.fieldBackgroundColor();
    }

    @Override
    protected void renderFieldText(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (showsTranslation()) {
            graphics.method_51433(font, font.method_27523(class_1074.method_4662(method_1882()), method_1859()), method_46426(), method_46427(), 0xFFD0D0D0, false);
        }
        else {
            super.renderFieldText(graphics, mouseX, mouseY, partialTick);
        }

    }

}
