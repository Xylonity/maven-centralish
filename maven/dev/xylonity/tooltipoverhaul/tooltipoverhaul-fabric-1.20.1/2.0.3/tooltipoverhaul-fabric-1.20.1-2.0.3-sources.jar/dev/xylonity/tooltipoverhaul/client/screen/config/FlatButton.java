package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.buttonBorder;
import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.*;

class FlatButton extends class_4185 {

    private float hoverAnimation;
    private final int accent;
    private final boolean primary;
    private final long createdAt = class_156.method_658();
    private int entranceDelay;

    private int entranceAlpha = 0xFF;

    FlatButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress, int accent) {
        this(x, y, width, height, message, onPress, accent, false);
    }

    FlatButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress, int accent, boolean primary) {
        super(x, y, width, height, message, onPress, field_40754);
        this.accent = accent;
        this.primary = primary;
    }

    FlatButton withEntranceDelay(int delayMs) {
        entranceDelay = delayMs;
        return this;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        final float entrance = AnimationUtils.easeOutCubic(class_3532.method_15363((class_156.method_658() - createdAt - entranceDelay) / 180f, 0f, 1f));
        entranceAlpha = (int) (0xFF * entrance);
        if (entranceAlpha < 0x10) {
            return;
        }

        final int rise = (int) ((1f - entrance) * 4f);
        final int x0 = method_46426();
        final int y0 = method_46427() + rise;
        final int x1 = x0 + method_25368();
        final int y1 = y0 + method_25364();
        final boolean hovering = mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1;
        hoverAnimation = hovering ? Math.min(1f, hoverAnimation + 0.15f) : Math.max(0f, hoverAnimation - 0.1f);

        if (primary) {
            final int[] channels = rgb(accent);
            final float boost = 0.32f + hoverAnimation * 0.18f;
            int background = (entranceAlpha << 24) | ((int) (channels[0] * boost) << 16) | ((int) (channels[1] * boost) << 8) | (int) (channels[2] * boost);
            drawCard(graphics, x0, y0, x1, y1, background, withAlpha(accent, entranceAlpha));
        }
        else {
            final float eased = AnimationUtils.smoothstep(0f, 1f, hoverAnimation);
            drawCard(graphics, x0, y0, x1, y1, (entranceAlpha << 24) | mixRgb(0x161618, 0x1E1E22, eased), withAlpha(buttonBorder(accent, hoverAnimation), entranceAlpha));
        }

        final class_310 client = class_310.method_1551();
        final int textColor = !field_22763 ? 0x666666 : primary ? 0xFFFFFF : 0xD0D0D0;
        graphics.method_27534(client.field_1772, method_25369(), x0 + field_22758 / 2, y0 + (field_22759 - client.field_1772.field_2000) / 2 + 1, withAlpha(textColor, entranceAlpha));
    }

}