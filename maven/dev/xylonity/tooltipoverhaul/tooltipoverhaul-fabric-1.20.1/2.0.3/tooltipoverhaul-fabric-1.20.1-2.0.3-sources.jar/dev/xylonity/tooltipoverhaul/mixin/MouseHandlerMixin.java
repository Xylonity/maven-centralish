package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import dev.xylonity.tooltipoverhaul.client.render.PinnedTooltipState;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;

@Mixin(value = class_312.class, priority = 1)
public abstract class MouseHandlerMixin {

    @Unique
    private static double tooltipoverhaul$deferredDy = Double.NaN;

    private static double tooltipoverhaul$mouseX(class_310 client) {
        return client.field_1729.method_1603() * client.method_22683().method_4486() / client.method_22683().method_4480();
    }

    private static double tooltipoverhaul$mouseY(class_310 client) {
        return client.field_1729.method_1604() * client.method_22683().method_4502() / client.method_22683().method_4507();
    }

    @Inject(method = "onPress", at = @At("HEAD"), cancellable = true)
    private void tooltipoverhaul$onPress(long window, int button, int action, int modifiers, CallbackInfo ci) {
        final class_310 client = class_310.method_1551();
        if (window == client.method_22683().method_4490() && PinnedTooltipState.mouseButton(tooltipoverhaul$mouseX(client), tooltipoverhaul$mouseY(client), button, action)) {
            ci.cancel();
            return;
        }

        if (window == client.method_22683().method_4490() && action == GLFW.GLFW_PRESS && TooltipOverhaulKeyMappings.handleConfigMouseShortcut(client, button)) {
            ci.cancel();
        }

    }

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void tooltipoverhaul$onScroll(long window, double dx, double dy, CallbackInfo ci) {
        final class_310 minecraft = class_310.method_1551();
        tooltipoverhaul$deferredDy = Double.NaN;
        if (window != minecraft.method_22683().method_4490()) {
            return;
        }

        if (PinnedTooltipState.scroll(tooltipoverhaul$mouseX(minecraft), tooltipoverhaul$mouseY(minecraft), dy)) {
            ci.cancel();
            return;
        }

        if (minecraft.field_1755 == null) {
            if (TooltipScrollState.isIsActive()) {
                TooltipScrollState.reset();
            }

            return;
        }

        if (TooltipScrollState.shouldCaptureScroll()) {
            // issue #33
            //  if (tooltipoverhaul$hoveredStackHasImage(minecraft.screen)) {
            //      tooltipoverhaul$deferredDy = dy;
            //      return;
            //  }

            TooltipScrollState.onRawScroll(dy);
            ci.cancel();
        }

    }

     // issue #33
     // @Redirect(method = "onScroll", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseScrolled(DDD)Z"), require = 0)
     // private boolean tooltipoverhaul$screenScrolled(Screen screen, double mouseX, double mouseY, double delta) {
     //     final boolean consumed = screen.mouseScrolled(mouseX, mouseY, delta);
     //     final double dy = tooltipoverhaul$deferredDy;
     //     tooltipoverhaul$deferredDy = Double.NaN;
     //     if (!consumed && !Double.isNaN(dy) && TooltipScrollState.shouldCaptureScroll()) {
     //         TooltipScrollState.onRawScroll(dy);
     //     }
     //
     //     return consumed;
     // }

    @Unique
    private static boolean tooltipoverhaul$hoveredStackHasImage(class_437 screen) {
        if (!(screen instanceof class_465<?> container) || screen instanceof class_481) {
            return false;
        }

        try {
            final class_1735 slot = ((AbstractContainerScreenMixin) container).getHoveredSlot();
            return slot != null && slot.method_7681() && slot.method_7677().method_32347().isPresent();
        }
        catch (Throwable ignored) {
            return false;
        }

    }

}
