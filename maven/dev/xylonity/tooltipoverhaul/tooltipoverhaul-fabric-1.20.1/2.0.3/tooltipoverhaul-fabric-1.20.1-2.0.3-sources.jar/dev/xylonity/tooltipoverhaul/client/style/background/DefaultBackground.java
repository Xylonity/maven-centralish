package dev.xylonity.tooltipoverhaul.client.style.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.BackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import net.minecraft.class_241;

public class DefaultBackground implements BackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int x0 = (int) (position.field_1343 - 3);
        final int y0 = (int) (position.field_1342 - 2);
        final int x1 = (int) (position.field_1343 + context.getTooltipSize().field_1343 + 2);
        final int y1 = (int) (position.field_1342 + context.getTooltipSize().field_1342 + 2);

        final int backgroundColor = ColorUtils.getBackgroundColor(context);
        final PreviewPanelDecorations.BackgroundCornerType corner = PreviewPanelDecorations.BackgroundCornerType.fromString(RenderUtils.getBackgroundCornerType(context));

        RenderUtils.fillBackgroundShape(context.getGraphics(), x0, y0, x1, y1, backgroundColor, corner);
    }

}
