package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.render.PinnedTooltipState;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftMixin {

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void tooltipoverhaul$onSetScreen(class_437 screen, CallbackInfo ci) {
        PinnedTooltipState.screenChanged(screen);
        TooltipScrollState.reset();
    }

}
