package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import java.util.function.Predicate;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.dimAccent;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.mixRgb;

public class StyledEditBox extends class_342 {

    private float focusAnimation;
    private float expandAnimation;
    private int baseWidth;
    private final int accent;
    private Predicate<String> validator = raw -> true;

    StyledEditBox(class_327 font, int x, int y, int width, int height, class_2561 message, int accent) {
        super(font, x, y, width, height, message);
        this.baseWidth = width;
        this.accent = accent;
        method_1858(false);
        method_1868(0xFFD0D0D0);
        method_1860(0xFF666666);
        method_1880(512);
    }

    void setValidator(Predicate<String> validator) {
        this.validator = validator;
    }

    void setBaseWidth(int width) {
        baseWidth = Math.max(1, width);
        if (!method_25370()) {
            method_25358(baseWidth);
        }

    }

    @Override
    public void method_1852(String text) {
        super.method_1852(text);
        if (!method_25370()) {
            method_1875(0);
            method_1884(0);
        }

    }

    int layoutWidth(int expandedMax) {
        final float target = method_25370() ? 1f : 0f;
        expandAnimation += (target - expandAnimation) * 0.2f;
        if (Math.abs(target - expandAnimation) < 0.01f) {
            expandAnimation = target;
        }

        if (expandedMax <= baseWidth || expandAnimation <= 0f) {
            return baseWidth;
        }

        return baseWidth + (int) ((expandedMax - baseWidth) * AnimationUtils.smoothstep(0f, 1f, expandAnimation));
    }

    float expandProgress() {
        return AnimationUtils.smoothstep(0f, 1f, expandAnimation);
    }

    @Override
    public int method_1859() {
        return field_22758 - 12;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        final int x0 = method_46426();
        final int y0 = method_46427();
        final int x1 = x0 + method_25368();
        final int y1 = y0 + method_25364();
        final boolean engaged = mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1 || method_25370();
        focusAnimation = engaged ? Math.min(1f, focusAnimation + 0.15f) : Math.max(0f, focusAnimation - 0.1f);

        final boolean valid = validator.test(method_1882());
        final int borderTarget = method_25370() ? accent & 0x00FFFFFF : dimAccent(accent);
        final int border = valid ? 0xFF000000 | mixRgb(0x3A3A3E, borderTarget, focusAnimation) : 0xFFCC4444;
        drawCard(graphics, x0, y0, x1, y1, valid ? 0xFF161618 : 0xFF221214, border);

        final int offsetY = (field_22759 - class_310.method_1551().field_1772.field_2000) / 2 + 1;
        final int paddingX = 5;

        graphics.method_44379(x0 + 1, y0 + 1, x1 - 1, y1 - 1);
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(paddingX, offsetY, 0);

        super.method_48579(graphics, mouseX - paddingX, mouseY - offsetY, partialTick);

        graphics.method_51448().method_22909();
        graphics.method_44380();
    }

}
