package dev.xylonity.tooltipoverhaul.client.screen.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameLoader;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameSource;
import dev.xylonity.tooltipoverhaul.client.frame.FrameTemplates;
import dev.xylonity.tooltipoverhaul.client.screen.config.FrameFieldSchema.FieldSpec;
import dev.xylonity.tooltipoverhaul.client.screen.config.FrameFieldSchema.Kind;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import dev.xylonity.tooltipoverhaul.config.parser.ConfigColorParser;
import org.lwjgl.glfw.GLFW;

import javax.annotation.Nullable;
import net.minecraft.class_1011;
import net.minecraft.class_1074;
import net.minecraft.class_156;
import net.minecraft.class_1772;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1889;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.io.InputStream;
import java.util.*;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.*;
import static dev.xylonity.tooltipoverhaul.client.screen.config.FrameFieldSchema.*;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.*;

/**
 * Visual editor shared by user, mod and resourcepack custom frame values
 */
public class FrameEditorScreen extends AbstractConfigScreen {

    private static final int HEADER_HEIGHT = ConfigScreenStyle.HEADER_HEIGHT;
    private static final int FOOTER_HEIGHT = 32;
    private static final int MAX_LIST_COLORS = 3;

    private final FrameEditorDocument document;
    private final CustomFrameSource source;
    private final JsonObject root;
    private final List<JsonObject> frameEntries;
    private final List<JsonObject> templateEntries;
    private List<JsonObject> entries;
    private boolean editingTemplates;
    private String searchQuery = "";
    private String validationError = "";
    private int selected = -1;
    private boolean dirty = false;
    private long nextDraftSaveAt;
    private String draftError = "";
    private final boolean loadFailed;

    private final List<FieldRow> rows = new ArrayList<>();
    private final List<FieldRow> visibleRows = new ArrayList<>();
    private double formScroll = 0;
    private @Nullable ConfigNavigationList<JsonObject> entryList;
    private @Nullable SearchBox searchBox;
    private @Nullable class_342 focusedBox = null;

    private final ConfigThreePaneLayout panelLayout = new ConfigThreePaneLayout(10, 8, HEADER_HEIGHT + 6,
            FOOTER_HEIGHT + 26, FOOTER_HEIGHT + 4, 130, 96, 220, 140);

    private boolean draggingListSplitter = false;
    private boolean draggingPreviewSplitter = false;
    private @Nullable ConfigIconButton createEntryButton = null;
    private @Nullable ConfigIconButton cloneEntryButton = null;
    private @Nullable ConfigIconButton deleteEntryButton = null;
    private @Nullable ConfigIconButton libraryEntryButton = null;

    private final FramePreviewPanel previewPanel = new FramePreviewPanel(accent);

    // Scrollbar dragging
    private boolean draggingFormBar = false;
    private double barDragOffset = 0;

    // Field and color index the open picker writes into
    private @Nullable FieldRow pickerRow = null;
    private int pickerPartIndex = -1;

    // Field help tooltip
    private @Nullable FieldRow hoveredRow = null;

    private boolean swatchHintHovered;
    private long hoveredRowSince = 0;
    private int hoverMouseX;
    private int hoverMouseY;

    private long formRevealAt = -1L;
    private long savedFlashAt = 0;

    private static final String[] BOOL_OPTIONS = { "inherit", "true", "false" };

    public FrameEditorScreen(class_437 parent, int accent) {
        this(parent, accent, CustomFrameLoader.discoverSources(class_310.method_1551().method_1478(), TooltipOverhaul.PLATFORM.getConfigPath()).get(0));
    }

    public FrameEditorScreen(class_437 parent, int accent, CustomFrameSource source) {
        super(class_2561.method_43470("Tooltip Overhaul"), parent, accent);
        this.source = source;
        this.document = new FrameEditorDocument(source);
        this.root = document.root();
        this.frameEntries = document.frames();
        this.templateEntries = document.templates();
        this.entries = frameEntries;
        this.loadFailed = document.loadFailed();
        this.dirty = document.hasDraft();
        if (!entries.isEmpty()) {
            select(0);
        }

    }

    private void save() {
        if (loadFailed) {
            return;
        }

        String error = document.save();
        if (error != null) {
            validationError = error;
            return;
        }

        validationError = "";
        dirty = false;
        draftError = "";
        savedFlashAt = class_156.method_658();
        CustomFrameManager.reset();
        CustomFrameManager.initialize();
    }

    private void syncRoot() {
        document.syncRoot();
    }

    private JsonObject selectedEntry() {
        return selected >= 0 && selected < entries.size() ? entries.get(selected) : null;
    }

    private void extractTemplate() {
        if (editingTemplates || selectedEntry() == null) {
            return;
        }

        applyFocused();
        JsonObject entry = selectedEntry();
        String name = uniqueTemplateName("style");

        final JsonObject style = FrameTemplates.styleOf(entry);
        for (String key : new ArrayList<>(style.keySet())) {
            entry.remove(key);
        }

        style.addProperty("name", name);
        templateEntries.add(style);
        entry.addProperty("extends", name);

        markDirty();
        rebuildRows();
    }

    private String uniqueTemplateName(String base) {
        Set<String> names = new HashSet<>();
        for (JsonObject template : templateEntries) {
            if (template.has("name")) {
                names.add(template.get("name").getAsString());
            }

        }

        String name = base;
        for (int i = 2; names.contains(name); i++) {
            name = base + "_" + i;
        }

        return name;
    }

    private String[] templateOptions(JsonObject entry) {
        final List<String> names = new ArrayList<>(List.of("inherit"));
        for (JsonObject template : templateEntries) {
            if (template != entry && template.has("name")) {
                names.add(template.get("name").getAsString());
            }

        }

        if (entry.has("extends") && !names.contains(entry.get("extends").getAsString())) {
            names.add(entry.get("extends").getAsString());
        }

        return names.toArray(String[]::new);
    }

    private void moveEntry(int target) {
        if (selected < 0 || target == selected || target < 0 || target >= entries.size()) {
            return;
        }

        final JsonObject entry = entries.remove(selected);
        entries.add(target, entry);
        selected = target;
        if (!editingTemplates) {
            for (int i = 0; i < entries.size(); i++) {
                entries.get(i).addProperty("priority", entries.size() - i);
            }

        }

        markDirty();
    }

    private static int identityIndexOf(List<JsonObject> haystack, @Nullable JsonObject needle) {
        if (needle == null) {
            return -1;
        }

        for (int i = 0; i < haystack.size(); i++) {
            if (haystack.get(i) == needle) {
                return i;
            }

        }

        return -1;
    }

    private void refreshEntryList(boolean resetScroll) {
        if (entryList == null) {
            return;
        }

        entryList.setItems(entries);
        entryList.setReorderingEnabled(true);
        entryList.setSelectedIndex(selected);
        if (resetScroll) {
            entryList.resetScroll();
        }

    }

    private void select(int index) {
        selected = class_3532.method_15340(index, -1, entries.size() - 1);
        formRevealAt = -1L;
        formScroll = 0;
        focusedBox = null;
        modals.clear();
        previewPanel.resetViewAndAnimations();
        if (entryList != null) {
            entryList.setSelectedIndex(selected);
        }

        rebuildRows();
        refreshPreview();
    }

    private void markDirty() {
        dirty = true;
        refreshPreview();
    }

    private void refreshPreview() {
        syncRoot();
        validationError = previewPanel.refresh(root, selectedEntry());
    }

    private class_1799 resolveListStack(JsonObject entry) {
        return previewPanel.stackFor(entry);
    }

    private int listLeft() {
        return panelLayout.left();
    }

    private int listTop() {
        return panelLayout.top();
    }

    private int listBottom() {
        return panelLayout.leftBottom();
    }

    private int listWidth() {
        return panelLayout.leftWidth();
    }

    private int previewWidth() {
        return panelLayout.rightWidth();
    }

    private int previewLeft() {
        return panelLayout.rightLeft();
    }

    private int formLeft() {
        return panelLayout.centerLeft();
    }

    private int formRight() {
        return panelLayout.centerRight();
    }

    private int listSplitterX() {
        return panelLayout.leftSplitter();
    }

    private int previewSplitterX() {
        return panelLayout.rightSplitter();
    }

    private boolean overListSplitter(double mouseX, double mouseY) {
        return panelLayout.overLeftSplitter(mouseX, mouseY);
    }

    private boolean overPreviewSplitter(double mouseX, double mouseY) {
        return panelLayout.overRightSplitter(mouseX, mouseY);
    }

    private void clampPanelWidths() {
        panelLayout.resize(field_22789, field_22790);
    }

    private int formTop() {
        return panelLayout.top();
    }

    private int formBottom() {
        return panelLayout.contentBottom();
    }

    @Override
    protected void initScreen() {
        draggingListSplitter = false;
        draggingPreviewSplitter = false;
        clampPanelWidths();
        rebuildRows();
        entryList = createEntryList();

        addCenteredFooterButtons(92, 8,
                new FooterAction(class_2561.method_43471("tooltipoverhaul.config.frames.save"), () -> {applyFocused();save();}, true),
                new FooterAction(class_2561.method_43471("tooltipoverhaul.config.frames.back"), this::method_25419, false)
        );

        final int manageY = listBottom() + 4;
        final int buttonWidth = Math.max(1, (listWidth() - 12) / 4);
        libraryEntryButton = method_37063(new ConfigIconButton(listLeft() + (buttonWidth + 4) * 3, manageY, buttonWidth, ConfigIconButton.Icon.TEMPLATES,
                class_2561.method_43471("tooltipoverhaul.config.frames.templates_hint"), button -> {
            applyFocused();
            editingTemplates = !editingTemplates;
            entries = editingTemplates ? templateEntries : frameEntries;
            refreshEntryList(true);
            select(entries.isEmpty() ? -1 : 0);
        }, accent));
        libraryEntryButton.method_47400(class_7919.method_47407(class_2561.method_43471("tooltipoverhaul.config.frames.templates_hint")));

        createEntryButton = method_37063(new ConfigIconButton(listLeft(), manageY, buttonWidth, ConfigIconButton.Icon.ADD,
                class_2561.method_43471("tooltipoverhaul.config.frames.create"), button -> {
            JsonObject entry = new JsonObject();
            if (editingTemplates) {
                entry.addProperty("name", uniqueTemplateName("style"));
            }
            else {
                entry.add("items", new JsonArray());
            }

            entries.add(entry);
            dirty = true;
            refreshEntryList(false);
            entryList.reveal();
            select(entries.size() - 1);
        }, accent));

        cloneEntryButton = method_37063(new ConfigIconButton(listLeft() + buttonWidth + 4, manageY, buttonWidth, ConfigIconButton.Icon.COPY,
                class_2561.method_43471("tooltipoverhaul.config.frames.clone"), button -> {
            JsonObject entry = selectedEntry();
            if (entry != null) {
                final JsonObject copy = entry.deepCopy();
                copy.remove("id");
                if (editingTemplates) {
                    copy.addProperty("name", uniqueTemplateName(entry.get("name").getAsString()));
                }

                entries.add(selected + 1, copy);
                dirty = true;
                refreshEntryList(false);
                entryList.reveal();
                select(selected + 1);
            }

        }, accent));

        deleteEntryButton = method_37063(new ConfigIconButton(listLeft() + (buttonWidth + 4) * 2, manageY, buttonWidth, ConfigIconButton.Icon.TRASH,
                class_2561.method_43471("tooltipoverhaul.config.frames.delete"), button -> {
            if (selected >= 0 && selected < entries.size()) {
                entries.remove(selected);
                dirty = true;
                refreshEntryList(false);
                select(Math.min(selected, entries.size() - 1));
            }

        }, accent));

        final int searchWidth = Math.min(200, this.field_22789 / 3);
        final int searchX = this.field_22789 - searchWidth - 14;
        final int searchY = (HEADER_HEIGHT - 16) / 2 - 1;
        searchBox = new SearchBox(field_22793, searchX, searchY, searchWidth, 16, accent);
        searchBox.method_1863(query -> {
            searchQuery = query;
            rebuildVisibleRows();
            formScroll = 0;
            formRevealAt = -1L;
            hoveredRow = null;
        });

        method_37063(searchBox);

        if (!searchQuery.isEmpty()) {
            searchBox.method_1852(searchQuery);
        }

        layoutEntryButtons();

    }

    private ConfigNavigationList<JsonObject> createEntryList() {
        ConfigNavigationList.Adapter<JsonObject> adapter = new ConfigNavigationList.Adapter<>() {

            @Override
            public class_2561 label(JsonObject entry, int index) {
                final int sourceIndex = identityIndexOf(entries, entry);
                return class_2561.method_43470(labelFor(entry, sourceIndex >= 0 ? sourceIndex : index));
            }

            @Override
            public int rowHeight(JsonObject entry, int index, int contentWidth) {
                final int textWidth = Math.max(4, contentWidth - 42);
                int lines = Math.max(1, field_22793.method_1728(label(entry, index), textWidth).size());
                return Math.max(22, lines * field_22793.field_2000 + Math.max(0, lines - 1) + 6);
            }

            @Override
            public int leadingWidth(JsonObject entry, int index) {
                return 20;
            }

            @Override
            public int trailingWidth(JsonObject entry, int index) {
                return 14;
            }

            @Override
            public boolean wrapLabel(JsonObject entry, int index) {
                return true;
            }

            @Override
            public void renderLeading(class_332 graphics, JsonObject entry, int index, int x, int y, int rowHeight, int alpha, boolean selected, boolean hovered) {
                previewPanel.renderListIcon(graphics, entry, x, y + (rowHeight - 2 - 16) / 2, alpha / 255f);
            }

            @Override
            public void renderTrailing(class_332 graphics, JsonObject entry, int index, int right, int y, int rowHeight, int alpha, boolean selected, boolean hovered) {
                ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.ALIGN, right - ConfigIconButton.Icon.ALIGN.width, y + (rowHeight - ConfigIconButton.Icon.ALIGN.height) / 2, withAlpha(selected ? accent : 0x505050, alpha));
            }

        };
        ConfigNavigationList<JsonObject> list = new ConfigNavigationList<>(listLeft(), listTop(), listWidth(), listBottom() - listTop(), class_2561.method_43470(class_1074.method_4662("tooltipoverhaul.config.frames.entries").toUpperCase(Locale.ROOT)),
                accent, entries, adapter, index -> {
            applyFocused();
            if (index >= 0 && index < entries.size()) {
                select(index);
            }

        }, (from, target) -> {
            moveEntry(target);
            rebuildRows();
        });

        list.setReorderingEnabled(true);
        list.setSelectedIndex(selected);

        return list;
    }

    private void layoutEntryButtons() {
        if (createEntryButton == null || cloneEntryButton == null || deleteEntryButton == null || libraryEntryButton == null) {
            return;
        }

        final int buttonWidth = Math.max(1, (listWidth() - 12) / 4);
        final int y = listBottom() + 4;
        final ConfigIconButton[] buttons = { createEntryButton, cloneEntryButton, deleteEntryButton, libraryEntryButton };
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].method_46421(listLeft() + (buttonWidth + 4) * i);
            buttons[i].method_46419(y);
            buttons[i].method_25358(buttonWidth);
        }

    }

    private final class FieldRow extends ConfigFormEntry {

        final @Nullable FieldSpec spec;
        final @Nullable String section;
        final String searchIndex;

        final @Nullable JsonObject entry;
        @Nullable ConfigIconButton replay;

        final List<int[]> swatchHits = new ArrayList<>();

        FieldRow(String section) {
            this.spec = null;
            this.section = section;
            this.entry = null;
            this.searchIndex = normalizeSearch(section + " " + class_1074.method_4662("tooltipoverhaul.config.frames.section." + section));
            initialize(class_2561.method_43473(), "", null, section, FrameEditorScreen.this.accent, 20);
        }

        FieldRow(FieldSpec spec, JsonObject entry, String containingSection) {
            super(class_2561.method_43470(fieldLabel(spec.key())), fieldDescription(spec.key()), null, spec.key(), FrameEditorScreen.this.accent, 32);
            this.spec = spec;
            this.section = null;
            this.entry = entry;
            this.searchIndex = normalizeSearch(spec.key() + " " + fieldLabel(spec.key()) + " "
                    + fieldDescription(spec.key()) + " " + containingSection + " " + class_1074.method_4662("tooltipoverhaul.config.frames.section." + containingSection));

            if (spec.key().equals("createTemplate")) {
                this.widget = new FlatButton(0, 0, widgetWidth(), 18, class_2561.method_43471("tooltipoverhaul.config.frames.extract_template"), button -> extractTemplate(), accent);
            }
            else if (spec.key().equals("specialEffect")) {
                this.widget = new FlatButton(0, 0, widgetWidth(), 18, class_2561.method_43471("tooltipoverhaul.config.frames.effect_editor"), button -> {
                    applyFocused();
                    syncRoot();
                    try {
                        field_22787.method_1507(new EffectEditorScreen(FrameEditorScreen.this, root, entry, previewPanel.selectedStack(), accent, draft -> {
                            for (String key : List.of("specialEffect", "effectSettings")) {
                                if (draft.has(key)) {
                                    entry.add(key, draft.get(key).deepCopy());
                                }
                                else {
                                    entry.remove(key);
                                }

                            }

                            markDirty();
                        }));

                    }
                    catch (RuntimeException exception) {
                        validationError = exception.getMessage();
                    }

                }, accent);
            }
            else if (spec.key().equals("vignettes")) {
                this.widget = new FlatButton(0, 0, widgetWidth(), 18, class_2561.method_43471("tooltipoverhaul.config.frames.vignette_editor"), button -> {
                    applyFocused();
                    syncRoot();
                    try {
                        field_22787.method_1507(new VignetteEditorScreen(FrameEditorScreen.this, root, entry, previewPanel.selectedStack(), accent, draft -> {
                            if (draft.has("vignettes")) {
                                entry.add("vignettes", draft.get("vignettes").deepCopy());
                            }
                            else {
                                entry.remove("vignettes");
                            }

                            markDirty();
                        }));

                    }
                    catch (RuntimeException exception) {
                        validationError = exception.getMessage();
                    }

                }, accent);
            }
            else if (spec.kind() == Kind.BOOL || spec.kind() == Kind.CHOICE) {
                final String[] options = spec.key().equals("extends") ? templateOptions(entry) : spec.kind() == Kind.BOOL ? BOOL_OPTIONS : withInherit(spec.options());
                this.widget = new ConfigOptionButton<>(0, 0, widgetWidth(), 18,
                        Arrays.asList(options), readChoice(entry, spec, options), accent,
                        value -> value, FrameEditorScreen::optionLabel,
                        value -> writeChoice(entry, spec, value), () -> { }, modals,
                        FrameEditorScreen.this.field_22789, FrameEditorScreen.this.field_22790);
            }
            else {
                final StyledEditBox box = new StyledEditBox(field_22787.field_1772, 0, 0, widgetWidth(), 18, class_2561.method_43473(), accent);
                box.method_1880(spec.kind() == Kind.LIST ? 32767 : 1024);
                box.method_1852(readText(entry, spec));
                box.method_1863(value -> writeText(entry, spec, value));
                this.widget = box;
            }

            if (spec.key().equals("tooltipAppearAnimation") || spec.key().equals("tooltipDisappearAnimation") || spec.key().equals("iconAppearAnimation")) {
                replay = new ConfigIconButton(0, 0, 18, ConfigIconButton.Icon.PLAY,
                        class_2561.method_43471("tooltipoverhaul.config.frames.replay_animation"), button -> {
                    applyFocused();
                    if (spec.key().equals("iconAppearAnimation")) {
                        previewPanel.replayIconAnimation();
                    }
                    else if (spec.key().equals("tooltipDisappearAnimation")) {
                        previewPanel.replayTooltipDisappearAnimation();
                    }
                    else {
                        previewPanel.replayTooltipAnimation();
                    }

                }, accent);

            }

        }

        @Override
        protected void prepareWidgetWidth(int rowWidth) {
            if (widget instanceof StyledEditBox box) {
                box.setBaseWidth(widgetWidth());
            }
            else if (widget != null) {
                widget.method_25358(widgetWidth());
            }

        }

        @Override
        protected int expandedWidgetWidth(int rowWidth) {
            return rowWidth - 16;
        }

        @Override
        boolean isModified() {
            return spec != null && entry != null && entry.has(spec.key());
        }

        @Override
        protected void renderAccessories(class_332 graphics, int mouseX, int mouseY, int widgetX, int widgetY, int alpha, float textFade, float entrance, float hover) {
            if (replay != null) {
                replay.method_46421(widgetX - 22);
                replay.method_46419(widgetY);
                replay.method_25350(entrance);
                replay.method_25394(graphics, mouseX, mouseY, 0);
            }

            renderRowSwatches(graphics, this, mouseX, mouseY, textFade * entrance);
            renderRowReset(graphics, this, mouseX, mouseY, widgetX, hover, entrance);
        }

        int widgetWidth() {
            final int formW = formRight() - formLeft();
            final int available = Math.max(36, formW - 52);
            return Math.min(available, Math.min(130, Math.max(88, (int) (formW / 3.5f))));
        }

        boolean matchesSearch(String query) {
            for (String term : normalizeSearch(query).split("\\s+")) {
                if (!term.isEmpty() && !searchIndex.contains(term)) {
                    return false;
                }

            }

            return true;
        }

    }

    private static String normalizeSearch(String value) {
        return value.toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private static String fieldDescription(String key) {
        final String descriptionKey = "tooltipoverhaul.config.frames.field." + key + ".desc";
        return class_1074.method_4663(descriptionKey) ? class_1074.method_4662(descriptionKey) : "";
    }

    private static String[] withInherit(String[] options) {
        final String[] all = new String[options.length + 1];
        all[0] = "inherit";
        System.arraycopy(options, 0, all, 1, options.length);
        return all;
    }

    static String fieldLabel(String key) {
        final String langKey = "tooltipoverhaul.config.frames.field." + key;
        if (class_1074.method_4663(langKey)) {
            return class_1074.method_4662(langKey);
        }

        return prettify(key.replaceAll("([a-z0-9])([A-Z])", "$1 $2").toLowerCase(Locale.ROOT));
    }

    private static String optionLabel(String value) {
        String key = "tooltipoverhaul.config.frames.option." + value;
        return class_1074.method_4663(key) ? class_1074.method_4662(key) : prettify(value);
    }

    private String readChoice(JsonObject entry, FieldSpec spec, String[] options) {
        if (!entry.has(spec.key()) || !entry.get(spec.key()).isJsonPrimitive()) {
            return options[0];
        }

        final String raw = spec.key().equals("extends") ? entry.get(spec.key()).getAsString().trim() : entry.get(spec.key()).getAsString().trim().toLowerCase(Locale.ROOT);
        if (spec.key().equals("previewPanelSideTriangles")) {
            return PreviewPanelDecorations.SideTriangles.fromString(raw).name().toLowerCase(Locale.ROOT);
        }

        for (String option : options) {
            if (option.equals(raw)) {
                return option;
            }

        }

        return options[0];
    }

    private void writeChoice(JsonObject entry, FieldSpec spec, String value) {
        if ("inherit".equals(value)) {
            entry.remove(spec.key());
        }
        else if (spec.kind() == Kind.BOOL) {
            entry.addProperty(spec.key(), Boolean.parseBoolean(value));
        }
        else {
            entry.addProperty(spec.key(), value);
        }

        markDirty();
        refreshInheritedText();
    }

    private String readText(JsonObject entry, FieldSpec spec) {
        return FrameFieldDefaults.read(root, entry, spec.key(), resolveListStack(entry));
    }

    private void writeText(JsonObject entry, FieldSpec spec, String raw) {
        final String value = raw.trim();
        if (editingTemplates && spec.key().equals("name") && entry.has("name") && !value.isEmpty()) {
            final String old = entry.get("name").getAsString();
            for (List<JsonObject> group : List.of(frameEntries, templateEntries)) {
                for (JsonObject dependent : group) {
                    if (dependent.has("extends") && dependent.get("extends").getAsString().equals(old)) {
                        dependent.addProperty("extends", value);
                    }

                }

            }

        }

        if (value.isEmpty()) {
            entry.remove(spec.key());
            markDirty();
            return;
        }

        switch (spec.kind()) {
            case LIST, COLOR_LIST -> {
                final JsonArray array = new JsonArray();
                for (String part : value.split(",")) {
                    if (!part.trim().isEmpty()) {
                        array.add(part.trim());
                    }

                }

                entry.add(spec.key(), array);
            }

            case TUPLE_LIST -> {
                final JsonArray array = new JsonArray();
                for (String part : value.split("(?<=\\))\\s*[,;]\\s*")) {
                    if (!part.trim().isEmpty()) {
                        array.add(part.trim());
                    }

                }

                entry.add(spec.key(), array);
            }

            case INT -> {
                try {
                    entry.addProperty(spec.key(), Integer.parseInt(value));
                }
                catch (NumberFormatException ignored) {
                    return;
                }

            }

            case FLOAT -> {
                try {
                    entry.addProperty(spec.key(), Float.parseFloat(value));
                }
                catch (NumberFormatException ignored) {
                    return;
                }

            }

            case COLOR_INT -> {
                if (value.startsWith("#") || value.startsWith("0x") || value.startsWith("0X")) {
                    entry.addProperty(spec.key(), ConfigColorParser.parseColor(value));
                }
                else {
                    return;
                }

            }

            default -> entry.addProperty(spec.key(), raw);
        }

        markDirty();
    }

    private void rebuildRows() {
        syncRoot();
        rows.clear();
        visibleRows.clear();

        final JsonObject entry = selectedEntry();
        if (entry == null) {
            return;
        }

        String currentSection = "";
        for (Object item : SECTIONS_AND_FIELDS) {
            if (item instanceof String section) {
                if (editingTemplates && section.equals("matching")) {
                    continue;
                }

                currentSection = section;
                rows.add(new FieldRow(section));
            }
            else if (item instanceof FieldSpec spec) {
                if (editingTemplates && Set.of("items", "tags", "namespace", "rarity", "priority", "createTemplate").contains(spec.key())) {
                    continue;
                }

                rows.add(new FieldRow(spec, entry, currentSection));
            }

        }

        rebuildVisibleRows();

    }

    private void rebuildVisibleRows() {
        visibleRows.clear();
        if (searchQuery.isBlank()) {
            visibleRows.addAll(rows);
            return;
        }

        FieldRow sectionRow = null;
        boolean sectionMatches = false;
        boolean sectionAdded = false;
        for (FieldRow row : rows) {
            if (row.section != null) {
                sectionRow = row;
                sectionMatches = row.matchesSearch(searchQuery);
                sectionAdded = false;
                continue;
            }

            if (!sectionMatches && !row.matchesSearch(searchQuery)) {
                hideRow(row);
                continue;
            }

            if (sectionRow != null && !sectionAdded) {
                visibleRows.add(sectionRow);
                sectionAdded = true;
            }

            visibleRows.add(row);
        }

        for (FieldRow row : rows) {
            if (!visibleRows.contains(row)) {
                hideRow(row);
            }

        }

    }

    private static void hideRow(FieldRow row) {
        row.swatchHits.clear();
        if (row.widget != null) {
            row.widget.method_46419(-1000);
            if (row.replay != null) {
                row.replay.method_46419(-1000);
            }

        }

    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        restoreGuiRenderState(graphics);
        clampPanelWidths();
        layoutEntryButtons();
        final String sourceLabel = source.primary() ? class_1074.method_4662("tooltipoverhaul.config.frames.subtitle") : source.location().toString();
        renderScreenShell(graphics, field_22793.method_27523(sourceLabel,
                Math.max(60, (searchBox == null ? field_22789 : searchBox.method_46426()) - 30)));

        renderHeader(graphics);
        renderList(graphics, mouseX, mouseY, partialTick);
        renderForm(graphics, mouseX, mouseY, partialTick);

        restoreGuiRenderState(graphics);
        renderPreview(graphics, mouseX, mouseY);
        restoreGuiRenderState(graphics);
        renderPanelSplitters(graphics, mouseX, mouseY);

        super.method_25394(graphics, mouseX, mouseY, partialTick);

        renderFieldTooltip(graphics);

        renderModalLayer(graphics, mouseX, mouseY, partialTick);

    }

    private void renderPanelSplitters(class_332 graphics, int mouseX, int mouseY) {
        renderPanelSplitter(graphics, listSplitterX(), draggingListSplitter || overListSplitter(mouseX, mouseY));
        renderPanelSplitter(graphics, previewSplitterX(), draggingPreviewSplitter || overPreviewSplitter(mouseX, mouseY));
    }

    private void renderPanelSplitter(class_332 graphics, int x, boolean active) {
        final int color = active ? withAlpha(dimAccent(accent), 0xD0) : 0x302E2E32;
        graphics.method_25294(x, formTop() + 5, x + 1, formBottom() - 5, color);

        if (active) {
            final int middleY = (formTop() + formBottom()) / 2;
            final ConfigIconButton.Icon icon = ConfigIconButton.Icon.RESIZE_PANEL;
            ConfigIconButton.drawIcon(graphics, icon, x - (icon.width - 1) / 2, middleY - icon.height / 2, color);
        }

    }

    private void renderHeader(class_332 graphics) {
        final int tagY = HEADER_HEIGHT - field_22793.field_2000 + 1;
        if (dirty) {
            final String tag = !draftError.isEmpty() ? class_1074.method_4662("tooltipoverhaul.config.frames.draft_error") : class_1074.method_4662("tooltipoverhaul.config.frames." + (document.hasDraft() ? "draft_saved" : "unsaved"));
            graphics.method_51433(field_22793, tag, this.field_22789 - field_22793.method_1727(tag) - 14, tagY, 0xFFFFB040, false);
            return;
        }

        final float fade = savedFlashAt > 0 ? 1f - class_3532.method_15363((class_156.method_658() - savedFlashAt) / 1600f, 0f, 1f) : 0f;
        if (fade > 0.06f) {
            final String tag = class_1074.method_4662("tooltipoverhaul.config.frames.saved");
            graphics.method_51433(field_22793, tag, this.field_22789 - field_22793.method_1727(tag) - 14, tagY, withAlpha(0x5FCB6A, (int) (0xFF * fade)), false);
        }

    }

    private void renderList(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (entryList == null) {
            return;
        }

        entryList.setBounds(listLeft(), listTop(), listWidth(), listBottom() - listTop());
        entryList.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private String labelFor(JsonObject entry, int index) {
        if (entry.has("name") && entry.get("name").isJsonPrimitive()) {
            final String name = entry.get("name").getAsString().trim();
            if (!name.isEmpty()) {
                return name;
            }

        }

        return class_1074.method_4662("tooltipoverhaul.config.frames.entry", index + 1);
    }

    private void renderForm(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        swatchHintHovered = false;
        final int x0 = formLeft();
        final int y0 = formTop();
        final int x1 = formRight();
        final int y1 = formBottom();

        drawCard(graphics, x0, y0, x1, y1, 0xE6111113, 0xFF232327);

        if (selectedEntry() == null) {
            final String empty = class_1074.method_4662(loadFailed ? "tooltipoverhaul.config.frames.load_failed" : "tooltipoverhaul.config.frames.no_selection");
            graphics.method_51433(field_22793, empty, x0 + (x1 - x0 - field_22793.method_1727(empty)) / 2, (y0 + y1) / 2 - 4, 0xFF555555, false);
            return;
        }

        if (visibleRows.isEmpty()) {
            final String empty = class_1074.method_4662("tooltipoverhaul.config.empty_search", searchQuery);
            graphics.method_51433(field_22793, empty, x0 + (x1 - x0 - field_22793.method_1727(empty)) / 2, (y0 + y1) / 2 - 4, 0xFF555555, false);
            return;
        }

        graphics.method_44379(x0, y0 + 2, x1, y1 - 2);

        final boolean mouseInForm = mouseX >= x0 && mouseX < x1 - 10 && mouseY >= y0 && mouseY < y1;
        FieldRow hoverCandidate = null;
        final long now = class_156.method_658();
        if (formRevealAt < 0L) {
            formRevealAt = now;
        }

        int y = y0 + 6 - (int) formScroll;
        for (int rowIndex = 0; rowIndex < visibleRows.size(); rowIndex++) {
            y += rowGapBefore(rowIndex);

            final FieldRow row = visibleRows.get(rowIndex);

            row.currentY = y;

            final int baseRowLeft = x0 + 6;
            final int baseRowRight = x1 - 8;
            if (row.widget != null) {
                row.recalcHeight(baseRowRight - baseRowLeft);
            }

            if (y + row.height >= y0 && y <= y1) {
                final float entrance = AnimationUtils.easeOutCubic(class_3532.method_15363((now - formRevealAt - Math.min(rowIndex, 12) * 35L) / 170f, 0f, 1f));
                final int slide = Math.round((1f - entrance) * 16f);
                final int entranceAlpha = Math.round(0xFF * entrance);
                if (row.section != null) {
                    final String label = class_1074.method_4662("tooltipoverhaul.config.frames.section." + row.section);
                    renderSectionHeader(graphics, field_22793, label, baseRowLeft + slide, y, baseRowRight - baseRowLeft, accent, entranceAlpha);
                }
                else if (row.spec != null && row.widget != null) {
                    final boolean rowHovered = mouseInForm && mouseX >= baseRowLeft && mouseX < baseRowRight && mouseY >= y && mouseY < y + row.height;
                    row.render(graphics, rowIndex, y, baseRowLeft, baseRowRight - baseRowLeft, mouseX, mouseY, rowHovered, entrance, partialTick);

                    if (rowHovered && mouseX < row.widget.method_46426() - 20) {
                        hoverCandidate = row;
                    }

                }

            }
            else {
                row.swatchHits.clear();
                if (row.widget != null) {
                    row.widget.method_46419(-1000);
                    if (row.replay != null) {
                        row.replay.method_46419(-1000);
                    }

                }

            }

            y += row.height;
        }

        graphics.method_44380();

        if (hoverCandidate != hoveredRow) {
            hoveredRow = hoverCandidate;
            hoveredRowSince = class_156.method_658();
        }

        if (hoveredRow != null) {
            hoverMouseX = mouseX;
            hoverMouseY = mouseY;
        }

        renderScrollbar(graphics, formBarGeometry(), x1, mouseX, mouseY);
    }

    private void renderRowReset(class_332 graphics, FieldRow row, int mouseX, int mouseY, int widgetX, float hover, float entrance) {
        if (row.spec == null || row.widget == null || hover <= 0.3f || !row.isModified() || entrance <= 0f) {
            return;
        }

        int leftmost = row.replay != null ? widgetX - 22 : widgetX;
        for (int[] hit : row.swatchHits) {
            leftmost = Math.min(leftmost, hit[0]);
        }

        final int resetX = leftmost - 22;
        final int resetY = row.widget.method_46427() + (row.widget.method_25364() - 18) / 2;
        final boolean hovered = mouseX >= resetX && mouseX < resetX + 18 && mouseY >= resetY && mouseY < resetY + 18;
        final int alpha = (int) (0xFF * entrance * (hover - 0.3f) / 0.7f);
        drawCard(graphics, resetX, resetY, resetX + 18, resetY + 18, withAlpha(hovered ? 0x202024 : 0x1A1A1C, alpha), withAlpha(hovered ? dimAccent(accent) : 0x2E2E32, alpha));
        ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.REPEAT, resetX + (18 - ConfigIconButton.Icon.REPEAT.width) / 2,
                resetY + (18 - ConfigIconButton.Icon.REPEAT.height) / 2, hovered ? withAlpha(accent & 0x00FFFFFF, alpha) : withAlpha(0x8A8A8A, alpha));
        row.swatchHits.add(new int[] { resetX, resetY, -4, 18 });
    }

    private void resetRow(FieldRow row) {
        if (row.spec == null || row.entry == null) {
            return;
        }

        if (row.widget instanceof class_342 box && focusedBox == box) {
            box.method_25365(false);
            focusedBox = null;
        }

        row.entry.remove(row.spec.key());
        if (row.widget instanceof ConfigOptionButton<?> options) {
            options.setCurrent("inherit");
        }

        markDirty();
        refreshInheritedText();
    }

    private void renderRowSwatches(class_332 graphics, FieldRow row, int mouseX, int mouseY, float textFade) {
        row.swatchHits.clear();
        if (row.spec == null || row.widget == null || textFade < 0.5f) {
            return;
        }

        final Kind kind = row.spec.kind();

        if ("texture".equals(row.spec.key()) && row.widget instanceof class_342) {
            final int catalogX = row.widget.method_46426() - 22;
            final int catalogY = row.widget.method_46427();
            final boolean hovered = mouseX >= catalogX && mouseX < catalogX + 18 && mouseY >= catalogY && mouseY < catalogY + 18;
            final int iconColor = hovered ? accent : 0xFF808080;

            graphics.method_25294(catalogX, catalogY, catalogX + 18, catalogY + 18, hovered ? 0xFF26262A : 0xFF1A1A1C);
            drawNotchedBorder(graphics, catalogX, catalogY, catalogX + 18, catalogY + 18, buttonBorder(accent, hovered ? 1f : 0f));
            ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.MENU, catalogX + (18 - ConfigIconButton.Icon.MENU.width) / 2, catalogY + (18 - ConfigIconButton.Icon.MENU.height) / 2, iconColor);
            row.swatchHits.add(new int[] { catalogX, catalogY, -3, 18 });
            return;
        }

        // Lists fields to specify multiple matching items in a better way
        if (kind == Kind.LIST && row.widget instanceof class_342) {
            final int listX = row.widget.method_46426() - 22;
            final int listY = row.widget.method_46427();
            final boolean hovered = mouseX >= listX && mouseX < listX + 18 && mouseY >= listY && mouseY < listY + 18;

            graphics.method_25294(listX, listY, listX + 18, listY + 18, hovered ? 0xFF26262A : 0xFF1A1A1C);
            drawNotchedBorder(graphics, listX, listY, listX + 18, listY + 18, buttonBorder(accent, hovered ? 1f : 0f));
            ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.MENU, listX + (18 - ConfigIconButton.Icon.MENU.width) / 2, listY + (18 - ConfigIconButton.Icon.MENU.height) / 2, hovered ? accent : 0xFF808080);

            row.swatchHits.add(new int[] { listX, listY, -2, 18 });

            return;
        }

        if ((kind != Kind.COLOR && kind != Kind.COLOR_INT && kind != Kind.COLOR_LIST) || !(row.widget instanceof class_342 box)) {
            return;
        }

        final List<String> parts = colorParts(box.method_1882(), kind);
        int swatchX = row.widget.method_46426() - 16;
        final int swatchY = row.widget.method_46427() + 3;

        // Color append
        if ((kind == Kind.COLOR_LIST && parts.size() < MAX_LIST_COLORS) || parts.isEmpty()) {
            final boolean hovered = mouseX >= swatchX && mouseX < swatchX + 12 && mouseY >= swatchY && mouseY < swatchY + 12;
            graphics.method_25294(swatchX, swatchY, swatchX + 12, swatchY + 12, hovered ? 0xFF26262A : 0xFF1A1A1C);
            drawNotchedBorder(graphics, swatchX, swatchY, swatchX + 12, swatchY + 12, buttonBorder(accent, hovered ? 1f : 0f));
            graphics.method_51433(field_22793, "+", swatchX + 4, swatchY + 2, hovered ? accent : 0xFF808080, false);
            row.swatchHits.add(new int[] { swatchX, swatchY, -1, 12 });
            swatchX -= 14;
        }

        for (int i = parts.size() - 1; i >= 0; i--) {
            final boolean hovered = mouseX >= swatchX && mouseX < swatchX + 12 && mouseY >= swatchY && mouseY < swatchY + 12;
            swatchHintHovered |= hovered;
            drawColorSwatch(graphics, swatchX, swatchY, 12, ConfigColorParser.parseColor(parts.get(i)), accent, hovered, 0xFF);
            row.swatchHits.add(new int[] { swatchX, swatchY, i, 12 });
            swatchX -= 14;
        }

    }

    private static List<String> colorParts(String raw, Kind kind) {
        return kind == Kind.COLOR_LIST ? colorTokens(raw) : raw.isBlank() ? new ArrayList<>() : new ArrayList<>(List.of(raw.trim()));
    }

    private int totalFormHeight() {
        int total = 12;
        for (int rowIndex = 0; rowIndex < visibleRows.size(); rowIndex++) {
            final FieldRow row = visibleRows.get(rowIndex);
            if (row.widget != null) {
                row.recalcHeight(Math.max(1, formRight() - formLeft() - 14));
            }

            total += rowGapBefore(rowIndex) + row.height;
        }

        return total;
    }

    private int rowGapBefore(int rowIndex) {
        return rowIndex > 0 && visibleRows.get(rowIndex - 1).section == null ? ConfigFormEntry.ROW_GAP : 0;
    }

    private @Nullable ConfigScroll.Geometry formBarGeometry() {
        return selectedEntry() == null ? null : ConfigScroll.fromContent(formTop(), formBottom(), totalFormHeight(), formScroll);
    }

    private void renderScrollbar(class_332 graphics, @Nullable ConfigScroll.Geometry bar, int rightEdge, int mouseX, int mouseY) {
        ConfigScroll.render(graphics, rightEdge, bar, accent, mouseX, mouseY, draggingFormBar);
    }

    private double maxFormScroll() {
        return Math.max(0, totalFormHeight() - (formBottom() - formTop()));
    }

    private void renderPreview(class_332 graphics, int mouseX, int mouseY) {
        previewPanel.setBounds(previewLeft(), formTop(), previewWidth(), formBottom() - formTop());
        previewPanel.render(graphics, field_22793, field_22789, field_22790, mouseX, mouseY, validationError);
    }

    private void renderFieldTooltip(class_332 graphics) {
        if (hoveredRow == null || hoveredRow.spec == null || modals.isOpen() || previewPanel.isPanning() || draggingFormBar || entryList != null && entryList.isDraggingEntry() || draggingListSplitter || draggingPreviewSplitter) {
            return;
        }

        final int maxWidth = 200;
        if (swatchHintHovered) {
            ConfigTooltipRenderer.render(graphics, field_22793, List.of(new ConfigTooltipRenderer.Section(field_22793.method_1728(class_2561.method_43471("tooltipoverhaul.config.swatch_hint"), maxWidth), 0xFFFFFF)),
                    hoverMouseX, hoverMouseY, field_22789, field_22790, HEADER_HEIGHT + 4, accent, 1f);
            return;
        }

        if (class_156.method_658() - hoveredRowSince < 400) {
            return;
        }

        final String key = hoveredRow.spec.key();
        final List<class_5481> lines = new ArrayList<>(field_22793.method_1728(class_2561.method_43469("tooltipoverhaul.config.frames.tooltip.key", key).method_27694(style -> style.method_36139(0x70707A)), maxWidth));

        if (hoveredRow.entry != null && hoveredRow.widget instanceof class_342) {
            if (hoveredRow.isModified()) {
                final JsonObject withoutOverride = hoveredRow.entry.deepCopy();
                withoutOverride.remove(key);
                final String fallback = FrameFieldDefaults.read(root, withoutOverride, key, resolveListStack(hoveredRow.entry));
                lines.addAll(field_22793.method_1728(fallback.isBlank() ? class_2561.method_43471("tooltipoverhaul.config.frames.tooltip.overridden").method_27694(style -> style.method_36139(0xC4C4C4))
                        : class_2561.method_43469("tooltipoverhaul.config.frames.tooltip.default", fallback).method_27694(style -> style.method_36139(0xC4C4C4)), maxWidth));
            }
            else {
                lines.addAll(field_22793.method_1728(class_2561.method_43471("tooltipoverhaul.config.frames.tooltip.using_default").method_27694(style -> style.method_36139(0x8C8C8C)), maxWidth));
            }

        }

        final float fade = AnimationUtils.easeOutQuad(class_3532.method_15363((class_156.method_658() - hoveredRowSince - 400) / 120f, 0f, 1f));
        ConfigTooltipRenderer.render(graphics, field_22793, List.of(new ConfigTooltipRenderer.Section(lines, 0xFFFFFF)),
                hoverMouseX, hoverMouseY, field_22789, field_22790, HEADER_HEIGHT + 4, accent, fade);
    }

    @Override
    protected boolean handleMouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && overListSplitter(mouseX, mouseY)) {
            applyFocused();
            draggingListSplitter = true;
            hoveredRow = null;
            return true;
        }

        if (button == 0 && overPreviewSplitter(mouseX, mouseY)) {
            applyFocused();
            draggingPreviewSplitter = true;
            hoveredRow = null;
            return true;
        }

        if (previewPanel.contains(mouseX, mouseY)) {
            applyFocused();
            return previewPanel.mouseClicked(mouseX, mouseY, button);
        }

        if (entryList != null && entryList.method_25402(mouseX, mouseY, button)) {
            return true;
        }

        // Form scrollbar
        final ConfigScroll.Geometry formBar = formBarGeometry();
        if (formBar != null && button == 0 && mouseX >= formRight() - 10 && mouseX < formRight() && mouseY >= formBar.top() && mouseY < formBar.bottom()) {
            if (mouseY >= formBar.thumbTop() && mouseY < formBar.thumbTop() + formBar.thumbHeight()) {
                draggingFormBar = true;
                barDragOffset = mouseY - formBar.thumbTop();
            }
            else {
                formScroll = ConfigScroll.valueFromMouse(mouseY, formBar, maxFormScroll());
            }

            return true;
        }

        // Form
        if (mouseX >= formLeft() && mouseX < formRight() && mouseY >= formTop() && mouseY < formBottom()) {
            for (FieldRow row : visibleRows) {
                for (int[] hit : row.swatchHits) {
                    if (mouseX >= hit[0] && mouseX < hit[0] + hit[3]
                            && mouseY >= hit[1] && mouseY < hit[1] + hit[3] && button == 0) {
                        if (hit[2] == -4) {
                            resetRow(row);
                        }
                        else if (hit[2] == -2) {
                            openListEditor(row, (int) mouseX, (int) mouseY);
                        }
                        else if (hit[2] == -3) {
                            openFrameCatalog(row);
                        }
                        else {
                            openPicker(row, hit[2], (int) mouseX, (int) mouseY);
                        }

                        playClickSound();
                        return true;
                    }

                }

            }

            for (FieldRow row : visibleRows) {
                if (row.widget == null) {
                    continue;
                }

                if (row.replay != null && row.replay.method_25402(mouseX, mouseY, button)) {
                    return true;
                }

                if (row.widget.method_25402(mouseX, mouseY, button)) {
                    if (row.widget instanceof class_342 box) {
                        if (focusedBox != null && focusedBox != box) {
                            focusedBox.method_25365(false);
                        }

                        focusedBox = box;
                        box.method_25365(true);
                    }
                    else {
                        applyFocused();
                    }

                    return true;
                }

            }

            applyFocused();
            return true;
        }

        applyFocused();

        return super.handleMouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected boolean handleMouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (draggingListSplitter && button == 0) {
            panelLayout.resizeLeft(mouseX);
            layoutEntryButtons();
            formScroll = class_3532.method_15350(formScroll, 0, maxFormScroll());
            return true;
        }

        if (draggingPreviewSplitter && button == 0) {
            panelLayout.resizeRight(mouseX);
            previewPanel.setBounds(previewLeft(), formTop(), previewWidth(), formBottom() - formTop());
            previewPanel.clampPan();
            formScroll = class_3532.method_15350(formScroll, 0, maxFormScroll());
            return true;
        }

        if (entryList != null && entryList.method_25403(mouseX, mouseY, button, dragX, dragY)) {
            return true;
        }

        if (previewPanel.mouseDragged(dragX, dragY)) {
            return true;
        }

        if (draggingFormBar) {
            final ConfigScroll.Geometry bar = formBarGeometry();
            if (bar != null) {
                formScroll = ConfigScroll.valueFromDrag(mouseY, barDragOffset, bar, maxFormScroll());

            }

            return true;
        }

        return super.handleMouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    protected boolean handleMouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && (draggingListSplitter || draggingPreviewSplitter)) {
            draggingListSplitter = false;
            draggingPreviewSplitter = false;
            return true;
        }

        if (entryList != null && entryList.method_25406(mouseX, mouseY, button)) {
            return true;
        }

        previewPanel.mouseReleased();
        draggingFormBar = false;

        return super.handleMouseReleased(mouseX, mouseY, button);
    }

    @Override
    protected boolean handleMouseScrolled(double mouseX, double mouseY, double delta) {
        if (previewPanel.mouseScrolled(mouseX, mouseY, delta)) {
            return true;
        }

        if (entryList != null && entryList.method_25401(mouseX, mouseY, delta)) {
            return true;
        }

        if (mouseX >= formLeft() && mouseX < formRight()) {
            formScroll = class_3532.method_15350(formScroll - delta * 18, 0, maxFormScroll());
            return true;
        }

        return super.handleMouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    protected boolean handleKeyPressed(int key, int scancode, int modifiers) {
        if (entryList != null && entryList.isDraggingEntry() && key == GLFW.GLFW_KEY_ESCAPE) {
            entryList.cancelDrag();
            return true;
        }

        if (key == GLFW.GLFW_KEY_F && method_25441() && searchBox != null) {
            applyFocused();
            method_25395(searchBox);
            searchBox.method_25365(true);
            return true;
        }

        if (method_25441() && key == GLFW.GLFW_KEY_S) {
            applyFocused();
            save();
            return true;
        }

        if (method_25443() && (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN)) {
            moveEntry(selected + (key == GLFW.GLFW_KEY_UP ? -1 : 1));
            rebuildRows();
            if (entryList != null) {
                entryList.setSelectedIndex(selected);
                entryList.revealSelected();
            }

            return true;
        }

        if (focusedBox != null && focusedBox.method_25404(key, scancode, modifiers)) {
            return true;
        }

        if (focusedBox != null && focusedBox.method_25370() && key != GLFW.GLFW_KEY_ESCAPE) {
            return true;
        }

        return super.handleKeyPressed(key, scancode, modifiers);
    }

    @Override
    protected boolean handleCharTyped(char chr, int modifiers) {
        if (focusedBox != null && focusedBox.method_25400(chr, modifiers)) {
            return true;
        }

        return super.handleCharTyped(chr, modifiers);
    }

    @Override
    protected void tickBeforeModals() {
        if (entryList != null) {
            entryList.tickDrag();
        }

    }

    @Override
    protected void tickScreen() {
        if (dirty && class_156.method_658() >= nextDraftSaveAt) {
            preserveDraft();
            nextDraftSaveAt = class_156.method_658() + 2000;
        }

        if (searchBox != null) {
            searchBox.method_1865();
        }

        if (focusedBox != null) {
            focusedBox.method_1865();
        }

        super.tickScreen();
    }

    private void applyFocused() {
        if (searchBox != null && searchBox.method_25370()) {
            searchBox.method_25365(false);
            if (method_25399() == searchBox) {
                method_25395(null);
            }

        }

        if (focusedBox != null) {
            focusedBox.method_25365(false);
            focusedBox = null;
            refreshInheritedText();
        }

    }

    private void refreshInheritedText() {
        final JsonObject entry = selectedEntry();
        if (entry == null) {
            return;
        }

        for (FieldRow row : rows) {
            if (row.spec == null || entry.has(row.spec.key()) || !(row.widget instanceof class_342 box) || box.method_25370()) {
                continue;
            }

            box.method_1863(null);
            box.method_1852(readText(entry, row.spec));
            box.method_1863(value -> writeText(entry, row.spec, value));
        }

    }

    @Override
    public void method_25419() {
        applyFocused();
        if (!preserveDraft()) {
            return;
        }

        previewPanel.close();
        returnToParent();
    }

    private boolean preserveDraft() {
        if (!dirty || loadFailed) {
            return true;
        }

        final String error = document.saveDraft();
        draftError = error == null ? "" : error;
        return error == null;
    }

    @Override
    public void method_25432() {
        applyFocused();
        preserveDraft();
        previewPanel.close();
        super.method_25432();
    }

    void selectPreviewItem(class_1799 stack) {
        previewPanel.selectStack(stack);
    }

    private void openListEditor(FieldRow row, int anchorX, int anchorY) {
        if (row.spec == null || !(row.widget instanceof class_342)) {
            return;
        }

        applyFocused();
        modals.clear();
        if (("items".equals(row.spec.key()) || "enchantments".equals(row.spec.key())) && row.widget instanceof class_342 box) {
            final boolean enchantments = "enchantments".equals(row.spec.key());
            final Set<String> values = new LinkedHashSet<>();
            for (String part : box.method_1882().split(",")) {
                if (part.isBlank()) {
                    continue;
                }

                class_2960 id = class_2960.method_12829(part.trim());
                final String value = id != null ? id.toString() : part.trim();
                if (!values.contains(value)) {
                    values.add(value);
                }

            }

            List<SelectionPopup.Option> options = new ArrayList<>();
            if (enchantments) {
                for (final class_1887 enchantment : class_7923.field_41176) {
                    String id = class_7923.field_41176.method_10221(enchantment).toString();
                    class_1799 book = class_1772.method_7808(new class_1889(enchantment, 1));
                    options.add(new SelectionPopup.Option(id, class_2561.method_43471(enchantment.method_8184()).getString(), id, book));
                }

            }
            else for (class_1792 item : class_7923.field_41178) {
                if (item == class_1802.field_8162) {
                    continue;
                }

                final String id = class_7923.field_41178.method_10221(item).toString();
                final class_1799 stack = new class_1799(item);
                String name;
                try {
                    name = stack.method_7964().getString();
                }
                catch (RuntimeException ignored) {
                    name = id;
                }

                options.add(new SelectionPopup.Option(id, name, id, stack));
            }

            final Set<String> known = new HashSet<>();
            for (final SelectionPopup.Option option : options) known.add(option.value());
            for (String value : values) if (!known.contains(value)) options.add(new SelectionPopup.Option(value, value, value, class_1799.field_8037));
            options.sort(Comparator.comparing(SelectionPopup.Option::label, String.CASE_INSENSITIVE_ORDER).thenComparing(SelectionPopup.Option::value));
            modals.open(new SelectionPopup(field_22789, field_22790, class_2561.method_43471("tooltipoverhaul.config.frames." + (enchantments ? "enchantment_catalog" : "item_catalog")),
                    options, values::contains, value -> {
                if (!values.remove(value)) {
                    values.add(value);
                }

                box.method_1852(String.join(", ", values));
            }, true, accent));

            return;
        }

        final class_342 box = (class_342) row.widget;
        modals.open(new StringListEditor(field_22789, field_22790, anchorX, anchorY, accent, class_2561.method_43470(fieldLabel(row.spec.key())), box.method_1882(), null, box::method_1852));
    }

    private void openFrameCatalog(FieldRow row) {
        if (row.spec == null || !(row.widget instanceof class_342 box)) {
            return;
        }

        applyFocused();
        modals.clear();

        final String current = box.method_1882().trim();
        modals.open(new SelectionPopup(field_22789, field_22790,
                class_2561.method_43471("tooltipoverhaul.config.frames.frame_catalog"), frameCatalogOptions(current), current::equals, box::method_1852, false, accent));
    }

    static List<SelectionPopup.Option> frameCatalogOptions(String current) {
        final List<SelectionPopup.Option> options = new ArrayList<>();
        final Map<class_2960, class_3298> textures = class_310.method_1551().method_1478()
                .method_14488("textures/overlay", location -> location.method_12832().endsWith(".png"));
        for (Map.Entry<class_2960, class_3298> entry : textures.entrySet()) {
            final class_2960 location = entry.getKey();
            SelectionPopup.FramePreview preview = null;
            try (InputStream stream = entry.getValue().method_14482(); class_1011 image = class_1011.method_4309(stream)) {
                if (image.method_4307() >= Constants.getOverlayFrameDimension()
                        && image.method_4323() >= Constants.getOverlayFrameDimension()) {
                    preview = new SelectionPopup.FramePreview(location, image.method_4307(), image.method_4323());
                }

            }
            catch (Exception exception) {
                TooltipOverhaul.LOGGER.warn("Frame editor could not preview {}: {}", location, exception.getMessage());
            }

            String filename = location.method_12832().substring(location.method_12832().lastIndexOf('/') + 1);
            if (filename.endsWith(".png")) {
                filename = filename.substring(0, filename.length() - 4);
            }

            if (filename.endsWith("_frame")) {
                filename = filename.substring(0, filename.length() - 6);
            }

            options.add(new SelectionPopup.Option(location.toString(), prettify(filename), location.toString(), new class_1799(class_1802.field_8802), preview));
        }

        if (!current.isEmpty() && options.stream().noneMatch(option -> option.value().equals(current))) {
            options.add(new SelectionPopup.Option(current, current, current, class_1799.field_8037));
        }

        options.sort(Comparator.comparing(SelectionPopup.Option::label, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(SelectionPopup.Option::value));

        return options;
    }

    private void openPicker(FieldRow row, int partIndex, int anchorX, int anchorY) {
        if (row.spec == null || !(row.widget instanceof class_342 box)) {
            return;
        }

        applyFocused();

        int initial = 0xFFFFFFFF;
        if (partIndex >= 0) {
            final List<String> parts = colorParts(box.method_1882(), row.spec.kind());
            if (partIndex < parts.size()) {
                initial = ConfigColorParser.parseColor(parts.get(partIndex));
            }

        }

        pickerRow = row;
        pickerPartIndex = partIndex;
        modals.open(new ColorLevelPicker(anchorX, anchorY, HEADER_HEIGHT + 4, this.field_22789, this.field_22790, accent, initial, row.spec.kind() == Kind.COLOR_INT,
                argb -> pickerPartIndex = applyPickedColor(pickerRow, pickerPartIndex, argb)));
    }

    private int applyPickedColor(FieldRow row, int partIndex, int argb) {
        if (row.spec == null || !(row.widget instanceof class_342 box)) {
            return partIndex;
        }

        final Kind kind = row.spec.kind();
        final String formatted = formatHex(argb, kind == Kind.COLOR_INT);

        if (kind != Kind.COLOR_LIST) {
            box.method_1852(formatted);
            return 0;
        }

        final List<String> parts = colorParts(box.method_1882(), kind);
        int index = partIndex;
        if (index < 0 || index >= parts.size()) {
            if (parts.size() < MAX_LIST_COLORS) {
                parts.add(formatted);
                index = parts.size() - 1;
            }
            else {
                index = parts.size() - 1;
                parts.set(index, formatted);
            }

        }
        else {
            parts.set(index, formatted);
        }

        box.method_1852(String.join(", ", parts));

        return index;
    }

}