package dev.xylonity.tooltipoverhaul.client.style.shadow;

import dev.xylonity.tooltipoverhaul.client.layer.impl.ShadowLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import java.awt.*;
import net.minecraft.class_241;

public class DefaultShadow implements ShadowLayer {

    public static final int COLOR = 0x80000000;

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int x0 = (int) position.field_1343 - 1;
        final int y0 = (int) position.field_1342;
        final int x1 = (int) (position.field_1343 + context.getTooltipSize().field_1343 + 4);
        final int y1 = (int) (position.field_1342 + context.getTooltipSize().field_1342 + 4);

        final int bgColor = COLOR;

        // Background
        context.getGraphics().method_51737(x0, y0, x1, y1, 0, bgColor);

        // Top border
        context.getGraphics().method_51737(x0, y0 - 1, x1, y0, 0, bgColor);
        // Bottom border
        context.getGraphics().method_51737(x0, y1 + 1, x1, y1, 0, bgColor);
        // Left border
        context.getGraphics().method_51737(x0 - 1, y0, x0, y1, 0, bgColor);
        // Right border
        context.getGraphics().method_51737(x1 + 1, y0, x1, y1, 0, bgColor);
    }

}
