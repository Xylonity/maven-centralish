package dev.xylonity.tooltipoverhaul.client.style.preview.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import net.minecraft.class_241;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;

public class DefaultPreviewBackground implements PreviewBackgroundLayer {

    @Override
    @SuppressWarnings("deprecation")
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        context.getGraphics().method_51741(() -> renderBackground(context, startPosition, endPosition));
    }

    private void renderBackground(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        final int x0 = (int) startPosition.field_1343;
        final int y0 = (int) startPosition.field_1342;
        final int x1 = (int) endPosition.field_1343;
        final int y1 = (int) endPosition.field_1342;
        if (x0 - x1 < 2 || y1 - y0 < 2) {
            return;
        }

        final int backgroundColor = ColorUtils.getBackgroundColor(context);
        final PreviewPanelDecorations.BackgroundCornerType corner = RenderUtils.getPreviewPanelBackgroundCornerType(context);
        final boolean notch = corner == PreviewPanelDecorations.BackgroundCornerType.NOTCH;
        final int trim = notch || corner == PreviewPanelDecorations.BackgroundCornerType.ROUNDED ? 1 : 0;

        if (notch) {
            context.getGraphics().method_25294(x1, y0 + 1, x0, y1 - 1, backgroundColor);
            context.getGraphics().method_25294(x1 + 1, y0, x0 - 1, y0 + 1, backgroundColor);
            context.getGraphics().method_25294(x1 + 1, y1 - 1, x0 - 1, y1, backgroundColor);
        }
        else {
            context.getGraphics().method_25294(x1, y0, x0, y1, backgroundColor);
        }

        // Top border
        context.getGraphics().method_25294(x1 + trim, y0 - 1, x0 - trim, y0, backgroundColor);
        // Bottom border
        context.getGraphics().method_25294(x1 + trim, y1, x0 - trim, y1 + 1, backgroundColor);
        // Left border
        context.getGraphics().method_25294(x1 - 1, y0 + trim, x1, y1 - trim, backgroundColor);
        // Right border
        context.getGraphics().method_25294(x0, y0 + trim, x0 + 1, y1 - trim, backgroundColor);
        if (corner == PreviewPanelDecorations.BackgroundCornerType.SQUARE) {
            context.getGraphics().method_25294(x1 - 1, y0 - 1, x1, y0, backgroundColor);
            context.getGraphics().method_25294(x0, y0 - 1, x0 + 1, y0, backgroundColor);
            context.getGraphics().method_25294(x1 - 1, y1, x1, y1 + 1, backgroundColor);
            context.getGraphics().method_25294(x0, y1, x0 + 1, y1 + 1, backgroundColor);
        }

        if (RenderUtils.hasPreviewPanelSideTriangles(context)) {
            for (int row = 1; row < y1 - y0 - 1; row++) {
                final int outset = PreviewPanelDecorations.triangleOutset(y1 - y0, row);
                if (outset <= 0) {
                    continue;
                }

                context.getGraphics().method_25294(x1 - outset - 1, y0 + row, x1 - 1, y0 + row + 1, backgroundColor);
                context.getGraphics().method_25294(x0 + 1, y0 + row, x0 + outset + 1, y0 + row + 1, backgroundColor);
            }

        }

    }

}
