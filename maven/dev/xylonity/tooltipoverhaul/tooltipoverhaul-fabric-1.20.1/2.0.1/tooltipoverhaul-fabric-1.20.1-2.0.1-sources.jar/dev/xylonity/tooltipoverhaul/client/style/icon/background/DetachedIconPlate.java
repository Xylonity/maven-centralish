package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.IconBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import net.minecraft.class_241;

public class DetachedIconPlate implements IconBackgroundLayer {

    private final IconBackgroundLayer background;

    public DetachedIconPlate(IconBackgroundLayer background) {
        this.background = background;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int x = (int) position.field_1343 + TooltipLayout.iconX(context);
        final int y = (int) position.field_1342 + TooltipLayout.iconY(context);
        final int size = Constants.getIconSize(context);
        final int[] colors = ColorUtils.getRenderedInnerOverlayColors(context);
        final boolean badge = context.getLayoutStyle() == TooltipLayout.Style.BADGE;

        context.getGraphics().method_25294(x - 1, y - 1, x + size + 1, y + size + 1, ColorUtils.getBackgroundColor(context));
        if (background != null) {
            context.push(() -> background.render(context, position));
        }

        for (int row = 0; row < size; row++) {
            final int color = ColorUtils.getInnerOverlayColorAtY(context, colors, y + row + 0.5f);
            context.getGraphics().method_25294(x - 1, y + row, x, y + row + 1, color);
            context.getGraphics().method_25294(x + size, y + row, x + size + 1, y + row + 1, color);
        }

        context.getGraphics().method_25294(x, y - 1, x + size, y, ColorUtils.getInnerOverlayColorAtY(context, colors, y - 0.5f));
        context.getGraphics().method_25294(x, y + size, x + size, y + size + 1, ColorUtils.getInnerOverlayColorAtY(context, colors, y + size + 0.5f));

        // Outer black edge
        final int blackEnd = badge ? (int) position.field_1343 - 3 : x + size;
        context.getGraphics().method_25294(x, y - 2, blackEnd, y - 1, 0xFF000000);
        context.getGraphics().method_25294(x - 1, y - 1, x, y, 0xFF000000);
        context.getGraphics().method_25294(x - 2, y, x - 1, y + size, 0xFF000000);
        context.getGraphics().method_25294(x - 1, y + size, x, y + size + 1, 0xFF000000);
        context.getGraphics().method_25294(x, y + size + 1, blackEnd, y + size + 2, 0xFF000000);

        if (!badge) {
            context.getGraphics().method_25294(x + size, y - 1, x + size + 1, y, 0xFF000000);
            context.getGraphics().method_25294(x + size + 1, y, x + size + 2, y + size, 0xFF000000);
            context.getGraphics().method_25294(x + size, y + size, x + size + 1, y + size + 1, 0xFF000000);
        }

    }

}
