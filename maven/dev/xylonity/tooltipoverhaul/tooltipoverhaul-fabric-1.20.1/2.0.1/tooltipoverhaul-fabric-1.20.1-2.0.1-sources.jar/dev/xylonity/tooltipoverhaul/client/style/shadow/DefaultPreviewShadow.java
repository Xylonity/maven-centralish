package dev.xylonity.tooltipoverhaul.client.style.shadow;

import dev.xylonity.tooltipoverhaul.client.layer.LayerDepth;
import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import net.minecraft.class_241;

public class DefaultPreviewShadow implements PreviewBackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        final int x0 = (int) startPosition.field_1343;
        final int y0 = (int) startPosition.field_1342;
        final int x1 = (int) endPosition.field_1343;
        final int y1 = (int) endPosition.field_1342;
        if (x0 - x1 < 2 || y1 - y0 < 2) {
            return;
        }

        context.getGraphics().method_25294(x1 + 1, y0 + 1, x0 + 2, y1 + 3, DefaultShadow.COLOR);
        context.getGraphics().method_25294(x0 + 2, y0 + 2, x0 + 3, y1 + 2, DefaultShadow.COLOR);
    }

    @Override
    public LayerDepth getLayerDepth() {
        return LayerDepth.SHADOW;
    }

}
