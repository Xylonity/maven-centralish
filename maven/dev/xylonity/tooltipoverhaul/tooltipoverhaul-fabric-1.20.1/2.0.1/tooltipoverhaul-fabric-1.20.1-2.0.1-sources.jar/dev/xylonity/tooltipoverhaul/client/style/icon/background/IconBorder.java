package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import net.minecraft.class_332;

final class IconBorder {

    public static void render(TooltipContext context, int left, int top, int right, int bottom, int color) {
        final String style = context.getFrameData() == null ? TooltipsConfig.ICON_BORDER_STYLE : context.getFrameData().getIconBorderStyle();
        render(context.getGraphics(), left, top, right, bottom, color, style);
    }

    public static void render(class_332 graphics, int left, int top, int right, int bottom, int color, String style) {
        final int corner = "style_2".equals(style) ? 1 : 0;

        // Top border
        graphics.method_25294(left - corner, top - 1, right + corner, top, color);

        // Bottom border
        graphics.method_25294(left - corner, bottom, right + corner, bottom + 1, color);

        // Left border
        graphics.method_25294(left - 1, top, left, bottom, color);

        // Right border
        graphics.method_25294(right, top, right + 1, bottom, color);
    }

}