package dev.xylonity.tooltipoverhaul.client.render;

import dev.xylonity.tooltipoverhaul.client.layer.ITooltipLayer;
import dev.xylonity.tooltipoverhaul.client.layer.LayerDepth;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipPositionCalculator;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipSizeCalculator;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameData;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import dev.xylonity.tooltipoverhaul.client.util.ModNameUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

import javax.annotation.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5684;
import net.minecraft.class_7833;
import net.minecraft.class_8000;
import java.util.List;

/**
 * Renderer wrapper that contains the relevant info from the tooltip context.
 */
public class TooltipContext {

    private final class_332 graphics;
    private final class_327 font;
    private final List<class_5684> components;
    private final int mouseX;
    private final int mouseY;
    private final int screenWidth;
    private final int screenHeight;
    private final class_8000 tooltipPositioner;

    private final class_1799 stack;

    private class_241 tooltipSize;
    private class_241 tooltipPosition;
    private LayerDepth layerDepth;

    private List<ITooltipLayer> layers;
    private final @Nullable CustomFrameData frameData;

    private final boolean isMainTooltip;
    private final boolean isEmptyTooltip;
    private final boolean hasIcon;
    private final boolean hasDividerLine;

    private final int paddingX;
    private final int paddingY;

    private final TooltipPositionCalculator positionCalculator;
    private final TooltipSizeCalculator sizeCalculator;

    private static final long START_TIME = System.currentTimeMillis();

    private @Nullable TooltipContext otherTooltipContext = null;

    public TooltipContext(class_332 graphics, class_327 font, List<class_5684> components, int mouseX, int mouseY, int screenWidth, int screenHeight, class_8000 tooltipPositioner, @NotNull class_1799 stack, boolean isMainTooltip) {
        this.graphics = graphics;
        this.font = font;
        this.components = ModNameUtils.appendModName(components, stack);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.tooltipPositioner = tooltipPositioner;
        this.stack = stack;
        this.isMainTooltip = isMainTooltip;
        this.frameData = CustomFrameManager.of(stack).orElse(null);
        this.isEmptyTooltip = stack.method_7960();
        this.hasIcon = RenderUtils.hasIcon(this);
        this.hasDividerLine = RenderUtils.hasDividerLine(this);
        this.paddingX = RenderUtils.calculatePadding(this, TextAxis.X);
        this.paddingY = RenderUtils.calculatePadding(this, TextAxis.Y);
        this.positionCalculator = new TooltipPositionCalculator(this);
        this.sizeCalculator = new TooltipSizeCalculator(this);
    }

    public class_332 getGraphics() {
        return graphics;
    }

    public class_327 getFont() {
        return font;
    }

    public List<class_5684> getComponents() {
        return components;
    }

    public int getMouseX() {
        return mouseX;
    }

    public int getMouseY() {
        return mouseY;
    }

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }

    public class_8000 getTooltipPositioner() {
        return tooltipPositioner;
    }

    public class_4597 getBuffer() {
        return graphics.method_51450();
    }

    public class_1799 getStack() {
        return stack;
    }

    public boolean isMainTooltip() {
        return isMainTooltip;
    }

    public void setTooltipSize(class_241 tooltipSize) {
        this.tooltipSize = tooltipSize;
    }

    public class_241 getTooltipSize() {
        return tooltipSize;
    }

    public void setTooltipPosition(class_241 tooltipPosition) {
        this.tooltipPosition = tooltipPosition;
    }

    public void setLayerDepth(LayerDepth layerDepth) {
        this.layerDepth = layerDepth;
    }

    public LayerDepth getLayerDepth() {
        return layerDepth;
    }

    public class_241 getTooltipPosition() {
        return tooltipPosition;
    }

    public void setTooltipLayers(List<ITooltipLayer> layers) {
        this.layers = layers;
    }

    public List<ITooltipLayer> getTooltipLayers() {
        return layers;
    }

    public boolean isEmptyTooltip() {
        return isEmptyTooltip;
    }

    public boolean hasIcon() {
        return hasIcon;
    }

    public boolean hasDividerLine() {
        return hasDividerLine;
    }

    public long getStartTime() {
        return START_TIME;
    }

    public int getPaddingX() {
        return paddingX;
    }

    public int getPaddingY() {
        return paddingY;
    }

    public TooltipPositionCalculator getPositionCalculator() {
        return positionCalculator;
    }

    public TooltipSizeCalculator getSizeCalculator() {
        return sizeCalculator;
    }

    @Nullable
    public CustomFrameData getFrameData() {
        return frameData;
    }

    public void setOtherTooltipContext(@Nullable TooltipContext otherTooltipContext) {
        this.otherTooltipContext = otherTooltipContext;
    }

    @Nullable
    public TooltipContext getOtherTooltipContext() {
        return otherTooltipContext;
    }

    public void flush() {
        this.graphics.method_51452();
    }

    public class_4587 getPose() {
        return graphics.method_51448();
    }

    public void push(Runnable r) {
        getPose().method_22903();
        try {
            r.run();
        }
        finally {
            getPose().method_22909();
        }

    }

    /**
     * Scissor helper that runs the rectangle through the current pose translation/scale before applying it
     */
    public void enableScissor(int x0, int y0, int x1, int y1) {
        final Matrix4f pose = getPose().method_23760().method_23761();
        final float px0 = pose.m00() * x0 + pose.m30();
        final float py0 = pose.m11() * y0 + pose.m31();
        final float px1 = pose.m00() * x1 + pose.m30();
        final float py1 = pose.m11() * y1 + pose.m31();

        graphics.method_44379(
                Math.round(Math.min(px0, px1)),
                Math.round(Math.min(py0, py1)),
                Math.round(Math.max(px0, px1)),
                Math.round(Math.max(py0, py1))
        );

    }

    public void translate(float x, float y, float z) {
        getPose().method_46416(x, y, z);
    }

    public void scale(float x, float y, float z) {
        getPose().method_22905(x, y, z);
    }

    public void multiply(class_7833 axis, float degrees) {
        getPose().method_22907(axis.rotationDegrees(degrees));
    }

}