package dev.xylonity.tooltipoverhaul.client.style.preview.renderer;

import com.mojang.authlib.GameProfile;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewRendererLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;
import net.minecraft.class_1304;
import net.minecraft.class_1664;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_745;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_898;

public class DefaultPreviewPlayerRenderer implements PreviewRendererLayer {

    private static final GameProfile DEFAULT_PROFILE = new GameProfile(new UUID(0L, 0L), "");
    private static final class_2960 DEFAULT_SKIN = TooltipOverhaul.pathOf("textures/preview/dummy.png");

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {

        int sizeX = RenderUtils.calculateSecondPanelSize(context, TextAxis.X);
        int sizeY = RenderUtils.calculateSecondPanelSize(context, TextAxis.Y);
        int y0 = (int) startPosition.field_1342;
        int x1 = (int) endPosition.field_1343;

        final class_310 minecraft = class_310.method_1551();

        // Without a loaded level the player doesnt exist, so the armor piece itself is drawn as a flat icon instead
        if (minecraft.field_1687 == null && context.getStack().method_7909() instanceof class_1738) {
            final float iconScale = Math.min(sizeX, sizeY) / 20f;
            context.translate(x1 + sizeX / 2f + 2 - 8 * iconScale, y0 + sizeY / 2f - 8 * iconScale, 0);
            context.scale(iconScale, iconScale, 1f);
            context.getGraphics().method_51427(context.getStack(), 0, 0);
            return;
        }

        context.translate((x1 + sizeX / 2f + 2), (y0 + sizeY / 1.15f) + 2, 0);

        context.multiply(class_7833.field_40714, -30);
        context.multiply(class_7833.field_40716, -45);

        context.multiply(class_7833.field_40716, (((System.currentTimeMillis() - context.getStartTime()) / 20f) % 360) * AnimationUtils.getSecondPanelRendererSpeed(context));

        final float scale = Math.min(sizeX, sizeY / 2f) / 1.25f;

        context.scale(-scale, -scale, scale);

        if (minecraft.field_1687 != null && context.getStack().method_7909() instanceof class_1738 armorItem) {
            class_745 player = getRemotePlayer(minecraft, context);

            for (class_1304 equipmentSlot : class_1304.values()) {
                player.method_5673(equipmentSlot, class_1799.field_8037);
            }
            player.method_5673(armorItem.method_7685(), context.getStack());

            player.method_36456(0);
            player.method_36457(0);
            player.field_6283 = 0;
            player.field_6241 = 0;

            class_308.method_34742();
            class_898 renderer = minecraft.method_1561();
            renderer.method_3948(false);
            renderer.method_3954(player, 0, 0, 0, 0, 1, context.getPose(), context.getBuffer(), 0xF000F0);
            renderer.method_3948(true);
        }

    }

    private static @NotNull class_745 getRemotePlayer(class_310 minecraft, TooltipContext context) {
        class_746 localPlayer = minecraft.field_1724;
        boolean usePlayerSkin = RenderUtils.usePlayerSkinInPreview(context);
        return new class_745(minecraft.field_1687, DEFAULT_PROFILE) {
            @Override
            public class_2960 method_3117() {
                if (localPlayer != null && usePlayerSkin) {
                    return localPlayer.method_3117();
                }

                return DEFAULT_SKIN;
            }

            @Override
            public @NotNull String method_3121() {
                if (localPlayer != null && usePlayerSkin) {
                    return localPlayer.method_3121();
                }

                return "default";
            }

            @Override
            public boolean method_7348(@NotNull class_1664 part) {
                if (localPlayer != null && usePlayerSkin) {
                    return localPlayer.method_7348(part);
                }

                return super.method_7348(part);
            }


        };

    }

}