package dev.xylonity.tooltipoverhaul.compat.glitchcore;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

/**
 * Replays GlitchCore's tooltip event so its components (the bug was reproduced with Tough As Nails' thirst droplets on
 * water bottles) survive the fact that I cancel renderTooltipInternal at head
 */
public final class GlitchcoreTooltipProxy {

    private static final String EVENT_CLASS = "glitchcore.event.client.RenderTooltipEvent";
    private static final String BASE_EVENT_CLASS = "glitchcore.event.Event";
    private static final String MANAGER_CLASS = "glitchcore.event.EventManager";

    @SuppressWarnings("unchecked")
    public static List<class_5684> gather(class_332 graphics, class_1799 stack, List<class_5684> components, class_327 font, int mouseX, int mouseY, int screenWidth, int screenHeight, class_8000 positioner) {
        try {
            final List<class_5684> mutable = new ArrayList<>(components);

            final ClassLoader loader = GlitchcoreTooltipProxy.class.getClassLoader();
            final Class<?> eventClass = Class.forName(EVENT_CLASS, false, loader);
            final Class<?> baseEventClass = Class.forName(BASE_EVENT_CLASS, false, loader);
            final Class<?> managerClass = Class.forName(MANAGER_CLASS, false, loader);

            final Constructor<?> constructor = eventClass.getConstructor(
                    class_1799.class, class_332.class, int.class, int.class, int.class, int.class,
                    List.class, class_327.class, class_8000.class
            );
            final Object event = constructor.newInstance(stack, graphics, mouseX, mouseY, screenWidth, screenHeight, mutable, font, positioner);

            final Method fire = managerClass.getMethod("fire", baseEventClass);
            fire.invoke(null, event);

            final Object result = eventClass.getMethod("getComponents").invoke(event);
            if (result instanceof List<?>) {
                return (List<class_5684>) result;
            }

            return mutable;
        }
        catch (Throwable ignored) {
            return components;
        }

    }

}