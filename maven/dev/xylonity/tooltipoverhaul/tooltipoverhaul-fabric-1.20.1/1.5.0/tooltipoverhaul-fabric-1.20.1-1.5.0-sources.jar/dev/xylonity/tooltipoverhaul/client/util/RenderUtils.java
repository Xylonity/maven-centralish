package dev.xylonity.tooltipoverhaul.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameData;
import dev.xylonity.tooltipoverhaul.client.render.FadeRenderType;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.mixin.KeyMappingAccessor;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Optional;
import net.minecraft.class_1087;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_1309;
import net.minecraft.class_148;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1937;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;

public class RenderUtils {

    public static boolean hasIcon(TooltipContext context) {
        return !context.getStack().method_7960() && !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableIcon).orElse(TooltipsConfig.DISABLE_ICON);
    }

    public static boolean hasRating(TooltipContext context) {
        return !context.getStack().method_7960() && Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldShowRating).orElse(TooltipsConfig.SHOW_RATING);
    }

    public static boolean hasDividerLine(TooltipContext context) {
        return !context.getStack().method_7960() && !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableDividerLine).orElse(TooltipsConfig.DISABLE_DIVIDER_LINE);
    }

    public static boolean hasShadow(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldShowShadow).orElse(TooltipsConfig.SHOW_TOOLTIP_SHADOW);
    }

    public static boolean hasVignette(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::hasVignette).orElse(TooltipsConfig.VIGNETTES.isBlank());
    }

    public static boolean shouldRender(TooltipContext context) {
        return !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableTooltip).orElse(false);
    }

    public static boolean hasPreviewOfTieredItem(TooltipContext context) {
        if (isComparisonActive(context)) {
            return false;
        }

        if (context.getStack().method_7909() instanceof class_1831) {
            return Optional.ofNullable(context.getFrameData()).map(data -> data.shouldShowSecondPanel(context)).orElse(TooltipsConfig.TIERED_ITEMS_RENDERER);
        }

        return false;
    }

    public static boolean hasPreviewOfArmorItem(TooltipContext context) {
        if (isComparisonActive(context)) {
            return false;
        }

        if (context.getStack().method_7909() instanceof class_1738) {
            return Optional.ofNullable(context.getFrameData()).map(data -> data.shouldShowSecondPanel(context)).orElse(TooltipsConfig.ARMOR_ITEMS_RENDERER);
        }

        return false;
    }

    private static boolean isComparisonActive(TooltipContext context) {
        class_3675.class_306 compareKey = ((KeyMappingAccessor) TooltipOverhaulKeyMappings.COMPARE_TOOLTIP).tooltipoverhaul$key();
        boolean isKeyDown = false;
        if (!compareKey.equals(class_3675.field_16237)) {
            isKeyDown = class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), compareKey.method_1444());
        }

        return isKeyDown && context.getOtherTooltipContext() != null;
    }

    public static int calculateSecondPanelSize(TooltipContext context, TextAxis axis) {
        if (axis == TextAxis.X) {
            return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getSecondPanelSizeX).orElse(TooltipsConfig.SECOND_PANEL_SIZE_X);
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getSecondPanelSizeY).orElse(TooltipsConfig.SECOND_PANEL_SIZE_Y);
    }

    public static String getIconAppearAnimation(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconAppearAnimation).orElse(TooltipsConfig.ICON_APPEAR_ANIMATION);
    }

    public static float getIconRotatingSpeed(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconRotatingSpeed).orElse(TooltipsConfig.ICON_ROTATING_SPEED);
    }

    public static String getIconBackgroundType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconBackground).orElse(TooltipsConfig.ICON_BACKGROUND_TYPE);
    }

    public static String getDividerLineType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getDividerLineType).orElse(TooltipsConfig.DIVIDER_LINE_TYPE);
    }

    public static String getEffect(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getEffect).orElse(TooltipsConfig.EFFECTS);
    }

    public static boolean usePlayerSkinInPreview(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getUsePlayerSkinInPreview).orElse(TooltipsConfig.USE_PLAYER_SKIN_IN_PREVIEW);
    }

    public static String getPreviewPanelModel(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getPreviewPanelModel).orElse(TooltipsConfig.PREVIEW_PANEL_MODEL);
    }

    public static int calculatePadding(TooltipContext context, TextAxis axis) {
        if (context.getStack().method_7960()) {
            if (axis == TextAxis.X) {
                return TooltipsConfig.NO_STACK_TOOLTIP_PADDING_X;
            }

            return TooltipsConfig.NO_STACK_TOOLTIP_PADDING_Y;
        }

        if (axis == TextAxis.X) {
            return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getMainPanelPaddingX).orElse(TooltipsConfig.MAIN_PANEL_PADDING_X);
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getMainPanelPaddingY).orElse(TooltipsConfig.MAIN_PANEL_PADDING_Y);
    }

    public static String getInnerOverlayType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getBorderType).orElse(TooltipsConfig.DEFAULT_INNER_OVERLAY_TYPE);
    }

    public static String getInnerFrameCornerType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getInnerFrameCornerType).orElse(TooltipsConfig.INNER_FRAME_CORNER_TYPE);
    }

    public static String getBackgroundCornerType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getBackgroundCornerType).orElse(TooltipsConfig.BACKGROUND_CORNER_TYPE);
    }

    public static void applyFrameCorners(class_332 graphics, int x0, int y0, int width, int height, int topColor, int bottomColor, int bgColor, String type, boolean cornerCut) {
        final int[][] erase;
        final int[][] add;
        // Which corners the style is applied to, as indices into the corners array below (in order: top left, top right, bottom left, bottom right)
        int[] cornersToApply = {0, 1, 2, 3};

        switch (type) {
            case "rounded" -> {
                erase = new int[][]{{0, 0}};
                add = new int[][]{};
            }
            case "bevel" -> {
                erase = new int[][]{{0, 0}};
                add = new int[][]{{1, 1}};
            }
            case "inner" -> {
                erase = new int[][]{};
                add = new int[][]{{1, 1}};
            }
            case "cut" -> {
                erase = new int[][]{{0, 0}, {1, 0}, {0, 1}};
                add = new int[][]{{1, 1}};
            }
            case "thick" -> {
                erase = new int[][]{};
                add = new int[][]{{1, 1}, {2, 1}, {3, 1}, {1, 2}, {2, 2}, {1, 3}};
                cornersToApply = new int[]{1};
            }
            case "bracket" -> {
                erase = new int[][]{};
                add = new int[][]{{2, 2}, {3, 2}, {2, 3}};
            }
            case "block" -> {
                erase = new int[][]{};
                add = new int[][]{{1, 1}, {2, 1}, {1, 2}, {2, 2}};
            }
            case "notch" -> {
                erase = new int[][]{{0, 0}, {1, 0}, {0, 1}};
                add = new int[][]{{2, 1}, {1, 2}, {2, 2}};
            }
            case "weld" -> {
                erase = new int[][]{};
                add = new int[][]{{1, 1}, {2, 1}, {1, 2}};
            }
            case "gem" -> {
                erase = new int[][]{};
                add = new int[][]{{2, 1}, {4, 1}, {1, 2}, {3, 2}, {2, 3}, {1, 4}};
            }
            default -> {
                return;
            }

        }

        final int xr = x0 + width - 1;
        final int yb = y0 + height - 1;

        // (cornerX, cornerY, inward X step, inward Y step) for each of the four corners
        int[][] corners = {
                {x0, y0, 1, 1},
                {xr, y0, -1, 1},
                {x0, yb, 1, -1},
                {xr, yb, -1, -1}
        };

        for (final int idx : cornersToApply) {
            final int[] corner = corners[idx];
            final int cornerX = corner[0];
            final int cornerY = corner[1];
            final int stepX = corner[2];
            final int stepY = corner[3];
            final int color = cornerY == y0 ? topColor : bottomColor;

            for (final int[] pixel : erase) {
                if (cornerCut && pixel[0] == 0 && pixel[1] == 0) {
                    continue;
                }

                fillPixel(graphics, cornerX + pixel[0] * stepX, cornerY + pixel[1] * stepY, bgColor);
            }
            for (final int[] pixel : add) {
                fillPixel(graphics, cornerX + pixel[0] * stepX, cornerY + pixel[1] * stepY, color);
            }

        }

    }

    private static void fillPixel(class_332 graphics, int x, int y, int color) {
        graphics.method_25294(x, y, x + 1, y + 1, color);
    }

    public static String getOverlayLocation(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getTextureLocation).orElse(TooltipsConfig.GLOBAL_FRAME_OVERLAY_LOCATION);
    }

    public static void renderItem(TooltipContext context, @Nullable class_1309 entity, @Nullable class_1937 level, class_1799 stack, int seed) {
        if (!stack.method_7960()) {
            class_1087 bakedmodel = class_310.method_1551().method_1480().method_4019(stack, level, entity, seed);
            context.getPose().method_22903();

            try {
                context.getPose().method_34425((new Matrix4f()).scaling(1.0F, -1.0F, 1.0F));
                context.getPose().method_22905(16.0F, 16.0F, 16.0F);
                boolean flag = !bakedmodel.method_24304();
                if (flag) {
                    class_308.method_24210();
                }

                // Cutout/solid item render types don't blend, so the fade of the in/out animation (applied
                // through the shader color alpha) has no visible effect on them
                class_4597 bufferSource = context.getBuffer();
                if (RenderSystem.getShaderColor()[3] < 1.0f) {
                    final class_4597 delegate = bufferSource;
                    bufferSource = type -> delegate.getBuffer(FadeRenderType.remap(type));
                }

                class_310.method_1551().method_1480().method_23179(stack, class_811.field_4317, false, context.getPose(), bufferSource, class_765.field_32767, class_4608.field_21444, bakedmodel);
                context.flush();
                if (flag) {
                    class_308.method_24211();
                }
            }
            catch (Throwable throwable) {
                class_128 crashreport = class_128.method_560(throwable, "Rendering item");
                class_129 crashreportcategory = crashreport.method_562("Item being rendered");
                crashreportcategory.method_577("Item Type", () -> String.valueOf(stack.method_7909()));
                crashreportcategory.method_577("Item Damage", () -> String.valueOf(stack.method_7919()));
                crashreportcategory.method_577("Item NBT", () -> String.valueOf(stack.method_7969()));
                crashreportcategory.method_577("Item Foil", () -> String.valueOf(stack.method_7958()));
                throw new class_148(crashreport);
            }

            context.getPose().method_22909();
        }

    }

    public static void renderFrameGradient(class_332 graphics, int x, int y, int width, int height, int c1, int c2, int c3) {
        int mid = height / 2;

        // Left border (top and bottom sections)
        graphics.method_25296(x, y, x + 1, y + mid, c1, c2);
        graphics.method_25296(x, y + mid, x + 1, y + height, c2, c3);

        // Right border (top and bottom sections)
        graphics.method_25296(x + width - 1, y, x + width, y + mid, c1, c2);
        graphics.method_25296(x + width - 1, y + mid, x + width, y + height, c2, c3);
    }

}
