package dev.xylonity.tooltipoverhaul.platform;

import dev.xylonity.tooltipoverhaul.compat.glitchcore.GlitchcoreTooltipProxy;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

public interface TooltipPlatform {

    boolean isModLoaded(String modid);

    Path resolveConfigFile(String configFileName);
    Path getConfigPath();

    class_1799 getHoveredItem(class_332 graphics, List<class_5684> components, int mouseX, int mouseY);

    Optional<String> getModDisplayName(String namespace);

    /**
     * Lets loader-specific tooltip event hooks contribute extra {@link class_5684}s before rendering
     */
    default List<class_5684> gatherTooltipComponents(class_332 graphics, class_1799 stack, List<class_5684> components, class_327 font, int mouseX, int mouseY, int screenWidth, int screenHeight, class_8000 positioner) {
        if (isModLoaded("glitchcore")) {
            return GlitchcoreTooltipProxy.gather(graphics, stack, components, font, mouseX, mouseY, screenWidth, screenHeight, positioner);
        }

        return components;
    }

    /**
     * Replays the loader-specific pre-render tooltip event, which normally fires inside {@code renderTooltipInternal} but is
     * skipped since I cancel it on the GUI graphics mixin
     */
    default boolean fireRenderTooltipPre(class_332 graphics, class_1799 stack, List<class_5684> components, class_327 font, int mouseX, int mouseY, int screenWidth, int screenHeight, class_8000 positioner) {
        return false;
    }

}
