package dev.xylonity.tooltipoverhaul.client.util;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.mixin.ClientTextTooltipAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_5683;
import net.minecraft.class_5684;
import net.minecraft.class_7923;

/**
 * Resolves the display name of the mod that adds an item, so it can be appended as the last tooltip line
 */
public final class ModNameUtils {

    private static final Map<String, String> CACHE = new ConcurrentHashMap<>();

    public static String getModName(class_1799 stack) {
        final String namespace = class_7923.field_41178.method_10221(stack.method_7909()).method_12836();
        return CACHE.computeIfAbsent(namespace, vNamespace -> {
            if ("minecraft".equals(vNamespace)) {
                return "Minecraft";
            }

            return TooltipOverhaul.PLATFORM.getModDisplayName(vNamespace).orElseGet(() -> capitalize(vNamespace));
        });

    }

    /**
     * Returns a new list with the mod name appended as a blue italic last line (ignored if the component list already includes such line)
     */
    public static List<class_5684> appendModName(List<class_5684> components, class_1799 stack) {
        if (!TooltipsConfig.SHOW_MOD_NAME || stack.method_7960()) {
            return components;
        }

        final String name = getModName(stack);
        if (!components.isEmpty() && name.equalsIgnoreCase(plainTextOf(components.get(components.size() - 1)))) {
            return components;
        }

        final List<class_5684> result = new ArrayList<>(components);
        result.add(class_5684.method_32662(class_2561.method_43470(name).method_27695(class_124.field_1078, class_124.field_1056).method_30937()));

        return result;
    }

    private static String plainTextOf(class_5684 component) {
        if (!(component instanceof class_5683 text)) {
            return "";
        }

        final StringBuilder stringBuilder = new StringBuilder();
        ((ClientTextTooltipAccessor) text).getText().accept((index, style, codePoint) -> {
            stringBuilder.appendCodePoint(codePoint);
            return true;
        });

        return stringBuilder.toString();
    }

    private static String capitalize(String namespace) {
        return namespace.isEmpty() ? namespace : Character.toUpperCase(namespace.charAt(0)) + namespace.substring(1);
    }

}
