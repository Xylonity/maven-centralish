package dev.xylonity.tooltipoverhaul.client.style.inner;

import dev.xylonity.tooltipoverhaul.client.layer.impl.InnerOverlayLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import net.minecraft.class_241;
import net.minecraft.class_332;

public class GradientInnerOverlay implements InnerOverlayLayer {

    private final int color1;
    private final int color2;
    private final int color3;

    public GradientInnerOverlay(int color1, int color2, int color3) {
        this.color1 = color1;
        this.color2 = color2;
        this.color3 = color3;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        int x0 = (int) (context.getTooltipPosition().field_1343 - 3);
        int y0 = (int) (context.getTooltipPosition().field_1342 - 2);
        int width = (int) (context.getTooltipSize().field_1343 + 5);
        int height = (int) (context.getTooltipSize().field_1342 + 4);

        renderFrameGradient(context.getGraphics(), x0, y0 + 1, width, height - 2, color1, color2, color3);

        // Top and bottom lines
        context.getGraphics().method_25294(x0, y0, x0 + width, y0 + 1, color1);
        context.getGraphics().method_25294(x0, y0 + height - 1, x0 + width, y0 + height, color3);
    }

    private static void renderFrameGradient(class_332 graphics, int x, int y, int width, int height, int c1, int c2, int c3) {
        int mid = height / 2;

        // Left border (top and bottom sections)
        graphics.method_25296(x, y, x + 1, y + mid, c1, c2);
        graphics.method_25296(x, y + mid, x + 1, y + height, c2, c3);

        // Right border (top and bottom sections)
        graphics.method_25296(x + width - 1, y, x + width, y + mid, c1, c2);
        graphics.method_25296(x + width - 1, y + mid, x + width, y + height, c2, c3);
    }

}
