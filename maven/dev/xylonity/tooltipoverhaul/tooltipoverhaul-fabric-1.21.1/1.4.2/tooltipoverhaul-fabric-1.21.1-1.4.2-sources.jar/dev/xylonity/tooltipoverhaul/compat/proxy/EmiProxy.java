package dev.xylonity.tooltipoverhaul.compat.proxy;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5684;

/**
 * Proxy used for dedicated EMI compat, in order to 'detect' the hovered stack on EMI categories (and the recipe viewer)
 */
public final class EmiProxy {

    private static final String CLASS_LOCATION = "dev.xylonity.tooltipoverhaul.compat.emi.EmiHoverHolder";
    private static final String CLASS_METHOD = "getItemStack";

    public static class_1799 getItemStack() {
        if (!TooltipOverhaul.PLATFORM.isModLoaded("emi")) return class_1799.field_8037;
        try {
            Class<?> holder = Class.forName(CLASS_LOCATION, false, EmiProxy.class.getClassLoader());
            Method method = holder.getMethod(CLASS_METHOD);
            Object stack = method.invoke(null);
            return (stack instanceof class_1799 s) ? s : class_1799.field_8037;
        }
        catch (Exception ignored) {
            return class_1799.field_8037;
        }

    }

    // Fallbacks to the category viewer if there is no hovered stack in the current coordinates (for the recipe viewer)
    public static class_1799 getItemStack(int mouseX, int mouseY) {
        if (!TooltipOverhaul.PLATFORM.isModLoaded("emi")) return class_1799.field_8037;
        try {
            Class<?> holder = Class.forName(CLASS_LOCATION, false, EmiProxy.class.getClassLoader());
            Method method = holder.getMethod(CLASS_METHOD, int.class, int.class);
            Object stack = method.invoke(null, mouseX, mouseY);
            return (stack instanceof class_1799 s) ? s : class_1799.field_8037;
        }
        catch (NoSuchMethodException e) {
            return getItemStack();
        }
        catch (Exception ignored) {
            return class_1799.field_8037;
        }

    }

    public static boolean isEmiTooltip(List<class_5684> components) {
        if (isEmiScreen()) {
            return true;
        }

        if (components != null) {
            for (class_5684 component : components) {
                if (component == null) {
                    continue;
                }

                String packageName = component.getClass().getName().toLowerCase(Locale.ROOT);
                if (packageName.contains("dev.emi") || packageName.contains(".emi.")) {
                    return true;
                }

            }

        }

        return false;
    }

    private static boolean isEmiScreen() {
        class_437 screen = class_310.method_1551().field_1755;
        if (screen == null) {
            return false;
        }

        String packageName = screen.getClass().getName().toLowerCase(Locale.ROOT);
        return packageName.contains("dev.emi") || packageName.contains(".emi.");
    }

}
