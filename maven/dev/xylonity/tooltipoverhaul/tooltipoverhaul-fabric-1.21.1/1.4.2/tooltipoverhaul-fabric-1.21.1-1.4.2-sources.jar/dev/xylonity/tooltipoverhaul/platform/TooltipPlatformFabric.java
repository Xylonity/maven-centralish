package dev.xylonity.tooltipoverhaul.platform;

import dev.xylonity.tooltipoverhaul.compat.proxy.EmiProxy;
import dev.xylonity.tooltipoverhaul.compat.proxy.JeiProxy;
import dev.xylonity.tooltipoverhaul.compat.proxy.ScreenTypeProxy;
import dev.xylonity.tooltipoverhaul.mixin.AbstractContainerScreenMixin;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_5684;
import java.nio.file.Path;
import java.util.List;

public class TooltipPlatformFabric implements TooltipPlatform {

    @Override
    public boolean isModLoaded(String modid) {
        return FabricLoader.getInstance().isModLoaded(modid);
    }

    @Override
    public Path resolveConfigFile(String configFileName) {
        return FabricLoader.getInstance().getConfigDir().resolve(configFileName);
    }

    @Override
    public Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir();
    }

    /**
     * Hovered ItemStack locator. For dedicated mod compatibility, proxies (reflection) are used
     */
    @Override
    public class_1799 getHoveredItem(class_332 graphics, List<class_5684> components, int mouseX, int mouseY) {

        class_437 screen = class_310.method_1551().field_1755;



        boolean isContainerLike = (screen instanceof class_465<?>) || (screen instanceof class_481) || ScreenTypeProxy.isContainerLikeOrJeiEmi();
        if (!isContainerLike) {
            return class_1799.field_8037;
        }

        // Vanilla GUI hovered stack
        if (screen instanceof class_465<?> container) {
            try {
                class_1735 slot = ((AbstractContainerScreenMixin) container).getHoveredSlot();
                if (slot != null) {
                    class_1799 stack = slot.method_7677();
                    if (!stack.method_7960()) {
                        return stack;
                    }
                }
            }
            catch (Throwable ignored) {
                ;;

            }

        }

        // Emi compat
        class_1799 emiStack = EmiProxy.getItemStack(mouseX, mouseY);
        if (!emiStack.method_7960()) {
            return emiStack;
        }

        // Jei compat
        class_1799 jeiStack = JeiProxy.getItemStack();
        if (!jeiStack.method_7960()) {
            return jeiStack;
        }

        return class_1799.field_8037;
    }

}
