package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.IconBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import net.minecraft.class_241;

public class SlotIconBackground implements IconBackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        int positionX = (int) context.getTooltipPosition().field_1343 - 1 + context.getPaddingX();
        int positionY = (int) context.getTooltipPosition().field_1342 + context.getPaddingY();

        int slotSizeX = positionX + Constants.getIconSize(context);
        int slotSizeY = positionY + Constants.getIconSize(context);

        int x0 = positionX;
        int y0 = positionY;
        int x1 = slotSizeX;
        int y1 = slotSizeY;

        // Background
        context.getGraphics().method_25294(x0, y0, x1, y1, 0x903E3E3E);

        // Top border
        context.getGraphics().method_25294(x0, y0 - 1, x1, y0, 0x903E3E3E);
        // Bottom border
        context.getGraphics().method_25294(x0, y1 + 1, x1, y1, 0x903E3E3E);
        // Left border
        context.getGraphics().method_25294(x0 - 1, y0, x0, y1, 0x903E3E3E);
        // Right border
        context.getGraphics().method_25294(x1 + 1, y0, x1, y1, 0x903E3E3E);
    }

}