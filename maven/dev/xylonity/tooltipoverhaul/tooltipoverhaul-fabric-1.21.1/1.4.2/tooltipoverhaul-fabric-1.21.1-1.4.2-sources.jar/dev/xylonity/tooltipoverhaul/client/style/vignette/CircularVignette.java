package dev.xylonity.tooltipoverhaul.client.style.vignette;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.VignetteLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.vignette.parser.VignetteEntry;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.PositionUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public class CircularVignette implements VignetteLayer {

    private static final int SEGMENTS = 64;

    private final VignetteEntry vignetteEntry;

    public CircularVignette(VignetteEntry vignetteEntry) {
        this.vignetteEntry = vignetteEntry;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {

        int positionX = (int) position.field_1343;
        int positionY = (int) position.field_1342;
        int tooltipWidth = (int) context.getTooltipSize().field_1343;
        int tooltipHeight = (int) context.getTooltipSize().field_1342;
        int paddingX = context.getPaddingX();
        int paddingY = context.getPaddingY();

        float anchorPositionX = positionX + PositionUtils.getVignettePosition(context, vignetteEntry, TextAxis.X) + (tooltipHeight * (vignetteEntry.extraPositionX() / 100f));
        float anchorPositionY = positionY + PositionUtils.getVignettePosition(context, vignetteEntry, TextAxis.Y) + (tooltipWidth * (vignetteEntry.extraPositionY() / 100f));
        float radius = tooltipWidth * vignetteEntry.radius();

        int color = vignetteEntry.color();

        context.translate(anchorPositionX, anchorPositionY, 0);

        context.getGraphics().method_44379(
                positionX - paddingX - 1,
                positionY - paddingY,
                positionX + tooltipWidth + paddingX,
                positionY + tooltipHeight + paddingY
        );

        RenderSystem.enableBlend();

        RenderSystem.blendFuncSeparate(
                GlStateManager.class_4535.SRC_ALPHA,
                GlStateManager.class_4534.ONE,
                GlStateManager.class_4535.ONE,
                GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
        );

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(class_757::method_34540);

        Matrix4f pose = context.getPose().method_23760().method_23761();
        class_289 tesselator = class_289.method_1348();

        // Circle
        class_287 buffer = tesselator.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

        // Completely opaque center
        buffer.method_22918(pose, 0, 0, 0)
                .method_1336(ColorUtils.red(color), ColorUtils.green(color), ColorUtils.blue(color), ColorUtils.alpha(color));

        // Transparent border along the chunk amount
        for (int i = 0; i <= SEGMENTS; i++) {
            float angle = (i / (float) SEGMENTS) * (float) Math.PI * 2.0f;
            float vertexPositionX = (float) Math.cos(angle) * radius;
            float vertexPositionY = (float) Math.sin(angle) * radius;

            buffer.method_22918(pose, vertexPositionX, vertexPositionY, 0)
                    .method_1336(ColorUtils.red(color), ColorUtils.green(color), ColorUtils.blue(color), 0);
        }

        try (class_9801 data = buffer.method_60800()) {
            class_286.method_43433(data);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();

        RenderSystem.blendFunc(
                GlStateManager.class_4535.SRC_ALPHA,
                GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
        );

        RenderSystem.disableBlend();
        RenderSystem.enableCull();

        context.getGraphics().method_44380();
    }

}