package dev.xylonity.tooltipoverhaul.client.style.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.BackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;

public class DefaultBackground implements BackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {
        int x0 = (int) (position.field_1343 - 3);
        int y0 = (int) (position.field_1342 - 2);
        int x1 = (int) (position.field_1343 + context.getTooltipSize().field_1343 + 2);
        int y1 = (int) (position.field_1342 + context.getTooltipSize().field_1342 + 2);

        int backgroundColor = ColorUtils.getBackgroundColor(context);

        // Background
        context.getGraphics().method_25294(x0, y0, x1, y1, backgroundColor);

        // Top border
        context.getGraphics().method_25294(x0, y0 - 1, x1, y0, backgroundColor);
        // Bottom border
        context.getGraphics().method_25294(x0, y1 + 1, x1, y1, backgroundColor);
        // Left border
        context.getGraphics().method_25294(x0 - 1, y0, x0, y1, backgroundColor);
        // Right border
        context.getGraphics().method_25294(x1 + 1, y0, x1, y1, backgroundColor);
    }

}