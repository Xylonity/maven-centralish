package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.compat.modernfix.HoveredStackCache;
import dev.xylonity.tooltipoverhaul.compat.modernfix.ModernFixCompat;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Restores the real baked model of the hovered stack in case there is a mod that potentially culls
 * non-visible faces of the current model (such as modernfix)
 */
@Mixin(value = class_918.class, priority = 1200)
public abstract class BypassHoverGuiCullingMixin {

    @ModifyArg(
            method = "render(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IILnet/minecraft/client/resources/model/BakedModel;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/ItemRenderer;renderModelLists(Lnet/minecraft/client/resources/model/BakedModel;Lnet/minecraft/world/item/ItemStack;IILcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;)V"
            ),
            index = 0
    )
    private class_1087 tooltipoverhaul$restoreModelIfHovered(class_1087 model, class_1799 stack, int combinedLight, int combinedOverlay, class_4587 poseStack, class_4588 buffer) {
        if (ModernFixCompat.isEnabled() && HoveredStackCache.model != null) return HoveredStackCache.model;
        return model;
    }

}
