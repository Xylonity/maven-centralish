package dev.xylonity.tooltipoverhaul.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = class_465.class, priority = 1)
public interface AbstractContainerScreenMixin {

    @Accessor("hoveredSlot")
    class_1735 getHoveredSlot();

}