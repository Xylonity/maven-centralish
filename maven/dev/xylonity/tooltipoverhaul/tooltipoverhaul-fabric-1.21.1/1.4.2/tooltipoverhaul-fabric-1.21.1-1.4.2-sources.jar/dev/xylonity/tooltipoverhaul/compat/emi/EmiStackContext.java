package dev.xylonity.tooltipoverhaul.compat.emi;

import net.minecraft.class_1799;

public final class EmiStackContext {

    private static final ThreadLocal<class_1799> STACK = ThreadLocal.withInitial(() -> class_1799.field_8037);

    public static void set(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            STACK.set(class_1799.field_8037);
            return;
        }

        STACK.set(stack.method_7972());
    }

    public static class_1799 get() {
        class_1799 stack = STACK.get();
        return (stack == null) ? class_1799.field_8037 : stack;
    }

    public static void clear() {
        STACK.set(class_1799.field_8037);
    }

}
