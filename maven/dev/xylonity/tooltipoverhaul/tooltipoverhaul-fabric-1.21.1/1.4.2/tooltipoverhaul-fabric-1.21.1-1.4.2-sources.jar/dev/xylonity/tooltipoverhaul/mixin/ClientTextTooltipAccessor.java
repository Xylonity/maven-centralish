package dev.xylonity.tooltipoverhaul.mixin;

import net.minecraft.class_5481;
import net.minecraft.class_5683;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = class_5683.class, priority = 1)
public interface ClientTextTooltipAccessor {
    @Accessor("text")
    class_5481 getText();
}
