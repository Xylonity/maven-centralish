package dev.xylonity.tooltipoverhaul.util;

import net.minecraft.class_1799;

public interface ITooltipOverhaulItemAware {

    class_1799 tooltipsOverhaul$hoveredItem();

}