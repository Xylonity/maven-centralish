package dev.xylonity.tooltipoverhaul.compat.modernfix;

import net.minecraft.class_1087;

public class HoveredStackCache {
    public static class_1087 model;
}
