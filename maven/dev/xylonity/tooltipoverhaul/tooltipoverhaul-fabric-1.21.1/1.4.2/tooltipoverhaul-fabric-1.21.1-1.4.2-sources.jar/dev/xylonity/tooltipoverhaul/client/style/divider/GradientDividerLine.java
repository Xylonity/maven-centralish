package dev.xylonity.tooltipoverhaul.client.style.divider;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.DividerLineLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public class GradientDividerLine implements DividerLineLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        int y = (int) position.field_1342;
        int x = (int) (position.field_1343 + context.getTooltipSize().field_1343 * 0.1f);
        int paddingX = context.getPaddingX();
        int width = (int) ((int) context.getTooltipSize().field_1343 - context.getTooltipSize().field_1343 * 0.2f);

        class_4587 pose = context.getGraphics().method_51448();
        Matrix4f matrix = pose.method_23760().method_23761();
        class_289 tesselator = class_289.method_1348();
        class_287 buf = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        int baseColor = ColorUtils.getDividerLineColor(context);
        int r = (baseColor >>> 16) & 0xFF;
        int g = (baseColor >>> 8) & 0xFF;
        int b = baseColor & 0xFF;

        int halfWidth = width / 2;
        int centerX = x + halfWidth - paddingX;

        buf.method_22918(matrix, x - paddingX, y + 1, 0).method_1336(r, g, b, 0);
        buf.method_22918(matrix, centerX, y + 1, 0).method_1336(r, g, b, 255);
        buf.method_22918(matrix, centerX, y, 0).method_1336(r, g, b, 255);
        buf.method_22918(matrix, x - paddingX, y, 0).method_1336(r, g, b, 0);
        buf.method_22918(matrix, centerX, y + 1, 0).method_1336(r, g, b, 255);
        buf.method_22918(matrix, x + width - paddingX, y + 1, 0).method_1336(r, g, b, 0);
        buf.method_22918(matrix, x + width - paddingX, y, 0).method_1336(r, g, b, 0);
        buf.method_22918(matrix, centerX, y, 0).method_1336(r, g, b, 255);

        try (class_9801 data = buf.method_60800()) {
            class_286.method_43433(data);
        }
    }
}