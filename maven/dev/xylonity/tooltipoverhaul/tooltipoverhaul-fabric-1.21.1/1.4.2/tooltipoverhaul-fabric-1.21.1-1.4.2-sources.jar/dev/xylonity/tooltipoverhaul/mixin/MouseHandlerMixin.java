package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_312.class, priority = 1)
public abstract class MouseHandlerMixin {

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void tooltipoverhaul$onScroll(long window, double dx, double dy, CallbackInfo ci) {
        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1755 == null) {
            if (TooltipScrollState.isIsActive()) {
                TooltipScrollState.reset();
            }

            return;
        }

        if (TooltipScrollState.shouldCaptureScroll()) {
            TooltipScrollState.onRawScroll(dy);
            ci.cancel();
        }

    }

}