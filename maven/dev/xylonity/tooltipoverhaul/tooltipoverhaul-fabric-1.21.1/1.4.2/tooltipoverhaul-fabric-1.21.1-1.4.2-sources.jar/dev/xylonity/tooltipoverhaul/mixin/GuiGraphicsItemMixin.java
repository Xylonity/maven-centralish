package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.util.ITooltipOverhaulItemAware;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(value = class_332.class, priority = 1)
public class GuiGraphicsItemMixin implements ITooltipOverhaulItemAware {

    @Unique
    private class_1799 tooltipsOverhaul$currentItemStack = class_1799.field_8037;

    @Inject(method = "renderTooltipInternal", at = @At("HEAD"))
    private void tooltipsOverhaul$captureHovered(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 positioner, CallbackInfo ci) {
        tooltipsOverhaul$currentItemStack = TooltipOverhaul.PLATFORM.getHoveredItem((class_332) (Object) this, components, mouseX, mouseY);
    }

    @Inject(method = "renderTooltipInternal", at = @At("RETURN"))
    private void tooltipsOverhaul$clearHovered(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 positioner, CallbackInfo ci) {
        tooltipsOverhaul$currentItemStack = class_1799.field_8037;
    }

    @Override
    public class_1799 tooltipsOverhaul$hoveredItem() {
        return tooltipsOverhaul$currentItemStack;
    }

}
