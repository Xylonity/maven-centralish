package dev.xylonity.tooltipoverhaul.compat.jei;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.class_2960;

@JeiPlugin
public final class TooltipOverhaulJeiPlugin implements IModPlugin {

    private static final class_2960 UID = class_2960.method_60655(TooltipOverhaul.MOD_ID, "jei_plugin");

    @Override
    public class_2960 getPluginUid() {
        return UID;
    }

    @Override
    public void onRuntimeAvailable(IJeiRuntime runtime) {
        JeiHoverHolder.init(runtime);
    }

}