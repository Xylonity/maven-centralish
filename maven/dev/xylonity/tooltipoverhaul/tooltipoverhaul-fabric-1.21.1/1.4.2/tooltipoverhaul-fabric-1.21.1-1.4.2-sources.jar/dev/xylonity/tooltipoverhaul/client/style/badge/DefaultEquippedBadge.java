package dev.xylonity.tooltipoverhaul.client.style.badge;

import dev.xylonity.tooltipoverhaul.client.layer.impl.BackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_5684;

public class DefaultEquippedBadge implements BackgroundLayer {

    private final int color1;
    private final int color2;
    private final int color3;

    public DefaultEquippedBadge(int color1, int color2, int color3) {
        this.color1 = color1;
        this.color2 = color2;
        this.color3 = color3;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {

        int sizeY = 20;
        int offsetY = 20;

        int x0 = (int) (position.field_1343 - 3);
        int y0 = (int) (position.field_1342 - sizeY - offsetY);
        int x1 = (int) (position.field_1343 + context.getTooltipSize().field_1343 + 2);
        int y1 = (int) (position.field_1342 - offsetY);

        int backgroundColor = ColorUtils.getBackgroundColor(context);

        // Background
        context.getGraphics().method_51737(x0, y0, x1, y1, 0, backgroundColor);

        // Top border
        context.getGraphics().method_51737(x0, y0 - 1, x1, y0, 0, backgroundColor);
        // Bottom border
        context.getGraphics().method_51737(x0, y1 + 1, x1, y1, 0, backgroundColor);
        // Left border
        context.getGraphics().method_51737(x0 - 1, y0, x0, y1, 0, backgroundColor);
        // Right border
        context.getGraphics().method_51737(x1 + 1, y0, x1, y1, 0, backgroundColor);

        RenderUtils.renderFrameGradient(context.getGraphics(), x1 - 1, y0 + 1, x0 - x1 + 2, y1 - y0, color1, color2, color3);

        // Top and bottom lines
        context.getGraphics().method_25294(x1, y0, x0, y0 + 1, color1);
        context.getGraphics().method_25294(x1, y1, x0, y1 - 1, color3);

        class_2561 text = class_2561.method_43471("tooltipoverhaul.equipped_badge_text");
        int textHeight = class_5684.method_32662(text.method_30937()).method_32661();
        int textX = (int) (x0 + context.getTooltipSize().field_1343 / 2f - context.getFont().method_27525(text) / 2f + context.getPaddingX());
        int textY = (int) (y0 - textHeight / 2f +  sizeY / 1.7f);

        // Equipped text
        context.getGraphics().method_51439(context.getFont(), text, textX, textY, color1, false);
    }

}