package dev.xylonity.tooltipoverhaul.client.style.preview.background;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;

public class DefaultPreviewBackground implements PreviewBackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {
        int x0 = (int) startPosition.field_1343;
        int y0 = (int) startPosition.field_1342;
        int x1 = (int) endPosition.field_1343;
        int y1 = (int) endPosition.field_1342;

        int backgroundColor = ColorUtils.getBackgroundColor(context);

        // Background
        context.getGraphics().method_25294(x0, y0, x1, y1, backgroundColor);

        // Top border
        context.getGraphics().method_25294(x1, y0 - 1, x0, y0, backgroundColor);
        // Bottom border
        context.getGraphics().method_25294(x1, y1, x0, y1 + 1, backgroundColor);
        // Left border
        context.getGraphics().method_25294(x1 - 1, y0, x1, y1, backgroundColor);
        // Right border
        context.getGraphics().method_25294(x0, y0, x0 + 1, y1, backgroundColor);
    }

}
