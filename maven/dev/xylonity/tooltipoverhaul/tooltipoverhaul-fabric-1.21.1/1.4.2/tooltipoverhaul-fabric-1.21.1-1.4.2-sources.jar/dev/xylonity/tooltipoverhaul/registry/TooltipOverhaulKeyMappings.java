package dev.xylonity.tooltipoverhaul.registry;

import net.minecraft.class_304;
import net.minecraft.class_3675;

public class TooltipOverhaulKeyMappings {

    public static final class_304 COMPARE_TOOLTIP = new class_304(
            "tooltipoverhaul.binds.compare_bind",
            class_3675.field_31951,
            "tooltipoverhaul.binds.category"
    );

}
