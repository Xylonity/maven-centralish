package dev.xylonity.tooltipoverhaul.platform;

import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public interface TooltipPlatform {

    boolean isModLoaded(String modid);

    Path resolveConfigFile(String configFileName);
    Path getConfigPath();

    class_1799 getHoveredItem(class_332 graphics, List<class_5684> components, int mouseX, int mouseY);
}
