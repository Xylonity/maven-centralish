package dev.xylonity.tooltipoverhaul.compat.proxy;

import net.minecraft.class_310;
import net.minecraft.class_437;

public final class ScreenTypeProxy {

    public static boolean isFtbQuests(class_437 screen) {
        return nameOf(screen).contains("ftbquests");
    }

    public static boolean isJei(class_437 screen) {
        return nameOf(screen).contains("mezz.jei");
    }

    public static boolean isEmi(class_437 screen) {
        return nameOf(screen).contains("dev.emi.emi");
    }

    public static boolean isContainerLikeOrJeiEmi() {
        class_437 screen = class_310.method_1551().field_1755;
        if (screen == null) return false;
        return isJei(screen) || isEmi(screen);
    }

    private static String nameOf(class_437 s) {
        return (s == null ? "" : s.getClass().getName()).toLowerCase();
    }

}
