package dev.xylonity.tooltipoverhaul.compat.emi;

import net.minecraft.class_1799;

public final class EmiDeferredHover {

    private static class_1799 LAST = class_1799.field_8037;

    public static void set(class_1799 stack) {
        LAST = (stack == null || stack.method_7960()) ? class_1799.field_8037 : stack.method_7972();
    }

    public static class_1799 pop() {
        class_1799 stack = LAST;
        LAST = class_1799.field_8037;
        return stack;
    }

}
