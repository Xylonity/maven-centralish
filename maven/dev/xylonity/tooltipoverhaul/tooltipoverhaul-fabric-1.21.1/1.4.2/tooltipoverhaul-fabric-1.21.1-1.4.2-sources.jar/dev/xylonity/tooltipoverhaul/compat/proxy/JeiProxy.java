package dev.xylonity.tooltipoverhaul.compat.proxy;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import java.lang.reflect.Method;
import net.minecraft.class_1799;

/**
 * Proxy used for dedicated JEI compat, in order to 'detect' the hovered stack on JEI categories
 */
public final class JeiProxy {

    private static final String CLASS_LOCATION = "dev.xylonity.tooltipoverhaul.compat.jei.JeiHoverHolder";
    private static final String CLASS_METHOD = "getItemStack";

    public static class_1799 getItemStack() {
        if (!TooltipOverhaul.PLATFORM.isModLoaded("jei")) return class_1799.field_8037;
        try {
            Class<?> holder = Class.forName(CLASS_LOCATION, false, JeiProxy.class.getClassLoader());
            Method method = holder.getMethod(CLASS_METHOD);
            Object stack = method.invoke(null);
            return (stack instanceof class_1799 s) ? s : class_1799.field_8037;
        }
        catch (Exception ignored) {
            return class_1799.field_8037;
        }
    }

}
