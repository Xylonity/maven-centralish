package dev.xylonity.tooltipoverhaul.client.render;

import dev.xylonity.tooltipoverhaul.client.layer.ITooltipLayer;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipPositionCalculator;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipSizeCalculator;
import dev.xylonity.tooltipoverhaul.client.style.StyleFactory;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_241;

public class TooltipRenderer {

    private final @Nullable TooltipContext context;

    public static float COUNTER = 0;

    public TooltipRenderer(@Nullable TooltipContext context) {
        this.context = context;
    }

    public void init() {
        if (context == null) return;

        if (context.getComponents().isEmpty()) return;

        // The style is computed here so the context knows if its context pair already exists
        context.setTooltipLayers(new StyleFactory().create(context, context.getFrameData()));

        TooltipSizeCalculator sizeCalculator = context.getSizeCalculator();
        TooltipPositionCalculator positionCalculator = context.getPositionCalculator();

        int margin = 5;

        // Uncapped size calculation
        class_241 uncappedSize = sizeCalculator.calculate();

        int screenHeight = context.getScreenHeight();
        int maxTooltipHeight = screenHeight - margin;
        int cappedHeight = Math.min((int) uncappedSize.field_1342, maxTooltipHeight);

        context.setTooltipSize(new class_241(uncappedSize.field_1343, cappedHeight));
        context.setTooltipPosition(positionCalculator.calculate());

        if (!TextUtils.shouldDisableScrolling(context)) {
            TooltipScrollState.begin((int) uncappedSize.field_1342, cappedHeight);
            TooltipScrollState.tick();
        }
        else {
            TooltipScrollState.reset();
        }

    }

    /**
     * Simple bridge to readjust the tooltip positions in case the equipped stack is enabled and any (or both) tooltip layouts are
     * exceeding the screen margins. The init predicate is called to compute the default layout values.
     */
    public void adjustLayout() {
        if (context == null) return;

        if (context.getComponents().isEmpty()) return;

        context.setTooltipPosition(context.getPositionCalculator().adjustPosition());
        context.setTooltipSize(context.getSizeCalculator().adjustSize());
    }

    public boolean render() {

        if (context == null) return false;

        if (context.getComponents().isEmpty()) return false;

        if (!RenderUtils.shouldRender(context)) return false;

        if (context.getStack().method_7960() && !TooltipsConfig.SHOW_TOOLTIP_WITHOUT_STACK) return false;

        List<ITooltipLayer> layers = context.getTooltipLayers();

        for (ITooltipLayer layer : layers) {
            layer.renderInternal(context);
        }

        return true;
    }

}
