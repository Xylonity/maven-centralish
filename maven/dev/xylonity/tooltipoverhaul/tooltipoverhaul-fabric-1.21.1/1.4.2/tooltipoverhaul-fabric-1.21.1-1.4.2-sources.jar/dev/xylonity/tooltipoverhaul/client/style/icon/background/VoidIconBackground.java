package dev.xylonity.tooltipoverhaul.client.style.icon.background;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.layer.impl.IconBackgroundLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.render.TooltipRenderer;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_7833;

public class VoidIconBackground implements IconBackgroundLayer {

    @Override
    public void render(TooltipContext context, class_241 position) {

        int positionX = (int) context.getTooltipPosition().field_1343 - 1 + context.getPaddingX();
        int positionY = (int) context.getTooltipPosition().field_1342 + context.getPaddingY();

        int slotSizeX = positionX + Constants.getIconSize(context) / 2;
        int slotSizeY = positionY + Constants.getIconSize(context) / 2;

        class_2960 texture = TooltipOverhaul.pathOf("textures/gui/star.png");

        context.translate(slotSizeX, slotSizeY, 0);
        context.multiply(class_7833.field_40718, -TooltipRenderer.COUNTER * 45);
        context.scale(0.4225f, 0.4225f, 0.4225f);

        int frames = 8;
        int currentFrame = (int) ((TooltipRenderer.COUNTER / 0.2f) % frames);

        int dim = 64;
        context.getGraphics().method_25290(texture, -32, -32, 0, currentFrame * dim, dim, dim, dim, frames * dim);
    }

}