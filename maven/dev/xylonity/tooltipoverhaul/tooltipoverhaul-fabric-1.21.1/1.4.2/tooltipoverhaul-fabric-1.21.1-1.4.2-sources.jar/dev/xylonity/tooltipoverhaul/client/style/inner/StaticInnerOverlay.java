package dev.xylonity.tooltipoverhaul.client.style.inner;

import dev.xylonity.tooltipoverhaul.client.layer.impl.InnerOverlayLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import net.minecraft.class_241;

public class StaticInnerOverlay implements InnerOverlayLayer {

    private final int color;

    public StaticInnerOverlay(int color) {
        this.color = color;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        int x0 = (int) (context.getTooltipPosition().field_1343 - 3);
        int y0 = (int) (context.getTooltipPosition().field_1342 - 2);
        int width = (int) (context.getTooltipSize().field_1343 + 5);
        int height = (int) (context.getTooltipSize().field_1342 + 4);

        // Top
        context.getGraphics().method_25294(x0, y0, x0 + width, y0 + 1, color);

        // Bottom
        context.getGraphics().method_25294(x0, y0 + height - 1, x0 + width, y0 + height, color);

        // Left
        context.getGraphics().method_25294(x0, y0, x0 + 1, y0 + height, color);

        // Right
        context.getGraphics().method_25294(x0 + width - 1, y0, x0 + width, y0 + height, color);
    }

}
