package dev.xylonity.tooltipoverhaul.client.style.preview.renderer;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewRendererLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import dev.xylonity.tooltipoverhaul.compat.modernfix.ModernFixCompat;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_7833;

public class DefaultPreviewStackRenderer implements PreviewRendererLayer {

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {

        int sizeX = RenderUtils.calculateSecondPanelSize(context, TextAxis.X);
        int sizeY = RenderUtils.calculateSecondPanelSize(context, TextAxis.Y);
        int x0 = (int) startPosition.field_1343;
        int y0 = (int) startPosition.field_1342;
        int x1 = (int) endPosition.field_1343;
        int y1 = (int) endPosition.field_1342;

        context.translate((x1 + sizeX / 2f + 2), (y0 + sizeY / 2f) + 2, 0);

        context.multiply(class_7833.field_40716, (((System.currentTimeMillis() - context.getStartTime()) / 20f) % 360) * AnimationUtils.getSecondPanelRendererSpeed(context));

        context.multiply(class_7833.field_40718, -45);

        float scale = Math.min(sizeX / 5f, sizeY / 10f) / 2.5f;

        context.scale(scale, scale, scale);

        class_310 minecraft = class_310.method_1551();
        if (ModernFixCompat.SHOULD_RETURN_ORIGINAL_RENDER) {
            ModernFixCompat.push();
            try {
                RenderUtils.renderItem(context, minecraft.field_1724, minecraft.field_1687, context.getStack(), 0);
            }
            finally {
                ModernFixCompat.pop();
            }
        }
        else {
            RenderUtils.renderItem(context, minecraft.field_1724, minecraft.field_1687, context.getStack(), 0);
        }

    }

}
