package dev.xylonity.tooltipoverhaul.compat.emi;

import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.EmiStackInteraction;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_310;

/**
 * This is a compat layer for EMI. It's only referenced through it's proxy
 */
public final class EmiHoverHolder {

    private static final String RECIPESCREEN_CLASS_LOCATION = "dev.emi.emi.screen.RecipeScreen";

    /**
     * Hard bypass for tag categories (containing the 'tag' word)
     */
    private static boolean isTagCategory() {
        try {
            class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1755 == null) return false;

            Class<?> recipeScreen = Class.forName(RECIPESCREEN_CLASS_LOCATION, false, EmiHoverHolder.class.getClassLoader());
            if (!recipeScreen.isInstance(minecraft.field_1755)) return false;

            Method method = recipeScreen.getMethod("getFocusedCategory");
            Object category = method.invoke(minecraft.field_1755);
            if (category == null) return false;

            Method getId = category.getClass().getMethod("getId");
            Object idValue = getId.invoke(category);
            String id = (idValue == null) ? null : idValue.toString();
            if (id == null) return false;

            String ss = id.toLowerCase(Locale.ROOT);
            return ss.contains("tag");
        }
        catch (Exception ignored) {
            return false;
        }

    }

    private static boolean isTagIngredient(EmiIngredient ei) {
        try {
            String isIng = ei.getClass().getName().toLowerCase(Locale.ROOT);
            return isIng.contains("tag");
        }
        catch (Throwable ignored) {
            ;;
        }

        return false;
    }

    public static class_1799 getItemStack() {
        if (isTagCategory()) return class_1799.field_8037;

        class_1799 fromCache = EmiDeferredHover.pop();
        if (!fromCache.method_7960()) {
            return fromCache;
        }

        class_1799 itemStack = fromRecipeScreen();
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        EmiStackInteraction internal = EmiApi.getHoveredStack(true);
        itemStack = getStack(internal);
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        return class_1799.field_8037;
    }

    public static class_1799 getItemStack(int mouseX, int mouseY) {
        if (isTagCategory()) return class_1799.field_8037;

        class_1799 fromCache = EmiDeferredHover.pop();
        if (!fromCache.method_7960()) {
            return fromCache;
        }

        class_1799 itemStack = fromRecipeScreen();
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        EmiStackInteraction internal = EmiApi.getHoveredStack(mouseX, mouseY, true);
        itemStack = getStack(internal);
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        internal = EmiApi.getHoveredStack(mouseX, mouseY, false);
        itemStack = getStack(internal);
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        internal = EmiApi.getHoveredStack(true);
        itemStack = getStack(internal);
        if (!itemStack.method_7960()) {
            return itemStack;
        }

        return class_1799.field_8037;
    }

    private static class_1799 fromRecipeScreen() {
        try {
            class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1755 == null) return class_1799.field_8037;

            Class<?> resource = Class.forName(RECIPESCREEN_CLASS_LOCATION, false, EmiHoverHolder.class.getClassLoader());
            if (!resource.isInstance(minecraft.field_1755)) return class_1799.field_8037;

            Method method = resource.getMethod("getHoveredStack");
            Object ingred = method.invoke(minecraft.field_1755);
            if (!(ingred instanceof EmiIngredient s)) {
                return class_1799.field_8037;
            }

            if (isTagIngredient(s)) {
                return class_1799.field_8037;
            }

            return getStack(s);
        }
        catch (Exception ignore) {
            ;;
        }

        return class_1799.field_8037;
    }

    private static class_1799 getStack(EmiStackInteraction hovered) {
        if (hovered == null || hovered.isEmpty()) return class_1799.field_8037;

        EmiIngredient ingred = hovered.getStack();
        if (ingred == null) return class_1799.field_8037;

        if (isTagIngredient(ingred)) return class_1799.field_8037;

        return getStack(ingred);
    }

    private static class_1799 getStack(EmiIngredient ingred) {
        if (ingred == null) return class_1799.field_8037;

        List<EmiStack> list = ingred.getEmiStacks();
        if (list == null || list.isEmpty()) return class_1799.field_8037;

        for (EmiStack es : list) {
            if (es == null) continue;
            class_1799 st = es.getItemStack();
            if (st != null && !st.method_7960()) return st;
        }

        return class_1799.field_8037;
    }

}