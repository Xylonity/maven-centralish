package dev.xylonity.tooltipoverhaul.client.frame;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2514;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

/**
 * Conditions are evaluated against the current stack, never cached by item ID
 */
public record FrameConditions(
        Float durabilityMin,
        Float durabilityMax,
        Boolean enchanted,
        Boolean hasCustomName,
        String customName,
        List<class_2960> enchantments,
        List<NbtRule> nbt
) {

    public static FrameConditions parse(JsonObject entry) {
        final Float min = percentage(entry, "durabilityMin");
        final Float max = percentage(entry, "durabilityMax");
        if (min != null && max != null && min > max) {
            throw new JsonParseException("durabilityMin exceeds durabilityMax");
        }

        final List<class_2960> enchantments = new ArrayList<>();
        if (entry.has("enchantments")) {
            if (!entry.get("enchantments").isJsonArray()) {
                throw new JsonParseException("enchantments must be an array of IDs");
            }

            for (final JsonElement value : entry.getAsJsonArray("enchantments")) {
                final class_2960 id = value.isJsonPrimitive() ? class_2960.method_12829(value.getAsString()) : null;
                if (id == null) {
                    throw new JsonParseException("Invalid enchantment ID: " + value);
                }

                enchantments.add(id);
            }

        }

        final List<NbtRule> nbt = new ArrayList<>();
        if (entry.has("nbt")) {
            if (!entry.get("nbt").isJsonArray()) {
                throw new JsonParseException("nbt must be an array of \"path\", \"path=value\" or \"path!=value\" strings");
            }

            for (final JsonElement value : entry.getAsJsonArray("nbt")) {
                if (!value.isJsonPrimitive()) {
                    throw new JsonParseException("Invalid nbt rule: " + value);
                }

                nbt.add(NbtRule.parse(value.getAsString()));
            }

        }

        return new FrameConditions(min, max, bool(entry, "enchanted"), bool(entry, "hasCustomName"),
                entry.has("customName") ? entry.get("customName").getAsString() : null, List.copyOf(enchantments), List.copyOf(nbt));
    }

    private static Float percentage(JsonObject entry, String key) {
        if (!entry.has(key)) {
            return null;
        }

        float value = entry.get(key).getAsFloat();
        if (!Float.isFinite(value) || value < 0 || value > 100) {
            throw new JsonParseException(key + " must be between 0 and 100");
        }

        return value;
    }

    private static Boolean bool(JsonObject entry, String key) {
        if (!entry.has(key)) {
            return null;
        }

        final String value = entry.get(key).getAsString();
        if (!value.equals("true") && !value.equals("false")) {
            throw new JsonParseException(key + " must be true or false");
        }

        return Boolean.parseBoolean(value);
    }

    public boolean matches(class_1799 stack) {
        if (durabilityMin != null || durabilityMax != null) {
            if (!stack.method_7963()) {
                return false;
            }

            final float remaining = 100f * (stack.method_7936() - stack.method_7919()) / stack.method_7936();
            if (durabilityMin != null && remaining < durabilityMin || durabilityMax != null && remaining > durabilityMax) {
                return false;
            }

        }

        if (hasCustomName != null && stack.method_57826(class_9334.field_49631) != hasCustomName) {
            return false;
        }

        if (customName != null && (!stack.method_57826(class_9334.field_49631) || !stack.method_7964().getString().equals(customName))) {
            return false;
        }

        if (!nbt.isEmpty()) {
            final class_2487 tag = componentsOf(stack);
            for (final NbtRule rule : nbt) {
                if (!rule.matches(tag)) {
                    return false;
                }

            }

        }

        if (enchanted == null && enchantments.isEmpty()) {
            return true;
        }

        final class_9304 actual = class_1890.method_57532(stack);
        if (enchanted != null && !actual.method_57543() != enchanted) {
            return false;
        }

        for (final class_2960 id : enchantments) {
            boolean present = false;
            for (final class_6880<class_1887> holder : actual.method_57534()) {
                present |= holder.method_40226(id);
            }

            if (!present) {
                return false;
            }

        }

        return true;
    }

    @Nullable
    private static class_2487 componentsOf(class_1799 stack) {
        final class_638 level = class_310.method_1551().field_1687;
        if (level == null || stack.method_7960()) {
            return null;
        }

        return stack.method_57358(level.method_30349()) instanceof class_2487 compound ? compound.method_10562("components") : null;
    }

    public record NbtRule(
            List<Object> path,
            Operation op,
            String value
    ) {

        public enum Operation {
            EXISTS,
            EQUALS,
            NOT_EQUALS
        }

        public static NbtRule parse(String raw) {
            String text = raw.trim();
            Operation operation = Operation.EXISTS;
            String value = null;

            final int notEquals = text.indexOf("!=");
            final int equals = text.indexOf('=');
            if (notEquals >= 0 && notEquals <= equals) {
                operation = Operation.NOT_EQUALS;
                value = text.substring(notEquals + 2).trim();
                text = text.substring(0, notEquals);
            }
            else if (equals >= 0) {
                operation = Operation.EQUALS;
                value = text.substring(equals + 1).trim();
                text = text.substring(0, equals);
            }

            final List<Object> path = new ArrayList<>();
            for (final String segment : text.trim().split("\\.")) {
                int bracket = segment.indexOf('[');
                final String key = bracket < 0 ? segment : segment.substring(0, bracket);
                if (!key.isEmpty()) {
                    path.add(key);
                }

                while (bracket >= 0) {
                    final int close = segment.indexOf(']', bracket);
                    if (close < 0) {
                        throw new JsonParseException("Invalid nbt rule, unclosed index: " + raw);
                    }

                    try {
                        path.add(Integer.parseInt(segment.substring(bracket + 1, close).trim()));
                    }
                    catch (NumberFormatException exception) {
                        throw new JsonParseException("Invalid nbt rule, index must be a number: " + raw);
                    }

                    bracket = segment.indexOf('[', close);
                }

            }

            if (path.isEmpty()) {
                throw new JsonParseException("Invalid nbt rule, empty path: " + raw);
            }

            return new NbtRule(List.copyOf(path), operation, value);
        }

        public boolean matches(@Nullable class_2487 root) {
            final class_2520 found = resolve(root);
            if (found == null) {
                return false;
            }

            return switch (op) {
                case EXISTS -> true;
                case EQUALS -> valueMatches(found);
                case NOT_EQUALS -> !valueMatches(found);
            };

        }

        @Nullable
        private class_2520 resolve(@Nullable class_2487 root) {
            class_2520 current = root;
            for (Object step : path) {
                if (step instanceof String key) {
                    if (!(current instanceof class_2487 compound)) {
                        return null;
                    }

                    current = compound.method_10580(key);
                }
                else {
                    final int index = (Integer) step;
                    if (!(current instanceof class_2499 list) || index < 0 || index >= list.size()) {
                        return null;
                    }

                    current = list.method_10534(index);
                }

                if (current == null) {
                    return null;
                }

            }

            return current;
        }

        private boolean valueMatches(class_2520 found) {
            if (found instanceof class_2514 numeric) {
                final Double expected = number(value);
                if (expected != null) {
                    return Math.abs(numeric.method_10697() - expected) < 1e-6;
                }

            }

            return found.method_10714().equals(value);
        }

        @Nullable
        private static Double number(String text) {
            if (text.equalsIgnoreCase("true")) {
                return 1d;
            }

            if (text.equalsIgnoreCase("false")) {
                return 0d;
            }

            String digits = text;
            if (!digits.isEmpty() && "bBsSlLfFdD".indexOf(digits.charAt(digits.length() - 1)) >= 0) {
                digits = digits.substring(0, digits.length() - 1);
            }

            try {
                return Double.parseDouble(digits);
            }
            catch (NumberFormatException exception) {
                return null;
            }

        }

    }

}