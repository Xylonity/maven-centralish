package dev.xylonity.tooltipoverhaul.client.util;

import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.mixin.KeyMappingAccessor;
import dev.xylonity.tooltipoverhaul.registry.TooltipOverhaulKeyMappings;
import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_5151;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

public class EquippedContextCalculator {

    public static @Nullable TooltipContext from(class_332 graphics, class_327 font, int mouseX, int mouseY, class_8000 tooltipPositioner, class_1799 fromStack, int screenWidth, int screenHeight) {

        class_3675.class_306 compareKey = ((KeyMappingAccessor) TooltipOverhaulKeyMappings.COMPARE_TOOLTIP).tooltipoverhaul$key();
        boolean isKeyDown = false;
        if (!compareKey.equals(class_3675.field_16237)) {
            isKeyDown = class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), compareKey.method_1444());
        }

        if (!isKeyDown) {
            return null;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_1657 player = minecraft.field_1724;

        if (player == null) {
            return null;
        }

        // Armor is compared against the piece currently worn in the matching slot, and weapons and tools (any tiered item, such as swords or axes) are
        // compared against the mainhand item, but only when it is itself a tiered item so the comparison stays weapon-weapon
        class_1799 equippedStack;
        if (fromStack.method_7909() instanceof class_5151 equippableStack) {
            class_1304 slot = equippableStack.method_7685();
            // offhand index collides with the leggings armor index lmao
            if (slot.method_5925() != class_1304.class_1305.field_6177) {
                equippedStack = player.method_31548().method_7372(slot.method_5927());
            }
            else {
                equippedStack = player.method_6118(slot);
            }

        }
        else if (fromStack.method_7909() instanceof class_1831) {
            equippedStack = player.method_6047();
            if (!(equippedStack.method_7909() instanceof class_1831)) {
                return null;
            }

        }
        else {
            return null;
        }

        if (equippedStack.method_7960() || class_1799.method_31577(fromStack, equippedStack)) {
            return null;
        }

        final List<class_5684> componentList = TextUtils.getTooltipComponentsFrom(equippedStack, font, screenWidth, 2.2f);
        return new TooltipContext(graphics, font, componentList, mouseX, mouseY, screenWidth, screenHeight, tooltipPositioner, equippedStack, false);
    }

}
