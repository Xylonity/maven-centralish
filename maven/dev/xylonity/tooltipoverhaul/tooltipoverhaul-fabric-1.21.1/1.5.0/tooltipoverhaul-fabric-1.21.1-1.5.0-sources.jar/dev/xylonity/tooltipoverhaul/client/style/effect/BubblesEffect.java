package dev.xylonity.tooltipoverhaul.client.style.effect;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.EffectLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import org.joml.Matrix4f;

import java.util.Random;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import net.minecraft.class_9801;

public class BubblesEffect implements EffectLayer {

    private static final int BUBBLE_COLOR = 0xFFBFE8FF;
    private static final int SHINE_COLOR = 0xFFFFFFFF;

    private static final int BUBBLE_COUNT = 10;
    private static final int RING_SEGMENTS = 14;

    private static final float[][] BUBBLES = new float[BUBBLE_COUNT][6];

    static {
        final Random random = new Random(44444L);
        for (int i = 0; i < BUBBLE_COUNT; i++) {
            BUBBLES[i][0] = random.nextFloat(); // Horizontal seed
            BUBBLES[i][1] = 0.07f + random.nextFloat() * 0.08f; // Rise speed
            BUBBLES[i][2] = 1.4f + random.nextFloat() * 2.2f; // Radius
            BUBBLES[i][3] = 2.0f + random.nextFloat() * 3.5f; // Wobble amplitude
            BUBBLES[i][4] = 1.0f + random.nextFloat() * 1.8f; // Wobble speed
            BUBBLES[i][5] = random.nextFloat(); // Phase
        }

    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final int positionX = (int) position.field_1343;
        final int positionY = (int) position.field_1342;
        final int tooltipWidth = (int) context.getTooltipSize().field_1343;
        final int tooltipHeight = (int) context.getTooltipSize().field_1342;

        final long now = System.currentTimeMillis();
        final float time = (now - context.getStartTime()) / 1000f;

        context.push(() -> {
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(
                    GlStateManager.class_4535.SRC_ALPHA,
                    GlStateManager.class_4534.ONE,
                    GlStateManager.class_4535.ONE,
                    GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
            );

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();

            RenderSystem.setShader(class_757::method_34540);

            final Matrix4f pose = context.getPose().method_23760().method_23761();
            final class_289 tesselator = class_289.method_1348();

            for (final float[] bubble : BUBBLES) {
                renderBubble(tesselator, pose, positionX, positionY, tooltipWidth, tooltipHeight, time, bubble);
            }

            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.blendFunc(
                    GlStateManager.class_4535.SRC_ALPHA,
                    GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
            );

            RenderSystem.disableBlend();
            RenderSystem.enableCull();
        });

    }

    private void renderBubble(class_289 tesselator, Matrix4f pose, int positionX, int positionY, int tooltipWidth, int tooltipHeight, float time, float[] bubble) {
        final float horizontalSeed = bubble[0];
        final float riseSpeed = bubble[1];
        final float radius = bubble[2];
        final float wobbleAmplitude = bubble[3];
        final float wobbleSpeed = bubble[4];
        final float phase = bubble[5];

        // Looping rise from below the tooltip to above
        final float progress = (time * riseSpeed + phase) % 1f;

        final float x = positionX + horizontalSeed * tooltipWidth + (float) Math.sin(time * wobbleSpeed + phase * (float) Math.PI * 2.0f) * wobbleAmplitude;
        final float y = positionY + tooltipHeight + 12 - progress * (tooltipHeight + 26);

        // Fades in and out at the loop edges
        final float alphaEnvelope = (float) Math.sin(progress * Math.PI);
        if (alphaEnvelope < 0.04f) {
            return;
        }

        final float currentRadius = radius * (0.8f + 0.3f * progress);
        final int ringAlpha = AnimationUtils.clamp255((int) (185 * alphaEnvelope));

        // Thin ring, brightest at its middle so the bubble looks hollow
        final float thickness = Math.max(0.7f, currentRadius * 0.36f);
        final float innerRadius = currentRadius - thickness * 0.5f;
        final float outerRadius = currentRadius + thickness * 0.5f;

        ring(tesselator, pose, x, y, innerRadius, currentRadius, outerRadius, ringAlpha);

        // Small highlight towards the upper left
        final float shineX = x - currentRadius * 0.42f;
        final float shineY = y - currentRadius * 0.42f;
        final float shineRadius = Math.max(0.5f, currentRadius * 0.32f);
        final int shineAlpha = AnimationUtils.clamp255((int) (220 * alphaEnvelope));

        class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

        bufferBuilder.method_22918(pose, shineX, shineY, 0).method_1336(ColorUtils.red(SHINE_COLOR), ColorUtils.green(SHINE_COLOR), ColorUtils.blue(SHINE_COLOR), shineAlpha);
        for (int i = 0; i <= 8; i++) {
            final float angle = (i / 8.0f) * (float) Math.PI * 2.0f;
            bufferBuilder.method_22918(pose, shineX + (float) Math.cos(angle) * shineRadius, shineY + (float) Math.sin(angle) * shineRadius, 0)
                    .method_1336(ColorUtils.red(SHINE_COLOR), ColorUtils.green(SHINE_COLOR), ColorUtils.blue(SHINE_COLOR), 0);
        }

        try (class_9801 data = bufferBuilder.method_60800()) {
            class_286.method_43433(data);
        }

    }

    private void ring(class_289 tesselator, Matrix4f pose, float x, float y, float innerRadius, float midRadius, float outerRadius, int alpha) {
        // Inner half
        class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27380, class_290.field_1576);

        for (int i = 0; i <= RING_SEGMENTS; i++) {
            float angle = (i / (float) RING_SEGMENTS) * (float) Math.PI * 2.0f;
            float cos = (float) Math.cos(angle), sin = (float) Math.sin(angle);

            bufferBuilder.method_22918(pose, x + cos * midRadius, y + sin * midRadius, 0).method_1336(ColorUtils.red(BUBBLE_COLOR), ColorUtils.green(BUBBLE_COLOR), ColorUtils.blue(BUBBLE_COLOR), alpha);
            bufferBuilder.method_22918(pose, x + cos * innerRadius, y + sin * innerRadius, 0).method_1336(ColorUtils.red(BUBBLE_COLOR), ColorUtils.green(BUBBLE_COLOR), ColorUtils.blue(BUBBLE_COLOR), 0);
        }

        try (class_9801 data = bufferBuilder.method_60800()) {
            class_286.method_43433(data);
        }

        // Outer half
        bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27380, class_290.field_1576);

        for (int i = 0; i <= RING_SEGMENTS; i++) {
            float angle = (i / (float) RING_SEGMENTS) * (float) Math.PI * 2.0f;
            float cos = (float) Math.cos(angle), sin = (float) Math.sin(angle);

            bufferBuilder.method_22918(pose, x + cos * outerRadius, y + sin * outerRadius, 0).method_1336(ColorUtils.red(BUBBLE_COLOR), ColorUtils.green(BUBBLE_COLOR), ColorUtils.blue(BUBBLE_COLOR), 0);
            bufferBuilder.method_22918(pose, x + cos * midRadius, y + sin * midRadius, 0).method_1336(ColorUtils.red(BUBBLE_COLOR), ColorUtils.green(BUBBLE_COLOR), ColorUtils.blue(BUBBLE_COLOR), alpha);
        }

        try (class_9801 data = bufferBuilder.method_60800()) {
            class_286.method_43433(data);
        }

    }

}