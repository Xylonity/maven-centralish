package dev.xylonity.tooltipoverhaul.client.style.effect;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.client.layer.impl.EffectLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import org.joml.Matrix4f;

import java.util.Random;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import net.minecraft.class_9801;

public class WhiteDustEffect implements EffectLayer {

    private static final int RUNE_COLOR = 0xDDFFFFFF;
    private static final int GLYPH_COLOR = 0xD0E0B35C;
    private static final int PARTICLE_COLOR = 0xDDFFFFFF;

    private static final int RUNE_COUNT = 8;
    private static final int PARTICLE_COUNT = 32;

    private static final float[][] RUNES = new float[RUNE_COUNT][4];
    private static final float[][] PARTICLES = new float[PARTICLE_COUNT][5];

    static {
        Random random = new Random(33333L);

        for (int i = 0; i < RUNE_COUNT; i++) {
            RUNES[i][0] = (float) i / RUNE_COUNT; // Angle seed
            RUNES[i][1] = 0.55f + random.nextFloat() * 0.35f; // Relative distance
            RUNES[i][2] = 0.5f + random.nextFloat() * 0.7f; // Speed
            RUNES[i][3] = random.nextFloat() * (float) Math.PI * 2.0f; // Phase
        }

        for (int i = 0; i < PARTICLE_COUNT; i++) {
            PARTICLES[i][0] = random.nextFloat(); // Angle seed
            PARTICLES[i][1] = 0.45f + random.nextFloat() * 0.65f; // Radial seed
            PARTICLES[i][2] = 0.5f + random.nextFloat() * 1.5f; // Size
            PARTICLES[i][3] = 0.4f + random.nextFloat() * 0.9f; // Speed
            PARTICLES[i][4] = random.nextFloat() * (float) Math.PI * 2.0f; // Phase
        }

    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        int positionX = (int) position.field_1343;
        int positionY = (int) position.field_1342;
        int tooltipWidth = (int) context.getTooltipSize().field_1343;
        int tooltipHeight = (int) context.getTooltipSize().field_1342;

        long now = System.currentTimeMillis();
        float time = (now - context.getStartTime()) / 12000f;
        float timeLoop = time % 1f;

        float centerX = positionX + tooltipWidth * 0.5f;
        float centerY = positionY + tooltipHeight * 0.5f;
        float radius = (float) Math.hypot(tooltipWidth, tooltipHeight) * 0.55f;

        context.push(() -> {

            //context.translate(0, 0, context.getLayerDepth().getZ());

            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(
                    GlStateManager.class_4535.SRC_ALPHA,
                    GlStateManager.class_4534.ONE,
                    GlStateManager.class_4535.ONE,
                    GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
            );

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();

            RenderSystem.setShader(class_757::method_34540);

            Matrix4f pose = context.getPose().method_23760().method_23761();
            class_289 tesselator = class_289.method_1348();

            // Dust
            renderDust(tesselator, pose, centerX, centerY, radius, time);

            // Stars
            renderStars(tesselator, pose, centerX, centerY, radius, time);

            // Glyphs
            renderGlyphs(tesselator, pose, centerX, centerY, radius, timeLoop);

            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.blendFunc(
                    GlStateManager.class_4535.SRC_ALPHA,
                    GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
            );

            RenderSystem.disableBlend();
            RenderSystem.enableCull();
        });

    }

    private void renderDust(class_289 tesselator, Matrix4f pose, float centerX, float centerY, float radius, float tGlobal) {

        class_287 buf = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);

        for (float[] particle : PARTICLES) {
            float angleSeed = particle[0];
            float radialSeed = particle[1];
            float sizeSeed = particle[2];
            float speed = particle[3];
            float phase = particle[4];

            float angle = angleSeed * (float) Math.PI * 2.0f + tGlobal * speed * (float) Math.PI * 2.0f;

            float fadeRadius = 0.6f + 0.4f * (float) Math.sin(tGlobal * Math.PI * 2.4f + phase);
            float starRadius = radius * radialSeed * fadeRadius;

            float starX = centerX + (float) Math.cos(angle) * starRadius;
            float starY = centerY + (float) Math.sin(angle) * starRadius;

            float twinkleBase = (float) Math.sin((tGlobal * 6.0f + phase) * Math.PI);
            float twinkle = 0.35f + 0.65f * Math.abs(twinkleBase);

            float size = sizeSeed * (0.6f + 0.4f * twinkle);

            int alphaCenter = AnimationUtils.clamp255((int) (255 * twinkle));
            int alphaEdge = AnimationUtils.clamp255((int) (200 * twinkle));

            float half = size * 0.5f;

            buf.method_22918(pose, starX, starY - half, 0).method_1336(ColorUtils.red(PARTICLE_COLOR), ColorUtils.green(PARTICLE_COLOR), ColorUtils.blue(PARTICLE_COLOR), alphaEdge);
            buf.method_22918(pose, starX + half, starY, 0).method_1336(ColorUtils.red(PARTICLE_COLOR), ColorUtils.green(PARTICLE_COLOR), ColorUtils.blue(PARTICLE_COLOR), alphaCenter);
            buf.method_22918(pose, starX, starY + half, 0).method_1336(ColorUtils.red(PARTICLE_COLOR), ColorUtils.green(PARTICLE_COLOR), ColorUtils.blue(PARTICLE_COLOR), alphaEdge);
            buf.method_22918(pose, starX - half, starY, 0).method_1336(ColorUtils.red(PARTICLE_COLOR), ColorUtils.green(PARTICLE_COLOR), ColorUtils.blue(PARTICLE_COLOR), alphaCenter);
        }

        try (class_9801 data = buf.method_60800()) {
            class_286.method_43433(data);
        }
    }

    private void renderStars(class_289 tesselator, Matrix4f pose, float centerX, float centerY, float radius, float time) {
        for (int i = 0; i < RUNE_COUNT; i++) {
            float[] rune = RUNES[i];
            float angleSeed  = rune[0];
            float radial = rune[1];
            float orbitSpeed = rune[2];
            float phase = rune[3];

            float angle = angleSeed * (float) Math.PI * 2.0f + time * orbitSpeed * (float) Math.PI * 2.0f;

            float orbitRadius = radius * radial * (0.9f + 0.1f * (float) Math.sin(time * Math.PI * 3.5f + phase));

            float dustX = centerX + (float) Math.cos(angle) * orbitRadius;
            float dustY = centerY + (float) Math.sin(angle) * orbitRadius;

            float runeRotation = phase + time * (float) Math.PI * 1.7f;
            float glow = 0.65f + 0.35f * (float) Math.sin((time * 4.0f + phase) * Math.PI * 2.0f);
            float size = 5.0f * (0.8f + 0.4f * glow);

            int type = (i % 4 == 3) ? 3 : (i % 3);
            star(tesselator, pose, dustX, dustY, size, runeRotation, glow, type);
        }

    }

    private void star(class_289 tesselator, Matrix4f pose, float centerX, float centerY, float size, float rotation, float glow, int type) {
        if (type == 3) {
            float glowSize = size * 1.6f;
            float coreSize = size * 0.9f;

            drawStar(tesselator, pose, centerX, centerY, glowSize, RUNE_COLOR, 0.5f * glow);
            drawStar(tesselator, pose, centerX, centerY, coreSize, RUNE_COLOR, glow);
        }

    }

    private void drawStar(class_289 tesselator, Matrix4f pose, float centerX, float centerY, float size, int color, float alphaMult) {

        class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

        int alpha = AnimationUtils.clamp255((int) (ColorUtils.alpha(color) * alphaMult));
        bufferBuilder.method_22918(pose, centerX, centerY, 0).method_1336(ColorUtils.red(color), ColorUtils.green(color), ColorUtils.blue(color), alpha);

        for (int i = 0; i <= 8; i++) {
            float angle = (i / 8.0f) * (float) Math.PI * 2.0f;
            float radius = size * (i % 2 == 0 ? 1.0f : 0.4f);

            float starX = centerX + (float) Math.cos(angle) * radius;
            float starY = centerY + (float) Math.sin(angle) * radius;

            int edgeAlpha = AnimationUtils.clamp255((int) (alpha * 0.2f));
            bufferBuilder.method_22918(pose, starX, starY, 0).method_1336(ColorUtils.red(color), ColorUtils.green(color), ColorUtils.blue(color), edgeAlpha);
        }

        try (class_9801 data = bufferBuilder.method_60800()) {
            class_286.method_43433(data);
        }
    }

    private void renderGlyphs(class_289 tesselator, Matrix4f pose, float centerX, float centerY, float radius, float time) {

        float envelope = (float) Math.sin(time * Math.PI);
        if (envelope < 0.05f) {
            return;
        }

        float rawV = (float) Math.pow(envelope, 1.2f);

        float size = radius * 0.24f * (0.9f + 0.2f * rawV);

        int alphaMain = AnimationUtils.clamp255((int) (ColorUtils.alpha(GLYPH_COLOR) * rawV));
        int alphaSoft = AnimationUtils.clamp255((int) (ColorUtils.alpha(GLYPH_COLOR) * 0.4f * rawV));

        class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27377, class_290.field_1576);

        bufferBuilder.method_22918(pose, centerX - size, centerY, 0)
                .method_1336(ColorUtils.red(GLYPH_COLOR), ColorUtils.green(GLYPH_COLOR), ColorUtils.blue(GLYPH_COLOR), alphaMain);
        bufferBuilder.method_22918(pose, centerX + size, centerY, 0)
                .method_1336(ColorUtils.red(GLYPH_COLOR), ColorUtils.green(GLYPH_COLOR), ColorUtils.blue(GLYPH_COLOR), alphaMain);

        bufferBuilder.method_22918(pose, centerX, centerY - size, 0)
                .method_1336(ColorUtils.red(GLYPH_COLOR), ColorUtils.green(GLYPH_COLOR), ColorUtils.blue(GLYPH_COLOR), alphaMain);
        bufferBuilder.method_22918(pose, centerX, centerY + size, 0)
                .method_1336(ColorUtils.red(GLYPH_COLOR), ColorUtils.green(GLYPH_COLOR), ColorUtils.blue(GLYPH_COLOR), alphaMain);

        try (class_9801 data = bufferBuilder.method_60800()) {
            class_286.method_43433(data);
        }

        class_287 bufferBuilder2 = tesselator.method_60827(class_293.class_5596.field_27378, class_290.field_1576);

        int innerSeg = 24;
        float innerRad = size * 0.7f;
        for (int i = 0; i <= innerSeg; i++) {
            float alpha = (i / (float) innerSeg) * (float) Math.PI * 2.0f;
            float x = centerX + (float) Math.cos(alpha) * innerRad;
            float y = centerY + (float) Math.sin(alpha) * innerRad;

            bufferBuilder2.method_22918(pose, x, y, 0)
                    .method_1336(ColorUtils.red(GLYPH_COLOR), ColorUtils.green(GLYPH_COLOR), ColorUtils.blue(GLYPH_COLOR), alphaSoft);
        }

        try (class_9801 data = bufferBuilder2.method_60800()) {
            class_286.method_43433(data);
        }
    }

}
