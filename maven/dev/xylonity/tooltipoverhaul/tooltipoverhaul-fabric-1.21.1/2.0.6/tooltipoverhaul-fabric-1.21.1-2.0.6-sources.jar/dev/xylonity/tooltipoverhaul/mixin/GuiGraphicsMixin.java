package dev.xylonity.tooltipoverhaul.mixin;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.render.TooltipHoverTracker;
import dev.xylonity.tooltipoverhaul.client.render.TooltipRenderer;
import dev.xylonity.tooltipoverhaul.client.util.EquippedContextCalculator;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.util.ITooltipOverhaulItemAware;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(value = class_332.class, priority = 1500)
public class GuiGraphicsMixin {

    @Unique
    private static int tooltipoverhaul$depth = 0;

    /**
     * Main tooltip renderer call. A context is populated with the relevant info needed to render the tooltip. Nothing else
     * is rendered except if explicit specified within the renderer internal logic, thus preventing possible incompats (that
     * shouldn't exist anyways)
     */
    @Inject(method = "renderTooltipInternal", at = @At(value = "HEAD"), cancellable = true)
    private void tooltipoverhaul$coreRenderCall(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 tooltipPositioner, CallbackInfo ci) {
        // Nested tooltips (like the ones in ESB) are drawn in the middle of the outer one, so keeping their animations is fundamental
        final boolean isNested = tooltipoverhaul$depth > 0;
        final float previousCounter = TooltipRenderer.COUNTER;
        final float previousIconCounter = TooltipRenderer.ICON_COUNTER;
        final TooltipScrollState.Snapshot previousScroll = TooltipScrollState.snapshot();

        tooltipoverhaul$depth++;

        try {
            tooltipoverhaul$render(font, components, mouseX, mouseY, tooltipPositioner, ci);
        }
        finally {
            tooltipoverhaul$depth--;
            if (isNested) {
                TooltipRenderer.COUNTER = previousCounter;
                TooltipRenderer.ICON_COUNTER = previousIconCounter;
                TooltipScrollState.restore(previousScroll);
            }

        }

    }

    @Unique
    private void tooltipoverhaul$render(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 tooltipPositioner, CallbackInfo ci) {

        final int screenWidth = class_310.method_1551().method_22683().method_4486();
        final int screenHeight = class_310.method_1551().method_22683().method_4502();

        final class_1799 stack = ((ITooltipOverhaulItemAware) this).tooltipsOverhaul$hoveredItem();

        tooltipoverhaul$calculateCounterValue(stack);

        // We create the context and the renderer for the equipped stack here, as this is the highest priority when computing certain values a posteriori
        final TooltipContext equippedStackContext = EquippedContextCalculator.from((class_332) (Object) this, font, mouseX, mouseY, tooltipPositioner, stack, screenWidth, screenHeight);
        final TooltipRenderer equippedStackRenderer = new TooltipRenderer(equippedStackContext);

        // The original lines of the original tooltip are rewrapped if the comparison exists, to prevent the content of the main tooltip from going beyond
        // the margins of the screen when forcing the screen scale under extreme circumstances
        List<class_5684> componentList;

        if (equippedStackContext != null) {
            componentList = TextUtils.getTooltipComponentsFrom(stack, font, screenWidth, 2.2f);
        }
        else {
            componentList = TooltipOverhaul.PLATFORM.gatherTooltipComponents((class_332) (Object) this, stack, components, font, mouseX, mouseY, screenWidth, screenHeight, tooltipPositioner);
        }

        // Then, the main renderer is computed here
        final TooltipContext context = new TooltipContext((class_332) (Object) this, font, componentList, mouseX, mouseY, screenWidth, screenHeight, tooltipPositioner, stack, true);
        final TooltipRenderer renderer = new TooltipRenderer(context);

        // Parity is assigned here so that both contexts inherit from each other
        if (equippedStackContext != null) {
            context.setOtherTooltipContext(equippedStackContext);
            equippedStackContext.setOtherTooltipContext(context);
        }

        // Original sizes and positions are initialized
        equippedStackRenderer.init();
        renderer.init();

        // The sizes and positions are recalculated after having been previously calculated, in order to readjust the layout of the tooltips and fit them
        // to the margins of the screen
        if (equippedStackContext != null) {
            equippedStackRenderer.adjustLayout();
            renderer.adjustLayout();
        }

        // Cancelling renderTooltipInternal at head also skips the loader's pre-render tooltip event, so it's replayed here
        // Only fired when the renderer is going to take over
        if (renderer.canRender() && TooltipOverhaul.PLATFORM.fireRenderTooltipPre((class_332) (Object) this, stack, componentList, font, mouseX, mouseY, screenWidth, screenHeight, tooltipPositioner)) {
            ci.cancel();
            return;
        }

        // If the rendering is correct, the rest of the call is canceled
        if (renderer.render()) {
            if (equippedStackContext != null) {
                equippedStackRenderer.render();
            }

            ci.cancel();
        }

    }

    @Unique
    private void tooltipoverhaul$calculateCounterValue(class_1799 stack) {
        final float delay = Math.max(0, TooltipsConfig.TOOLTIP_APPEAR_DELAY);
        final TooltipHoverTracker.Timing timing = TooltipHoverTracker.timing(stack, tooltipoverhaul$hoveredSlot(), delay, !TooltipsConfig.TOOLTIP_ANIMATE_ON_SWITCH);
        TooltipRenderer.COUNTER = timing.tooltipSeconds();
        TooltipRenderer.ICON_COUNTER = timing.iconSeconds();
    }

    @Unique
    @Nullable
    private static class_1735 tooltipoverhaul$hoveredSlot() {
        if (class_310.method_1551().field_1755 instanceof class_465<?> container) {
            try {
                return ((AbstractContainerScreenMixin) container).getHoveredSlot();
            }
            catch (Throwable ignored) {
                ;;
            }

        }

        return null;
    }

}