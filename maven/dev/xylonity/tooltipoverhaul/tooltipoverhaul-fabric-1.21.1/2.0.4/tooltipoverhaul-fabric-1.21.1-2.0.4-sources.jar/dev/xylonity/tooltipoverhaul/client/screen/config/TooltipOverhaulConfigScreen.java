package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.Palette;
import dev.xylonity.tooltipoverhaul.config.ConfigManager;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.config.parser.ConfigColorParser;
import dev.xylonity.tooltipoverhaul.config.wrapper.AutoConfig;
import dev.xylonity.tooltipoverhaul.config.wrapper.ConfigEntry;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1074;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5244;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.*;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.rgb;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.colorEntries;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.formatHex;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.withAlpha;

public class TooltipOverhaulConfigScreen extends AbstractConfigScreen {

    private final Class<?> configClass;
    private final AutoConfig meta;

    private ConfigPanel panel;
    private ConfigCategorySidebar sidebar;
    private SearchBox searchBox;

    private ConfigEntryRow pickerRow = null;
    private int pickerPartIndex = -1;

    private final Map<Field, Object> snapshot = new LinkedHashMap<>();

    // Preserved across resizes so the screen rebuilds in the same state
    private String selectedCategory = null;
    private String searchQuery = "";

    // Category each config screen was last left on
    private static final Map<Class<?>, String> REMEMBERED_CATEGORIES = new HashMap<>();

    public TooltipOverhaulConfigScreen(class_437 parent, Class<?> configClass) {
        super(class_2561.method_43470(resolveTitle(configClass)), parent, accentFor(configClass));
        this.configClass = configClass;
        this.meta = configClass.getAnnotation(AutoConfig.class);
        if (TooltipsConfig.REMEMBER_LAST_PAGE) {
            selectedCategory = REMEMBERED_CATEGORIES.get(configClass);
        }

        takeSnapshot();
    }

    private static int accentFor(Class<?> configClass) {
        final AutoConfig config = configClass.getAnnotation(AutoConfig.class);
        return config != null ? config.accentColor() : DEFAULT_ACCENT;
    }

    private void takeSnapshot() {
        for (Field field : configClass.getDeclaredFields()) {
            if (field.getAnnotation(ConfigEntry.class) == null) {
                continue;
            }

            field.setAccessible(true);
            try {
                snapshot.put(field, field.get(null));
            }
            catch (Exception ignored) {
                ;;
            }

        }

    }

    private void restoreSnapshot() {
        for (Map.Entry<Field, Object> entry : snapshot.entrySet()) {
            try {
                ConfigManager.setPrimitive(entry.getKey(), entry.getValue());
            }
            catch (Exception ignored) {
                ;;
            }

        }

        Palette.reload();
    }

    @Override
    protected void initScreen() {
        final int panelTop = HEADER_HEIGHT + 6;
        final int panelBottom = this.field_22790 - 36;

        final List<Field> entryFields = new ArrayList<>();
        final Map<String, Integer> categoryCounts = new LinkedHashMap<>();
        for (Field field : configClass.getDeclaredFields()) {
            final ConfigEntry entry = field.getAnnotation(ConfigEntry.class);
            if (entry == null) {
                continue;
            }

            field.setAccessible(true);
            entryFields.add(field);
            categoryCounts.merge(entry.category().trim(), 1, Integer::sum);
        }

        final boolean hasSidebar = categoryCounts.size() >= 2;
        final int sidebarWidth = hasSidebar ? class_3532.method_15340(this.field_22789 / 5, 84, 120) : 0;
        final int panelLeft = hasSidebar ? 10 + sidebarWidth + 6 : 16;

        final int formTop = panelTop + (hasSidebar ? 0 : 24);
        this.panel = new ConfigPanel(panelLeft, formTop, this.field_22789 - panelLeft - 10, Math.max(0, panelBottom - formTop), accent, modals, field_22789, field_22790);
        this.panel.setSwatchClickListener(this::openColorPicker);

        if (hasSidebar) {
            this.sidebar = new ConfigCategorySidebar(10, panelTop, sidebarWidth,
                    Math.max(0, panelBottom - panelTop - 24), accent, categoryCounts, entryFields.size(),
                    key -> {
                        selectedCategory = key;
                        panel.setCategory(key);
                    });

            this.sidebar.setSelectedKey(selectedCategory);
            this.method_37063(this.sidebar);
        }
        else {
            this.sidebar = null;
            this.selectedCategory = null;
        }

        this.method_37063(this.panel);

        method_37063(new FlatButton(hasSidebar ? 10 : 16, hasSidebar ? panelBottom - 18 : panelTop,
                hasSidebar ? sidebarWidth : 100, 18, class_2561.method_43471("tooltipoverhaul.config.global_preview"), button -> {
            panel.applyToFields();
            Palette.reload();
            modals.open(new GlobalPreviewModal(field_22789, field_22790, accent));
        }, accent));

        final int searchWidth = Math.min(200, this.field_22789 / 3);
        final int searchX = this.field_22789 - searchWidth - 14;
        final int searchY = (HEADER_HEIGHT - 16) / 2 - 1;

        final int framesWidth = this.field_22793.method_1727(class_1074.method_4662("tooltipoverhaul.config.custom_frames")) + 16;
        method_37063(new FlatButton(searchX - framesWidth - 8, searchY, framesWidth, 16, class_2561.method_43471("tooltipoverhaul.config.custom_frames"),
                button -> {
                        panel.applyToFields();
                        field_22787.method_1507(FrameSourceScreen.editorOrSelector(this, accent));
                    },
                accent));

        this.searchBox = new SearchBox(this.field_22793, searchX, searchY, searchWidth, 16, accent);
        this.searchBox.method_1863(q -> {
            searchQuery = q;
            if (this.panel != null) {
                this.panel.setQuery(q);
            }

            if (this.sidebar != null) {
                this.sidebar.setDimmed(!q.isBlank());
            }

        });

        this.method_37063(this.searchBox);

        for (final Field field : entryFields) {
            this.panel.addEntry(field, field.getAnnotation(ConfigEntry.class), snapshot.get(field));
        }

        this.panel.setCategory(selectedCategory);
        if (!searchQuery.isEmpty()) {
            this.searchBox.method_1852(searchQuery);
        }

        addCenteredFooterButtons(90, 8,
                new FooterAction(class_5244.field_24334, () -> {
                    panel.applyToFields();
                    ConfigManager.save(configClass);
                    returnToParent();
                }, true, 60),
                new FooterAction(class_2561.method_43471("tooltipoverhaul.config.cancel"), () -> {
                    restoreSnapshot();
                    returnToParent();
                }, false, 120),
                new FooterAction(class_2561.method_43471("tooltipoverhaul.config.reset_all"), panel::resetAllToDefault, false, 180));
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        if (panel != null) {
            panel.applyToFields();
        }

        super.method_25410(minecraft, width, height);
    }

    @Override
    protected void tickScreen() {
        if (panel != null) {
            panel.tickPanel();
        }

        super.tickScreen();
    }

    @Override
    protected boolean handleKeyPressed(int key, int scancode, int modifiers) {
        if (key == GLFW.GLFW_KEY_F && method_25441() && searchBox != null) {
            this.method_25395(searchBox);
            searchBox.method_25365(true);
            return true;
        }

        return super.handleKeyPressed(key, scancode, modifiers);
    }

    private void openColorPicker(ConfigEntryRow row, int partIndex, int x, int y) {
        if (!(row.widget instanceof class_342 box)) {
            return;
        }

        if (partIndex == ConfigEntryRow.CATALOG_HIT) {
            final String current = box.method_1882().trim();
            modals.open(new SelectionPopup(this.field_22789, this.field_22790, class_2561.method_43471("tooltipoverhaul.config.frames.frame_catalog"), FrameEditorScreen.frameCatalogOptions(current), current::equals, box::method_1852, false, accent));
            playClickSound();
            return;
        }

        int initial = 0xFFFFFFFF;
        final List<String> parts = colorEntries(box.method_1882());
        if (partIndex >= 0 && partIndex < parts.size()) {
            initial = ConfigColorParser.parseColor(parts.get(partIndex));
        }

        pickerRow = row;
        pickerPartIndex = partIndex;
        modals.open(new ColorLevelPicker(x, y, HEADER_HEIGHT + 4, this.field_22789, this.field_22790, accent, initial, false, argb -> applyPickedColor(pickerRow, pickerPartIndex, argb)));

        playClickSound();
    }

    private void applyPickedColor(ConfigEntryRow row, int partIndex, int argb) {
        if (row == null || !(row.widget instanceof class_342 box)) {
            return;
        }

        final List<String> parts = colorEntries(box.method_1882());
        if (partIndex < 0 || partIndex >= parts.size()) {
            return;
        }

        parts.set(partIndex, formatHex(argb, false));
        box.method_1852(String.join(", ", parts));
    }

    @Override
    public void method_25419() {
        panel.applyToFields();
        ConfigManager.save(configClass);
        returnToParent();
    }

    @Override
    public void method_25432() {
        REMEMBERED_CATEGORIES.put(configClass, selectedCategory);
        super.method_25432();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        renderScreenShell(graphics, meta != null ? meta.description() : "");
        renderHeaderInfo(graphics);

        super.method_25394(graphics, mouseX, mouseY, partialTick);

        renderModifiedCounter(graphics);

        if (panel != null) {
            panel.renderPendingTooltip(graphics, field_22793, field_22789, field_22790);
        }

        renderModalLayer(graphics, mouseX, mouseY, partialTick);

    }

    private void renderHeaderInfo(class_332 graphics) {
        if (panel == null) {
            return;
        }

        final String text;
        if (!searchQuery.isBlank()) {
            final int results = panel.visibleCount();
            text = class_1074.method_4662(results == 1 ? "tooltipoverhaul.config.result" : "tooltipoverhaul.config.results", results);
        }
        else {
            final int total = snapshot.size();
            text = class_1074.method_4662(total == 1 ? "tooltipoverhaul.config.option" : "tooltipoverhaul.config.options", total) + (meta != null ? " \u00b7 " + meta.file() + ".toml" : "");
        }

        final int alpha = (int) (0xFF * AnimationUtils.easeOutCubic(class_3532.method_15363((class_156.method_658() - openedAt - 120) / 240f, 0f, 1f)));
        if (alpha >= 0x10) {
            graphics.method_51433(field_22793, text, field_22789 - 14 - field_22793.method_1727(text), 34, withAlpha(0x4A4A4A, alpha), false);
        }

    }

    private void renderModifiedCounter(class_332 graphics) {
        if (panel == null) {
            return;
        }

        final int modified = panel.countModified();
        if (modified <= 0) {
            return;
        }

        final String text = class_1074.method_4662(modified == 1 ? "tooltipoverhaul.config.change" : "tooltipoverhaul.config.changes", modified);
        final int textX = field_22789 - 14 - field_22793.method_1727(text);
        final int textY = field_22790 - 22;

        // Accent dot next to the pending changes counter
        final int[] ac = rgb(accent);
        graphics.method_25294(textX - 8, textY + 2, textX - 4, textY + 6, 0xFF000000 | (ac[0] << 16) | (ac[1] << 8) | ac[2]);

        graphics.method_51433(field_22793, text, textX, textY, withAlpha(accent, 0xE0), false);
    }

}
