package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameLoader;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameSource;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_410;
import net.minecraft.class_437;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.*;

public final class FrameSourceScreen extends AbstractConfigScreen {

    private List<Entry> sources = List.of();
    private List<Entry> visibleSources = List.of();

    private class_2960 selected = CustomFrameLoader.DEFAULT_SOURCE;
    private ConfigNavigationList<Entry> list;

    private SearchBox search;

    private FlatButton edit;
    private FlatButton restore;

    private String query = "";
    private String status = "";

    private boolean failed;

    private int panelX;
    private int panelWidth;
    private int listBottom;

    public FrameSourceScreen(class_437 parent, int accent) {
        super(class_2561.method_43470("Tooltip Overhaul"), parent, accent);
    }

    public static class_437 editorOrSelector(class_437 parent, int accent) {
        final List<CustomFrameSource> sources = CustomFrameLoader.discoverSources(class_310.method_1551().method_1478(), TooltipOverhaul.PLATFORM.getConfigPath());
        return sources.size() == 1 && sources.get(0).primary() ? new FrameEditorScreen(parent, accent, sources.get(0)) : new FrameSourceScreen(parent, accent);
    }

    @Override
    protected void initScreen() {
        panelWidth = Math.max(80, Math.min(680, field_22789 - 24));
        panelX = (field_22789 - panelWidth) / 2;
        listBottom = Math.max(HEADER_HEIGHT + 74, field_22790 - 94);
        sources = CustomFrameLoader.discoverSources(field_22787.method_1478(), TooltipOverhaul.PLATFORM.getConfigPath())
                .stream().map(source -> new Entry(source,
                        source.primary() ? "Tooltip Overhaul" : TooltipOverhaul.PLATFORM
                                .getModDisplayName(source.location().method_12836()).orElse(source.location().method_12836()),
                        source.customized())).toList();

        search = method_37063(new SearchBox(field_22793, panelX, HEADER_HEIGHT + 6, panelWidth, 18, accent));
        list = method_37063(new ConfigNavigationList<>(panelX, HEADER_HEIGHT + 30, panelWidth,
                listBottom - HEADER_HEIGHT - 30, class_2561.method_43471(key("files")), accent, List.of(),
                new ConfigNavigationList.Adapter<>() {

                    @Override
                    public class_2561 label(Entry entry, int index) {
                        return class_2561.method_43470(entry.name() + " / " + relativePath(entry.source()));
                    }

                    @Override
                    public class_2561 description(Entry entry, int index) {
                        return class_2561.method_43470(entry.source().location().method_12836() + "  ·  " + state(entry));
                    }

                    @Override
                    public int rowHeight(Entry entry, int index, int contentWidth) {
                        return 34;
                    }

                }, index -> {
                    if (index >= 0 && index < visibleSources.size()) {
                        selected = visibleSources.get(index).source().location();
                        updateButtons();
                    }

                }));

        list.setReorderingEnabled(false);

        final int buttonWidth = Math.min(140, (panelWidth - 16) / 3);
        final int start = (field_22789 - buttonWidth * 3 - 16) / 2;
        edit = method_37063(new FlatButton(start, field_22790 - 26, buttonWidth, 18, class_2561.method_43471(key("edit")), ignored -> openSelected(), accent, true));
        restore = method_37063(new FlatButton(start + buttonWidth + 8, field_22790 - 26, buttonWidth, 18, class_2561.method_43471(key("restore")), ignored -> confirmRestore(), accent));
        method_37063(new FlatButton(start + (buttonWidth + 8) * 2, field_22790 - 26, buttonWidth, 18, class_2561.method_43471("tooltipoverhaul.config.frames.back"), ignored -> method_25419(), accent));
        search.method_1863(value -> { query = value; filter(); });
        search.method_1852(query);

        filter();
    }

    private void filter() {
        final String needle = query.toLowerCase(Locale.ROOT).trim();
        visibleSources = sources.stream().filter(entry -> (entry.name() + " " + entry.source().location() + " " + entry.source().packName()).toLowerCase(Locale.ROOT).contains(needle)).toList();
        list.setItems(visibleSources);
        int index = -1;
        for (int i = 0; i < visibleSources.size(); i++) {
            if (visibleSources.get(i).source().location().equals(selected)) {
                index = i;
            }

        }

        if (index < 0 && !visibleSources.isEmpty()) {
            index = 0;
            selected = visibleSources.get(0).source().location();
        }

        list.setSelectedIndex(index);
        list.resetScroll();

        updateButtons();
    }

    private Entry selection() {
        return visibleSources.stream().filter(entry -> entry.source().location().equals(selected)).findFirst().orElse(null);
    }

    private void updateButtons() {
        Entry entry = selection();
        edit.field_22763 = entry != null;
        restore.field_22763 = entry != null && !entry.source().primary() && entry.customized();
    }

    private void openSelected() {
        Entry entry = selection();
        if (entry != null) {
            field_22787.method_1507(new FrameEditorScreen(this, accent, entry.source()));
        }

    }

    private void confirmRestore() {
        Entry entry = selection();
        if (entry == null || !restore.field_22763) {
            return;
        }

        field_22787.method_1507(new class_410(confirmed -> {
            if (confirmed) {
                try {
                    final Path backup = entry.source().restoreOriginal();
                    CustomFrameManager.reset();
                    CustomFrameManager.initialize();
                    status = class_1074.method_4662(key("restored"), backup.getFileName());
                    failed = false;
                }
                catch (Exception exception)  {
                    TooltipOverhaul.LOGGER.error("Could not restore {}", entry.source().location(), exception);
                    status = class_1074.method_4662(key("restore_failed"), exception.getMessage());
                    failed = true;
                }

            }

            field_22787.method_1507(this);
        }, class_2561.method_43471(key("restore")), class_2561.method_43469(key("restore_confirm"), entry.source().location().toString())));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        restoreGuiRenderState(graphics);
        renderScreenShell(graphics, class_1074.method_4662(key("subtitle")));

        drawCard(graphics, panelX, listBottom + 6, panelX + panelWidth, field_22790 - 36, 0xFF151517, 0xFF29292E);

        final Entry entry = selection();
        final int y = listBottom + 16;
        if (entry != null) {
            String origin = entry.source().primary() ? class_1074.method_4662(key("user_file")) : class_1074.method_4662(key("origin"), entry.source().packName());
            graphics.method_51433(field_22793, field_22793.method_27523(origin, panelWidth - 16), panelX + 8, y, 0xFFCCCCCC, false);

            String path = TooltipOverhaul.PLATFORM.getConfigPath().toAbsolutePath().normalize().relativize(entry.source().file().toAbsolutePath().normalize()).toString();
            graphics.method_51433(field_22793, field_22793.method_27523(path, panelWidth - 16), panelX + 8, y + 12, 0xFF92929E, false);

            String hint = status.isEmpty() ? class_1074.method_4662(key(entry.source().primary() ? "primary_hint" : entry.customized() ? "custom_hint" : "original_hint")) : status;
            graphics.method_51433(field_22793, field_22793.method_27523(hint, panelWidth - 16), panelX + 8, y + 24, failed ? 0xFFFF7777 : 0xFF92929E, false);
        }

        super.method_25394(graphics, mouseX, mouseY, partialTick);
        if (visibleSources.isEmpty()) {
            graphics.method_27534(field_22793, class_2561.method_43469("tooltipoverhaul.config.empty_search", query), field_22789 / 2, HEADER_HEIGHT + 62, 0xFF999999);
        }

        if (entry != null && mouseX >= panelX && mouseX < panelX + panelWidth && mouseY >= listBottom + 6 && mouseY < field_22790 - 36) {
            graphics.method_51447(field_22793, field_22793.method_1728(class_2561.method_43470(entry.source().location() + "\n" + entry.source().file() + (status.isEmpty() ? "" : "\n" + status)), Math.min(420, field_22789 - 24)), mouseX, mouseY);
        }

    }

    @Override
    protected void tickScreen() {
        ;;
    }

    @Override
    protected boolean handleKeyPressed(int key, int scanCode, int modifiers) {
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && (search.method_25370() || list.method_25370())) {
            openSelected();
            return true;
        }

        return super.handleKeyPressed(key, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        returnToParent();
    }

    private static String relativePath(CustomFrameSource source) {
        return source.location().method_12832().substring("tooltipoverhaul/".length());
    }

    private static String state(Entry entry) {
        return class_1074.method_4662(key(entry.source().primary() ? "user_file" : entry.customized() ? "customized" : "original"));
    }

    private static String key(String name) {
        return "tooltipoverhaul.config.sources." + name;
    }

    private record Entry(
            CustomFrameSource source,
            String name,
            boolean customized
    ) {
        ;;
    }

}
