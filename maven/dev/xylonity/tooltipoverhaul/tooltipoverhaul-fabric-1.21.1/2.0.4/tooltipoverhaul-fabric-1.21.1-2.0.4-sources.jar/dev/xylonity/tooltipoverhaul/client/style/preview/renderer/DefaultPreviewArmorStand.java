package dev.xylonity.tooltipoverhaul.client.style.preview.renderer;

import dev.xylonity.tooltipoverhaul.client.layer.impl.PreviewRendererLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import net.minecraft.class_1531;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_7833;
import net.minecraft.class_898;

public class DefaultPreviewArmorStand implements PreviewRendererLayer {

    @Override
    public void render(TooltipContext context, class_241 startPosition, class_241 endPosition) {

        int sizeX = RenderUtils.calculateSecondPanelSize(context, TextAxis.X);
        int sizeY = RenderUtils.calculateSecondPanelSize(context, TextAxis.Y);
        int y0 = (int) startPosition.field_1342;
        int x1 = (int) endPosition.field_1343;

        if (!(context.getStack().method_7909() instanceof class_1738 armorItem)) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();

        // Without a loaded level the armor stand entity doesnt exist, so the armor piece itself is drawn as a flat icon instead
        if (minecraft.field_1687 == null) {
            final float iconScale = Math.min(sizeX, sizeY) / 20f;
            context.translate(x1 + sizeX / 2f + 2 - 8 * iconScale, y0 + sizeY / 2f - 8 * iconScale, 0);
            context.scale(iconScale, iconScale, 1f);
            context.getGraphics().method_51427(context.getStack(), 0, 0);
            return;
        }

        context.translate((x1 + sizeX / 2f + 2), (y0 + sizeY / 1.15f) + 2, 0);

        context.multiply(class_7833.field_40714, -30);
        context.multiply(class_7833.field_40716, -45);

        context.multiply(class_7833.field_40716, (((System.currentTimeMillis() - context.getStartTime()) / 20f) % 360) * AnimationUtils.getSecondPanelRendererSpeed(context));

        final float scale = Math.min(sizeX, sizeY / 2f) / 1.25f;

        context.scale(-scale, -scale, scale);

        final class_1531 armorStand = PreviewEntityCache.armorStand(minecraft.field_1687);

        armorStand.method_5673(armorItem.method_7685(), context.getStack());

        class_308.method_34742();
        class_898 renderer = class_310.method_1551().method_1561();
        renderer.method_3948(false);
        try {
            renderer.method_3954(armorStand, 0, 0, 0, 0, 1, context.getPose(), context.getBuffer(), 0xF000F0);
        }
        finally {
            armorStand.method_5673(armorItem.method_7685(), class_1799.field_8037);
            renderer.method_3948(true);
        }

    }

}
