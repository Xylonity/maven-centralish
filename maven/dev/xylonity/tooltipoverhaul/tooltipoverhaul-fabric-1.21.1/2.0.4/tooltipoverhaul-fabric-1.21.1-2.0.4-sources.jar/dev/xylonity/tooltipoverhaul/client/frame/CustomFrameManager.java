package dev.xylonity.tooltipoverhaul.client.frame;

import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;

/**
 * Handles the loading context of the custom_frames.json files
 */
public class CustomFrameManager {

    private static final Map<class_2960, CustomFrameData> customFrames = new LinkedHashMap<>();

    private static boolean INIT = false;

    // Set by the frame editor screen so the live preview tooltip uses the frame being edited instead of the loaded ones
    private static volatile CustomFrameData previewOverride = null;
    private static boolean globalPreview;

    public static void setGlobalPreview(boolean enabled) {
        globalPreview = enabled;
    }

    public static void setPreviewOverride(CustomFrameData data) {
        previewOverride = data;
    }

    public static void initialize() {
        if (INIT) {
            return;
        }

        try {
            customFrames.clear();
            customFrames.putAll(CustomFrameLoader.loadCustomFrames(class_310.method_1551().method_1478(), TooltipOverhaul.PLATFORM.getConfigPath()));

            INIT = true;

            TooltipOverhaul.LOGGER.info("{} frames have been loaded!", customFrames.size());
        }
        catch (Exception e) {
            TooltipOverhaul.LOGGER.error("Failed to initialize custom frames loader: {}", e.getMessage());
        }

    }

    public static void initialize(class_3300 resourceManager) {
        if (INIT) {
            return;
        }

        try {
            customFrames.clear();
            customFrames.putAll(CustomFrameLoader.loadCustomFrames(resourceManager, TooltipOverhaul.PLATFORM.getConfigPath()));

            INIT = true;

            TooltipOverhaul.LOGGER.info("{} frames have been loaded!", customFrames.size());
        }
        catch (Exception e) {
            TooltipOverhaul.LOGGER.error("Failed to initialize custom frames loader: {}", e.getMessage());
        }

    }

    /**
     * Per resource reload
     */
    public static void reset() {
        customFrames.clear();
        INIT = false;
    }

    public static Optional<CustomFrameData> of(class_1799 stack) {
        if (globalPreview) {
            return Optional.empty();
        }

        if (previewOverride != null) {
            return Optional.of(previewOverride);
        }

        if (!INIT) {
            initialize();
        }

        return findMatch(customFrames.values(), stack);
    }

    /**
     * priority > specificity > order
     */
    public static Optional<CustomFrameData> findMatch(Iterable<CustomFrameData> frames, class_1799 stack) {
        CustomFrameData best = null;
        int bestScore = 0;
        for (final CustomFrameData customFrameData : frames) {
            final int score = customFrameData.matchScore(stack);
            if (score > 0 && (best == null || customFrameData.priority() > best.priority() || customFrameData.priority() == best.priority() && score > bestScore)) {
                bestScore = score;
                best = customFrameData;

            }

        }

        return Optional.ofNullable(best);
    }

}
