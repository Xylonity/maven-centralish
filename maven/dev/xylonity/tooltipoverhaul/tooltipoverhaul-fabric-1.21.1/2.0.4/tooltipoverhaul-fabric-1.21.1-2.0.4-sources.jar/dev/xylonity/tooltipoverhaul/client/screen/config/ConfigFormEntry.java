package dev.xylonity.tooltipoverhaul.client.screen.config;

import dev.xylonity.tooltipoverhaul.client.util.AnimationUtils;
import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_5481;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCardHoverFx;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.dimAccent;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.mixRgb;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.rgb;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.withAlpha;

/**
 * Visual and interaction contract for one configuration value
 */
class ConfigFormEntry {

    // Vertical gap
    static final int ROW_GAP = 4;

    class_2561 label;
    String description;
    @Nullable class_339 widget;
    String stableKey;
    int accent;

    float hoverAnim;
    long hoverStart;
    int height;
    int currentY;

    private int minimumHeight;
    private List<class_5481> descriptionLines = List.of();
    private int cachedWidth = -1;

    ConfigFormEntry() {
        this(class_2561.method_43473(), "", null, "", 0, 0);
    }

    ConfigFormEntry(class_2561 label, String description, @Nullable class_339 widget, String stableKey, int accent, int minimumHeight) {
        this.label = label;
        this.description = description;
        this.widget = widget;
        this.stableKey = stableKey;
        this.accent = accent;
        this.minimumHeight = minimumHeight;
        this.height = minimumHeight;
    }

    final void initialize(class_2561 label, String description, @Nullable class_339 widget, String stableKey, int accent, int minimumHeight) {
        this.label = label;
        this.description = description;
        this.widget = widget;
        this.stableKey = stableKey;
        this.accent = accent;
        this.minimumHeight = minimumHeight;
        this.height = minimumHeight;
        this.cachedWidth = -1;
        this.descriptionLines = List.of();
    }

    boolean isModified() {
        return false;
    }

    boolean requiresRestart() {
        return false;
    }

    protected void prepareWidgetWidth(int rowWidth) {
        ;;
    }

    protected int expandedWidgetWidth(int rowWidth) {
        return rowWidth - 40;
    }

    protected int descriptionSpacing() {
        return 54;
    }

    final void recalcHeight(int rowWidth) {
        if (widget == null) {
            height = minimumHeight;
            descriptionLines = List.of();
            return;
        }

        prepareWidgetWidth(rowWidth);

        final int layoutWidth = Math.max(1, rowWidth);
        if (cachedWidth == layoutWidth) {
            return;
        }

        cachedWidth = layoutWidth;

        final class_310 minecraft = class_310.method_1551();

        final int available = rowWidth - widget.method_25368() - descriptionSpacing();
        final int descriptionWidth = Math.min(available, (int) (rowWidth * 0.5f));

        descriptionLines = !description.isEmpty() && descriptionWidth > 30 ? minecraft.field_1772.method_1728(class_2561.method_43470(description), descriptionWidth) : List.of();

        final int contentHeight = minecraft.field_1772.field_2000 + (descriptionLines.isEmpty() ? 0 : 2 + descriptionLines.size() * minecraft.field_1772.field_2000);
        height = Math.max(minimumHeight, Math.max(contentHeight + 12, widget.method_25364() + 12));
    }

    void render(class_332 graphics, int index, int top, int left, int width, int mouseX, int mouseY, boolean hovered, float entrance, float partialTick) {
        if (widget == null) {
            return;
        }

        recalcHeight(width);

        currentY = top;
        if (!hovered) {
            hoverStart = 0;
        }

        final float target = hovered ? 1f : 0f;
        final float difference = target - hoverAnim;
        hoverAnim += difference * 0.12f;
        if (Math.abs(difference) < 0.005f) {
            hoverAnim = target;
        }

        final float hover = AnimationUtils.smoothstep(0f, 1f, hoverAnim);
        final int slide = (int) ((1f - entrance) * 16f);

        left += slide;

        final int alpha = (int) (0xFF * entrance);
        final int background = (alpha << 24) | mixRgb(0x151517, 0x1B1B1F, hover);
        final int border = (alpha << 24) | mixRgb(0x26262A, dimAccent(accent), hover);

        drawCard(graphics, left, top, left + width, top + height, background, border);
        drawCardHoverFx(graphics, left, top, width, height, hover * entrance, accent, index * 73 + stableKey.hashCode());

        prepareWidgetWidth(width);
        float textFade = 1f;
        if (widget instanceof StyledEditBox box) {
            widget.method_25358(Math.max(1, box.layoutWidth(Math.max(1, expandedWidgetWidth(width)))));
            textFade = 1f - box.expandProgress();
        }

        final int textAlpha = (int) (alpha * textFade);
        final class_310 minecraft = class_310.method_1551();
        int contentHeight = minecraft.field_1772.field_2000 + (descriptionLines.isEmpty() ? 0 : 2 + descriptionLines.size() * minecraft.field_1772.field_2000);
        final int contentTop = top + (height - contentHeight) / 2;
        final int labelX = left + 10;
        if (textAlpha >= 0x10) {
            graphics.method_51439(minecraft.field_1772, label, labelX, contentTop, withAlpha(mixRgb(0xC4C4C4, 0xFFFFFF, hover), textAlpha), false);
            int afterLabel = labelX + minecraft.field_1772.method_27525(label);
            if (requiresRestart()) {
                graphics.method_51433(minecraft.field_1772, "\u27f3", afterLabel + 4, contentTop, withAlpha(0xFF8844, textAlpha), false);
                afterLabel += 4 + minecraft.field_1772.method_1727("\u27f3");
            }

            if (isModified()) {
                final int[] channels = rgb(accent);
                graphics.method_25294(afterLabel + 5, contentTop + 2, afterLabel + 8, contentTop + 5, (textAlpha << 24) | (channels[0] << 16) | (channels[1] << 8) | channels[2]);
            }

            int descriptionY = contentTop + minecraft.field_1772.field_2000 + 2;
            for (final class_5481 line : descriptionLines) {
                graphics.method_51430(minecraft.field_1772, line, labelX, descriptionY, withAlpha(mixRgb(0x646464, 0x8C8C8C, hover), textAlpha), false);
                descriptionY += minecraft.field_1772.field_2000;
            }

        }

        final int widgetX = left + width - widget.method_25368() - 8;
        final int widgetY = top + (height - widget.method_25364()) / 2;
        widget.method_46421(widgetX);
        widget.method_46419(widgetY);
        widget.method_25350(entrance);

        if (entrance <= 0f) {
            return;
        }

        renderAccessories(graphics, mouseX, mouseY, widgetX, widgetY, alpha, textFade, entrance, hover);

        widget.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    protected void renderAccessories(class_332 graphics, int mouseX, int mouseY, int widgetX, int widgetY, int alpha, float textFade, float entrance, float hover) {
        ;;
    }

    void setFocused(boolean focused) {
        if (widget != null) {
            widget.method_25365(focused);
            if (widget instanceof class_342 editBox) {
                editBox.method_25365(focused);
            }

        }

    }

    boolean mouseClicked(double mouseX, double mouseY, int button) {
        return widget != null && widget.method_25402(mouseX, mouseY, button);
    }

    boolean mouseReleased(double mouseX, double mouseY, int button) {
        return widget != null && widget.method_25406(mouseX, mouseY, button);
    }

    boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return widget != null && widget.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    boolean keyPressed(int key, int scanCode, int modifiers) {
        return widget != null && widget.method_25404(key, scanCode, modifiers);
    }

    boolean charTyped(char character, int modifiers) {
        return widget != null && widget.method_25400(character, modifiers);
    }

}