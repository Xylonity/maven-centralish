package dev.xylonity.tooltipoverhaul;

import dev.xylonity.tooltipoverhaul.client.event.TooltipOverhaulClientEvents;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import dev.xylonity.tooltipoverhaul.client.util.Palette;
import dev.xylonity.tooltipoverhaul.config.ConfigManager;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.client.style.effect.internal.EffectFieldRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

public class TooltipOverhaulFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        TooltipOverhaulClientEvents.init();
        CoreShaderRegistrationCallback.EVENT.register(registry -> {
            EffectFieldRenderer.reset();
            try {
                registry.register(EffectFieldRenderer.SHADER_ID, class_290.field_1592, EffectFieldRenderer::setShader);
            }
            catch (Exception failure)  {
                TooltipOverhaul.LOGGER.warn("Could not load effect shader... ", failure);
            }

        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> EffectFieldRenderer.reset());

        // Loads a simplex wrapper of nightconfig, impl derived from knightlib
        ConfigManager.init(FabricLoader.getInstance().getConfigDir(), TooltipsConfig.class);
        ConfigManager.onReload(TooltipsConfig.class, Palette::reload);

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            CustomFrameManager.initialize();
        });

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public class_2960 getFabricId() {
                        return class_2960.method_60655(TooltipOverhaul.MOD_ID, "custom_frames_reload");
                    }

                    @Override
                    public void method_14491(class_3300 resourceManager) {
                        CustomFrameManager.reset();
                        CustomFrameManager.initialize();
                    }

                }
        );

    }

}
