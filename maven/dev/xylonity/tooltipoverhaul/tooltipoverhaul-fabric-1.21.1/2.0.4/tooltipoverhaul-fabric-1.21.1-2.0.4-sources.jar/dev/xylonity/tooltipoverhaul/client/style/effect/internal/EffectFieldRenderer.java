package dev.xylonity.tooltipoverhaul.client.style.effect.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import org.joml.Matrix4f;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_277;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import net.minecraft.class_757;

import static dev.xylonity.tooltipoverhaul.client.style.effect.internal.EffectParameter.*;

public final class EffectFieldRenderer {

    public static final class_2960 SHADER_ID = class_2960.method_60655(TooltipOverhaul.MOD_ID, "effect_field");
    private static final int MAX_MESHES = 8;
    private static final Map<EffectField.Grid, class_291> MESHES = new LinkedHashMap<>(16, 0.75f, true);
    private static class_5944 shader;

    private static final class_277 OPAQUE_BLEND = new class_277();

    private static final int[][] COLORS = {
            {0xFF77BBB5, 0xFFA69BD3, 0xFFD5B596, 0xFF7F88A9, 0xFF77BBB5},
            {0xFF70CFC6, 0xFF9390DF, 0xFFE6BC8B, 0xFF70CFC6, 0xFF70CFC6},
            {0xFF6CDFB8, 0xFF947ADC, 0xFFB1EAD5, 0xFF6CDFB8, 0xFF6CDFB8},
            {0xFF5ABBB5, 0xFF879CDB, 0xFFD9A6BF, 0xFFE5DFC9, 0xFF5ABBB5},
            {0xFF659DCF, 0xFFB2A5E6, 0xFFE4C49A, 0xFFD3A2C6, 0xFFD8E8F1}
    };

    private static final int[][] CHANNELS = { {0,1,2,0,0}, {0,1,2,0,0}, {0,1,2,0,0}, {0,1,2,2,0}, {0,1,2,1,1} };

    public static void setShader(class_5944 loaded) {
        clearMeshes();
        shader = loaded;
    }

    public static void reset() {
        shader = null;
        clearMeshes();
    }

    private static void clearMeshes() {
        MESHES.values().forEach(class_291::close);
        MESHES.clear();
    }

    public static boolean available() {
        return shader != null;
    }

    public static void draw(EffectField field, TooltipContext context, EffectClip clip, double time, float interiorVisibility) {
        final EffectField.Grid grid = field.grid(clip.width(), clip.height());
        final class_291 mesh = mesh(grid);

        configure(shader, field, grid, time, interiorVisibility);

        final Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix()).mul(context.getPose().method_23760().method_23761()).translate(clip.left(), clip.top(), 0);
        try {
            clip.draw(mesh, modelView, shader);
        }
        finally {
            restoreGuiShader(class_757.method_34540());
        }

    }

    static void restoreGuiShader(class_5944 regular) {
        OPAQUE_BLEND.method_1244();
        regular.method_34586();
        regular.method_34585();
    }

    static class_291 mesh(EffectField.Grid grid) {
        class_291 mesh = MESHES.get(grid);
        if (mesh == null) {
            mesh = createMesh(grid);
            MESHES.put(grid, mesh);
            if (MESHES.size() > MAX_MESHES) {
                final Iterator<Map.Entry<EffectField.Grid, class_291>> oldest = MESHES.entrySet().iterator();
                oldest.next().getValue().close();
                oldest.remove();
            }

        }

        return mesh;
    }

    static void configure(class_5944 shader, EffectField field, EffectField.Grid grid, double time, float interiorVisibility) {
        shader.method_35785("FieldKind").method_35649(field.ordinal());
        shader.method_35785("FieldTime").method_1251((float) time);
        shader.method_35785("CanvasSize").method_1255(grid.width(), grid.height());
        shader.method_35785("FieldScale").method_1249(grid.scale(), EffectRuntime.value(FIELD_SCALE), grid.pixelSize());
        shader.method_35785("FieldControls").method_1254(EffectRuntime.value(DISTORTION), EffectRuntime.value(SHARPNESS), EffectRuntime.value(CURTAIN_HEIGHT), EffectRuntime.intensity());
        shader.method_35785("InteriorVisibility").method_1251(interiorVisibility);
        shader.method_35785("Variation").method_35649((int) EffectRuntime.value(VARIATION));
        shader.method_35785("PatternPhase").method_1249(EffectCanvas.patternPhase(80), EffectCanvas.patternPhase(81), EffectCanvas.patternPhase(82));
        for (int i = 0; i < 5; i++) {
            final int color = EffectRuntime.color(CHANNELS[field.ordinal()][i], COLORS[field.ordinal()][i]);
            shader.method_35785("Palette" + i).method_1249((float) ((color >>> 16) & 255), (float) ((color >>> 8) & 255), (float) (color & 255));
        }

    }

    private static class_291 createMesh(EffectField.Grid grid) {
        final class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        for (int row = 0; row < grid.rows(); row++) {
            final float y0 = grid.y(row), y1 = grid.y(row + 1);
            for (int column = 0; column < grid.columns(); column++) {
                final float x0 = grid.x(column), x1 = grid.x(column + 1);
                builder.method_22912(x0, y0, 0);
                builder.method_22912(x1, y0, 0);
                builder.method_22912(x1, y1, 0);
                builder.method_22912(x0, y1, 0);
            }

        }

        final class_291 mesh = new class_291(class_291.class_8555.field_44793);
        try {
            mesh.method_1353();
            mesh.method_1352(builder.method_60800());
            return mesh;
        }
        catch (final RuntimeException failure) {
            mesh.close();
            throw failure;
        }
        finally {
            class_291.method_1354();
        }

    }

}