package dev.xylonity.tooltipoverhaul.client.style.preview.renderer;

import com.mojang.authlib.GameProfile;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1531;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_8685;

public final class PreviewEntityCache {

    private static final GameProfile PROFILE = new GameProfile(new UUID(0L, 0L), "");
    private static final class_8685 SKIN = new class_8685(TooltipOverhaul.pathOf("textures/preview/dummy.png"), null, null, null, class_8685.class_7920.field_41123, true);

    private static class_1531 armorStand;
    private static PreviewPlayer player;

    public static void clear() {
        armorStand = null;
        player = null;
    }

    static class_1531 armorStand(class_638 level) {
        if (armorStand == null || armorStand.method_37908() != level) {
            armorStand = new class_1531(class_1299.field_6131, level);
            armorStand.method_6907(true);
        }

        return armorStand;
    }

    static class_745 player(class_638 level, boolean usePlayerSkin) {
        if (player == null || player.method_37908() != level) {
            player = new PreviewPlayer(level);
        }

        player.usePlayerSkin = usePlayerSkin;

        return player;
    }

    private static final class PreviewPlayer extends class_745 {

        private boolean usePlayerSkin;

        private PreviewPlayer(class_638 level) {
            super(level, PROFILE);
        }

        @Override
        public class_8685 method_52814() {
            final var local = class_310.method_1551().field_1724;
            return usePlayerSkin && local != null ? local.method_52814() : SKIN;
        }

    }

}
