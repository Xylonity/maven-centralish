package dev.xylonity.tooltipoverhaul.client.style.vignette;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layer.impl.VignetteLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.vignette.parser.VignetteEntry;
import dev.xylonity.tooltipoverhaul.client.util.ColorUtils;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public final class LinearVignette implements VignetteLayer {

    private final VignetteEntry entry;

    public LinearVignette(VignetteEntry entry) {
        this.entry = entry;
    }

    @Override
    public void render(TooltipContext context, class_241 position) {
        final float width = context.getTooltipSize().field_1343, height = context.getTooltipSize().field_1342;
        if (!Float.isFinite(entry.radius()) || entry.radius() <= 0) {
            return;
        }

        final float left = position.field_1343 - context.getPaddingX() - 1, top = position.field_1342 - context.getPaddingY();
        final float right = position.field_1343 + width + context.getPaddingX(), bottom = position.field_1342 + height + context.getPaddingY();
        final float offsetX = height * entry.extraPositionX() / 100f, offsetY = width * entry.extraPositionY() / 100f;

        context.enableScissor((int) left, (int) top, (int) right, (int) bottom);
        context.flush();

        RenderSystem.enableBlend();

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        RenderSystem.setShader(class_757::method_34540);
        try {
            final Matrix4f pose = context.getPose().method_23760().method_23761();
            final class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);

            final String anchor = entry.position();
            final float depthY = Math.min(bottom - top, (bottom - top) * entry.radius());
            final float depthX = Math.min(right - left, (right - left) * entry.radius());
            if (anchor.startsWith("top") || anchor.equals("middle")) {
                float edge = top + offsetY;
                vertical(buffer, pose, left + offsetX, right + offsetX, edge, edge + depthY);
            }

            if (anchor.startsWith("bottom") || anchor.equals("middle")) {
                float edge = bottom + offsetY;
                vertical(buffer, pose, left + offsetX, right + offsetX, edge, edge - depthY);
            }

            if (anchor.equals("left")) {
                float edge = left + offsetX;
                horizontal(buffer, pose, top + offsetY, bottom + offsetY, edge, edge + depthX);
            }

            if (anchor.equals("right")) {
                final float edge = right + offsetX;
                horizontal(buffer, pose, top + offsetY, bottom + offsetY, edge, edge - depthX);
            }

            final class_9801 mesh = buffer.method_60794();
            if (mesh != null) {
                class_286.method_43433(mesh);
            }

        }
        finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();

            RenderSystem.disableBlend();

            context.getGraphics().method_44380();
        }

    }

    private void vertical(class_287 buffer, Matrix4f pose, float x0, float x1, float edgeY, float innerY) {
        int alpha = ColorUtils.alpha(entry.color());
        vertex(buffer, pose, x0, edgeY, alpha);
        vertex(buffer, pose, x0, innerY, 0);
        vertex(buffer, pose, x1, innerY, 0);
        vertex(buffer, pose, x1, edgeY, alpha);
    }

    private void horizontal(class_287 buffer, Matrix4f pose, float y0, float y1, float edgeX, float innerX) {
        final int alpha = ColorUtils.alpha(entry.color());
        vertex(buffer, pose, edgeX, y0, alpha);
        vertex(buffer, pose, innerX, y0, 0);
        vertex(buffer, pose, innerX, y1, 0);
        vertex(buffer, pose, edgeX, y1, alpha);
    }

    private void vertex(class_287 buffer, Matrix4f pose, float x, float y, int alpha) {
        buffer.method_22918(pose, x, y, 0).method_1336(ColorUtils.red(entry.color()), ColorUtils.green(entry.color()), ColorUtils.blue(entry.color()), alpha);
    }

}