package dev.xylonity.tooltipoverhaul.client.style.effect.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layout.TooltipLayout;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.Constants;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_291;
import net.minecraft.class_5944;
import net.minecraft.class_9801;

public final class EffectClip {

    private final TooltipContext context;
    private final List<Rect> regions = new ArrayList<>();

    private final Rect bounds;

    public EffectClip(TooltipContext context, class_241 position) {
        this.context = context;
        final int x = (int) position.field_1343;
        final int y = (int) position.field_1342;
        final Rect main = new Rect(x - context.getPaddingX() - 1, y - context.getPaddingY(), x + (int) context.getTooltipSize().field_1343 + context.getPaddingX(), y + (int) context.getTooltipSize().field_1342 + context.getPaddingY());

        add(main);

        if (context.getLayoutStyle() == TooltipLayout.Style.BADGE) {
            final int iconX = x + TooltipLayout.iconX(context);
            final int iconY = y + TooltipLayout.iconY(context);
            final int size = Constants.getIconSize(context);

            addOutside(new Rect(iconX, iconY - 1, iconX + size, iconY), main);
            addOutside(new Rect(iconX - 1, iconY, iconX + size + 1, iconY + size), main);
            addOutside(new Rect(iconX, iconY + size, iconX + size, iconY + size + 1), main);
        }

        int left = main.left, top = main.top, right = main.right, bottom = main.bottom;
        for (final Rect region : regions) {
            left = Math.min(left, region.left);
            top = Math.min(top, region.top);
            right = Math.max(right, region.right);
            bottom = Math.max(bottom, region.bottom);
        }

        bounds = new Rect(left, top, right, bottom);
    }

    private void add(Rect rect) {
        if (rect.right > rect.left && rect.bottom > rect.top) {
            regions.add(rect);
        }

    }

    private void addOutside(Rect rect, Rect main) {
        final int left = Math.max(rect.left, main.left);
        final int right = Math.min(rect.right, main.right);
        final int top = Math.max(rect.top, main.top);
        final int bottom = Math.min(rect.bottom, main.bottom);
        if (left >= right || top >= bottom) {
            add(rect);
            return;
        }

        add(new Rect(rect.left, rect.top, rect.right, top));
        add(new Rect(rect.left, bottom, rect.right, rect.bottom));
        add(new Rect(rect.left, top, left, bottom));
        add(new Rect(right, top, rect.right, bottom));
    }

    public int left() {
        return bounds.left;
    }

    public int top() {
        return bounds.top;
    }

    public int width() {
        return bounds.right - bounds.left;
    }

    public int height() {
        return bounds.bottom - bounds.top;
    }

    public boolean hasExtension() {
        return regions.size() > 1;
    }

    public void draw(class_291 buffer, Matrix4f modelView, class_5944 shader) {
        try {
            for (final Rect region : regions) {
                context.enableScissor(region.left, region.top, region.right, region.bottom);
                try {
                    RenderSystem.disableDepthTest();
                    buffer.method_1353();
                    buffer.method_34427(modelView, RenderSystem.getProjectionMatrix(), shader);
                }
                finally {
                    context.getGraphics().method_44380();
                }

            }

        }
        finally {
            class_291.method_1354();
        }

    }

    public void draw(class_9801 mesh) {
        if (mesh == null) {
            return;
        }

        final class_291 buffer = mesh.method_60822().comp_749().method_43446();
        boolean uploaded = false;
        try {
            for (final Rect region : regions) {
                context.enableScissor(region.left, region.top, region.right, region.bottom);
                try {
                    RenderSystem.disableDepthTest();
                    if (!uploaded) {
                        uploaded = true;
                        class_286.method_43433(mesh);
                    }
                    else {
                        buffer.method_1353();
                        buffer.method_34427(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
                    }

                }
                finally {
                    context.getGraphics().method_44380();
                }

            }

        }
        finally {
            if (!uploaded) {
                mesh.close();
            }

            if (hasExtension()) {
                class_291.method_1354();
            }

        }

    }

    private record Rect(
            int left,
            int top,
            int right,
            int bottom
    ) {
        ;;
    }

}
