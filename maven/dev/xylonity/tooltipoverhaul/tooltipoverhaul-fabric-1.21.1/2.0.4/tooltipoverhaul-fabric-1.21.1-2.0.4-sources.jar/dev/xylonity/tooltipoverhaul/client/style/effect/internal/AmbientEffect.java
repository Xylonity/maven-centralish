package dev.xylonity.tooltipoverhaul.client.style.effect.internal;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.layer.impl.EffectLayer;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import net.minecraft.class_9801;

/**
 * Shared setup for every effect, which owns the render state so the effects themselves only ever have to write down geometry
 */
public abstract class AmbientEffect implements EffectLayer {

    @Override
    public final void render(TooltipContext context, class_241 position) {
        final class_241 size = context.getTooltipSize();
        if (size == null || size.field_1343 <= 0 || size.field_1342 <= 0) {
            return;
        }

        // Finishing buffered gui layers before switching their blend mode
        context.flush();

        final boolean clipped = clipToTooltip();
        final EffectClip clip = clipped ? new EffectClip(context, position) : null;

        float left = position.field_1343 - 4;
        float top = position.field_1342 - 3;
        float width = size.field_1343 + 7;
        float height = size.field_1342 + 6;
        if (clipped) {
            left = clip.left();
            top = clip.top();
            width = clip.width();
            height = clip.height();
        }

        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(class_757::method_34540);

        final class_289 tesselator = class_289.method_1348();
        try {
            final double time = EffectRuntime.seconds(context);
            final boolean gpuField = field() != null && clip != null && EffectFieldRenderer.available();
            if (gpuField) {
                EffectFieldRenderer.draw(field(), context, clip, time, interiorVisibility());
                RenderSystem.setShader(class_757::method_34540);
            }

            if (hasMaterial()) {
                RenderSystem.defaultBlendFunc();

                final class_287 material = tesselator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
                try {
                    drawMaterial(new EffectCanvas(material, context.getPose().method_23760().method_23761(), left, top, width, height, time, 1, clipped));
                }
                finally {
                    submit(clip, material.method_60794());
                }

            }

            RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            final class_287 buffer = tesselator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
            try {
                final EffectCanvas canvas = new EffectCanvas(buffer, context.getPose().method_23760().method_23761(), left, top, width, height, time, interiorVisibility(), clipped);
                if (gpuField) {
                    drawAfterField(canvas);
                }
                else {
                    draw(canvas);
                }

            }
            finally {
                submit(clip, buffer.method_60794());
            }

        }
        finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
            RenderSystem.enableCull();

        }

    }

    private static void submit(EffectClip clip, class_9801 mesh) {
        if (clip != null) {
            clip.draw(mesh);
        }
        else if (mesh != null) {
            class_286.method_43433(mesh);
        }

    }

    protected abstract void draw(EffectCanvas canvas);

    protected EffectField field() {
        return null;
    }

    protected void drawAfterField(EffectCanvas canvas) {
        ;;
    }

    protected boolean clipToTooltip() {
        return false;
    }

    protected boolean hasMaterial() {
        return false;
    }

    protected void drawMaterial(EffectCanvas canvas) {
        ;;
    }

    /**
     * Transparency when the effect is within the tooltip margins, so it doesn't interfere with text reading
     */
    protected float interiorVisibility() {
        return 0.18f;
    }

}
