package dev.xylonity.tooltipoverhaul.client.screen.config;

import org.lwjgl.glfw.GLFW;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.*;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

/**
 * HSV color picker shared by the config screens
 */
final class ColorLevelPicker implements ConfigModal {

    interface Commit {

        void accept(int argb);
    }

    private static final int SV_WIDTH = 134;
    private static final int SV_HEIGHT = 84;
    private static final int BAR_HEIGHT = 10;
    private static final int PADDING = 8;

    private final Commit commit;
    private final int accent;

    private final boolean alwaysAlphaHex;
    private final boolean alphaEnabled;

    private final int x;
    private final int y;
    private final int width;
    private final int height;

    private float hue;
    private float saturation;
    private float value;
    private int alpha;

    private final StyledEditBox hexBox;
    private boolean syncingHex = false;
    private boolean closed;

    // 0 none, 1 sv square, 2 hue bar, 3 alpha bar
    private int dragZone = 0;

    ColorLevelPicker(int anchorX, int anchorY, int minY, int screenWidth, int screenHeight, int accent, int initialArgb, boolean alwaysAlphaHex, Commit commit) {
        this(anchorX, anchorY, minY, screenWidth, screenHeight, accent, initialArgb, alwaysAlphaHex, true, commit);
    }

    ColorLevelPicker(int anchorX, int anchorY, int minY, int screenWidth, int screenHeight, int accent, int initialArgb, boolean alwaysAlphaHex, boolean alphaEnabled, Commit commit) {
        this.commit = commit;
        this.alphaEnabled = alphaEnabled;
        this.accent = accent;
        this.alwaysAlphaHex = alwaysAlphaHex;
        this.width = PADDING * 2 + SV_WIDTH;
        this.height = PADDING + SV_HEIGHT + 6 + BAR_HEIGHT + (alphaEnabled ? 6 + BAR_HEIGHT : 0) + 8 + 16 + PADDING;
        this.x = class_3532.method_15340(anchorX - width - 6, 4, Math.max(4, screenWidth - width - 4));
        this.y = class_3532.method_15340(anchorY - height / 2, minY, Math.max(minY, screenHeight - height - 4));

        final float[] hsv = rgbToHsv(initialArgb & 0x00FFFFFF);
        this.hue = hsv[0];
        this.saturation = hsv[1];
        this.value = hsv[2];
        this.alpha = alphaEnabled ? initialArgb >>> 24 : 255;

        this.hexBox = new StyledEditBox(class_310.method_1551().field_1772, x + PADDING, y + height - PADDING - 16, SV_WIDTH - 24, 16, class_2561.method_43473(), accent);
        this.hexBox.method_1880(alphaEnabled ? 9 : 7);
        this.hexBox.method_1852(currentHex());
        this.hexBox.method_1863(this::onHexTyped);
    }

    private int svX() {
        return x + PADDING;
    }

    private int svY() {
        return y + PADDING;
    }

    private int hueY() {
        return svY() + SV_HEIGHT + 6;
    }

    private int alphaY() {
        return hueY() + BAR_HEIGHT + 6;
    }

    private int argb() {
        return (alpha << 24) | hsvToRgb(hue, saturation, value);
    }

    private String currentHex() {
        return formatHex(argb(), alwaysAlphaHex);
    }

    private void onHexTyped(String raw) {
        if (syncingHex) {
            return;
        }

        String hex = raw.trim();
        if (hex.startsWith("#")) {
            hex = hex.substring(1);
        }
        else if (hex.startsWith("0x") || hex.startsWith("0X")) {
            hex = hex.substring(2);
        }

        if (!hex.matches("[0-9a-fA-F]{6}([0-9a-fA-F]{2})?")) {
            return;
        }

        final long value = Long.parseLong(hex, 16);
        if (alphaEnabled && hex.length() == 8) {
            alpha = (int) ((value >> 24) & 0xFF);
        }

        final float[] hsv = rgbToHsv((int) (value & 0x00FFFFFF));
        // Grays lose their hue in the conversion
        if (hsv[1] > 0f) {
            hue = hsv[0];
        }

        saturation = hsv[1];
        this.value = hsv[2];

        commit();
    }

    private void syncHex() {
        syncingHex = true;
        hexBox.method_1852(currentHex());
        syncingHex = false;
    }

    private void commit() {
        commit.accept(argb());
    }

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(0, 0, 400);

        drawCard(graphics, x, y, x + width, y + height, 0xF8101012, withAlpha(dimAccent(accent), 0xFF));

        // Color level square
        for (int i = 0; i < SV_WIDTH; i++) {
            final int top = 0xFF000000 | hsvToRgb(hue, (float) i / (SV_WIDTH - 1), 1f);
            graphics.method_25296(svX() + i, svY(), svX() + i + 1, svY() + SV_HEIGHT, top, 0xFF000000);
        }

        final int svCursorX = svX() + (int) (saturation * (SV_WIDTH - 1));
        final int svCursorY = svY() + (int) ((1f - value) * (SV_HEIGHT - 1));
        graphics.method_25294(svCursorX - 2, svCursorY - 2, svCursorX + 3, svCursorY + 3, 0xFFFFFFFF);
        graphics.method_25294(svCursorX - 1, svCursorY - 1, svCursorX + 2, svCursorY + 2, 0xFF000000 | hsvToRgb(hue, saturation, value));

        // Hue bar
        for (int i = 0; i < SV_WIDTH; i++) {
            graphics.method_25294(svX() + i, hueY(), svX() + i + 1, hueY() + BAR_HEIGHT, 0xFF000000 | hsvToRgb((float) i / (SV_WIDTH - 1) * 360f, 1f, 1f));
        }

        final int hueCursorX = svX() + (int) (hue / 360f * (SV_WIDTH - 1));
        graphics.method_25294(hueCursorX - 1, hueY() - 1, hueCursorX + 2, hueY() + BAR_HEIGHT + 1, 0xFFFFFFFF);
        graphics.method_25294(hueCursorX, hueY(), hueCursorX + 1, hueY() + BAR_HEIGHT, 0xFF000000 | hsvToRgb(hue, 1f, 1f));

        // Alpha bar
        final int rgb = hsvToRgb(hue, saturation, value);
        if (alphaEnabled) {
            for (int i = 0; i < SV_WIDTH; i++) {
                final float ratio = (float) i / (SV_WIDTH - 1);
                graphics.method_25294(svX() + i, alphaY(), svX() + i + 1, alphaY() + BAR_HEIGHT, 0xFF000000 | mixRgb(0x232327, rgb, ratio));
            }

            final int alphaCursorX = svX() + (int) (alpha / 255f * (SV_WIDTH - 1));
            graphics.method_25294(alphaCursorX - 1, alphaY() - 1, alphaCursorX + 2, alphaY() + BAR_HEIGHT + 1, 0xFFFFFFFF);
            graphics.method_25294(alphaCursorX, alphaY(), alphaCursorX + 1, alphaY() + BAR_HEIGHT, 0xFF17171A);
        }

        hexBox.method_25394(graphics, mouseX, mouseY, 0);

        final int swatchX = x + width - PADDING - 16;
        final int swatchY = y + height - PADDING - 16;
        graphics.method_25294(swatchX, swatchY, swatchX + 16, swatchY + 16, 0xFF2E2E32);
        graphics.method_25294(swatchX + 1, swatchY + 1, swatchX + 15, swatchY + 15, 0xFF000000 | mixRgb(0x151517, rgb, alpha / 255f));

        graphics.method_51448().method_22909();
    }

    /**
     * Clicking outside marks the picker for dismissal by its host
     */
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (mouseX < x || mouseX >= x + width || mouseY < y || mouseY >= y + height) {
            closed = true;
            return true;
        }

        if (button != 0) {
            return true;
        }

        if (mouseY >= svY() && mouseY < svY() + SV_HEIGHT && mouseX >= svX() && mouseX < svX() + SV_WIDTH) {
            dragZone = 1;
        }
        else if (mouseY >= hueY() - 2 && mouseY < hueY() + BAR_HEIGHT + 2 && mouseX >= svX() && mouseX < svX() + SV_WIDTH) {
            dragZone = 2;
        }
        else if (alphaEnabled && mouseY >= alphaY() - 2 && mouseY < alphaY() + BAR_HEIGHT + 2 && mouseX >= svX() && mouseX < svX() + SV_WIDTH) {
            dragZone = 3;
        }

        if (dragZone != 0) {
            hexBox.method_25365(false);
            update(mouseX, mouseY);
            return true;
        }

        hexBox.method_25365(hexBox.method_25402(mouseX, mouseY, button));

        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragZone == 0) {
            return true;
        }

        update(mouseX, mouseY);
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragZone != 0) {
            dragZone = 0;
            commit();
        }

        return true;
    }

    private void update(double mouseX, double mouseY) {
        final float tx = class_3532.method_15363((float) (mouseX - svX()) / (SV_WIDTH - 1), 0f, 1f);

        if (dragZone == 1) {
            saturation = tx;
            value = 1f - class_3532.method_15363((float) (mouseY - svY()) / (SV_HEIGHT - 1), 0f, 1f);
        }
        else if (dragZone == 2) {
            hue = tx * 360f;
        }
        else if (dragZone == 3) {
            alpha = Math.round(tx * 255f);
        }

        syncHex();
        commit();
    }

    @Override
    public boolean keyPressed(int key, int scancode, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            closed = true;
            return true;
        }

        if (hexBox.method_25370()) {
            hexBox.method_25404(key, scancode, modifiers);
            return true;
        }

        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (hexBox.method_25370()) {
            hexBox.method_25400(chr, modifiers);
        }

        return true;
    }

    @Override
    public void tick() {
        ;;
    }

    @Override
    public boolean closed() {
        return closed;
    }

}