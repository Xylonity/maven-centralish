package dev.xylonity.tooltipoverhaul.client.layout;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.util.PositionUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import net.minecraft.class_241;
import org.joml.Matrix4f;

public class TooltipPositionCalculator {

    private final TooltipContext context;

    public TooltipPositionCalculator(TooltipContext context) {
        this.context = context;
    }

    public class_241 calculate() {

        boolean isMainTooltip = context.isMainTooltip();

        int paddingX = context.getPaddingX();
        int leftOverflow = TooltipLayout.leftOverflow(context);
        int paddingY = context.getPaddingY();
        final int tooltipWidth = (int) context.getTooltipSize().field_1343;
        int tooltipHeight = (int) context.getTooltipSize().field_1342;
        final int screenWidth = context.getScreenWidth();
        int screenHeight = context.getScreenHeight();

        // Packed up translates the model-view stack and hands widget-local mouse coordinates to renderTooltipInternal,
        // so all the math here is done in real screen space
        final Matrix4f modelView = RenderSystem.getModelViewStack();
        final int viewOffsetX = Math.round(modelView.m30());
        final int viewOffsetY = Math.round(modelView.m31());

        final int mouseX = context.getMouseX() + viewOffsetX;
        final int mouseY = context.getMouseY() + viewOffsetY;

        // Initial position (with offset)
        float posX = mouseX + (isMainTooltip ? 12 + leftOverflow : -12) + PositionUtils.getMainPanelPosition(context, TextAxis.X);
        float posY = mouseY - 12 + PositionUtils.getMainPanelPosition(context, TextAxis.Y);

        if (isMainTooltip) {
            final TooltipContext equippedContext = context.getOtherTooltipContext();
            final boolean hasEquippedContext = equippedContext != null;

            // Just if the equipped stack is not available
            if (!hasEquippedContext) {
                boolean bedrockCentered = false;

                // Bedrock-like centering (if the tooltip fits on neither side of the cursor, centers it horizontally
                // and places it above (or below) the cursor so the hovered item stays visible)
                if (TooltipsConfig.BEDROCK_CENTERING) {
                    final boolean fitsRight = mouseX + 12 + tooltipWidth + leftOverflow <= screenWidth;
                    final boolean fitsLeft = mouseX - 12 - tooltipWidth - leftOverflow >= paddingX;

                    if (!fitsRight && !fitsLeft) {
                        posX = (screenWidth - tooltipWidth + leftOverflow) / 2f + PositionUtils.getMainPanelPosition(context, TextAxis.X);

                        final float offsetY = PositionUtils.getMainPanelPosition(context, TextAxis.Y);
                        if (mouseY - 12 - tooltipHeight >= paddingY) {
                            posY = mouseY - 12 - tooltipHeight + offsetY;
                        }
                        else {
                            posY = mouseY + 12 + offsetY;
                        }

                        bedrockCentered = true;
                    }

                }

                // If it exceeds the right border, put the tooltip to the left
                // Not adding the padding here so the vanilla's wrapper doesn't flicker
                if (!bedrockCentered && posX + tooltipWidth > screenWidth) {
                    posX = mouseX - tooltipWidth - 12;
                }

            }

            // Clamps to the right border of the screen (now taking into account the padding value),
            // so the tooltip doesn't exceed the screen limits
            if (posX + tooltipWidth + paddingX > screenWidth) {
                posX = screenWidth - tooltipWidth - paddingX;
            }

            // Clamps to the left border of the screen
            if (posX < paddingX + leftOverflow) {
                posX = paddingX + leftOverflow;
            }

            // If it exceeds the bottom border, increase the height
            if (posY + tooltipHeight + paddingY > screenHeight) {
                posY = screenHeight - tooltipHeight - paddingY;
            }

            // If it exceeds the top border, decrease the height
            if (posY < paddingY) {
                posY = paddingY;
            }

        }
        else {

            posX = posX - tooltipWidth;

        }

        if (isMainTooltip && context.getLayoutStyle() == TooltipLayout.Style.FLOATING && context.getOtherTooltipContext() == null) {
            posX = FloatingLayout.adjustPanelX(context, posX);
        }

        return new class_241(posX - viewOffsetX, posY - viewOffsetY);
    }

    /**
     * This method is used as a filter if the equipped stack is active, thus recalculating certain tooltip positions depending on
     * the length of both tooltips
     * @return the new size of the current context
     */
    public class_241 adjustPosition() {

        class_241 newPosition = context.getTooltipPosition();

        final boolean isMainTooltip = context.isMainTooltip();

        final int paddingX = context.getPaddingX();
        final int leftOverflow = TooltipLayout.leftOverflow(context);
        final int paddingY = context.getPaddingY();
        final int mouseY = context.getMouseY();
        final int tooltipHeight = (int) context.getTooltipSize().field_1342;
        final int screenHeight = context.getScreenHeight();

        // Initial position (with offset)
        float posY = mouseY - 12;

        final TooltipContext otherContext = context.getOtherTooltipContext();

        final class_241 otherContextPosition = otherContext != null ? otherContext.getTooltipPosition() : null;
        final class_241 otherContextSize = otherContext != null ? otherContext.getTooltipSize() : null;

        if (isMainTooltip) {

            if (otherContextPosition != null && otherContextSize != null) {
                if (otherContextPosition.field_1343 <= otherContext.getPaddingX() * 2 + TooltipLayout.leftOverflow(otherContext)) {
                    newPosition = new class_241(otherContextPosition.field_1343 + otherContextSize.field_1343 + 12 * 2 + leftOverflow, newPosition.field_1342);
                }

            }

            if (otherContext != null && !otherContext.isMainTooltip()) {
                final int equippedHeight = otherContextSize != null ? (int) otherContextSize.field_1342 : 0;
                final float equippedPosY = mouseY - 12;

                // Checks if the equipped tooltip would be clamped at the bottom
                final boolean equippedClampedAtBottom = equippedPosY + equippedHeight + paddingY > screenHeight;
                // Checks if the equipped tooltip would be clamped at the top
                final boolean equippedClampedAtTop = equippedPosY < paddingY;

                if (equippedClampedAtBottom || equippedClampedAtTop) {
                    // Using the same Y position as the equipped tooltip will have after clamping
                    if (equippedClampedAtBottom) {
                        newPosition = new class_241(newPosition.field_1343, screenHeight - equippedHeight - paddingY);
                    }
                    else {
                        newPosition = new class_241(newPosition.field_1343, paddingY);
                    }

                }

            }

            // Vertically aligns the tooltip under a certain margin. That is, if the main tooltip is too high or too
            // low, the equippable tooltip is aligned with respect to the margins of the screen
            int margin = 100;
            if (otherContextPosition != null && otherContextSize != null) {
                if (posY != otherContextPosition.field_1342) {
                    int difference = (int) (posY - otherContextPosition.field_1342);
                    difference = difference < 0 ? -difference : difference;

                    if (difference > margin) {
                        newPosition = new class_241(newPosition.field_1343, screenHeight / 2f - tooltipHeight / 2f);
                    }

                }

            }

        }
        else {

            // If it exceeds the bottom border, increase the height
            if (posY + tooltipHeight + paddingY > screenHeight) {
                posY = screenHeight - tooltipHeight - paddingY;
            }

            // If it exceeds the top border, decrease the height
            if (posY < paddingY) {
                posY = paddingY;
            }

            // Hooks the second tooltip to the main tooltip X position
            if (otherContextPosition != null && otherContextSize != null) {
                newPosition = new class_241(0, context.getTooltipPosition().field_1342).method_35586(new class_241(otherContextPosition.field_1343 - TooltipLayout.leftOverflow(otherContext) - 24 - context.getTooltipSize().field_1343, 0));
                newPosition = new class_241(newPosition.field_1343, otherContextPosition.field_1342);

                if (newPosition.field_1343 < context.getPaddingX() + leftOverflow) {
                    newPosition = new class_241(context.getPaddingX() * 2 + leftOverflow, newPosition.field_1342);
                }

            }

            // Vertically aligns the tooltip under a certain margin. That is, if the main tooltip is too high or too
            // low, the equippable tooltip is aligned with respect to the margins of the screen
            final int margin = 100;
            if (otherContextPosition != null && otherContextSize != null) {
                if (posY != otherContextPosition.field_1342) {
                    int difference = (int) (posY - otherContextPosition.field_1342);
                    difference = difference < 0 ? -difference : difference;

                    if (difference > margin) {
                        newPosition = new class_241(newPosition.field_1343, screenHeight / 2f - tooltipHeight / 2f);
                    }

                }

            }

            float finalY = newPosition.field_1342;

            // If it exceeds the bottom border, clamps to bottom
            if (finalY + tooltipHeight + paddingY > screenHeight) {
                finalY = screenHeight - tooltipHeight - paddingY;
            }

            // If it exceeds the top border, clamps to the top
            if (finalY < paddingY) {
                finalY = paddingY;
            }

            newPosition = new class_241(newPosition.field_1343, finalY);
        }

        return newPosition;
    }

}
