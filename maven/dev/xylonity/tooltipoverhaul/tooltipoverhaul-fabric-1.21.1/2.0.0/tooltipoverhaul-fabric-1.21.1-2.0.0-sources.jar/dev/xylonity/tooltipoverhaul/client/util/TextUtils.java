package dev.xylonity.tooltipoverhaul.client.util;

import com.google.common.collect.Lists;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameData;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import dev.xylonity.tooltipoverhaul.mixin.ClientTextTooltipAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_5631;
import net.minecraft.class_5683;
import net.minecraft.class_5684;
import net.minecraft.class_7923;

public class TextUtils {

    public static boolean shouldDisableScrolling(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableScrolling).orElse(TooltipsConfig.DISABLE_TOOLTIP_SCROLLING);
    }

    /**
     * Adds vanilla's durability line without enabling the item id and component count
     */
    public static List<class_5684> appendDurability(List<class_5684> components, class_1799 stack) {
        final class_310 minecraft = class_310.method_1551();
        if (!TooltipsConfig.SHOW_ITEM_DURABILITY || stack.method_7960() || !stack.method_7986() || minecraft.field_1690.field_1827) {
            return components;
        }

        final List<class_5684> result = new ArrayList<>(components);
        final int insertionIndex = ModNameUtils.hasTrailingModName(result, stack) ? result.size() - 1 : result.size();

        result.add(insertionIndex, class_5684.method_32662(class_2561.method_43469("item.durability",
                stack.method_7936() - stack.method_7919(), stack.method_7936()).method_30937()));

        return result;
    }

    /**
     * Adds the item id, skipped when F3+H already shows it
     */
    public static List<class_5684> appendRegistryName(List<class_5684> components, class_1799 stack) {
        if (!TooltipsConfig.SHOW_REGISTRY_NAME || stack.method_7960() || class_310.method_1551().field_1690.field_1827) {
            return components;
        }

        final List<class_5684> result = new ArrayList<>(components);
        final int insertionIndex = ModNameUtils.hasTrailingModName(result, stack) ? result.size() - 1 : result.size();

        result.add(insertionIndex, class_5684.method_32662(class_2561.method_43470(class_7923.field_41178.method_10221(stack.method_7909()).toString()).method_27692(class_124.field_1063).method_30937()));

        return result;
    }

    public static List<class_5684> getTooltipComponentsFrom(class_1799 stack, class_327 font, int screenWidth, float screenSplit) {
        final class_310 minecraft = class_310.method_1551();
        final class_1657 player = minecraft.field_1724;
        final List<class_5684> componentList = Lists.newArrayList();

        final List<class_2561> originalComponentLines = stack.method_7950(class_1792.class_9635.method_59528(player != null ? player.method_37908() : null), player, minecraft.field_1690.field_1827 ? class_1836.field_41071 : class_1836.field_41070);
        for (class_2561 originalComponentLine : originalComponentLines) {
            final List<class_5481> wrappedLines = font.method_1728(originalComponentLine, Math.max((int)(screenWidth / screenSplit), 200));

            if (wrappedLines.isEmpty()) {
                componentList.add(class_5684.method_32662(class_5481.field_26385));
            }
            else if (wrappedLines.size() == 1) {
                componentList.add(class_5684.method_32662(originalComponentLine.method_30937()));
            }
            else {
                for (class_5481 wrappedLine : wrappedLines) {
                    componentList.add(class_5684.method_32662(wrappedLine));
                }

            }

        }

        stack.method_32347().ifPresent(component -> {
            if (component instanceof class_5631 bundleTooltip) {
                final int idx = originalComponentLines.size() > 1 ? 1 : componentList.size();
                componentList.add(idx, class_5684.method_32663(bundleTooltip));
            }

        });

        return componentList;
    }

    public static List<class_5684> wrapToWidth(List<class_5684> components, class_327 font, int firstLineWidth, int lineWidth) {
        List<class_5684> result = null;
        for (int i = 0; i < components.size(); i++) {
            final class_5684 component = components.get(i);
            final int limit = Math.max(40, i == 0 ? firstLineWidth : lineWidth);
            if (!(component instanceof class_5683 text) || component.method_32664(font) <= limit) {
                if (result != null) {
                    result.add(component);
                }

                continue;
            }

            if (result == null) {
                result = new ArrayList<>(components.subList(0, i));
            }

            for (class_5481 line : font.method_1728(toText(((ClientTextTooltipAccessor) text).getText()), limit)) {
                result.add(class_5684.method_32662(line));
            }

        }

        return result == null ? components : result;
    }

    /**
     * Rebuilds a component from an already ordered sequence keeping each style run so the font splitter can rewrap it
     */
    private static class_2561 toText(class_5481 sequence) {
        final class_5250 result = class_2561.method_43473();
        final StringBuilder run = new StringBuilder();
        final class_2583[] current = {null};
        sequence.accept((index, style, codePoint) -> {
            if (current[0] != null && !style.equals(current[0])) {
                result.method_10852(class_2561.method_43470(run.toString()).method_27696(current[0]));
                run.setLength(0);
            }

            current[0] = style;
            run.appendCodePoint(codePoint);

            return true;
        });

        if (run.length() > 0 && current[0] != null) {
            result.method_10852(class_2561.method_43470(run.toString()).method_27696(current[0]));
        }

        return result;
    }

    public static class_2561 getRatingText(TooltipContext context) {
        // Computes the default color per rarity
        // Defaults to a simulated legendary rarity with gold color
        // Can't use enum checking here as it would crash on certain rarity enum injections
        class_124 color = class_124.field_1065;
        final class_1814 rarity = context.getStack().method_7932();
        if (rarity == class_1814.field_8906) {
            color = class_124.field_1080;
        }
        else if (rarity == class_1814.field_8907) {
            color = class_124.field_1054;
        }
        else if (rarity == class_1814.field_8903) {
            color = class_124.field_1078;
        }
        else if (rarity == class_1814.field_8904) {
            color = class_124.field_1064;
        }

        final CustomFrameData data = context.getFrameData();
        // If the curent stack is declared in a custom frame format
        if (data != null) {
            // If the stack has a custom rating
            if (data.hasCustomItemRating()) {

                // Computes the rating, either as a translatable key or a literal component
                final String raw = data.getItemRating(context.getStack());
                final class_5250 base = raw.startsWith("key.tooltipoverhaul") ? class_2561.method_43471(raw) : class_2561.method_43470(raw);

                if (data.hasCustomColorItemRating()) {
                    return base.method_27696(class_2583.field_24360.method_36139(data.getItemRatingColor(context)));
                }
                // If the frame doesn't provide a color, uses rarity color by default
                else {
                    return base.method_27692(color);
                }

            }

        }

        return getDefaultRarity(context.getStack()).method_27661().method_27692(color);
    }

    private static class_2561 getDefaultRarity(class_1799 stack) {
        final class_1814 rarity = stack.method_7932();
        final String string = rarity.toString();
        if (rarity == class_1814.field_8906 || rarity == class_1814.field_8907 || rarity == class_1814.field_8903 || rarity == class_1814.field_8904) {
            return class_2561.method_43471("tooltipoverhaul." + string.trim().toLowerCase() + "_rarity");
        }

        if (string.contains("alexscaves")) {
            return class_2561.method_43471("rarity.alexscaves." + string.split(":")[1] + ".name");
        }

        return class_2561.method_43471(rarity.name().trim().toLowerCase());
    }

}
