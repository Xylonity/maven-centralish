package dev.xylonity.tooltipoverhaul.client.screen.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.TooltipOverhaul;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameData;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameLoader;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameManager;
import dev.xylonity.tooltipoverhaul.client.render.TooltipAnimationState;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.render.TooltipRenderer;
import dev.xylonity.tooltipoverhaul.client.style.animation.TooltipAnimator;
import dev.xylonity.tooltipoverhaul.client.util.PositionUtils;
import dev.xylonity.tooltipoverhaul.client.util.RenderUtils;
import dev.xylonity.tooltipoverhaul.client.util.TextAxis;
import dev.xylonity.tooltipoverhaul.client.util.TextUtils;
import dev.xylonity.tooltipoverhaul.client.util.TooltipScrollState;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1074;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5481;
import net.minecraft.class_5684;
import net.minecraft.class_7923;
import net.minecraft.class_8001;

import static dev.xylonity.tooltipoverhaul.client.screen.config.ConfigScreenStyle.drawCard;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.dimAccent;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.mixRgb;
import static dev.xylonity.tooltipoverhaul.client.util.ColorUtils.withAlpha;

final class FramePreviewPanel {

    private static final PreviewBounds PLACEHOLDER_BOUNDS = new PreviewBounds(150, 46, 0);
    private static final int STRIP_CAP = 12;

    private final int accent;
    private final List<class_1799> stacks = new ArrayList<>();
    private final List<PreviewBounds> sizes = new ArrayList<>();
    private final Set<class_1792> brokenItems = new HashSet<>();
    private final List<String> unresolvedIds = new ArrayList<>();

    private @Nullable CustomFrameData data;
    private boolean hasEntry;
    private boolean broken;
    private int totalItems;
    private float contentWidth;
    private float contentHeight;
    private double panX;
    private double panY;
    private double zoom = 1;
    private int selectedItem;
    private boolean comparison;
    private float fittedScale = 1;
    private boolean panning;
    private long iconAnimationAt = class_156.method_658();
    private long tooltipAnimationAt = iconAnimationAt;
    private boolean tooltipAnimationOut;

    private int x;
    private int y;
    private int width;
    private int height;

    FramePreviewPanel(int accent) {
        this.accent = accent;
    }

    String refresh(JsonObject root, @Nullable JsonObject entry) {
        final int previousIndex = selectedItem;
        final class_1792 previousItem = stacks.isEmpty() ? null : stacks.get(Math.min(selectedItem, stacks.size() - 1)).method_7909();
        hasEntry = entry != null;
        broken = false;
        data = null;
        stacks.clear();
        sizes.clear();
        if (entry == null) {
            return "";
        }

        String error = "";
        try {
            data = CustomFrameLoader.parseFrame(root, entry);
        }
        catch (Exception exception) {
            broken = true;
            error = exception.getMessage() == null ? exception.toString() : exception.getMessage();
        }

        resolveStacks(entry);
        selectedItem = 0;
        if (previousItem != null) {
            if (previousIndex < stacks.size() && stacks.get(previousIndex).method_31574(previousItem)) {
                selectedItem = previousIndex;
            }
            else for (int i = 0; i < stacks.size(); i++) {
                if (stacks.get(i).method_31574(previousItem)) { selectedItem = i; break; }
            }

        }

        for (int i = 0; i < stacks.size(); i++) {
            sizes.add(null);
        }

        return error;
    }

    void resetViewAndAnimations() {
        panX = 0;
        panY = 0;
        zoom = 1;
        panning = false;
        iconAnimationAt = class_156.method_658();
        tooltipAnimationAt = iconAnimationAt;
    }

    void replayIconAnimation() {
        iconAnimationAt = class_156.method_658();
    }

    void replayTooltipAnimation() {
        tooltipAnimationAt = class_156.method_658();
        tooltipAnimationOut = false;
    }

    void replayTooltipDisappearAnimation() {
        tooltipAnimationAt = class_156.method_658();
        tooltipAnimationOut = true;
    }

    class_1799 stackFor(JsonObject entry) {
        if (entry.has("items") && entry.get("items").isJsonArray()) {
            for (JsonElement element : entry.getAsJsonArray("items")) {
                if (!element.isJsonPrimitive()) {
                    continue;
                }

                class_2960 id = class_2960.method_12829(element.getAsString().trim());
                if (id != null && class_7923.field_41178.method_10250(id)) {
                    return new class_1799(class_7923.field_41178.method_10223(id));
                }

            }

        }

        return new class_1799(class_1802.field_8802);
    }

    class_1799 selectedStack() {
        return stacks.isEmpty() ? new class_1799(class_1802.field_8802) : stacks.get(selectedItem).method_7972();
    }

    void selectStack(class_1799 stack) {
        for (int i = 0; i < stacks.size(); i++) {
            if (stacks.get(i).method_31574(stack.method_7909())) {
                selectItem(i);
                return;
            }

        }

    }

    void renderListIcon(class_332 graphics, JsonObject entry, int x, int y, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1f, 1f, 1f, class_3532.method_15363(alpha, 0f, 1f));
        try {
            renderItemSafe(graphics, stackFor(entry), x, y);
        }
        finally {
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        }

    }

    void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        clampPan();
    }

    void render(class_332 graphics, class_327 font, int screenWidth, int screenHeight, int mouseX, int mouseY, String validationError) {
        final int right = x + width, bottom = y + height;
        drawCard(graphics, x, y, right, bottom, 0xE60D0D0F, 0xFF232327);
        graphics.method_51433(font, font.method_27523(class_1074.method_4662(key("preview")), Math.max(0, width - 78)), x + 8, y + 9, 0xFF9898A2, false);
        renderViewButtons(graphics, mouseX, mouseY);
        if (!hasEntry) {
            return;
        }

        if (broken || !validationError.isEmpty()) {
            int errorY = y + 34;
            for (class_5481 line : font.method_1728(class_2561.method_43470(class_1074.method_4662(key("preview_error")) + ": " + validationError), Math.max(20, width - 20))) {
                if (errorY + font.field_2000 > bottom - 8) {
                    break;
                }

                graphics.method_51430(font, line, x + 10, errorY, 0xFFFF9999, false);
                errorY += font.field_2000 + 2;
            }

            return;
        }

        if (stacks.isEmpty()) {
            return;
        }

        final int first = comparison ? selectedItem / 4 * 4 : selectedItem;
        final int end = comparison ? Math.min(stacks.size(), first + 4) : first + 1;
        final int virtualWidth = screenWidth + 4096, virtualHeight = screenHeight + 4096;
        final float previousCounter = TooltipRenderer.COUNTER;
        final float previousIconCounter = TooltipRenderer.ICON_COUNTER;
        final TooltipScrollState.Snapshot previousScroll = TooltipScrollState.snapshot();

        TooltipRenderer.COUNTER = (class_156.method_658() - iconAnimationAt) / 1000f;
        TooltipRenderer.ICON_COUNTER = TooltipRenderer.COUNTER;

        graphics.method_44379(x + 1, stageTop(), right - 1, stageBottom());
        try {
            CustomFrameManager.setPreviewOverride(data);
            TooltipAnimationState.setSuppressCapture(true);
            final List<FramePreviewLayout.Size> dimensions = new ArrayList<>();
            for (int i = first; i < end; i++) {
                if (sizes.get(i) == null) {
                    measureSlot(graphics, font, screenWidth, i, virtualWidth, virtualHeight);
                }

                final PreviewBounds measured = sizes.get(i);
                dimensions.add(new FramePreviewLayout.Size(measured.width(), measured.height()));
            }

            final FramePreviewLayout.Layout layout = FramePreviewLayout.arrange(dimensions, width, stageBottom() - stageTop(), comparison, zoom);
            contentWidth = layout.width();
            contentHeight = layout.height();
            fittedScale = layout.scale();

            clampPan();

            for (int i = first; i < end; i++) {
                final FramePreviewLayout.Slot slot = layout.slots().get(i - first);
                final float slotX = x + slot.x() + (float) panX;
                final float slotY = stageTop() + slot.y() + (float) panY;
                renderSlot(graphics, font, screenWidth, virtualWidth, virtualHeight, i, slotX, slotY, layout.scale());
            }

        }
        finally {
            CustomFrameManager.setPreviewOverride(null);
            TooltipAnimationState.setSuppressCapture(false);
            TooltipRenderer.COUNTER = previousCounter;
            TooltipRenderer.ICON_COUNTER = previousIconCounter;
            TooltipScrollState.restore(previousScroll);

            graphics.method_44380();
        }

        renderItemStrip(graphics, font, mouseX, mouseY);
        renderInfo(graphics, font, screenWidth, bottom, mouseX, mouseY);

        final String zoomLabel = Math.round(fittedScale * 100) + "%";
        graphics.method_51433(font, zoomLabel, right - 8 - font.method_1727(zoomLabel), bottom - 11, 0xFF777782, false);

        final String hint = class_1074.method_4662(key("preview_controls"));
        if (font.method_1727(hint) < width - 72) {
            graphics.method_25300(font, hint, x + width / 2, bottom - 11, 0xFF666671);
        }

        int control = headerControl(mouseX, mouseY);
        if (control >= 0) graphics.method_51438(font, class_2561.method_43471(key(control == 0 ? "preview_focus" : control == 1 ? "preview_compare" : "preview_fit")), mouseX, mouseY);
    }

    private void renderSlot(class_332 graphics, class_327 font, int screenWidth, int virtualWidth, int virtualHeight, int index, float slotX, float slotY, float scale) {
        class_1799 stack = stacks.get(index);
        if (brokenItems.contains(stack.method_7909())) {
            renderBrokenSlot(graphics, font, stack, slotX, slotY, scale);
            return;
        }

        final float targetX = slotX + sizes.get(index).insetLeft() * scale;
        final float targetY = slotY;
        try {
            List<class_5684> components = TextUtils.getTooltipComponentsFrom(stack, font, screenWidth, 2.2f);
            TooltipContext context = new TooltipContext(graphics, font, components, 100, 100, virtualWidth, virtualHeight, class_8001.field_41687, stack, true);
            final TooltipRenderer renderer = new TooltipRenderer(context);

            renderer.init();

            sizes.set(index, measuredBounds(context));

            final float offsetX = PositionUtils.getMainPanelPosition(context, TextAxis.X);
            final float offsetY = PositionUtils.getMainPanelPosition(context, TextAxis.Y);
            final class_241 actual = context.getTooltipPosition();

            graphics.method_51448().method_22903();

            graphics.method_51448().method_46416(targetX + scale * (offsetX - actual.field_1343), targetY + scale * (offsetY - actual.field_1342), 0);
            graphics.method_51448().method_22905(scale, scale, 1f);

            try {
                if (renderer.canRender()) {
                    float progress = (class_156.method_658() - tooltipAnimationAt) / 1000f / TooltipAnimator.duration(context);
                    if (tooltipAnimationOut) {
                        if (progress < 1) {
                            TooltipAnimator.render(context, true, progress);
                        }
                        else if (progress >= 1.5f) {
                            tooltipAnimationOut = false;
                            tooltipAnimationAt = class_156.method_658();
                        }

                    }
                    else {
                        TooltipAnimator.render(context, false, progress);
                    }

                }

            }
            finally {
                graphics.method_51448().method_22909();
            }

        }
        catch (Throwable throwable) {
            flagBroken(stack, throwable);
            sizes.set(index, PLACEHOLDER_BOUNDS);
        }

    }

    private int stageTop() {
        return y + 28;
    }

    private int stageBottom() {
        return Math.max(stageTop() + 1, y + height - 58);
    }

    private int stripY() {
        return y + height - 39;
    }

    private int stripCapacity() {
        return Math.max(1, Math.min(STRIP_CAP, (width - 52) / 24));
    }

    private int stripStart() {
        return selectedItem / stripCapacity() * stripCapacity();
    }

    private int stripCount() {
        return Math.min(stripCapacity(), stacks.size() - stripStart());
    }

    private int stripLeft() {
        return x + (width - stripCount() * 24) / 2;
    }

    private int headerButtonX(int control) {
        return x + width - 64 + control * 20;
    }

    private int headerControl(double mouseX, double mouseY) {
        if (mouseY < y + 5 || mouseY >= y + 23) {
            return -1;
        }

        for (int i = 0; i < 3; i++) if (mouseX >= headerButtonX(i) && mouseX < headerButtonX(i) + 18) return i;
        return -1;
    }

    private void renderViewButtons(class_332 graphics, int mouseX, int mouseY) {
        int hovered = headerControl(mouseX, mouseY);
        for (int i = 0; i < 3; i++) {
            int bx = headerButtonX(i), by = y + 5;
            final boolean active = i == (comparison ? 1 : 0);
            drawCard(graphics, bx, by, bx + 18, by + 18, active ? 0xFF202630 : hovered == i ? 0xFF222227 : 0xFF141416, active ? withAlpha(accent, 0xAA) : 0xFF303038);
            final int color = active || hovered == i ? accent : 0xFF92929E;
            if (i == 0) {
                drawCard(graphics, bx + 4, by + 5, bx + 14, by + 13, 0, color);
            }
            else if (i == 1) {
                for (int row = 0; row < 2; row++) for (int col = 0; col < 2; col++)
                    graphics.method_25294(bx + 4 + col * 6, by + 4 + row * 6, bx + 8 + col * 6, by + 8 + row * 6, color);
            }
            else {
                ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.EXPAND, bx + 4, by + 4, color);
            }

        }

    }

    private void renderItemStrip(class_332 graphics, class_327 font, int mouseX, int mouseY) {
        final int bottom = y + height;
        graphics.method_25294(x + 8, bottom - 57, x + width - 8, bottom - 56, 0xFF222229);

        final String counter = (selectedItem + 1) + " / " + stacks.size();

        graphics.method_51433(font, counter, x + width - 8 - font.method_1727(counter), bottom - 51, 0xFF747481, false);
        graphics.method_51433(font, font.method_27523(stacks.get(selectedItem).method_7964().getString(), Math.max(1, width - 26 - font.method_1727(counter))), x + 8, bottom - 51, 0xFFBCBCC6, false);
        graphics.method_25300(font, "<", x + 13, stripY() + 7, selectedItem > 0 ? 0xFFA0A0AB : 0xFF41414A);
        graphics.method_25300(font, ">", x + width - 13, stripY() + 7, selectedItem + 1 < stacks.size() ? 0xFFA0A0AB : 0xFF41414A);

        int hovered = -1;
        for (int i = 0; i < stripCount(); i++) {
            int index = stripStart() + i, bx = stripLeft() + i * 24, by = stripY();
            final boolean selected = index == selectedItem;
            final boolean over = mouseX >= bx && mouseX < bx + 22 && mouseY >= by && mouseY < by + 22;
            drawCard(graphics, bx, by, bx + 22, by + 22, selected ? 0xFF202833 : over ? 0xFF25252C : 0xFF151519, selected ? withAlpha(accent, 0xCC) : 0xFF303038);
            renderItemSafe(graphics, stacks.get(index), bx + 3, by + 3);
            if (over) {
                hovered = index;
            }

        }

        if (hovered >= 0) {
            graphics.method_51438(font, stacks.get(hovered).method_7964(), mouseX, mouseY);
        }

    }

    private static String key(String suffix) {
        return "tooltipoverhaul.config.frames." + suffix;
    }

    private void resolveStacks(JsonObject entry) {
        totalItems = 0;
        unresolvedIds.clear();
        if (entry.has("items") && entry.get("items").isJsonArray()) {
            for (JsonElement element : entry.getAsJsonArray("items")) {
                if (!element.isJsonPrimitive()) {
                    continue;
                }

                final String raw = element.getAsString().trim();
                if (raw.isEmpty()) {
                    continue;
                }

                class_2960 id = class_2960.method_12829(raw);
                if (id == null || !class_7923.field_41178.method_10250(id)) {
                    unresolvedIds.add(raw);
                    continue;
                }

                totalItems++;
                stacks.add(new class_1799(class_7923.field_41178.method_10223(id)));
            }

        }

        if (stacks.isEmpty()) {
            stacks.add(new class_1799(class_1802.field_8802));
        }

    }

    private void flagBroken(class_1799 stack, Throwable throwable) {
        if (brokenItems.add(stack.method_7909())) {
            TooltipOverhaul.LOGGER.warn("Frame editor cannot preview {} on this screen: {}", class_7923.field_41178.method_10221(stack.method_7909()), throwable.toString());
        }

    }

    private void renderItemSafe(class_332 graphics, class_1799 stack, int x, int y) {
        if (brokenItems.contains(stack.method_7909())) {
            graphics.method_51427(new class_1799(class_1802.field_8407), x, y);
            return;
        }

        try {
            graphics.method_51427(stack, x, y);
        }
        catch (Throwable throwable) {
            flagBroken(stack, throwable);
        }

    }

    private void renderInfo(class_332 graphics, class_327 font, int screenWidth, int bottom, int mouseX, int mouseY) {
        final int hidden = totalItems - stacks.size();
        final boolean unknown = !unresolvedIds.isEmpty();
        if (hidden <= 0 && !unknown) {
            return;
        }

        final int badgeX = x + 8;
        final int badgeY = bottom - 18;
        boolean hovered = mouseX >= badgeX && mouseX < badgeX + 11 && mouseY >= badgeY + 1 && mouseY < badgeY + 12;
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(0, 0, 500);

        ConfigIconButton.drawIcon(graphics, ConfigIconButton.Icon.QUESTION, badgeX + 1, badgeY + 2, unknown ? 0xFFCC8040 : hovered ? accent : 0xFFB0B0B0);

        if (hovered) {
            final List<class_5481> lines = new ArrayList<>();
            final int maxWidth = Math.min(240, width - 24);
            if (hidden > 0) {
                lines.addAll(font.method_1728(class_2561.method_43469(
                        "tooltipoverhaul.config.frames.preview_more", hidden), maxWidth));
            }
            if (unknown) {
                lines.addAll(font.method_1728(class_2561.method_43469(
                        "tooltipoverhaul.config.frames.preview_unknown", String.join(", ", unresolvedIds)), maxWidth));
            }

            int textWidth = 0;
            for (class_5481 line : lines) {
                textWidth = Math.max(textWidth, font.method_30880(line));
            }

            final int boxWidth = textWidth + 12;
            final int boxHeight = lines.size() * (font.field_2000 + 1) - 1 + 10;
            final int popupX = Math.min(badgeX, screenWidth - 4 - boxWidth);
            final int popupY = badgeY - boxHeight - 4;

            drawCard(graphics, popupX, popupY, popupX + boxWidth, popupY + boxHeight, 0xF2121214, withAlpha(mixRgb(0x2E2E32, dimAccent(accent), 0.4f), 0xFF));

            int lineY = popupY + 6;
            for (class_5481 line : lines) {
                graphics.method_51430(font, line, popupX + 6, lineY, 0xFFDDDDDD, false);
                lineY += font.field_2000 + 1;
            }

        }

        graphics.method_51448().method_22909();
    }

    private void measureSlot(class_332 graphics, class_327 font, int screenWidth, int index, int virtualWidth, int virtualHeight) {
        final class_1799 stack = stacks.get(index);
        if (brokenItems.contains(stack.method_7909())) {
            sizes.set(index, PLACEHOLDER_BOUNDS);
            return;
        }

        try {
            final List<class_5684> components = TextUtils.getTooltipComponentsFrom(stack, font, screenWidth, 2.2f);
            TooltipContext context = new TooltipContext(graphics, font, components, 100, 100, virtualWidth, virtualHeight, class_8001.field_41687, stack, true);
            new TooltipRenderer(context).init();
            sizes.set(index, measuredBounds(context));
        }
        catch (Throwable throwable) {
            flagBroken(stack, throwable);
            sizes.set(index, PLACEHOLDER_BOUNDS);
        }

    }

    private static PreviewBounds measuredBounds(TooltipContext context) {
        final class_241 size = context.getTooltipSize();
        float inset = 0;
        float panelHeight = 0;
        if (RenderUtils.hasPreviewOfStack(context) || RenderUtils.hasPreviewOfArmorItem(context)) {
            inset = RenderUtils.calculateSecondPanelSize(context, TextAxis.X) + 30;
            panelHeight = RenderUtils.calculateSecondPanelSize(context, TextAxis.Y) + 4;
        }

        return new PreviewBounds(size.field_1343 + inset, Math.max(size.field_1342, panelHeight), inset);
    }

    private void renderBrokenSlot(class_332 graphics, class_327 font, class_1799 stack, float slotX, float slotY, float scale) {
        graphics.method_51448().method_22903();

        graphics.method_51448().method_46416(slotX, slotY, 0);
        graphics.method_51448().method_22905(scale, scale, 1f);

        final int cardWidth = (int) PLACEHOLDER_BOUNDS.width();
        drawCard(graphics, 0, 0, cardWidth, (int) PLACEHOLDER_BOUNDS.height(), 0xE6151517, 0xFF2E2E32);

        final String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        graphics.method_51433(font, font.method_27523(id, cardWidth - 16), 8, 11, 0xFFB0B0B0, false);

        final String reason = class_1074.method_4662("tooltipoverhaul.config.frames.preview_unrenderable");
        graphics.method_51433(font, font.method_27523(reason, cardWidth - 16), 8, 27, 0xFF8A5A45, false);

        graphics.method_51448().method_22909();
    }

    boolean contains(double mouseX, double mouseY) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!contains(mouseX, mouseY)) {
            return false;
        }

        if (button == 1) {
            resetViewAndAnimations();
            return true;
        }

        if (button == 0) {
            final int control = headerControl(mouseX, mouseY);
            if (control >= 0) {
                if (control < 2) {
                    comparison = control == 1;
                }

                resetViewAndAnimations();
                return true;
            }

            if (!stacks.isEmpty() && mouseY >= stripY() && mouseY < stripY() + 22) {
                if (mouseX < x + 24) {
                    selectItem(selectedItem - 1);
                }
                else if (mouseX >= x + width - 24) {
                    selectItem(selectedItem + 1);
                }
                else {
                    final int index = (int) ((mouseX - stripLeft()) / 24);
                    if (mouseX >= stripLeft() && index >= 0 && index < stripCount()) {
                        selectItem(stripStart() + index);
                    }

                }

                return true;
            }

        }

        if (button == 0 && mouseY >= stageTop() && mouseY < stageBottom()) {
            panning = true;
            return true;
        }

        return true;
    }

    boolean mouseDragged(double deltaX, double deltaY) {
        if (!panning) {
            return false;
        }

        panX += deltaX;
        panY += deltaY;
        clampPan();

        return true;
    }

    void mouseReleased() {
        panning = false;
    }

    boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (!contains(mouseX, mouseY)) {
            return false;
        }

        if (delta == 0) {
            return true;
        }

        if (mouseY >= stripY() && mouseY < stripY() + 22 && !stacks.isEmpty()) {
            selectItem(selectedItem + (delta > 0 ? -1 : 1));
            return true;
        }

        if (mouseY < stageTop() || mouseY >= stageBottom()) {
            return true;
        }

        final double nextZoom = class_3532.method_15350(zoom * (delta > 0 ? 1.15 : 1 / 1.15), 0.4, 2.0);
        if (nextZoom != zoom) {
            panX *= nextZoom / zoom;
            panY *= nextZoom / zoom;
            zoom = nextZoom;
            clampPan();
        }

        return true;
    }

    boolean isPanning() {
        return panning;
    }

    private void selectItem(int index) {
        final int next = class_3532.method_15340(index, 0, stacks.size() - 1);
        if (next == selectedItem) {
            return;
        }

        selectedItem = next;
        resetViewAndAnimations();
    }

    void clampPan() {
        final double limitX = Math.max(0, (contentWidth - width) / 2.0 + 24);
        final double limitY = Math.max(0, (contentHeight - (stageBottom() - stageTop())) / 2.0 + 24);
        panX = class_3532.method_15350(panX, -limitX, limitX);
        panY = class_3532.method_15350(panY, -limitY, limitY);
    }

    void close() {
        CustomFrameManager.setPreviewOverride(null);
        TooltipAnimationState.clear();
    }

    private record PreviewBounds(
            float width,
            float height,
            float insetLeft
    ) {
        ;;
    }

}