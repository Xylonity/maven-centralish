package dev.xylonity.tooltipoverhaul.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.tooltipoverhaul.client.frame.CustomFrameData;
import dev.xylonity.tooltipoverhaul.client.render.FadeRenderType;
import dev.xylonity.tooltipoverhaul.client.render.TooltipContext;
import dev.xylonity.tooltipoverhaul.client.style.preview.PreviewPanelDecorations;
import dev.xylonity.tooltipoverhaul.config.TooltipsConfig;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Optional;
import net.minecraft.class_1087;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_1309;
import net.minecraft.class_148;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1937;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4059;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;

public class RenderUtils {

    public static String getTooltipLayout(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getTooltipLayout).orElse(TooltipsConfig.TOOLTIP_LAYOUT);
    }

    public static boolean shouldShowCompactModName(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldShowCompactModName).orElse(TooltipsConfig.COMPACT_SHOW_MOD_NAME);
    }

    public static boolean hasIcon(TooltipContext context) {
        return !context.getStack().method_7960() && !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableIcon).orElse(TooltipsConfig.DISABLE_ICON);
    }

    public static boolean hasRating(TooltipContext context) {
        return !context.getStack().method_7960() && Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldShowRating).orElse(TooltipsConfig.SHOW_RATING);
    }

    public static boolean hasDividerLine(TooltipContext context) {
        return !context.getStack().method_7960() && !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableDividerLine).orElse(TooltipsConfig.DISABLE_DIVIDER_LINE);
    }

    public static boolean hasShadow(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldShowShadow).orElse(TooltipsConfig.SHOW_TOOLTIP_SHADOW);
    }

    public static float getIconScale(TooltipContext context) {
        final float scale = Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconSize).orElse(1f);
        return Float.isFinite(scale) ? Math.max(0.5f, Math.min(2f, scale)) : 1f;
    }

    public static boolean effectsBehindText(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldRenderEffectsBehindText).orElse(TooltipsConfig.EFFECTS_BEHIND_TEXT);
    }

    public static boolean hasVignette(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::hasVignette).orElse(!TooltipsConfig.VIGNETTES.isBlank());
    }

    public static boolean shouldRender(TooltipContext context) {
        return !Optional.ofNullable(context.getFrameData()).map(CustomFrameData::shouldDisableTooltip).orElse(false);
    }

    public static boolean hasPreviewOfStack(TooltipContext context) {
        if (context.isPinned()) {
            return false;
        }

        if (isComparisonActive(context)) {
            return false;
        }

        if (!context.getStack().method_7960() && !(context.getStack().method_7909() instanceof class_1738)) {
            return Optional.ofNullable(context.getFrameData()).map(data -> data.shouldShowSecondPanel(context)).orElse(context.getStack().method_7909() instanceof class_1831 && TooltipsConfig.TIERED_ITEMS_RENDERER);
        }

        return false;
    }

    public static boolean hasPreviewOfArmorItem(TooltipContext context) {
        if (context.isPinned()) {
            return false;
        }

        if (isComparisonActive(context)) {
            return false;
        }

        if (context.getStack().method_7909() instanceof class_1738 && !(context.getStack().method_7909() instanceof class_4059)) {
            return Optional.ofNullable(context.getFrameData()).map(data -> data.shouldShowSecondPanel(context)).orElse(TooltipsConfig.ARMOR_ITEMS_RENDERER);
        }

        return false;
    }

    private static boolean isComparisonActive(TooltipContext context) {
        return EquippedContextCalculator.isComparisonRequested() && context.getOtherTooltipContext() != null;
    }

    public static int calculateSecondPanelSize(TooltipContext context, TextAxis axis) {
        if (axis == TextAxis.X) {
            return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getSecondPanelSizeX).orElse(TooltipsConfig.SECOND_PANEL_SIZE_X);
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getSecondPanelSizeY).orElse(TooltipsConfig.SECOND_PANEL_SIZE_Y);
    }

    public static String getIconAppearAnimation(TooltipContext context) {
        if (TooltipsConfig.REDUCED_MOTION || context.isPinned()) {
            return "none";
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconAppearAnimation).orElse(TooltipsConfig.ICON_APPEAR_ANIMATION);
    }

    public static float getIconRotatingSpeed(TooltipContext context) {
        if (TooltipsConfig.REDUCED_MOTION) {
            return 0;
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconRotatingSpeed).orElse(TooltipsConfig.ICON_ROTATING_SPEED);
    }

    public static String getIconBackgroundType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getIconBackground).orElse(TooltipsConfig.ICON_BACKGROUND_TYPE);
    }

    public static String getDividerLineType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getDividerLineType).orElse(TooltipsConfig.DIVIDER_LINE_TYPE);
    }

    public static String getEffect(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getEffect).orElse(TooltipsConfig.EFFECTS);
    }

    public static boolean usePlayerSkinInPreview(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getUsePlayerSkinInPreview).orElse(TooltipsConfig.USE_PLAYER_SKIN_IN_PREVIEW);
    }

    public static String getPreviewPanelModel(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getPreviewPanelModel).orElse(TooltipsConfig.PREVIEW_PANEL_MODEL);
    }

    public static boolean hasPreviewPanelSideTriangles(TooltipContext context) {
        return getPreviewPanelSideTriangles(context) != PreviewPanelDecorations.SideTriangles.NONE;
    }

    public static PreviewPanelDecorations.SideTriangles getPreviewPanelSideTriangles(TooltipContext context) {
        return PreviewPanelDecorations.SideTriangles.fromString(
                Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getPreviewPanelSideTriangles).orElse(TooltipsConfig.PREVIEW_PANEL_SIDE_TRIANGLES));
    }

    public static String getPreviewPanelCornerType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getPreviewPanelCornerType).orElse(TooltipsConfig.PREVIEW_PANEL_CORNER_TYPE);
    }

    public static PreviewPanelDecorations.BackgroundCornerType getPreviewPanelBackgroundCornerType(TooltipContext context) {
        return PreviewPanelDecorations.BackgroundCornerType.fromString(
                Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getPreviewPanelBackgroundCornerType).orElse(TooltipsConfig.PREVIEW_PANEL_BACKGROUND_CORNER_TYPE));
    }

    public static int calculatePadding(TooltipContext context, TextAxis axis) {
        if (context.getStack().method_7960()) {
            if (axis == TextAxis.X) {
                return TooltipsConfig.NO_STACK_TOOLTIP_PADDING_X;
            }

            return TooltipsConfig.NO_STACK_TOOLTIP_PADDING_Y;
        }

        if (axis == TextAxis.X) {
            return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getMainPanelPaddingX).orElse(TooltipsConfig.MAIN_PANEL_PADDING_X);
        }

        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getMainPanelPaddingY).orElse(TooltipsConfig.MAIN_PANEL_PADDING_Y);
    }

    public static String getInnerOverlayType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getBorderType).orElse(TooltipsConfig.DEFAULT_INNER_OVERLAY_TYPE);
    }

    public static String getInnerFrameCornerType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getInnerFrameCornerType).orElse(TooltipsConfig.INNER_FRAME_CORNER_TYPE);
    }

    public static String getBackgroundCornerType(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getBackgroundCornerType).orElse(TooltipsConfig.BACKGROUND_CORNER_TYPE);
    }

    public static int cornerTrim(String type) {
        return switch (type) {
            case "rounded", "bevel" -> 1;
            case "cut", "notch" -> 2;
            default -> 0;
        };

    }

    public static void applyFrameCorners(class_332 graphics, int x0, int y0, int width, int height, int topColor, int bottomColor, String type) {
        final int[][] add;
        // Which corners the style is applied to, as indices into the corners array below, in order top left, top right, bottom left and bottom right
        int[] cornersToApply = {0, 1, 2, 3};

        switch (type) {
            case "rounded" -> {
                add = new int[][]{};
            }
            case "bevel" -> {
                add = new int[][]{{1, 1}};
            }
            case "inner" -> {
                add = new int[][]{{1, 1}};
            }
            case "cut" -> {
                add = new int[][]{{1, 1}};
            }
            case "thick" -> {
                add = new int[][]{{1, 1}, {2, 1}, {3, 1}, {1, 2}, {2, 2}, {1, 3}};
                cornersToApply = new int[]{1};
            }
            case "bracket" -> {
                add = new int[][]{{2, 2}, {3, 2}, {2, 3}};
            }
            case "block" -> {
                add = new int[][]{{1, 1}, {2, 1}, {1, 2}, {2, 2}};
            }
            case "notch" -> {
                add = new int[][]{{2, 1}, {1, 2}, {2, 2}};
            }
            case "weld" -> {
                add = new int[][]{{1, 1}, {2, 1}, {1, 2}};
            }
            case "gem" -> {
                add = new int[][]{{2, 1}, {4, 1}, {1, 2}, {3, 2}, {2, 3}, {1, 4}};
            }
            default -> {
                return;
            }

        }

        final int xr = x0 + width - 1;
        final int yb = y0 + height - 1;

        // (cornerX, cornerY, inward X step, inward Y step) for each of the four corners
        int[][] corners = {
                {x0, y0, 1, 1},
                {xr, y0, -1, 1},
                {x0, yb, 1, -1},
                {xr, yb, -1, -1}
        };

        for (final int idx : cornersToApply) {
            final int[] corner = corners[idx];
            final int cornerX = corner[0];
            final int cornerY = corner[1];
            final int stepX = corner[2];
            final int stepY = corner[3];
            final int color = cornerY == y0 ? topColor : bottomColor;

            for (final int[] pixel : add) {
                fillPixel(graphics, cornerX + pixel[0] * stepX, cornerY + pixel[1] * stepY, color);
            }

        }

    }

    private static void fillPixel(class_332 graphics, int x, int y, int color) {
        graphics.method_25294(x, y, x + 1, y + 1, color);
    }

    public static String getOverlayLocation(TooltipContext context) {
        return Optional.ofNullable(context.getFrameData()).map(CustomFrameData::getTextureLocation).orElse(TooltipsConfig.GLOBAL_FRAME_OVERLAY_LOCATION);
    }

    public static void renderItem(TooltipContext context, @Nullable class_1309 entity, @Nullable class_1937 level, class_1799 stack, int seed) {
        if (!stack.method_7960()) {
            final class_1087 bakedmodel = class_310.method_1551().method_1480().method_4019(stack, level, entity, seed);
            context.getPose().method_22903();

            try {
                context.getPose().method_22905(16.0F, -16.0F, 16.0F);
                final boolean flag = !bakedmodel.method_24304();
                if (flag) {
                    class_308.method_24210();
                }

                // Cutout/solid item render types don't blend, so the fade of the in/out animation (applied
                // through the shader color alpha) has no visible effect on them
                class_4597 bufferSource = context.getBuffer();
                if (RenderSystem.getShaderColor()[3] < 1.0f) {
                    final class_4597 delegate = bufferSource;
                    bufferSource = type -> delegate.getBuffer(FadeRenderType.remap(type));
                }

                class_310.method_1551().method_1480().method_23179(stack, class_811.field_4317, false, context.getPose(), bufferSource, class_765.field_32767, class_4608.field_21444, bakedmodel);
                context.flush();
                if (flag) {
                    class_308.method_24211();
                }

            }
            catch (Throwable throwable) {
                final class_128 crashreport = class_128.method_560(throwable, "Rendering item");
                final class_129 crashreportcategory = crashreport.method_562("Item being rendered");
                crashreportcategory.method_577("Item Type", () -> String.valueOf(stack.method_7909()));
                crashreportcategory.method_577("Item Components", () -> String.valueOf(stack.method_57353()));
                crashreportcategory.method_577("Item Foil", () -> String.valueOf(stack.method_7958()));
                throw new class_148(crashreport);
            }

            context.getPose().method_22909();
        }

    }

    public static void renderFrameGradient(class_332 graphics, int x, int y, int width, int height, int c1, int c2, int c3) {
        renderFrameGradient(graphics, x, y, width, height, c1, c2, c3, 0, 0);
    }

    public static void renderFrameGradient(class_332 graphics, int x, int y, int width, int height, int c1, int c2, int c3, int trimTop, int trimBottom) {
        final int mid = height / 2;
        for (int lineX : new int[]{x, x + width - 1}) {
            gradientColumn(graphics, lineX, y, y + mid, c1, c2, trimTop, 0);
            gradientColumn(graphics, lineX, y + mid, y + height, c2, c3, 0, trimBottom);
        }

    }

    private static void gradientColumn(class_332 graphics, int x, int y0, int y1, int c0, int c1, int trimTop, int trimBottom) {
        final int top = y0 + trimTop, bottom = y1 - trimBottom, span = y1 - y0;
        if (bottom <= top || span <= 0) {
            return;
        }

        final int topColor = trimTop == 0 ? c0 : ColorUtils.lerpColor(c0, c1, (float) trimTop / span);
        final int bottomColor = trimBottom == 0 ? c1 : ColorUtils.lerpColor(c0, c1, (float) (span - trimBottom) / span);
        graphics.method_25296(x, top, x + 1, bottom, topColor, bottomColor);
    }

}