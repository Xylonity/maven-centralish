package dev.xylonity.knightlib.api.loot;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.TagLoader;
import net.minecraft.tags.TagManager;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootDataType;
import net.minecraft.world.level.storage.loot.LootPool;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Applies registered entity drops before loot tables are deserialized. Internal. */
public final class EntityLootTableInjector {

    private EntityLootTableInjector() {
    }

    public static void inject(ResourceManager resources, Map<ResourceLocation, JsonElement> tables,
                              List<EntityLootEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        // Registry tags are not bound yet on first load, and still contain the old
        // values during /reload. Resolve this reload's pack stack with the native
        // loader so nested tags, replace, optional entries and loader extensions work.
        TagLoader<EntityType<?>> loader = new TagLoader<>(BuiltInRegistries.ENTITY_TYPE::getOptional,
                TagManager.getTagDir(Registries.ENTITY_TYPE));
        Map<ResourceLocation, Collection<EntityType<?>>> tags = loader.loadAndBuild(resources);

        for (int index = 0; index < entries.size(); index++) {
            EntityLootEntry entry = entries.get(index);
            Set<ResourceLocation> targets = new HashSet<>();
            for (EntityType<?> type : tags.getOrDefault(entry.getEntityTag().location(), List.of())) {
                targets.add(type.getDefaultLootTable());
            }
            targets.remove(BuiltInLootTables.EMPTY);

            JsonObject pool = null;
            for (ResourceLocation target : targets) {
                JsonElement element = tables.get(target);
                if (element == null || !element.isJsonObject()) {
                    continue;
                }

                JsonObject table = element.getAsJsonObject();
                if (table.has("pools") && !table.get("pools").isJsonArray()) {
                    // Leave malformed tables to the normal loot parser's diagnostics.
                    continue;
                }

                if (pool == null) {
                    pool = LootDataType.TABLE.parser().toJsonTree(KnightLibLoot.buildPool(entry).build(),
                            LootPool.class).getAsJsonObject();
                    pool.addProperty("name", "knightlib:entity_drop_" + index);
                }

                if (!table.has("pools")) {
                    table.add("pools", new JsonArray());
                }
                table.getAsJsonArray("pools").add(pool.deepCopy());
            }
        }
    }
}
