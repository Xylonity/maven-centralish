package dev.xylonity.knightlib.mixin;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import dev.xylonity.knightlib.api.loot.EntityLootTableInjector;
import dev.xylonity.knightlib.api.loot.KnightLibLoot;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(SimpleJsonResourceReloadListener.class)
public abstract class LootTableResourcesMixin {

    @Inject(method = "scanDirectory", at = @At("RETURN"))
    private static void knightlib$injectEntityDrops(ResourceManager resources, String directory, Gson gson,
                                                   Map<ResourceLocation, JsonElement> elements, CallbackInfo ci) {
        if (directory.equals("loot_tables")) {
            EntityLootTableInjector.inject(resources, elements, KnightLibLoot.getEntityEntries());
        }
    }
}
