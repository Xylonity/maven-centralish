package dev.xylonity.knightlib.client.shader.post;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

import java.nio.IntBuffer;

/**
 * Captures the currently bound framebuffer and viewport so temporary render target
 * work can restore the exact state it found.
 */
public final class FramebufferState {

    private final int readFramebuffer;
    private final int drawFramebuffer;
    private final int viewportX;
    private final int viewportY;
    private final int viewportWidth;
    private final int viewportHeight;

    private FramebufferState(int readFramebuffer, int drawFramebuffer, IntBuffer viewport) {
        this.readFramebuffer = readFramebuffer;
        this.drawFramebuffer = drawFramebuffer;
        this.viewportX = viewport.get(0);
        this.viewportY = viewport.get(1);
        this.viewportWidth = viewport.get(2);
        this.viewportHeight = viewport.get(3);
    }

    public static FramebufferState capture() {
        final IntBuffer viewport = BufferUtils.createIntBuffer(4);
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);

        return new FramebufferState(
                GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),
                GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),
                viewport
        );
    }

    public void restore() {
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFramebuffer);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFramebuffer);
        RenderSystem.viewport(viewportX, viewportY, viewportWidth, viewportHeight);
    }

}
