package dev.xylonity.knightlib.mixin;

import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface CameraAccessor {

    @Invoker("move")
    void moveAccessor(float dx, float dy, float dz);

}