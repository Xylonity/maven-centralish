package dev.xylonity.knightlib.common.event;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.interop.TickPhase;
import dev.xylonity.knightlib.api.event.impl.server.*;
import dev.xylonity.knightlib.api.loot.EntityLootEntry;
import dev.xylonity.knightlib.api.loot.KnightLibLoot;
import dev.xylonity.knightlib.common.event.impl.EntityAttributeRegistrationEventFabric;
import dev.xylonity.knightlib.common.event.impl.SpawnPlacementRegistrationEventFabric;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;
import net.minecraft.class_55;

public final class KnightLibFabricServerEvents {

    public static void init() {
        ServerTickEvents.START_SERVER_TICK.register(server ->
                KnightLibEvents.SERVER.dispatch(new ServerTickEvent(server, TickPhase.START))
        );

        ServerTickEvents.END_SERVER_TICK.register(server ->
                KnightLibEvents.SERVER.dispatch(new ServerTickEvent(server, TickPhase.END))
        );

        ServerWorldEvents.UNLOAD.register((server, level) ->
                KnightLibEvents.SERVER.dispatch(new ServerWorldUnloadEvent(server, level))
        );

        ServerWorldEvents.LOAD.register((server, level) ->
                KnightLibEvents.SERVER.dispatch(new ServerWorldLoadEvent(server, level))
        );

        EntityAttributeRegistrationEventFabric attributeEvent = new EntityAttributeRegistrationEventFabric();
        KnightLibEvents.SERVER.dispatch(attributeEvent);

        SpawnPlacementRegistrationEventFabric spawnEvent = new SpawnPlacementRegistrationEventFabric();
        KnightLibEvents.SERVER.dispatch(spawnEvent);

        onServerPlayerTickEvents();
        onCommandRegistrationEvents();
        onEntityLevelEvents();
        onPlayerConnectionEvents();
        onLootTableModificationEvent();
        onLivingDeathEvents();
    }

    private static void onLivingDeathEvents() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            final LivingDeathEvent event = new LivingDeathEvent(entity, source);
            KnightLibEvents.SERVER.dispatch(event);

            return !event.isCancelled();
        });

    }

    private static void onServerPlayerTickEvents() {
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                KnightLibEvents.SERVER.dispatch(new ServerPlayerTickEvent(server, player, TickPhase.START));
            }

        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                KnightLibEvents.SERVER.dispatch(new ServerPlayerTickEvent(server, player, TickPhase.END));
            }

        });

    }

    private static void onCommandRegistrationEvents() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            KnightLibEvents.SERVER.dispatch(new CommandRegistrationEvent(dispatcher, registryAccess, environment));
        });

    }

    private static void onEntityLevelEvents() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
            KnightLibEvents.SERVER.dispatch(new ServerEntityJoinLevelEvent(level.method_8503(), level, entity));
        });

        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            KnightLibEvents.SERVER.dispatch(new ServerEntityLeaveLevelEvent(level.method_8503(), level, entity));
        });

    }

    private static void onPlayerConnectionEvents() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            KnightLibEvents.SERVER.dispatch(new ServerPlayerJoinEvent(server, player));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 player = handler.method_32311();
            KnightLibEvents.SERVER.dispatch(new ServerPlayerLeaveEvent(server, player));
        });

    }

    private static void onLootTableModificationEvent() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source) -> {
            final LootTableModifyEvent event = new LootTableModifyEvent(id.method_29177());
            KnightLibEvents.SERVER.dispatch(event);

            for (class_55.class_56 pool : event.getPendingPools()) {
                tableBuilder.method_336(pool);
            }

            if (id.method_29177().method_12832().startsWith("entities/")) {
                for (EntityLootEntry entityLootEntry : KnightLibLoot.getEntityEntries()) {
                    tableBuilder.method_336(KnightLibLoot.buildPool(entityLootEntry));
                }

            }

        });

    }

}