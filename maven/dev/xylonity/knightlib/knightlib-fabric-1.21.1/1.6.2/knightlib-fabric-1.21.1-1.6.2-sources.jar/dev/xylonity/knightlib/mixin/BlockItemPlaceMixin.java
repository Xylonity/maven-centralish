package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.EntityPlaceBlockEvent;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1747.class)
public class BlockItemPlaceMixin {

    @Inject(method = "place", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/BlockItem;placeBlock(Lnet/minecraft/world/item/context/BlockPlaceContext;Lnet/minecraft/world/level/block/state/BlockState;)Z", shift = At.Shift.AFTER))
    private void knightlib$onPlace(class_1750 context, CallbackInfoReturnable<class_1269> cir) {
        final class_1937 level = context.method_8045();
        if (level.field_9236) {
            return;
        }

        final class_2338 clickedPos = context.method_8037();
        final class_2680 placed = level.method_8320(clickedPos);
        final class_1657 player = context.method_8036();

        final EntityPlaceBlockEvent event = new EntityPlaceBlockEvent(level, clickedPos, placed, player);
        KnightLibEvents.SERVER.dispatch(event);

        if (event.isCancelled()) {
            level.method_8650(clickedPos, false);
        }
    }

}