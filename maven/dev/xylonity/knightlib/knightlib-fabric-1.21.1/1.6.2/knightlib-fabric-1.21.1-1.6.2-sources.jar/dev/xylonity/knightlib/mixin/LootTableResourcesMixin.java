package dev.xylonity.knightlib.mixin;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import dev.xylonity.knightlib.api.loot.EntityLootEntry;
import dev.xylonity.knightlib.api.loot.KnightLibLoot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3503;
import net.minecraft.class_39;
import net.minecraft.class_4309;
import net.minecraft.class_5455;
import net.minecraft.class_55;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

@Mixin(class_4309.class)
public abstract class LootTableResourcesMixin {

    @Inject(method = "scanDirectory", at = @At("RETURN"))
    private static void knightlib$injectEntityDrops(class_3300 resources, String directory, Gson gson, Map<class_2960, JsonElement> elements, CallbackInfo ci) {
        if (directory.equals(class_7924.method_60915(class_7924.field_50079))) {
            final List<EntityLootEntry> entries = KnightLibLoot.getEntityEntries();
            if (entries.isEmpty()) {
                return;
            }

            final class_3503<class_1299<?>> loader = new class_3503<>(class_7923.field_41177::method_17966, class_7924.method_60916(class_7924.field_41266));
            final Map<class_2960, Collection<class_1299<?>>> tags = loader.method_33176(resources);
            final class_6903<JsonElement> ops = class_5455.method_40302(class_7923.field_41167).method_57093(JsonOps.INSTANCE);

            for (int index = 0; index < entries.size(); index++) {
                final EntityLootEntry entry = entries.get(index);
                final Set<class_2960> targets = new HashSet<>();
                for (final class_1299<?> type : tags.getOrDefault(entry.getEntityTag().comp_327(), List.of())) {
                    targets.add(type.method_16351().method_29177());
                }

                targets.remove(class_39.field_844.method_29177());

                JsonObject pool = null;
                for (final class_2960 target : targets) {
                    final JsonElement element = elements.get(target);
                    if (element == null || !element.isJsonObject()) {
                        continue;
                    }

                    final JsonObject table = element.getAsJsonObject();
                    if (table.has("pools") && !table.get("pools").isJsonArray()) {
                        // Malformed mainly
                        continue;
                    }

                    if (pool == null) {
                        pool = class_55.field_45795.encodeStart(ops, KnightLibLoot.buildPool(entry).method_355()).getOrThrow().getAsJsonObject();
                        pool.addProperty("name", "knightlib:entity_drop_" + index);
                    }

                    if (!table.has("pools")) {
                        table.add("pools", new JsonArray());
                    }

                    table.getAsJsonArray("pools").add(pool.deepCopy());
                }

            }

        }

    }

}
