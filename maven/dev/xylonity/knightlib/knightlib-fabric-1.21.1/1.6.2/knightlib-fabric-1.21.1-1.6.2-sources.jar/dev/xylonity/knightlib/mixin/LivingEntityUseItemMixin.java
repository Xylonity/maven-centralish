package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.LivingUseItemFinishEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1309.class)
public class LivingEntityUseItemMixin {

    @Redirect(method = "completeUsingItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;"))
    private class_1799 knightlib$onFinishUsingItem(class_1799 instance, class_1937 level, class_1309 entity) {
        final class_1799 result = instance.method_7910(level, entity);
        if (level.field_9236) {
            return result;
        }

        final LivingUseItemFinishEvent event = new LivingUseItemFinishEvent(entity, instance, result);
        KnightLibEvents.SERVER.dispatch(event);
        return event.getResult();
    }

}