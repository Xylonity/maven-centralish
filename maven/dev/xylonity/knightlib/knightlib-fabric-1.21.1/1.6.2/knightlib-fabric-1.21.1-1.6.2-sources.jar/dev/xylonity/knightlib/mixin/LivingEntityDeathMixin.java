package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.LivingDeathEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityDeathMixin {

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void knightlib$onDeath(class_1282 source, CallbackInfo ci) {
        final class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) {
            return;
        }

        final LivingDeathEvent event = new LivingDeathEvent(self, source);
        KnightLibEvents.SERVER.dispatch(event);

        if (event.isCancelled()) {
            ci.cancel();
        }

    }

}
