package dev.xylonity.knightlib.client.animation.model;

import dev.xylonity.knightlib.client.animation.KnightLibPose;
import dev.xylonity.knightlib.client.animation.geo.GeoModelDefinition;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/**
 * Mutable geo bone tree instantiated from a parsed {@link GeoModelDefinition}.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/object/BakedGeoModel.java
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/renderer/GeoRenderer.java
 */
public final class GeoModel extends KnightLibModel {

    public static final String ROOT = "__root";

    private final GeoBone root;
    private final Map<String, GeoBone> bones = new LinkedHashMap<>();
    private final Set<String> boneNames;
    private final Set<String> locatorNames;

    public GeoModel(GeoModelDefinition definition) {
        this.root = new GeoBone(ROOT, 0f, 0f, 0f, 0f, 0f, 0f, true, java.util.List.of());
        bones.put(ROOT, root);

        for (final GeoModelDefinition.BoneDefinition boneDefinition : definition.bones()) {
            if (ROOT.equals(boneDefinition.name()) || bones.containsKey(boneDefinition.name())) {
                throw new IllegalArgumentException("[KnightLib] Reserved or duplicate bone name: " + boneDefinition.name());
            }

            final GeoBone bone = new GeoBone(
                    boneDefinition.name(),
                    boneDefinition.offsetX(), boneDefinition.offsetY(), boneDefinition.offsetZ(),
                    boneDefinition.rotX(), boneDefinition.rotY(), boneDefinition.rotZ(),
                    boneDefinition.visible(),
                    boneDefinition.cubes()
            );

            bones.put(bone.name, bone);
        }

        for (final GeoModelDefinition.BoneDefinition boneDefinition : definition.bones()) {
            final GeoBone bone = bones.get(boneDefinition.name());
            final GeoBone parent = boneDefinition.parent().isEmpty() ? root : bones.get(boneDefinition.parent());
            if (parent == null) {
                throw new IllegalStateException("[KnightLib] Bone '" + boneDefinition.name() + "' references unknown parent '" + boneDefinition.parent() + "'");
            }

            parent.addChild(bone);
        }

        for (final GeoModelDefinition.LocatorDefinition locatorDefinition : definition.locators()) {
            final GeoBone bone = bones.get(locatorDefinition.bone());
            if (bone == null) {
                throw new IllegalStateException("[KnightLib] Locator '" + locatorDefinition.name() + "' references unknown bone '" + locatorDefinition.bone() + "'");
            }

            bone.addLocator(
                    locatorDefinition.name(),
                    locatorDefinition.offsetX(), locatorDefinition.offsetY(), locatorDefinition.offsetZ(),
                    locatorDefinition.rotX(), locatorDefinition.rotY(), locatorDefinition.rotZ()
            );

        }

        boneNames = Set.copyOf(bones.keySet());
        final Set<String> locators = new java.util.LinkedHashSet<>();
        root.forEachLocator(locators::add);
        locatorNames = Set.copyOf(locators);
    }

    public GeoBone bone(String name) {
        return bones.get(name);
    }

    @Override
    public Set<String> boneNames() {
        return boneNames;
    }

    @Override
    protected void visitEachBone(Consumer<String> visitor) {
        for (final GeoBone child : root.children()) {
            child.forEachBone(visitor);
        }

    }

    @Override
    public boolean hasBone(String name) {
        return bones.containsKey(name);
    }

    @Override
    public Set<String> locatorNames() {
        return locatorNames;
    }

    @Override
    public boolean hasLocator(String name) {
        return locatorNames.contains(name);
    }

    @Override
    public void resetPose() {
        for (final GeoBone bone : bones.values()) {
            bone.reset();
        }

    }

    @Override
    public void applyPosition(String bone, float x, float y, float z) {
        final GeoBone target = bones.get(bone);
        if (target == null) {
            return;
        }

        target.x += -x;
        target.y += y;
        target.z += z;
    }

    @Override
    public void applyRotation(String bone, float xDeg, float yDeg, float zDeg) {
        final GeoBone target = bones.get(bone);
        if (target == null) {
            return;
        }

        target.rotX += -xDeg;
        target.rotY += -yDeg;
        target.rotZ += zDeg;
    }

    @Override
    public void applyScale(String bone, float x, float y, float z) {
        final GeoBone target = bones.get(bone);
        if (target == null) {
            return;
        }

        target.scaleX *= x;
        target.scaleY *= y;
        target.scaleZ *= z;
    }

    @Override
    public void setBoneVisible(String bone, boolean visible) {
        final GeoBone target = bones.get(bone);
        if (target == null) {
            return;
        }

        target.visible = visible;
    }

    @Override
    public KnightLibPose capturePose() {
        final KnightLibPose pose = new KnightLibPose();
        for (final GeoBone bone : bones.values()) {
            final float[] values = pose.bone(bone.name);
            values[0] = bone.x;
            values[1] = bone.y;
            values[2] = bone.z;
            values[3] = bone.rotX;
            values[4] = bone.rotY;
            values[5] = bone.rotZ;
            values[6] = bone.scaleX;
            values[7] = bone.scaleY;
            values[8] = bone.scaleZ;
        }

        return pose;
    }

    @Override
    public void applyPose(KnightLibPose pose) {
        for (final GeoBone bone : bones.values()) {
            final float[] values = pose.get(bone.name);
            if (values == null) {
                continue;
            }

            bone.x = values[0];
            bone.y = values[1];
            bone.z = values[2];
            bone.rotX = values[3];
            bone.rotY = values[4];
            bone.rotZ = values[5];
            bone.scaleX = values[6];
            bone.scaleY = values[7];
            bone.scaleZ = values[8];
        }

    }

    @Override
    public void applyPoseDelta(KnightLibPose layer, KnightLibPose rest) {
        for (final String name : layer.boneNames()) {
            final GeoBone bone = bones.get(name);
            final float[] values = layer.get(name);
            final float[] base = rest.get(name);
            if (bone == null || values == null || base == null) {
                continue;
            }

            bone.x += values[0] - base[0];
            bone.y += values[1] - base[1];
            bone.z += values[2] - base[2];
            bone.rotX += values[3] - base[3];
            bone.rotY += values[4] - base[4];
            bone.rotZ += values[5] - base[5];
            bone.scaleX *= scaleRatio(values[6], base[6]);
            bone.scaleY *= scaleRatio(values[7], base[7]);
            bone.scaleZ *= scaleRatio(values[8], base[8]);
        }

    }

    private static float scaleRatio(float value, float rest) {
        return Math.abs(rest) < 1.0E-6f ? 1f : value / rest;
    }

    @Override
    public void blendFromPose(KnightLibPose from, float currentWeight) {
        for (final GeoBone bone : bones.values()) {
            final float[] values = from.get(bone.name);
            if (values == null) {
                continue;
            }

            bone.x = class_3532.method_16439(currentWeight, values[0], bone.x);
            bone.y = class_3532.method_16439(currentWeight, values[1], bone.y);
            bone.z = class_3532.method_16439(currentWeight, values[2], bone.z);
            bone.rotX = class_3532.method_17821(currentWeight, values[3], bone.rotX);
            bone.rotY = class_3532.method_17821(currentWeight, values[4], bone.rotY);
            bone.rotZ = class_3532.method_17821(currentWeight, values[5], bone.rotZ);
            bone.scaleX = class_3532.method_16439(currentWeight, values[6], bone.scaleX);
            bone.scaleY = class_3532.method_16439(currentWeight, values[7], bone.scaleY);
            bone.scaleZ = class_3532.method_16439(currentWeight, values[8], bone.scaleZ);
        }

    }

    @Override
    public void setupRootTransform(class_4587 poseStack, float bodyYawDegrees, boolean entityContext) {
        if (entityContext) {
            root.rotY += 180f - bodyYawDegrees;
        }

    }

    @Override
    public void render(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        root.render(poseStack, consumer, packedLight, packedOverlay, r, g, b, a);
    }

    @Override
    public void renderBones(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a, Set<String> boneNames) {
        root.renderSelected(poseStack, consumer, packedLight, packedOverlay, r, g, b, a, boneNames);
    }

    @Override
    public void renderLiving(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        poseStack.method_22903();

        poseStack.method_46416(0f, 1.501f, 0f);
        poseStack.method_22905(-1f, -1f, 1f);
        render(poseStack, consumer, packedLight, packedOverlay, r, g, b, a);

        poseStack.method_22909();
    }

    @Override
    public void visitBones(class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        root.visit(poseStack, names, visitor);
    }

    @Override
    public void renderLivingBones(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a, Set<String> boneNames) {
        poseStack.method_22903();
        try {
            poseStack.method_46416(0f, 1.501f, 0f);
            poseStack.method_22905(-1f, -1f, 1f);
            renderBones(poseStack, consumer, packedLight, packedOverlay, r, g, b, a, boneNames);
        }
        finally {
            poseStack.method_22909();
        }

    }

    @Override
    public void visitLivingBones(class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        poseStack.method_22903();
        poseStack.method_46416(0f, 1.501f, 0f);
        poseStack.method_22905(-1f, -1f, 1f);
        visitBones(poseStack, names, visitor);
        poseStack.method_22909();
    }

    @Override
    public void visitLocators(class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        root.visitLocators(poseStack, names, visitor);
    }

    @Override
    public void visitLivingLocators(class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        poseStack.method_22903();
        poseStack.method_46416(0f, 1.501f, 0f);
        poseStack.method_22905(-1f, -1f, 1f);
        visitLocators(poseStack, names, visitor);
        poseStack.method_22909();
    }

    @Override
    public class_243 boneHalfExtents(String name) {
        final GeoBone bone = bones.get(name);
        return bone == null ? new class_243(0.1, 0.1, 0.1) : bone.halfExtents();
    }

}