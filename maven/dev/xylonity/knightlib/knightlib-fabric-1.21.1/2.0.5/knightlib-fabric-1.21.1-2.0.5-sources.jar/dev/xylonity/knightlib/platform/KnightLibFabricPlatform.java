package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.armor.KnightLibArmorMaterial;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.common.item.armor.GenericArmorItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1738;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.Supplier;

@SuppressWarnings("unchecked")
public class KnightLibFabricPlatform implements KnightLibPlatform {

    /**
     * ExtendedScreenHandler now serializes a data object via a StreamCodec instead of writing into a buffer directly
     */
    private static final class_9139<class_9129, class_2540> MENU_DATA_CODEC = class_9139.method_56437(
            (target, data) -> {
                final int readable = data.readableBytes();
                target.method_10804(readable);
                target.method_52977(data, data.readerIndex(), readable);
            },
            source -> {
                final int readable = source.method_10816();
                final class_2540 copy = new class_2540(Unpooled.buffer(Math.max(readable, 1)));
                copy.method_52976(source, readable);
                return copy;
            }

    );

    @Override
    public <T extends class_2396<?>> Supplier<T> createParticle(boolean overrideLimiter) {
        return () -> (T) FabricParticleTypes.simple(overrideLimiter);
    }

    @Override
    public class_1738 createArmorItem(KnightLibArmorMaterial material, class_1738.class_8051 type, class_1792.class_1793 properties, class_2960 modelId) {
        return new GenericArmorItem(material.get(), type, properties, modelId);
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> supplier, Supplier<class_2248> block) {
        return class_2591.class_2592.method_20528(supplier::create, block.get()).method_11034(null);
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> supplier, Supplier<class_2248>... blocks) {
        final class_2248[] blocksArray = Arrays.stream(blocks)
                .map(Supplier::get)
                .toArray(class_2248[]::new);

        return class_2591.class_2592.method_20528(supplier::create, blocksArray).method_11034(null);
    }

    @Override
    public <T extends class_1703> class_3917<T> createMenuFactory(ResourceRegistry.MenuFactory<T> supplier) {
        return new ExtendedScreenHandlerType<>(supplier::create, MENU_DATA_CODEC);
    }

    @Override
    public <X extends class_1308> class_1792 createSpawnEgg(Supplier<class_1299<X>> entityType, int primaryColor, int secondaryColor, class_1792.class_1793 properties) {
        return new class_1826(entityType.get(), primaryColor, secondaryColor, properties);
    }

    @Override
    public void openMenu(class_3222 player, class_3908 provider, Consumer<class_2540> extraData) {
        player.method_17355(new ExtendedScreenHandlerFactory<class_2540>() {
            @Override
            public class_2540 getScreenOpeningData(class_3222 serverPlayer) {
                class_2540 buf = new class_2540(Unpooled.buffer());
                extraData.accept(buf);
                return buf;
            }

            @Override
            public @NotNull class_2561 method_5476() {
                return provider.method_5476();
            }

            @Override
            public @Nullable class_1703 createMenu(int syncId, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return provider.createMenu(syncId, inventory, player);
            }

        });

    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isModLoaded(String modid) {
        return FabricLoader.getInstance().isModLoaded(modid);
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    @Override
    public Path resolveConfigFile(String configFileName) {
        return FabricLoader.getInstance().getConfigDir().resolve(configFileName);
    }

    @Override
    public Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir();
    }

    @Override
    public class_1761.class_7913 creativeTabBuilder() {
        return FabricItemGroup.builder();
    }

}
