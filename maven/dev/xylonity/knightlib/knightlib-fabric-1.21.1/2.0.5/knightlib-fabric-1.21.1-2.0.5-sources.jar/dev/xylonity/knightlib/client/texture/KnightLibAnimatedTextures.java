package dev.xylonity.knightlib.client.texture;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.KnightLib;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1047;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_1061;
import net.minecraft.class_1079;
import net.minecraft.class_1084;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7368;
import net.minecraft.class_7771;

/**
 * Gives standalone textures vanilla-style {@code .mcmeta} animation without replacing their normal {@link class_1060} entry.
 * Animated files are loaded under a private alias, while static files keep using their original location and pay no extra cost.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/texture/AnimatableTexture.java
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/mixin/client/TextureManagerMixin.java
 */
@ApiStatus.Internal
public final class KnightLibAnimatedTextures {

    private static final String ALIAS_PREFIX = "__animated_texture__/";
    private static final Map<class_2960, Entry> ENTRIES = new HashMap<>();

    private static final class_1044 ABSENT_TEXTURE = new class_1044() {

        @Override
        public void method_4625(@NotNull class_3300 resourceManager) {
            ;;
        }

    };

    private static int resourceGeneration;

    private KnightLibAnimatedTextures() {
        ;;
    }

    /**
     * Returns the texture location that should be passed to a vanilla RenderType
     */
    public static synchronized class_2960 resolve(class_2960 source) {
        Objects.requireNonNull(source, "source");
        if (isInternalAlias(source)) {
            return source;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_1060 textureManager = minecraft.method_1531();

        // An explicitly registered texture subclass owns its own loading semantics
        final class_1044 originalTexture = textureManager.method_34590(source, ABSENT_TEXTURE);
        if (originalTexture != ABSENT_TEXTURE && originalTexture.getClass() != class_1049.class) {
            return source;
        }

        final Entry entry = ENTRIES.computeIfAbsent(source, Entry::new);
        if (entry.metadataGeneration != resourceGeneration) {
            entry.refreshMetadata(minecraft.method_1478(), resourceGeneration);
        }

        if (!entry.hasAnimationMetadata) {
            entry.releaseOwnedTexture(textureManager);
            return source;
        }

        return entry.resolve(textureManager);
    }

    /**
     * Invalidates metadata decisions after a resourcepack change
     */
    public static synchronized void onResourceReload() {
        resourceGeneration++;
    }

    private static boolean isInternalAlias(class_2960 location) {
        return KnightLib.MOD_ID.equals(location.method_12836()) && location.method_12832().startsWith(ALIAS_PREFIX);
    }

    private static class_2960 aliasFor(class_2960 source) {
        return KnightLib.of(ALIAS_PREFIX + source.method_12836() + "/" + source.method_12832());
    }

    private static boolean hasAnimationMetadata(class_3300 resourceManager, class_2960 source) {
        final class_3298 resource = resourceManager.method_14486(source).orElse(null);
        if (resource == null) {
            return false;
        }

        try {
            return resource.method_14481().method_43041(class_1079.field_5337).isPresent();
        }
        catch (Exception exception) {
            KnightLib.LOGGER.warn("Failed reading animation metadata for {}", source, exception);
            return false;
        }

    }

    private static final class Entry {

        private final class_2960 source;
        private final class_2960 alias;

        private int metadataGeneration = Integer.MIN_VALUE;
        private boolean hasAnimationMetadata;
        private boolean registrationFailed;
        private boolean warnedAliasCollision;
        @Nullable
        private KnightLibAnimatedTexture ownedTexture;

        private Entry(class_2960 source) {
            this.source = source;
            this.alias = aliasFor(source);
        }

        private void refreshMetadata(class_3300 resourceManager, int generation) {
            this.hasAnimationMetadata = KnightLibAnimatedTextures.hasAnimationMetadata(resourceManager, source);
            this.metadataGeneration = generation;
            this.registrationFailed = false;
            this.warnedAliasCollision = false;
        }

        private class_2960 resolve(class_1060 textureManager) {
            if (registrationFailed) {
                return source;
            }

            final class_1044 existing = textureManager.method_34590(alias, ABSENT_TEXTURE);
            if (existing instanceof KnightLibAnimatedTexture animatedTexture && animatedTexture.source().equals(source)) {
                ownedTexture = animatedTexture;
                return alias;
            }

            if (existing != ABSENT_TEXTURE) {
                if (existing == class_1047.method_4540()) {
                    registrationFailed = true;
                }
                else if (!warnedAliasCollision) {
                    warnedAliasCollision = true;
                    KnightLib.LOGGER.warn("Internal animated-texture alias {} is already owned by {}, using the original texture {}", alias, existing.getClass().getName(), source);
                }

                return source;
            }

            final KnightLibAnimatedTexture candidate = new KnightLibAnimatedTexture(source);
            textureManager.method_4616(alias, candidate);
            if (textureManager.method_34590(alias, ABSENT_TEXTURE) == candidate) {
                ownedTexture = candidate;
                return alias;
            }

            candidate.close();
            candidate.method_4528();

            registrationFailed = true;

            return source;
        }

        private void releaseOwnedTexture(class_1060 textureManager) {
            final class_1044 existing = textureManager.method_34590(alias, ABSENT_TEXTURE);
            final boolean ownsExisting = existing == ownedTexture || existing instanceof final KnightLibAnimatedTexture animatedTexture && animatedTexture.source().equals(source);
            if (ownsExisting) {
                textureManager.method_4615(alias);
            }

            ownedTexture = null;
        }

    }

    /**
     * A standalone texture that plays its own frames. Vanilla ticker is avoided on purpose because Sodium/Embeddium cancel
     * its {@code tickAndUpload} for every sprite they didn't see rendered, and nothing ever marks a texture outside an
     * atlas as visible, so it would stay frozen on its first frame
     */
    private static final class KnightLibAnimatedTexture extends class_1049 implements class_1061 {

        @Nullable
        private Animation animation;
        private boolean uploaded;
        private boolean field_5205;
        private boolean clamp;

        private KnightLibAnimatedTexture(class_2960 source) {
            super(source);
        }

        private class_2960 source() {
            return field_5224;
        }

        @Override
        public synchronized void method_4625(class_3300 resourceManager) throws IOException {
            closeAnimationData();

            final class_3298 resource = resourceManager.getResourceOrThrow(field_5224);
            final class_7368 metadata = resource.method_14481();
            final class_1079 animationMetadata;
            try {
                animationMetadata = metadata
                        .method_43041(class_1079.field_5337)
                        .orElse(null);
            }
            catch (Exception exception) {
                KnightLib.LOGGER.warn("Invalid animation metadata for {}, loading it as a static texture", field_5224, exception);
                super.method_4625(resourceManager);
                return;
            }

            if (animationMetadata == null) {
                super.method_4625(resourceManager);
                return;
            }

            class_1084 textureMetadata = null;
            try {
                textureMetadata = metadata.method_43041(class_1084.field_5344).orElse(null);
            }
            catch (RuntimeException exception) {
                KnightLib.LOGGER.warn("Invalid texture metadata for {}, using vanilla defaults", field_5224, exception);
            }

            final class_1011 image;
            try (final InputStream stream = resource.method_14482()) {
                image = class_1011.method_4309(stream);
            }

            final class_7771 frameSize;
            try {
                frameSize = animationMetadata.method_24143(image.method_4307(), image.method_4323());
            }
            catch (RuntimeException exception) {
                image.close();
                KnightLib.LOGGER.warn("Invalid animated frame size for {}, loading it as a static texture", field_5224, exception);
                super.method_4625(resourceManager);
                return;
            }

            if (frameSize.comp_1049() <= 0 || frameSize.comp_1050() <= 0 || image.method_4307() % frameSize.comp_1049() != 0 || image.method_4323() % frameSize.comp_1050() != 0) {
                KnightLib.LOGGER.warn("Texture {} size {}x{} is not a multiple of its animated frame size {}x{}, loading it as a static texture", field_5224, image.method_4307(), image.method_4323(), frameSize.comp_1049(), frameSize.comp_1050());
                image.close();
                super.method_4625(resourceManager);
                return;
            }

            final Animation nextAnimation;
            try {
                nextAnimation = Animation.create(field_5224, image, frameSize, animationMetadata);
            }
            catch (RuntimeException exception) {
                image.close();
                KnightLib.LOGGER.warn("Failed creating animated frames for {}, loading it as a static texture", field_5224, exception);
                super.method_4625(resourceManager);
                return;
            }

            this.field_5205 = textureMetadata != null && textureMetadata.method_4696();
            this.clamp = textureMetadata != null && textureMetadata.method_4697();
            this.animation = nextAnimation;

            scheduleFirstFrameUpload(nextAnimation);
        }

        private void scheduleFirstFrameUpload(Animation expectedAnimation) {
            final Runnable upload = () -> uploadFirstFrame(expectedAnimation);
            if (RenderSystem.isOnRenderThreadOrInit()) {
                upload.run();
            }
            else {
                RenderSystem.recordRenderCall(upload::run);
            }

        }

        private synchronized void uploadFirstFrame(Animation expectedAnimation) {
            if (animation != expectedAnimation) {
                return;
            }

            TextureUtil.prepareImage(method_4624(), 0, expectedAnimation.frameWidth, expectedAnimation.frameHeight);
            expectedAnimation.uploadFirstFrame();

            applyTextureParameters();

            uploaded = true;
        }

        @Override
        public void method_4622() {
            final Animation expectedAnimation;
            synchronized (this) {
                if (!uploaded || animation == null || !animation.isAnimated()) {
                    return;
                }

                expectedAnimation = animation;
            }

            if (RenderSystem.isOnRenderThread()) {
                tickOnRenderThread(expectedAnimation);
            }
            else {
                RenderSystem.recordRenderCall(() -> tickOnRenderThread(expectedAnimation));
            }

        }

        private synchronized void tickOnRenderThread(Animation expectedAnimation) {
            if (!uploaded || animation != expectedAnimation) {
                return;
            }

            method_23207();

            expectedAnimation.tickAndUpload();
            applyTextureParameters();
        }

        private void applyTextureParameters() {
            method_4527(field_5205, false);
            final int wrapping = clamp ? GL12.GL_CLAMP_TO_EDGE : GL11.GL_REPEAT;
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, wrapping);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, wrapping);
        }

        private void closeAnimationData() {
            uploaded = false;
            if (animation != null) {
                animation.close();
                animation = null;
            }

        }

        @Override
        public synchronized void close() {
            closeAnimationData();
            super.close();
        }

    }

    /**
     * Copy of vanilla's sprite animation ticker, keeps a pointer for the current rendered frame
     */
    private static final class Animation implements AutoCloseable {

        private final class_1011 sheet;
        private final int frameWidth;
        private final int frameHeight;
        private final int framesPerRow;
        private final List<Frame> frames;
        @Nullable
        private final class_1011 interpolatedFrame;

        private int frame;
        private int subFrame;

        private Animation(class_1011 sheet, class_7771 frameSize, List<Frame> frames, boolean interpolate) {
            this.sheet = sheet;
            this.frameWidth = frameSize.comp_1049();
            this.frameHeight = frameSize.comp_1050();
            this.framesPerRow = sheet.method_4307() / frameWidth;
            this.frames = frames;
            this.interpolatedFrame = interpolate && frames.size() > 1 ? new class_1011(frameWidth, frameHeight, false) : null;
        }

        private static Animation create(class_2960 location, class_1011 sheet, class_7771 frameSize, class_1079 metadata) {
            final int frameCount = (sheet.method_4307() / frameSize.comp_1049()) * (sheet.method_4323() / frameSize.comp_1050());

            final List<Frame> declaredFrames = new ArrayList<>();
            metadata.method_33460((index, time) -> declaredFrames.add(new Frame(index, time)));

            final List<Frame> frames = new ArrayList<>();
            if (declaredFrames.isEmpty()) {
                for (int i = 0; i < frameCount; i++) {
                    frames.add(new Frame(i, metadata.method_4684()));
                }

            }
            else {
                for (Frame frame : declaredFrames) {
                    if (frame.time() > 0 && frame.index() >= 0 && frame.index() < frameCount) {
                        frames.add(frame);
                    }
                    else {
                        KnightLib.LOGGER.warn("Ignoring invalid frame {} (time {}) in animated texture {}", frame.index(), frame.time(), location);
                    }

                }

            }

            // Same as vanilla, a sheet with no usable frames shows the first one
            if (frames.isEmpty()) {
                frames.add(new Frame(0, metadata.method_4684()));
            }

            return new Animation(sheet, frameSize, List.copyOf(frames), metadata.method_4685());
        }

        private boolean isAnimated() {
            return frames.size() > 1;
        }

        private void uploadFirstFrame() {
            uploadFrame(frames.get(0).index());
        }

        /**
         * Advances one client tick
         */
        private void tickAndUpload() {
            final Frame current = frames.get(frame);
            if (++subFrame >= current.time()) {
                frame = (frame + 1) % frames.size();
                subFrame = 0;

                final int nextIndex = frames.get(frame).index();
                if (nextIndex != current.index()) {
                    uploadFrame(nextIndex);
                }

            }
            else if (interpolatedFrame != null) {
                uploadInterpolatedFrame(current, interpolatedFrame);
            }

        }

        private void uploadFrame(int index) {
            sheet.method_4312(0, 0, 0, frameX(index), frameY(index), frameWidth, frameHeight, false, false);
        }

        private void uploadInterpolatedFrame(Frame current, class_1011 target) {
            final int nextIndex = frames.get((frame + 1) % frames.size()).index();
            if (nextIndex == current.index()) {
                return;
            }

            final double delta = 1.0D - (double) subFrame / current.time();
            final int fromX = frameX(current.index());
            final int fromY = frameY(current.index());
            final int toX = frameX(nextIndex);
            final int toY = frameY(nextIndex);

            for (int y = 0; y < frameHeight; y++) {
                for (int x = 0; x < frameWidth; x++) {
                    final int from = sheet.method_4315(fromX + x, fromY + y);
                    final int to = sheet.method_4315(toX + x, toY + y);
                    final int c0 = mix(delta, from >> 16 & 255, to >> 16 & 255);
                    final int c1 = mix(delta, from >> 8 & 255, to >> 8 & 255);
                    final int c2 = mix(delta, from & 255, to & 255);

                    target.method_4305(x, y, from & 0xFF000000 | c0 << 16 | c1 << 8 | c2);
                }

            }

            target.method_4312(0, 0, 0, 0, 0, frameWidth, frameHeight, false, false);
        }

        private static int mix(double delta, int from, int to) {
            return (int) (delta * from + (1.0D - delta) * to);
        }

        private int frameX(int index) {
            return index % framesPerRow * frameWidth;
        }

        private int frameY(int index) {
            return index / framesPerRow * frameHeight;
        }

        @Override
        public void close() {
            sheet.close();
            if (interpolatedFrame != null) {
                interpolatedFrame.close();
            }

        }

        private record Frame(
                int index,
                int time
        ) {
            ;;
        }

    }

}