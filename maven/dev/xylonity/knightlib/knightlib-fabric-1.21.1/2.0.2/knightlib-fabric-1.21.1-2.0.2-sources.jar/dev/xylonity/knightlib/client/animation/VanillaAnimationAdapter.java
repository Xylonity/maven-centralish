package dev.xylonity.knightlib.client.animation;

import dev.xylonity.knightlib.api.client.animation.KnightLibAnimation;
import dev.xylonity.knightlib.api.util.KnightLibEasings;
import org.joml.Vector3f;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import java.util.ArrayList;

/**
 * Converts a vanilla code {@link class_7184} into KnightLib's internal representation.
 */
public final class VanillaAnimationAdapter {

    public static KnightLibAnimation convert(String name, class_7184 definition) {
        return convert(name, definition, null);
    }

    /**
     * Converts a definition, optionally overriding the playback mode inferred from vanilla
     */
    public static KnightLibAnimation convert(String name, class_7184 definition, KnightLibAnimation.LoopMode loopOverride) {
        final Map<String, KnightLibAnimation.Channels> bones = new LinkedHashMap<>();

        for (final Map.Entry<String, List<class_7179>> entry : definition.comp_599().entrySet()) {
            List<KnightLibAnimation.Keyframe> position = null;
            List<KnightLibAnimation.Keyframe> rotation = null;
            List<KnightLibAnimation.Keyframe> scale = null;

            final List<List<KnightLibAnimation.Keyframe>> additionalPositions = new ArrayList<>();
            final List<List<KnightLibAnimation.Keyframe>> additionalRotations = new ArrayList<>();
            final List<List<KnightLibAnimation.Keyframe>> additionalScales = new ArrayList<>();

            for (final class_7179 channel : entry.getValue()) {
                if (channel.comp_595() == class_7179.class_7183.field_37886) {
                    final List<KnightLibAnimation.Keyframe> converted = convertKeyframes(channel, Kind.POSITION);
                    if (position == null) {
                        position = converted;
                    }
                    else {
                        additionalPositions.add(converted);
                    }

                }
                else if (channel.comp_595() == class_7179.class_7183.field_37887) {
                    final List<KnightLibAnimation.Keyframe> converted = convertKeyframes(channel, Kind.ROTATION);
                    if (rotation == null) {
                        rotation = converted;
                    }
                    else {
                        additionalRotations.add(converted);
                    }

                }
                else if (channel.comp_595() == class_7179.class_7183.field_37888) {
                    final List<KnightLibAnimation.Keyframe> converted = convertKeyframes(channel, Kind.SCALE);
                    if (scale == null) {
                        scale = converted;
                    }
                    else {
                        additionalScales.add(converted);
                    }

                }

            }

            bones.put(entry.getKey(), new KnightLibAnimation.Channels(
                    position, rotation, scale,
                    additionalPositions, additionalRotations, additionalScales)
            );

        }

        KnightLibAnimation.LoopMode loopMode = loopOverride != null ? loopOverride :
                definition.comp_598()
                        ? KnightLibAnimation.LoopMode.LOOP
                        : KnightLibAnimation.LoopMode.ONCE;

        // Blockbench exports static single-keyframe poses as zero-length non-looping definitions, so holding it instead would make the
        // blending up to rest work properly
        if (loopOverride == null && definition.comp_597() <= 0f && loopMode == KnightLibAnimation.LoopMode.ONCE) {
            loopMode = KnightLibAnimation.LoopMode.HOLD_ON_LAST_FRAME;
        }

        return new KnightLibAnimation(name, definition.comp_597() * 20f, loopMode, bones);
    }

    private static List<KnightLibAnimation.Keyframe> convertKeyframes(class_7179 channel, Kind kind) {
        final List<KnightLibAnimation.Keyframe> frames = new ArrayList<>();

        for (final class_7186 keyframe : channel.comp_596()) {
            final KnightLibAnimation.Lerp lerp = keyframe.comp_602() == class_7179.class_7181.field_37885 ?
                    KnightLibAnimation.Lerp.CATMULLROM : KnightLibAnimation.Lerp.LINEAR;

            final Vector3f value = keyframe.comp_601();
            final Vector3f authored = switch (kind) {
                case POSITION -> new Vector3f(value.x(), -value.y(), value.z());
                case ROTATION -> new Vector3f(
                        (float) Math.toDegrees(value.x()),
                        (float) Math.toDegrees(value.y()),
                        (float) Math.toDegrees(value.z())
                );
                case SCALE -> new Vector3f(value.x() + 1f, value.y() + 1f, value.z() + 1f);
            };

            frames.add(new KnightLibAnimation.Keyframe(keyframe.comp_600() * 20f, null, KnightLibAnimation.KeyframeValue.constant(authored), lerp, KnightLibEasings.LINEAR));
        }

        return frames;
    }

    private enum Kind {
        POSITION,
        ROTATION,
        SCALE
    }

}