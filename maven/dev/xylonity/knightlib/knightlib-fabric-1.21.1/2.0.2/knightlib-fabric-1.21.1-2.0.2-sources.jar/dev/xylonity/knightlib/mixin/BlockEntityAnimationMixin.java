package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.api.animation.internal.BlockEntityAnimationTicker;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hooks animatable blockentities into KnightLib's independent ticker.
 */
@Mixin(class_2586.class)
public abstract class BlockEntityAnimationMixin {

    @Inject(method = "setLevel", at = @At("RETURN"))
    private void knightlib$registerAnimations(class_1937 level, CallbackInfo ci) {
        BlockEntityAnimationTicker.register((class_2586) (Object) this);
    }

    @Inject(method = "clearRemoved", at = @At("RETURN"))
    private void knightlib$reregisterAnimations(CallbackInfo ci) {
        BlockEntityAnimationTicker.register((class_2586) (Object) this);
    }

    @Inject(method = "setRemoved", at = @At("RETURN"))
    private void knightlib$unregisterAnimations(CallbackInfo ci) {
        BlockEntityAnimationTicker.unregister((class_2586) (Object) this);
    }

    @Inject(method = "saveWithoutMetadata", at = @At("RETURN"))
    private void knightlib$saveAnimations(class_7225.class_7874 registries, CallbackInfoReturnable<class_2487> cir) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.getAnimationHandler().save(cir.getReturnValue());
        }

    }

    @Inject(method = "loadAdditional", at = @At("RETURN"))
    private void knightlib$loadAnimations(class_2487 tag, class_7225.class_7874 registries, CallbackInfo ci) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.getAnimationHandler().load(tag);
        }

    }

    @Inject(method = "getUpdateTag", at = @At("RETURN"))
    private void knightlib$syncAnimations(class_7225.class_7874 registries, CallbackInfoReturnable<class_2487> cir) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.getAnimationHandler().save(cir.getReturnValue());
        }

    }

}
