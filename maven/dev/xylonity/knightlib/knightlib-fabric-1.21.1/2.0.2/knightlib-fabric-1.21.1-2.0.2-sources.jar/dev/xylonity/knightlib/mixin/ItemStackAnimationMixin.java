package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.animation.KnightLibItemAnimations;
import dev.xylonity.knightlib.api.item.KnightLibAnimatedItem;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ticks itemstack animation controllers through vanilla's inventory tick.
 */
@Mixin(class_1799.class)
public abstract class ItemStackAnimationMixin {

    @Inject(method = "inventoryTick", at = @At("RETURN"))
    private void knightlib$tickAnimations(class_1937 level, class_1297 holder, int slot, boolean selected, CallbackInfo ci) {
        final class_1799 stack = (class_1799) (Object) this;
        if (stack.method_7909() instanceof KnightLibAnimatedItem item && (level.method_8608() || KnightLibItemAnimations.needsServerTick(stack))) {
            KnightLibItemAnimations.getAnimationHandler(item, stack, level, holder).tick();
        }

    }

}
