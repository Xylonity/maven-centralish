package dev.xylonity.knightlib.compat.jei.category;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import dev.xylonity.knightlib.common.recipe.GreatChaliceRecipe;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Vector3f;

public final class GreatChaliceRecipeCategory implements IRecipeCategory<GreatChaliceRecipe> {
    public static final class_2960 UID = KnightLib.of("great_chalice_interaction");
    public static final RecipeType<GreatChaliceRecipe> TYPE = new RecipeType<>(UID, GreatChaliceRecipe.class);

    public static final class_2960 SHADOW = KnightLib.of("textures/gui/shadow.png");

    private final IDrawable icon;

    private GreatChaliceBlockEntity cachedBlockEntity;
    private long lastUpdateTime = 0;

    public GreatChaliceRecipeCategory(IGuiHelper gui) {
        this.icon = gui.createDrawableIngredient(VanillaTypes.ITEM_STACK, new class_1799(KnightLibBlocks.GREAT_CHALICE.get()));
    }

    @Override
    public @NotNull RecipeType<GreatChaliceRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return class_2561.method_43471("jei.knightlib.great_chalice_grail_interaction.title");
    }

    @Override
    public int getHeight() {
        return 80;
    }

    @Override
    public int getWidth() {
        return 160;
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, GreatChaliceRecipe rec, @NotNull IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 10, 5).addItemStack(rec.input);

        builder.addSlot(RecipeIngredientRole.OUTPUT, 130, 42).addItemStack(rec.output);
    }

    private GreatChaliceBlockEntity getOrCreateBlockEntity() {
        if (cachedBlockEntity == null) {
            cachedBlockEntity = new GreatChaliceBlockEntity(class_2338.field_10980, KnightLibBlocks.GREAT_CHALICE.get().method_9564());
            cachedBlockEntity.setCharges(IGreatChaliceInteractable.MAX_CHARGES);
        }

        return cachedBlockEntity;
    }

    private void updateAnimation() {
        long currentTime = System.currentTimeMillis();
        if (lastUpdateTime == 0) {
            lastUpdateTime = currentTime;
        }

        if (currentTime - lastUpdateTime >= 50) {
            lastUpdateTime = currentTime;
        }
    }

    @Override
    public void draw(@NotNull GreatChaliceRecipe recipe, @NotNull IRecipeSlotsView slots, @NotNull class_332 guiGraphics, double mouseX, double mouseY) {
        RenderSystem.setShaderTexture(0, SHADOW);
        // chalice shadow
        guiGraphics.method_25302(SHADOW, 20, 55, 0, 0, 39, 17);
        // arrow down
        guiGraphics.method_25302(SHADOW, 32, 10, 46, 3, 33, 22);
        // arrow right
        guiGraphics.method_25302(SHADOW, 85, 45, 81, 6, 39, 12);
        // item bg input
        guiGraphics.method_25302(SHADOW, 129, 41, 120, 0, 19, 19);
        // item bg output
        guiGraphics.method_25302(SHADOW, 9, 4, 120, 0, 19, 19);

        updateAnimation();

        GreatChaliceBlockEntity be = getOrCreateBlockEntity();

        class_827<GreatChaliceBlockEntity> renderer = class_310.method_1551().method_31975().method_3550(be);

        if (renderer == null) return;

        class_4587 pose = guiGraphics.method_51448();
        class_4597.class_4598 buffer = guiGraphics.method_51450();

        pose.method_22903();
        pose.method_46416(59, 55, 0);
        pose.method_22905(24f, 24f, 24f);
        pose.method_22907(class_7833.field_40714.rotationDegrees(-25f));
        pose.method_22907(class_7833.field_40716.rotationDegrees(45f));
        pose.method_22907(class_7833.field_40718.rotationDegrees(180f));

        Matrix3f normalMat = pose.method_23760().method_23762();

        Vector3f up = new Vector3f(-1, 10, -1);
        Vector3f front = new Vector3f(-1, 3, -1);

        normalMat.transform(up).normalize();
        normalMat.transform(front).normalize();

        RenderSystem.setupGui3DDiffuseLighting(up, front);

        try {
            float partialTicks = (float)((System.currentTimeMillis() - lastUpdateTime) / 50.0);

            renderer.method_3569(be, partialTicks, pose, buffer, class_765.method_23687(15, 15), class_4608.field_21444);
        } catch (Exception e) {
            renderer.method_3569(be, class_310.method_1551().method_60646().method_60637(true), pose, buffer, class_765.method_23687(15, 15), class_4608.field_21444);
        }

        pose.method_22909();
        buffer.method_22993();
    }

}
