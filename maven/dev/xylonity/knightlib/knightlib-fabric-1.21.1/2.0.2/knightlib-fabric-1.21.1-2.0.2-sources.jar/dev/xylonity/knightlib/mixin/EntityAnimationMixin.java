package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Wires {@link KnightLibAnimatable} into the three vanilla entity lifecycle points the animation handler needs (tick, save, load).
 */
@Mixin(class_1297.class)
public abstract class EntityAnimationMixin {

    @Inject(method = "tick", at = @At("RETURN"))
    private void knightlib$tickAnimations(CallbackInfo ci) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.tickAnimations();
        }

    }

    @Inject(method = "saveWithoutId", at = @At("RETURN"))
    private void knightlib$saveAnimations(class_2487 tag, CallbackInfoReturnable<class_2487> cir) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.getAnimationHandler().save(cir.getReturnValue());
        }

    }

    @Inject(method = "load", at = @At("RETURN"))
    private void knightlib$loadAnimations(class_2487 tag, CallbackInfo ci) {
        if ((Object) this instanceof KnightLibAnimatable animatable) {
            animatable.getAnimationHandler().load(tag);
        }

    }

}