package dev.xylonity.knightlib.network.packets;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.animation.KnightLibAnim;
import dev.xylonity.knightlib.api.animation.KnightLibAnimationBlendMode;
import dev.xylonity.knightlib.api.animation.KnightLibAnimationMask;
import dev.xylonity.knightlib.api.animation.internal.AnimationMaskCodec;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.ClientPacketDispatcher;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import io.netty.handler.codec.DecoderException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Clientbound packet that plays or stops an animation controller on a tracked entity or block entity. An empty
 * step list means stop.
 */
public record AnimationSyncS2C(
        boolean entityTarget,
        int entityId,
        class_2338 pos,
        String controller,
        List<KnightLibAnim.Step> steps,
        int transitionTicks,
        int easingId,
        float speed,
        long commandGameTime,
        KnightLibAnimationBlendMode blendMode,
        boolean snapshot,
        KnightLibAnimationMask mask,
        float weight
) {

    public AnimationSyncS2C(boolean entityTarget, int entityId, class_2338 pos, String controller, List<KnightLibAnim.Step> steps, int transitionTicks, int easingId, float speed, long commandGameTime, KnightLibAnimationBlendMode blendMode) {
        this(entityTarget, entityId, pos, controller, steps, transitionTicks, easingId, speed, commandGameTime, blendMode, false);
    }

    public AnimationSyncS2C(boolean entityTarget, int entityId, class_2338 pos, String controller, List<KnightLibAnim.Step> steps, int transitionTicks, int easingId, float speed, long commandGameTime, KnightLibAnimationBlendMode blendMode, boolean snapshot) {
        this(entityTarget, entityId, pos, controller, steps, transitionTicks, easingId, speed, commandGameTime, blendMode, snapshot, KnightLibAnimationMask.ALL, 1f);
    }

    public static final class_2960 ID = class_2960.method_60655(KnightLib.MOD_ID, "animation_sync");

    public AnimationSyncS2C {
        steps = List.copyOf(steps);
        if (!KnightLibAnim.isValidSequence(steps)) {
            throw new IllegalArgumentException("Invalid animation sequence");
        }

        Objects.requireNonNull(blendMode, "blendMode");
        Objects.requireNonNull(mask, "mask");
        if (!Float.isFinite(weight) || weight < 0f || weight > 1f) {
            throw new IllegalArgumentException("[KnightLib] Invalid animation weight");
        }

    }

    public static final ClientboundPacketType<AnimationSyncS2C> TYPE =
            PacketType.clientbound(
                    ID,
                    AnimationSyncS2C.class,
                    PacketCodec.of(AnimationSyncS2C::encode, AnimationSyncS2C::decode),
                    ClientPacketDispatcher::dispatch
            );

    public static void encode(AnimationSyncS2C packet, class_2540 buf) {
        buf.method_52964(packet.entityTarget());
        if (packet.entityTarget()) {
            buf.method_10804(packet.entityId());
        }
        else {
            buf.method_10807(packet.pos());
        }

        buf.method_10788(packet.controller(), 64);
        buf.method_10804(packet.steps().size());
        for (final KnightLibAnim.Step step : packet.steps()) {
            buf.method_10788(step.animation(), 256);
            buf.method_10804(step.mode().id());
        }

        buf.method_10804(packet.transitionTicks());
        buf.method_10804(packet.easingId());
        buf.method_52941(packet.speed());
        buf.method_10804(packet.blendMode().id());
        buf.method_52974(packet.commandGameTime());
        buf.method_52964(packet.snapshot());
        buf.method_52941(packet.weight());
        AnimationMaskCodec.write(packet.mask(), buf);
    }

    public static AnimationSyncS2C decode(class_2540 buf) {
        final boolean entityTarget = buf.readBoolean();
        int entityId = 0;
        class_2338 pos = class_2338.field_10980;
        if (entityTarget) {
            entityId = buf.method_10816();
        }
        else {
            pos = buf.method_10811();
        }

        final String controller = buf.method_10800(64);
        final int stepCount = buf.method_10816();
        if (stepCount < 0 || stepCount > KnightLibAnim.MAX_STEPS) {
            throw new DecoderException("[KnightLib] Invalid animation sequence size");
        }

        final List<KnightLibAnim.Step> steps = new ArrayList<>(stepCount);
        try {
            for (int i = 0; i < stepCount; i++) {
                steps.add(new KnightLibAnim.Step(buf.method_10800(256), KnightLibAnim.PlaybackMode.byId(buf.method_10816())));
            }

        }
        catch (IllegalArgumentException exception) {
            throw new DecoderException("[KnightLib] Invalid animation sequence step", exception);
        }

        final int transition = buf.method_10816();
        final int easing = buf.method_10816();
        final float speed = buf.readFloat();
        final KnightLibAnimationBlendMode blendMode;
        try {
            blendMode = KnightLibAnimationBlendMode.byId(buf.method_10816());
        }
        catch (IllegalArgumentException exception) {
            throw new DecoderException("[KnightLib] Invalid animation blend mode", exception);
        }

        final long commandGameTime = buf.readLong();
        if (controller.isBlank() || transition < 0 || transition > 1200 || !Float.isFinite(speed) || speed <= 0f || speed > 100f || commandGameTime < 0L || !KnightLibAnim.isValidSequence(steps)) {
            throw new DecoderException("[KnightLib] Invalid animation sync payload");
        }

        final boolean snapshot = buf.isReadable() && buf.readBoolean();
        float weight = 1f;
        KnightLibAnimationMask mask = KnightLibAnimationMask.ALL;
        try {
            if (buf.isReadable()) {
                weight = buf.readFloat();
                mask = AnimationMaskCodec.read(buf);
            }

            return new AnimationSyncS2C(entityTarget, entityId, pos, controller, steps, transition, easing, speed, commandGameTime, blendMode, snapshot, mask, weight);
        }
        catch (Exception exception) {
            throw new DecoderException("[KnightLib] Invalid animation mask or weight", exception);
        }

    }

}
