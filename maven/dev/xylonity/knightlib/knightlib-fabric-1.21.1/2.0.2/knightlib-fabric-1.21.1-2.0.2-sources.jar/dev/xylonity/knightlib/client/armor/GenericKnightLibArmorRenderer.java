package dev.xylonity.knightlib.client.armor;

import dev.xylonity.knightlib.api.client.armor.KnightLibArmorModel;
import dev.xylonity.knightlib.api.client.armor.KnightLibArmorRenderer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;

/**
 * Default renderer for conventionally registered vanilla armor models.
 */
public class GenericKnightLibArmorRenderer extends KnightLibArmorRenderer {

    private final class_2960 modelId;

    public GenericKnightLibArmorRenderer(class_2960 modelId) {
        this.modelId = modelId;
    }

    @Override
    protected KnightLibArmorModel createModel() {
        final KnightLibArmorModels.Definition definition = KnightLibArmorModels.get(modelId);
        final class_630 root = class_310.method_1551().method_31974().method_32072(definition.layer());
        return definition.modelFactory().apply(root);
    }

    @Override
    public class_2960 getTextureLocation(class_1799 stack, class_1309 wearer, class_1304 slot, @Nullable String layer) {
        return KnightLibArmorModels.get(modelId).texture();
    }

}
