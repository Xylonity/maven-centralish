package dev.xylonity.knightlib.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4668;
import net.minecraft.class_757;

public final class KnightLibRenderTypes extends class_1921 {

    private static final Function<class_2960, class_1921> ENTITY_EMISSIVE = class_156.method_34866(texture -> createEntityEmissive(texture, false));
    private static final Function<class_2960, class_1921> ENTITY_EMISSIVE_DEPTH = class_156.method_34866(texture -> createEntityEmissive(texture, true));
    private static final Function<class_2960, class_1921> ENTITY_EMISSIVE_DEPTH_MASK = class_156.method_34866(KnightLibRenderTypes::createEntityEmissiveDepthMask);

    private KnightLibRenderTypes(String name, class_293 format, class_293.class_5596 mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setupState, Runnable clearState) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
    }

    /**
     * Pass backed by vanilla's eyes shader
     */
    private static class_1921 createEntityEmissive(class_2960 texture, boolean writeDepth) {
        final class_1921.class_4688 state = class_1921.class_4688.method_23598()
                .method_34578(field_29414)
                .method_34577(new class_4668.class_4683(texture, false, false))
                .method_23615(field_21370)
                .method_23603(field_21345)
                .method_23616(writeDepth ? field_21349 : field_21350)
                .method_23617(false);

        return method_24049(
                writeDepth ? "knightlib_entity_emissive_depth" : "knightlib_entity_emissive",
                class_290.field_1580, class_293.class_5596.field_27382, 256, false, true, state
        );
    }

    /**
     * Depth alpha pass, computed below the emissive layer, preventing actual geometry from culling clouds
     */
    private static class_1921 createEntityEmissiveDepthMask(class_2960 texture) {
        final class_1921.class_4688 state = class_1921.class_4688.method_23598()
                .method_34578(field_29452)
                .method_34577(new class_4668.class_4683(texture, false, false))
                .method_23615(field_21364)
                .method_23603(field_21345)
                .method_23608(field_21383)
                .method_23611(field_21385)
                .method_23616(field_21351)
                .method_23617(false);

        return method_24049("knightlib_entity_emissive_depth_mask", class_290.field_1580, class_293.class_5596.field_27382, 256, false, false, state);
    }

    public static final class_1921 LINES_SEE_THROUGH = new class_1921(
            "knightlib_editor_lines_see_through", class_290.field_29337, class_293.class_5596.field_27377, 1536, false, false,
            () -> {
                RenderSystem.setShader(class_757::method_34535);
                RenderSystem.enableBlend();
                RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
                RenderSystem.lineWidth(Math.max(2.5f, class_310.method_1551().method_22683().method_4489() / 1920f * 2.5f));
                RenderSystem.disableCull();
                RenderSystem.disableDepthTest();
                RenderSystem.depthMask(false);
            },
            () -> {
                RenderSystem.depthMask(true);
                RenderSystem.enableDepthTest();
                RenderSystem.enableCull();
                RenderSystem.disableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.lineWidth(1f);
            }

    ) {
        ;;
    };

    public static class_1921 entityEmissive(class_2960 texture) {
        return entityEmissive(texture, true);
    }

    public static class_1921 entityEmissive(class_2960 texture, boolean writeDepth) {
        return (writeDepth ? ENTITY_EMISSIVE_DEPTH : ENTITY_EMISSIVE).apply(texture);
    }

    public static class_1921 entityEmissiveDepthMask(class_2960 texture) {
        return ENTITY_EMISSIVE_DEPTH_MASK.apply(texture);
    }

}