package dev.xylonity.knightlib.common.blockentity;

import dev.xylonity.knightlib.api.animation.*;
import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.api.interop.GreatChaliceState;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import dev.xylonity.knightlib.registry.KnightLibParticles;
import org.jetbrains.annotations.NotNull;

import java.util.Random;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class GreatChaliceBlockEntity extends class_2586 implements KnightLibAnimatable {

    private final KnightLibAnimationHandler animations = KnightLibAnimationHandler.of(this);

    private static final KnightLibAnim IDLE = KnightLibAnim.begin().thenLoop("idle");

    private int charges;
    private int prevCharges;

    private GreatChaliceState state;

    private long tickcount;

    public GreatChaliceBlockEntity(class_2338 pos, class_2680 state) {
        super(KnightLibBlockEntities.GREAT_CHALICE.get(), pos, state);
        this.state = GreatChaliceState.EMPTY;
        this.charges = 0;
        this.prevCharges = 0;
        this.tickcount = 0;
    }

    public int getCharges() {
        return this.charges;
    }

    public void setCharges(int charges) {
        this.charges = Math.min(charges, IGreatChaliceInteractable.MAX_CHARGES);

        if (charges == 0) setState(GreatChaliceState.EMPTY);

        this.prevCharges = this.charges;
        method_5431();
        sync();
    }

    public GreatChaliceState getState() {
        return state;
    }

    public boolean isFull() {
        return this.getCharges() == IGreatChaliceInteractable.MAX_CHARGES;
    }

    public void setState(GreatChaliceState newState) {
        if (this.state == newState) return;
        this.state = newState;
        method_5431();
        sync();
    }

    @Override
    protected void method_11007(@NotNull class_2487 tag, net.minecraft.class_7225.@NotNull class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569("Charges", charges);
        tag.method_10569("PrevCharges", prevCharges);
        tag.method_10582("State", state.method_15434());
    }

    @Override
    protected void method_11014(@NotNull class_2487 tag, net.minecraft.class_7225.@NotNull class_7874 registries) {
        super.method_11014(tag, registries);
        this.charges = tag.method_10550("Charges");
        this.prevCharges = tag.method_10550("PrevCharges");
        try {
            state = GreatChaliceState.valueOf(tag.method_10558("State").toUpperCase());
        } catch (Exception e) {
            state = GreatChaliceState.NORMAL;
        }
    }

    @Override
    public @NotNull class_2487 method_16887(net.minecraft.class_7225.@NotNull class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        tag.method_10569("Charges", charges);
        tag.method_10569("PrevCharges", prevCharges);
        tag.method_10582("State", state.method_15434());
        return tag;
    }

    public static <T extends class_2586> void tick(class_1937 level, class_2338 pos, class_2680 state, T F) {
        if (!(F instanceof GreatChaliceBlockEntity chalice)) {
            return;
        }

        if (chalice.charges == IGreatChaliceInteractable.MAX_CHARGES && chalice.tickcount % 15 == 0) {
            chalice.spawnSpecialParticles();
        }

        if (chalice.charges == IGreatChaliceInteractable.MAX_CHARGES && chalice.tickcount % 5 == 0) {
            chalice.spawnChaoticParticles();
        }

        if (chalice.tickcount % 5 == 0) {
            chalice.spawnProgressiveParticles(pos);
        }

        chalice.tickcount++;
    }

    private void spawnSpecialParticles() {
        if (field_11863 instanceof class_3218 sv && getState() == GreatChaliceState.NORMAL) {
            for (int i = 0; i < 2; i++) {
                double dx = (new Random().nextDouble() - 0.5) * 0.5;
                double dy = (new Random().nextDouble() - 0.5) * 0.5;
                double dz = (new Random().nextDouble() - 0.5) * 0.5;
                if (i % 3 == 0) {
                    sv.method_14199(KnightLibParticles.STARSET.get(),
                            this.method_11016().method_10263() + 0.5,
                            this.method_11016().method_10264() + 0.5 * Math.random(),
                            this.method_11016().method_10260() + 0.5,
                            1, dx, dy, dz, 0.35);
                }
            }
        }

    }

    private void spawnChaoticParticles() {
        if (field_11863 instanceof class_3218 sv && getState() == GreatChaliceState.CHAOTIC) {
            for (int i = 0; i < 2; i++) {
                double dx = (new Random().nextDouble() - 0.5) * 0.5;
                double dy = (new Random().nextDouble() - 0.5) * 0.5;
                double dz = (new Random().nextDouble() - 0.5) * 0.5;
                sv.method_14199(class_2398.field_22249,
                        this.method_11016().method_10263() + 0.5,
                        this.method_11016().method_10264() + 0.5 * Math.random(),
                        this.method_11016().method_10260() + 0.5,
                        1, dx, dy, dz, 0.3);
            }
            for (int i = 0; i < 2; i++) {
                double dx = (new Random().nextDouble() - 0.5) * 0.5;
                double dy = (new Random().nextDouble() - 0.5) * 0.5;
                double dz = (new Random().nextDouble() - 0.5) * 0.5;
                sv.method_14199(class_2398.field_22248,
                        this.method_11016().method_10263() + 0.5,
                        this.method_11016().method_10264() + 0.5 * Math.random(),
                        this.method_11016().method_10260() + 0.5,
                        1, dx, dy, dz, 0.25);
            }
        }

    }

    private void spawnProgressiveParticles(class_2338 pos) {
        if (field_11863 instanceof class_3218 sv) {
            for (int i = 0; i < this.charges; i++) {
                if (sv.field_9229.method_43057() < 0.10f) {
                    sv.method_14199(class_2398.field_11245,
                            pos.method_10263() + 0.5 + (sv.field_9229.method_43058() - 0.5) * 0.9,
                            pos.method_10264() + ((double) this.getCharges() / 12) + sv.field_9229.method_43058() * 0.5,
                            pos.method_10260() + 0.5 + (sv.field_9229.method_43058() - 0.5) * 0.9,
                            1, 0.0, 0.1, 0.0, 0.0);
                }
            }
        }

    }

    public void sync() {
        if (!(field_11863 instanceof class_3218 serverLevel)) return;

        class_2596<class_2602> pkt = class_2622.method_38585(this);
        serverLevel.method_14178().field_17254.method_17210(new class_1923(field_11867), false).forEach(p -> p.field_13987.method_14364(pkt));
    }

    @Override
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public void registerAnimationControllers(KnightLibAnimationControllerRegistrar controllers) {
        controllers.add("main", this::mainController);
    }

    public KnightLibAnim mainController(final KnightLibAnimationState state) {
        return IDLE;
    }

    @Override
    public KnightLibAnimationHandler getAnimationHandler() {
        return this.animations;
    }

}
