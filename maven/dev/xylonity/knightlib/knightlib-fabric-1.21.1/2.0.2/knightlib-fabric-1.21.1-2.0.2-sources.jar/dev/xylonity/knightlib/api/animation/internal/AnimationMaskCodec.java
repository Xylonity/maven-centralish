package dev.xylonity.knightlib.api.animation.internal;

import dev.xylonity.knightlib.api.animation.KnightLibAnimationMask;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2540;

public final class AnimationMaskCodec {

    public static void write(KnightLibAnimationMask mask, class_2540 buffer) {
        buffer.method_52964(mask.allBones());
        buffer.method_52997(mask.channelBits());
        buffer.method_10804(mask.boneNames().size());
        for (final String bone : mask.boneNames()) {
            buffer.method_10788(bone, 256);
        }

    }

    public static KnightLibAnimationMask read(class_2540 buffer) {
        final boolean all = buffer.readBoolean();
        final int channels = buffer.readUnsignedByte();
        final int count = buffer.method_10816();
        if (count < 0 || count > KnightLibAnimationMask.MAX_BONES) {
            throw new IllegalArgumentException("[KnightLib] Invalid animation mask size");
        }

        final Set<String> bones = new HashSet<>();
        for (int i = 0; i < count; i++) {
            bones.add(buffer.method_10800(256));
        }

        return new KnightLibAnimationMask(bones, channels, all);
    }

    public static void write(KnightLibAnimationMask mask, class_2487 tag) {
        tag.method_10556("MaskAllBones", mask.allBones());
        tag.method_10569("MaskChannels", mask.channelBits());
        final class_2499 bones = new class_2499();
        for (final String bone : mask.boneNames()) {
            bones.add(class_2519.method_23256(bone));
        }

        tag.method_10566("MaskBones", bones);
    }

    public static KnightLibAnimationMask read(class_2487 tag) {
        if (!tag.method_10573("MaskChannels", class_2520.field_33263)) {
            return KnightLibAnimationMask.ALL;
        }

        final class_2499 names = tag.method_10554("MaskBones", class_2520.field_33258);
        if (names.size() > KnightLibAnimationMask.MAX_BONES) {
            throw new IllegalArgumentException("[KnightLib] Invalid animation mask size");
        }

        final Set<String> bones = new HashSet<>();
        for (int i = 0; i < names.size(); i++) {
            bones.add(names.method_10608(i));
        }

        return new KnightLibAnimationMask(bones, tag.method_10550("MaskChannels"), tag.method_10577("MaskAllBones"));
    }

}