package dev.xylonity.knightlib.client.animation.renderer;

import dev.xylonity.knightlib.api.animation.KnightLibAnimationHandler;
import dev.xylonity.knightlib.api.client.animation.KnightLibAnimation;
import dev.xylonity.knightlib.api.item.KnightLibAnimatedItem;
import dev.xylonity.knightlib.api.item.KnightLibRenderedItem;
import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.KnightLibAnimationSource;
import dev.xylonity.knightlib.client.animation.KnightLibAnimator;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibEmissiveLayer;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibOverlayLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.client.texture.KnightLibAnimatedTextures;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_756;
import net.minecraft.class_811;
import net.minecraft.class_918;

/**
 * Base item renderer (BEWLR) for items rendered with a KnightLib model.
 */
public abstract class KnightLibItemRenderer extends class_756 {

    private final List<KnightLibRenderLayer<class_1799>> layers = new ArrayList<>();
    private final KnightLibModelSource.InstanceCache modelCache = new KnightLibModelSource.InstanceCache();

    protected KnightLibItemRenderer() {
        super(class_310.method_1551().method_31975(), class_310.method_1551().method_31974());
    }

    /**
     * Geometry file or method reference
     */
    protected abstract KnightLibModelSource defineModel(class_1799 stack);

    /**
     * Animation file or method reference
     */
    protected KnightLibAnimationSource defineAnimations(class_1799 stack) {
        return KnightLibAnimationSource.none();
    }

    /**
     * Packed ARGB multiplier, evaluated once immediately before drawing
     */
    protected int getRenderColor(class_1799 stack, class_811 displayContext, float partialTicks, int packedLight) {
        return KnightLibColor.WHITE_ARGB;
    }

    /**
     * Calculates scale and ARGB together once for the complete render pass
     */
    protected KnightLibRenderState getRenderState(class_1799 stack, class_811 displayContext, float partialTicks, int packedLight) {
        return KnightLibRenderState.of(getScale(stack), getRenderColor(stack, displayContext, partialTicks, packedLight));
    }

    /**
     * Texture source for this stack
     */
    public abstract class_2960 getTextureLocation(class_1799 stack);

    protected class_1921 getRenderType(class_1799 stack, class_2960 texture) {
        return class_1921.method_23578(texture);
    }

    protected class_1921 getRenderType(class_1799 stack, class_2960 texture, int renderColor) {
        return KnightLibColor.fromArgb(renderColor).isTranslucent()
                ? class_1921.method_23580(texture)
                : getRenderType(stack, texture);
    }

    /**
     * Optional atlas sprite backing the returned texture (no need to override this at all)
     */
    protected class_1058 getTextureSprite(class_1799 stack, class_2960 texture) {
        return null;
    }

    protected float getScale(class_1799 stack) {
        return 1f;
    }

    /**
     * Vertical offset of the model inside the unit cube
     */
    protected float getVerticalOffset(class_1799 stack) {
        return 0.51f;
    }

    /**
     * Name of a looping animation driven by the game clock, or null for the rest pose (convenience)
     */
    protected String getAmbientAnimation(class_1799 stack) {
        return null;
    }

    protected float getAmbientAnimationSpeed(class_1799 stack) {
        return 1f;
    }

    protected final void addEmissiveLayer(Function<class_1799, class_2960> texture) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture));
    }

    protected final void addEmissiveLayer(Function<class_1799, class_2960> texture, KnightLibEmissiveLayer.AnimatedTint<class_1799> animatedTint) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture, animatedTint));
    }

    protected final void addOverlayLayer(Function<class_1799, class_2960> texture) {
        addRenderLayer(new KnightLibOverlayLayer<>(texture));
    }

    /**
     * Adds an arbitrary render layer
     */
    protected final void addRenderLayer(KnightLibRenderLayer<class_1799> layer) {
        layers.add(Objects.requireNonNull(layer, "layer"));
    }

    /**
     * Called every frame after animations are applied and before rendering
     */
    protected void setupPose(class_1799 stack, KnightLibModel model, float partialTicks) {
        ;;
    }

    /**
     * Called every frame after animations are applied and before rendering
     */
    protected void setupPose(class_1799 stack, class_811 displayContext, KnightLibModel model, float partialTicks) {
        setupPose(stack, model, partialTicks);
    }

    /**
     * Called for every bone after animation/pose evaluation and before rendering
     */
    protected void setupBone(class_1799 stack, class_811 displayContext, KnightLibModel model, String boneName, float partialTicks) {
        ;;
    }

    @Override
    public void method_3166(@NotNull class_1799 stack, @NotNull class_811 displayContext, @NotNull class_4587 poseStack, @NotNull class_4597 buffers, int packedLight, int packedOverlay) {
        final KnightLibModel model = modelCache.resolve(defineModel(stack));

        final class_310 minecraft = class_310.method_1551();
        final float partialTicks = minecraft.method_60646().method_60637(true);
        final double now = minecraft.field_1687 != null ? minecraft.field_1687.method_8510() + partialTicks : partialTicks;

        final KnightLibAnimationSource animations = defineAnimations(stack);
        KnightLibAnimationHandler handler = null;
        if (stack.method_7909() instanceof KnightLibAnimatedItem item) {
            handler = item.getAnimationHandler(stack, minecraft.field_1687);
            handler.tick();
        }

        if (handler != null && !handler.controllers().isEmpty()) {
            KnightLibAnimator.animate(handler, model, animations::get, now);
        }
        else {
            final String ambient = getAmbientAnimation(stack);
            final KnightLibAnimation animation = ambient == null ? null : animations.get(ambient);
            if (animation != null) {
                KnightLibAnimator.applyAmbient(model, animation, now, getAmbientAnimationSpeed(stack));
            }
            else {
                model.resetPose();
            }

        }

        setupPose(stack, displayContext, model, partialTicks);
        model.forEachBone(boneName -> setupBone(stack, displayContext, model, boneName, partialTicks));
        KnightLibRenderState renderState = getRenderState(stack, displayContext, partialTicks, packedLight);
        if (renderState == null) {
            renderState = KnightLibRenderState.DEFAULT;
        }

        poseStack.method_22903();
        poseStack.method_22904(0.5, getVerticalOffset(stack), 0.5);

        final float scale = renderState.scale();
        if (scale != 1f) {
            poseStack.method_22905(scale, scale, scale);
        }

        model.setupRootTransform(poseStack, 0f, false);

        final class_2960 baseTexture = getTextureLocation(stack);
        final class_1058 baseSprite = getTextureSprite(stack, baseTexture);
        actuallyRender(stack, displayContext, model, baseTexture, baseSprite, partialTicks, poseStack, buffers, packedLight, packedOverlay, renderState.renderColor());

        poseStack.method_22909();
    }

    /**
     * Render hook that's derived from the main render call that can alter the actual packed ARGB
     */
    protected void actuallyRender(class_1799 stack, class_811 displayContext, KnightLibModel model, class_2960 baseTexture, class_1058 baseSprite, float partialTicks, class_4587 poseStack, class_4597 buffers, int packedLight, int packedOverlay, int renderColor) {
        final KnightLibColor color = KnightLibColor.fromArgb(renderColor);
        final class_2960 renderTexture = baseSprite == null ? KnightLibAnimatedTextures.resolve(baseTexture) : baseSprite.method_45852();
        final class_1921 baseRenderType = getRenderType(stack, renderTexture, renderColor);
        class_4588 baseConsumer = class_918.method_29711(buffers, baseRenderType, false, stack.method_7958());
        if (baseSprite != null) {
            baseConsumer = baseSprite.method_24108(baseConsumer);
        }

        model.render(poseStack, baseConsumer, packedLight, packedOverlay, color.red(), color.green(), color.blue(), color.alpha());

        final class_310 minecraft = class_310.method_1551();
        final double renderTime = minecraft.field_1687 != null ? minecraft.field_1687.method_8510() + partialTicks : partialTicks;
        final KnightLibRenderLayerContext<class_1799> context = new KnightLibRenderLayerContext<>(
                stack, model, poseStack, buffers, packedLight, packedOverlay, renderColor,
                partialTicks, renderTime, displayContext, false
        );
        for (final KnightLibRenderLayer<class_1799> layer : layers) {
            layer.renderIsolated(context);
        }

    }

}
