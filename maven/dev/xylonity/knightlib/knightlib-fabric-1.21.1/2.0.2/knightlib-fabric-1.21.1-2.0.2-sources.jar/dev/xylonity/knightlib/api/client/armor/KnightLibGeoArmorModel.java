package dev.xylonity.knightlib.api.client.armor;

import dev.xylonity.knightlib.client.animation.KnightLibPose;
import dev.xylonity.knightlib.client.animation.model.GeoModel;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.api.util.KnightLibColor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_1304;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_572;
import net.minecraft.class_630;

/**
 * Humanoud armor model with a {@link KnightLibModel} underneath that lets vanilla draw geo geometry.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/renderer/GeoArmorRenderer.java
 */
public final class KnightLibGeoArmorModel extends KnightLibArmorModel {

    private final GeoModel geoModel;
    private final BoneNames bones;

    private final PartRestPose headRest;
    private final PartRestPose bodyRest;
    private final PartRestPose rightArmRest;
    private final PartRestPose leftArmRest;
    private final PartRestPose rightLegRest;
    private final PartRestPose leftLegRest;

    private class_1304 activeSlot;

    KnightLibGeoArmorModel(class_630 root, GeoModel geoModel, BoneNames bones) {
        super(root, geoModel);
        this.geoModel = geoModel;
        this.bones = bones;

        this.headRest = PartRestPose.capture(field_3398);
        this.bodyRest = PartRestPose.capture(field_3391);
        this.rightArmRest = PartRestPose.capture(field_3401);
        this.leftArmRest = PartRestPose.capture(field_27433);
        this.rightLegRest = PartRestPose.capture(field_3392);
        this.leftLegRest = PartRestPose.capture(field_3397);

        if (bones.all().stream().noneMatch(geoModel::hasBone)) {
            throw new IllegalArgumentException("[KnightLib] Geo armor model has none of its configured humanoid bones: " + bones.all());
        }

    }

    public GeoModel geoModel() {
        return geoModel;
    }

    @Override
    public void composeWithWearer(class_572<?> source, KnightLibPose animatedPose, KnightLibPose restPose) {
        // The humanoid parts carry vanilla's movement pose
        geoModel.resetPose();
        geoModel.applyPose(animatedPose);
        copyPropertiesFrom(source);

        applyPart(bones.head(), field_3398, headRest);
        applyPart(bones.body(), field_3391, bodyRest);
        applyPart(bones.leggingsBody(), field_3391, bodyRest);
        applyPart(bones.rightArm(), field_3401, rightArmRest);
        applyPart(bones.leftArm(), field_27433, leftArmRest);
        applyPart(bones.rightLeg(), field_3392, rightLegRest);
        applyPart(bones.leftLeg(), field_3397, leftLegRest);
        applyPart(bones.rightBoot(), field_3392, rightLegRest);
        applyPart(bones.leftBoot(), field_3397, leftLegRest);
    }

    private void applyPart(@Nullable String boneName, class_630 part, PartRestPose restPose) {
        if (boneName == null || !geoModel.hasBone(boneName)) {
            return;
        }

        geoModel.applyPosition(boneName,
                part.field_3657 - restPose.x(),
                restPose.y() - part.field_3656,
                part.field_3655 - restPose.z()
        );
        geoModel.applyRotation(boneName,
                (float) Math.toDegrees(part.field_3654 - restPose.xRot()),
                (float) Math.toDegrees(part.field_3675 - restPose.yRot()),
                (float) Math.toDegrees(part.field_3674 - restPose.zRot())
        );
        geoModel.applyScale(boneName,
                scaleRatio(part.field_37938, restPose.xScale()),
                scaleRatio(part.field_37939, restPose.yScale()),
                scaleRatio(part.field_37940, restPose.zScale())
        );

    }

    private static float scaleRatio(float value, float rest) {
        return Math.abs(rest) < 1.0E-6f ? 1f : value / rest;
    }

    @Override
    public void prepareForSlot(class_1304 slot) {
        activeSlot = slot;
        setMappedVisible(false);

        switch (slot) {
            case field_6169 -> setVisible(bones.head(), true);
            case field_6174 -> {
                setVisible(bones.body(), true);
                setVisible(bones.rightArm(), true);
                setVisible(bones.leftArm(), true);
            }
            case field_6172 -> {
                setVisible(bones.leggingsBody(), true);
                setVisible(bones.rightLeg(), true);
                setVisible(bones.leftLeg(), true);
            }
            case field_6166 -> {
                setVisible(firstPresent(bones.rightBoot(), bones.rightLeg()), true);
                setVisible(firstPresent(bones.leftBoot(), bones.leftLeg()), true);
            }
            default -> {
                ;;
            }

        }

    }

    private void setMappedVisible(boolean visible) {
        for (final String bone : bones.all()) {
            setVisible(bone, visible);
        }

    }

    private void setVisible(@Nullable String bone, boolean visible) {
        if (bone != null && geoModel.hasBone(bone)) {
            geoModel.setBoneVisible(bone, visible);
        }

    }

    private @Nullable String firstPresent(@Nullable String preferred, @Nullable String fallback) {
        return preferred != null && geoModel.hasBone(preferred) ? preferred : fallback;
    }

    @Override
    public void method_2828(@NotNull class_4587 poseStack, @NotNull class_4588 buffer, int packedLight, int packedOverlay, int renderColor) {
        if (activeSlot == null) {
            return;
        }

        poseStack.method_22903();

        if (field_3448) {
            if (activeSlot == class_1304.field_6169) {
                poseStack.method_22905(0.75f, 0.75f, 0.75f);
                poseStack.method_46416(0f, 1f, 0f);
            }
            else {
                poseStack.method_22905(0.5f, 0.5f, 0.5f);
                poseStack.method_46416(0f, 1.5f, 0f);
            }

        }

        applyArmorTransform(poseStack);
        final KnightLibColor color = KnightLibColor.fromArgb(renderColor);
        geoModel.render(poseStack, buffer, packedLight, packedOverlay, color.red(), color.green(), color.blue(), color.alpha());

        poseStack.method_22909();
    }

    static void applyArmorTransform(class_4587 poseStack) {
        poseStack.method_46416(0f, 24f / 16f, 0f);
        poseStack.method_22905(-1f, -1f, 1f);
    }

    record BoneNames(
            @Nullable String head,
            @Nullable String body,
            @Nullable String leggingsBody,
            @Nullable String rightArm,
            @Nullable String leftArm,
            @Nullable String rightLeg,
            @Nullable String leftLeg,
            @Nullable String rightBoot,
            @Nullable String leftBoot
    ) {

        Set<String> all() {
            final Set<String> names = new LinkedHashSet<>();
            add(names, head);
            add(names, body);
            add(names, leggingsBody);
            add(names, rightArm);
            add(names, leftArm);
            add(names, rightLeg);
            add(names, leftLeg);
            add(names, rightBoot);
            add(names, leftBoot);
            return names;
        }

        private static void add(Set<String> names, @Nullable String name) {
            if (name != null && !name.isBlank()) {
                names.add(name);
            }

        }

    }

    private record PartRestPose(
            float x,
            float y,
            float z,
            float xRot,
            float yRot,
            float zRot,
            float xScale,
            float yScale,
            float zScale
    ) {

        static PartRestPose capture(class_630 part) {
            return new PartRestPose(part.field_3657, part.field_3656, part.field_3655, part.field_3654, part.field_3675, part.field_3674, part.field_37938, part.field_37939, part.field_37940);
        }

    }

}
