package dev.xylonity.knightlib.client.item;

import dev.xylonity.knightlib.api.util.ResourceLocations;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.renderer.KnightLibItemRenderer;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

/**
 * Default renderer for a named animated block item using the knightlib animation system with a custom geo model.
 */
public final class GenericRenderedBlockItemRenderer extends KnightLibItemRenderer {

    private final class_2960 geometry;
    private final class_2960 texture;

    public GenericRenderedBlockItemRenderer(class_2960 id) {
        this.geometry = ResourceLocations.of(id.method_12836(), "geo/" + id.method_12832() + ".geo.json");
        this.texture = ResourceLocations.of(id.method_12836(), "textures/block/" + id.method_12832() + ".png");
    }

    @Override
    protected KnightLibModelSource defineModel(class_1799 stack) {
        return KnightLibModelSource.geo(geometry);
    }

    @Override
    public class_2960 getTextureLocation(class_1799 stack) {
        return texture;
    }

}