package dev.xylonity.knightlib.common.item.armor;

import dev.xylonity.knightlib.api.animation.KnightLibItemAnimations;
import dev.xylonity.knightlib.api.item.KnightLibRenderedArmorItem;
import dev.xylonity.knightlib.client.armor.GenericKnightLibArmorRenderer;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6880;

/**
 * Implementation of a vanilla armor item backed by a registered KnightLib armor model.
 *
 * Geo models must override {@code armorRendererFactory} with a custom {@code dev.xylonity.knightlib.api.client.armor.KnightLibGeoArmorRenderer}
 * renderer, while vanilla models must register a custom model through {@code ArmorModelRegistrationEvent}
 */
public class GenericArmorItem extends class_1738 implements KnightLibRenderedArmorItem {

    private final class_2960 modelId;

    public GenericArmorItem(class_1741 material, class_8051 type, class_1793 properties, class_2960 modelId) {
        this(class_6880.method_40223(material), type, properties, modelId);
    }

    public GenericArmorItem(class_6880<class_1741> material, class_8051 type, class_1793 properties, class_2960 modelId) {
        super(material, type, properties);
        this.modelId = Objects.requireNonNull(modelId, "modelId");
    }

    public final class_2960 modelId() {
        return modelId;
    }

    /**
     * Stub that matches Forge's optional item hook
     */
    public boolean shouldCauseReequipAnimation(class_1799 oldStack, class_1799 newStack, boolean slotChanged) {
        return KnightLibItemAnimations.shouldCauseReequipAnimation(oldStack, newStack);
    }

    @Override
    public Supplier<Object> armorRendererFactory() {
        return () -> new GenericKnightLibArmorRenderer(modelId);
    }

}
