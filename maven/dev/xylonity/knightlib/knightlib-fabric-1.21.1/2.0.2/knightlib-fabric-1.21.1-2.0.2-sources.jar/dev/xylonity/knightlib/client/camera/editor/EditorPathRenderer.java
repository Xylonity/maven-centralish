package dev.xylonity.knightlib.client.camera.editor;

import dev.xylonity.knightlib.api.camera.path.impl.CameraPathManager;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPathSampler;
import dev.xylonity.knightlib.api.event.impl.client.ClientRenderLevelStageEvent;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderRenderStage;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import dev.xylonity.knightlib.client.KnightLibRenderTypes;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * In-world visualization of the path being edited by the campath system.
 * The trajectory curve, a camera per keyframe, tangent handles on the selected keyframe and an additional camera at the current timeline position.
 */
public final class EditorPathRenderer {

    private static final int CURVE_STEPS = 24;
    private static final float TIME_MARK_EVERY_TICKS = 20f;
    private static final float HANDLE_FRACTION = 1f / 3f;

    // Path gradient endpoints
    private static final float[] COLOR_START = { 0.30f, 0.85f, 1.00f };
    private static final float[] COLOR_END = { 1.00f, 0.55f, 0.20f };

    private static final float[] COLOR_SELECTED = { 0.95f, 0.78f, 0.25f };
    private static final float[] COLOR_KEYFRAME = { 0.92f, 0.92f, 0.92f };
    private static final float[] COLOR_HANDLE = { 1.00f, 0.35f, 0.80f };
    private static final float[] COLOR_GHOST = { 0.35f, 1.00f, 0.75f };
    private static final float[] COLOR_CUT = { 0.60f, 0.60f, 0.65f };

    // Move/rotate camera of the selected keyframe
    private static final float[] COLOR_AXIS_X = { 0.96f, 0.28f, 0.32f };
    private static final float[] COLOR_AXIS_Y = { 0.42f, 0.88f, 0.36f };
    private static final float[] COLOR_AXIS_Z = { 0.30f, 0.52f, 0.98f };
    private static final float[] COLOR_RING_YAW = { 0.25f, 0.85f, 0.85f };
    private static final float[] COLOR_RING_PITCH = { 0.95f, 0.60f, 0.25f };

    private static final int RING_SEGMENTS = 40;

    private static final Matrix4f LAST_PROJECTION = new Matrix4f();
    private static final Matrix4f LAST_MODEL_VIEW = new Matrix4f();
    private static class_243 lastCameraPos = class_243.field_1353;
    private static boolean hasMatrices = false;

    private EditorPathRenderer() {
        ;;
    }

    public static void onRenderStage(final ClientRenderLevelStageEvent event) {
        if (event.getStage() != PostShaderRenderStage.AFTER_LEVEL) {
            return;
        }

        if (!CameraPathEditor.isActive() || CameraPathEditor.isPreviewing() || CameraPathManager.isPlaying()) {
            hasMatrices = false;
            return;
        }

        final class_4184 camera = event.getCamera();

        // The picking matrix is rebuilt from the camera state (as it is not guaranteed that the camera rotations are present in this stage)
        LAST_PROJECTION.set(event.getProjection());
        LAST_MODEL_VIEW.identity()
                .rotate(class_7833.field_40714.rotationDegrees(camera.method_19329()))
                .rotate(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180f));
        lastCameraPos = camera.method_19326();
        hasMatrices = true;

        final CameraEditorSession session = CameraPathEditor.session();
        if (session.isEmpty()) {
            return;
        }

        final class_4587 poseStack = new class_4587();
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180f));
        poseStack.method_22904(-lastCameraPos.field_1352, -lastCameraPos.field_1351, -lastCameraPos.field_1350);

        final class_4597.class_4598 buffers = class_310.method_1551().method_22940().method_23000();

        draw(poseStack, buffers.getBuffer(KnightLibRenderTypes.LINES_SEE_THROUGH), session, 0.25f);
        buffers.method_22994(KnightLibRenderTypes.LINES_SEE_THROUGH);

        draw(poseStack, buffers.getBuffer(class_1921.method_23594()), session, 1f);
        buffers.method_22994(class_1921.method_23594());

        drawLabels(poseStack, buffers, session, camera);
        buffers.method_22993();
    }

    /**
     * World-space ray under the mouse cursor, reconstructed from the last frame matrices
     */
    @Nullable
    public static PickRay pickRay(double mouseX, double mouseY) {
        if (!hasMatrices) {
            return null;
        }

        final class_310 minecraft = class_310.method_1551();
        final double guiWidth = minecraft.method_22683().method_4486();
        final double guiHeight = minecraft.method_22683().method_4502();

        final float ndcX = (float) (2.0 * mouseX / guiWidth - 1.0);
        final float ndcY = (float) (1.0 - 2.0 * mouseY / guiHeight);

        final Matrix4f inverse = new Matrix4f(LAST_PROJECTION).mul(LAST_MODEL_VIEW);
        if (Math.abs(inverse.determinant()) < 1.0E-12) {
            return null;
        }

        inverse.invert();

        final Vector4f near = inverse.transform(new Vector4f(ndcX, ndcY, -1f, 1f));
        final Vector4f far = inverse.transform(new Vector4f(ndcX, ndcY, 1f, 1f));
        if (near.w == 0f || far.w == 0f) {
            return null;
        }

        // The matrices are camera-relative, so I shift back into the absolute world space
        final class_243 nearPos = lastCameraPos.method_1031(near.x / near.w, near.y / near.w, near.z / near.w);
        final class_243 farPos = lastCameraPos.method_1031(far.x / far.w, far.y / far.w, far.z / far.w);
        return new PickRay(nearPos, farPos.method_1020(nearPos).method_1029());
    }

    /**
     * Picks whatever sits under the cursor
     */
    @Nullable
    public static PickResult pick(CameraEditorSession session, double mouseX, double mouseY) {
        final PickRay ray = pickRay(mouseX, mouseY);
        if (ray == null || session.isEmpty()) {
            return null;
        }

        final int selected = session.selectedIndex();
        if (selected >= 0) {
            final PickResult gizmo = pickGizmo(ray, session, selected);
            if (gizmo != null) {
                return gizmo;
            }

            final PickResult handle = pickBetween(ray,
                    pickAt(ray, PickKind.HANDLE_OUT, selected, outHandle(session, selected), 0.10),
                    pickAt(ray, PickKind.HANDLE_IN, selected, inHandle(session, selected), 0.10));

            if (handle != null) {
                return handle;
            }

        }

        PickResult best = null;
        for (int i = 0; i < session.keyframeCount(); i++) {
            best = pickBetween(ray, best, pickAt(ray, PickKind.KEYFRAME, i, session.keyframes().get(i).position, 0.45));
        }

        return best;
    }

    /**
     * Picks the translate arrows and rotation rings of the selected keyframe
     */
    @Nullable
    private static PickResult pickGizmo(PickRay ray, CameraEditorSession session, int selected) {
        final EditorKeyframe keyframe = session.keyframes().get(selected);
        final class_243 position = keyframe.position;

        final double length = gizmoScale(position);
        final double ring = ringRadius(position);

        // Arrows are only grabbable on their outer span
        final double inner = length * 0.3;

        PickResult best = null;
        best = pickBetween(ray, best, pickSegment(ray, PickKind.AXIS_X, selected, position.method_1031(inner, 0, 0), position.method_1031(length, 0, 0)));
        best = pickBetween(ray, best, pickSegment(ray, PickKind.AXIS_Y, selected, position.method_1031(0, inner, 0), position.method_1031(0, length, 0)));
        best = pickBetween(ray, best, pickSegment(ray, PickKind.AXIS_Z, selected, position.method_1031(0, 0, inner), position.method_1031(0, 0, length)));

        best = pickBetween(ray, best, pickRing(ray, PickKind.RING_YAW, selected, position, new class_243(0, 1, 0), ring));
        best = pickBetween(ray, best, pickRing(ray, PickKind.RING_PITCH, selected, position, rightVector(keyframe.yaw), ring));

        return best;
    }

    /**
     * World size of the selected keyframe's gizmo
     */
    public static double gizmoScale(class_243 position) {
        return Math.max(0.5, position.method_1022(lastCameraPos) * 0.11);
    }

    public static double ringRadius(class_243 position) {
        return gizmoScale(position) * 0.72;
    }

    public static class_243 axisDirection(PickKind kind) {
        return switch (kind) {
            case AXIS_X -> new class_243(1, 0, 0);
            case AXIS_Y -> new class_243(0, 1, 0);
            case AXIS_Z -> new class_243(0, 0, 1);
            default -> class_243.field_1353;
        };

    }

    /**
     * Horizontal right vector of a camera with the given yaw
     */
    public static class_243 rightVector(float yaw) {
        final float rad = (float) Math.toRadians(yaw);
        return new class_243(class_3532.method_15362(rad), 0, class_3532.method_15374(rad));
    }

    /**
     * Horizontal forward vector of a camera with the given yaw
     */
    public static class_243 forwardVector(float yaw) {
        final float rad = (float) Math.toRadians(yaw);
        return new class_243(-class_3532.method_15374(rad), 0, class_3532.method_15362(rad));
    }

    /**
     * Parameter along an axis line of the point closest to the cursor ray
     */
    public static double axisParameter(PickRay ray, class_243 origin, class_243 axis) {
        final class_243 w = origin.method_1020(ray.origin());

        final double b = axis.method_1026(ray.direction());
        final double denominator = 1.0 - b * b;
        if (Math.abs(denominator) < 1.0E-6) {
            // Axis parallel to the view ray
            return 0.0;
        }

        return (b * ray.direction().method_1026(w) - axis.method_1026(w)) / denominator;
    }

    @Nullable
    private static PickResult pickSegment(PickRay ray, PickKind kind, int index, class_243 from, class_243 to) {
        class_243 axis = to.method_1020(from);
        final double length = axis.method_1033();
        if (length < 1.0E-6) {
            return null;
        }

        axis = axis.method_1021(1.0 / length);

        final double s = class_3532.method_15350(axisParameter(ray, from, axis), 0.0, length);
        final class_243 point = from.method_1019(axis.method_1021(s));

        final double along = point.method_1020(ray.origin()).method_1026(ray.direction());
        if (along < 0.2) {
            return null;
        }

        final double radius = Math.max(0.07, along * 0.02);
        final double distance = ray.origin().method_1019(ray.direction().method_1021(along)).method_1022(point);

        return distance <= radius ? new PickResult(kind, index, point, along) : null;
    }

    @Nullable
    private static PickResult pickRing(PickRay ray, PickKind kind, int index, class_243 center, class_243 normal, double radius) {
        final class_243 hit = intersectPlane(ray, center, normal);
        if (hit == null) {
            return null;
        }

        final double along = hit.method_1020(ray.origin()).method_1026(ray.direction());
        if (along < 0.2) {
            return null;
        }

        final double tolerance = Math.max(0.07, along * 0.02);
        if (Math.abs(hit.method_1022(center) - radius) > tolerance) {
            return null;
        }

        return new PickResult(kind, index, hit, along);
    }

    /**
     * Cursor ray / plane intersection
     */
    @Nullable
    public static class_243 intersectPlane(PickRay ray, class_243 planePoint, class_243 planeNormal) {
        final double denominator = ray.direction().method_1026(planeNormal);
        if (Math.abs(denominator) < 1.0E-6) {
            return null;
        }

        final double t = planePoint.method_1020(ray.origin()).method_1026(planeNormal) / denominator;
        if (t < 0.05) {
            return null;
        }

        return ray.origin().method_1019(ray.direction().method_1021(t));
    }

    /**
     * World position of the outgoing tangent handle
     */
    @Nullable
    public static class_243 outHandle(CameraEditorSession session, int index) {
        final CameraPathSampler sampler = session.sampler();
        if (sampler == null || !session.smoothPosition || index < 0 || index >= sampler.keyframeCount() - 1 || sampler.isCut(index + 1)) {
            return null;
        }

        return sampler.keyframe(index).position().method_1019(sampler.outTangent(index).method_1021(HANDLE_FRACTION));
    }

    /**
     * World position of the incoming tangent handle
     */
    @Nullable
    public static class_243 inHandle(CameraEditorSession session, int index) {
        final CameraPathSampler sampler = session.sampler();
        if (sampler == null || !session.smoothPosition || index <= 0 || index >= sampler.keyframeCount() || sampler.isCut(index)) {
            return null;
        }

        return sampler.keyframe(index).position().method_1020(sampler.inTangent(index).method_1021(HANDLE_FRACTION));
    }

    @Nullable
    private static PickResult pickAt(PickRay ray, PickKind kind, int index, @Nullable class_243 position, double baseRadius) {
        if (position == null) {
            return null;
        }

        final double along = position.method_1020(ray.origin()).method_1026(ray.direction());
        if (along < 0.2) {
            return null;
        }

        // The world-space radius of the target (with a little distance increase)
        final double radius = Math.max(baseRadius, along * 0.022);
        final double distance = ray.origin().method_1019(ray.direction().method_1021(along)).method_1022(position);

        return distance <= radius ? new PickResult(kind, index, position, along) : null;
    }

    @Nullable
    private static PickResult pickBetween(PickRay ray, @Nullable PickResult a, @Nullable PickResult b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }

        return a.distanceAlongRay() <= b.distanceAlongRay() ? a : b;
    }

    private static void draw(class_4587 poseStack, class_4588 lines, CameraEditorSession session, float alpha) {
        final CameraPathSampler sampler = session.sampler();
        if (sampler == null) {
            return;
        }

        drawTrajectory(poseStack, lines, sampler, alpha);
        drawTimeMarks(poseStack, lines, sampler, alpha);

        for (int i = 0; i < session.keyframeCount(); i++) {
            final EditorKeyframe keyframe = session.keyframes().get(i);
            final float[] color = (i == session.selectedIndex()) ? COLOR_SELECTED : COLOR_KEYFRAME;

            drawCameraGizmo(poseStack, lines, keyframe.position, keyframe.yaw, keyframe.pitch, color, alpha, 0.7f);
        }

        drawHandles(poseStack, lines, session, alpha);
        drawMoveRotateGizmo(poseStack, lines, session, alpha);
        drawGhost(poseStack, lines, session, sampler, alpha);
    }

    private static void drawMoveRotateGizmo(class_4587 poseStack, class_4588 lines, CameraEditorSession session, float alpha) {
        final EditorKeyframe keyframe = session.selectedKeyframe();
        if (keyframe == null) {
            return;
        }

        final class_243 position = keyframe.position;
        final double length = gizmoScale(position);
        final double ring = ringRadius(position);

        drawArrow(poseStack, lines, position, new class_243(1, 0, 0), length, COLOR_AXIS_X, alpha);
        drawArrow(poseStack, lines, position, new class_243(0, 1, 0), length, COLOR_AXIS_Y, alpha);
        drawArrow(poseStack, lines, position, new class_243(0, 0, 1), length, COLOR_AXIS_Z, alpha);

        // Yaw and pitch rings
        drawRing(poseStack, lines, position, new class_243(1, 0, 0), new class_243(0, 0, 1), ring, COLOR_RING_YAW, alpha);
        drawRing(poseStack, lines, position, forwardVector(keyframe.yaw), new class_243(0, 1, 0), ring, COLOR_RING_PITCH, alpha);
    }

    private static void drawArrow(class_4587 poseStack, class_4588 lines, class_243 origin, class_243 direction, double length, float[] color, float alpha) {
        final class_243 tip = origin.method_1019(direction.method_1021(length));
        line(poseStack, lines, origin, tip, color[0], color[1], color[2], alpha);

        // Arrow head
        final class_243 up = Math.abs(direction.field_1351) > 0.9 ? new class_243(1, 0, 0) : new class_243(0, 1, 0);
        final class_243 sideA = direction.method_1036(up).method_1029().method_1021(length * 0.06);
        final class_243 sideB = direction.method_1036(sideA).method_1029().method_1021(length * 0.06);
        final class_243 back = tip.method_1020(direction.method_1021(length * 0.16));

        line(poseStack, lines, tip, back.method_1019(sideA), color[0], color[1], color[2], alpha);
        line(poseStack, lines, tip, back.method_1020(sideA), color[0], color[1], color[2], alpha);
        line(poseStack, lines, tip, back.method_1019(sideB), color[0], color[1], color[2], alpha);
        line(poseStack, lines, tip, back.method_1020(sideB), color[0], color[1], color[2], alpha);
    }

    private static void drawRing(class_4587 poseStack, class_4588 lines, class_243 center, class_243 basisA, class_243 basisB, double radius, float[] color, float alpha) {
        class_243 previous = center.method_1019(basisA.method_1021(radius));

        for (int i = 1; i <= RING_SEGMENTS; i++) {
            final double angle = (Math.PI * 2.0 * i) / RING_SEGMENTS;
            final class_243 current = center.method_1019(basisA.method_1021(radius * Math.cos(angle))).method_1019(basisB.method_1021(radius * Math.sin(angle)));

            line(poseStack, lines, previous, current, color[0], color[1], color[2], alpha);
            previous = current;
        }

    }

    /**
     * The trajectory line
     */
    private static void drawTrajectory(class_4587 poseStack, class_4588 lines, CameraPathSampler sampler, float alpha) {
        final float travel = Math.max(1f, sampler.travelTicks());

        for (int i = 1; i < sampler.keyframeCount(); i++) {
            final class_243 from = sampler.keyframe(i - 1).position();
            final class_243 to = sampler.keyframe(i).position();

            if (sampler.isCut(i)) {
                drawDashed(poseStack, lines, from, to, COLOR_CUT, alpha * 0.8f);
                continue;
            }

            final float startTime = sampler.segmentStart(i) / travel;
            final float endTime = (sampler.segmentStart(i) + sampler.keyframe(i).durationTicks()) / travel;

            class_243 previous = from;
            for (int step = 1; step <= CURVE_STEPS; step++) {
                final float t = step / (float) CURVE_STEPS;
                final class_243 current = sampler.positionOnSegment(i, t);

                final float time = class_3532.method_16439((step - 0.5f) / CURVE_STEPS, startTime, endTime);
                final float[] color = gradient(time);

                line(poseStack, lines, previous, current, color[0], color[1], color[2], alpha);
                previous = current;
            }

        }

    }

    /**
     * Small vertical marks along the curve at a fixed tick interval
     */
    private static void drawTimeMarks(class_4587 poseStack, class_4588 lines, CameraPathSampler sampler, float alpha) {
        float travel = sampler.travelTicks();

        for (float ticks = TIME_MARK_EVERY_TICKS; ticks < travel; ticks += TIME_MARK_EVERY_TICKS) {
            final class_243 position = sampler.sample(ticks).position();
            final float[] color = gradient(ticks / Math.max(1f, travel));

            line(poseStack, lines, position.method_1031(0, -0.07, 0), position.method_1031(0, 0.07, 0), color[0], color[1], color[2], alpha);
        }

    }

    private static void drawHandles(class_4587 poseStack, class_4588 lines, CameraEditorSession session, float alpha) {
        final int selected = session.selectedIndex();
        final EditorKeyframe keyframe = session.selectedKeyframe();
        if (keyframe == null) {
            return;
        }

        final class_243 outHandle = outHandle(session, selected);
        final class_243 inHandle = inHandle(session, selected);

        if (outHandle != null) {
            line(poseStack, lines, keyframe.position, outHandle, COLOR_HANDLE[0], COLOR_HANDLE[1], COLOR_HANDLE[2], alpha * 0.85f);
            drawDiamond(poseStack, lines, outHandle, COLOR_HANDLE, alpha);
        }

        if (inHandle != null) {
            line(poseStack, lines, keyframe.position, inHandle, COLOR_HANDLE[0], COLOR_HANDLE[1], COLOR_HANDLE[2], alpha * 0.85f);
            drawDiamond(poseStack, lines, inHandle, COLOR_HANDLE, alpha);
        }

    }

    private static void drawGhost(class_4587 poseStack, class_4588 lines, CameraEditorSession session, CameraPathSampler sampler, float alpha) {
        if (session.scrubTicks <= 0f) {
            return;
        }

        final CameraPathSampler.Pose pose = sampler.sample(Math.min(session.scrubTicks, sampler.totalTicks()));
        drawCameraGizmo(poseStack, lines, pose.position(), pose.yaw(), pose.pitch(), COLOR_GHOST, alpha * 0.7f, 0.55f);
    }

    /**
     * Blender-style wireframe camera: a small body box plus a view frustum pyramid opening
     * toward where the keyframe points, with the classic "up" triangle on top of the lens
     */
    private static void drawCameraGizmo(class_4587 poseStack, class_4588 lines, class_243 position, float yaw, float pitch, float[] color, float alpha, float scale) {
        poseStack.method_22903();
        poseStack.method_22904(position.field_1352, position.field_1351, position.field_1350);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(pitch));
        poseStack.method_22905(scale, scale, scale);

        float r = color[0];
        float g = color[1];
        float b = color[2];

        // Body
        localBox(poseStack, lines, -0.16f, -0.12f, -0.34f, 0.16f, 0.12f, 0.02f, r, g, b, alpha);

        // View frustum
        float lx = 0.32f;
        float ly = 0.21f;
        float lz = 0.55f;

        localLine(poseStack, lines, 0f, 0f, 0.02f, -lx, -ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, 0f, 0f, 0.02f, lx, -ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, 0f, 0f, 0.02f, -lx, ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, 0f, 0f, 0.02f, lx, ly, lz, r, g, b, alpha);

        // Lens rectangle
        localLine(poseStack, lines, -lx, -ly, lz, lx, -ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, lx, -ly, lz, lx, ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, lx, ly, lz, -lx, ly, lz, r, g, b, alpha);
        localLine(poseStack, lines, -lx, ly, lz, -lx, -ly, lz, r, g, b, alpha);

        // Up triangle on top of the lens
        localLine(poseStack, lines, -0.12f, ly + 0.02f, lz, 0.12f, ly + 0.02f, lz, r, g, b, alpha);
        localLine(poseStack, lines, -0.12f, ly + 0.02f, lz, 0f, ly + 0.2f, lz, r, g, b, alpha);
        localLine(poseStack, lines, 0.12f, ly + 0.02f, lz, 0f, ly + 0.2f, lz, r, g, b, alpha);

        poseStack.method_22909();
    }

    /**
     * Camera-facing tanget grabbable marker
     */
    private static void drawDiamond(class_4587 poseStack, class_4588 lines, class_243 center, float[] color, float alpha) {
        final class_4184 camera = class_310.method_1551().field_1773.method_19418();

        final class_243 up = new class_243(camera.method_19336());
        final class_243 right = new class_243(camera.method_35689()).method_1021(-1);

        final double size = Math.max(0.05, center.method_1022(lastCameraPos) * 0.014);

        final class_243 top = center.method_1019(up.method_1021(size));
        final class_243 bottom = center.method_1020(up.method_1021(size));
        final class_243 rightPoint = center.method_1019(right.method_1021(size));
        final class_243 leftPoint = center.method_1020(right.method_1021(size));

        line(poseStack, lines, top, rightPoint, color[0], color[1], color[2], alpha);
        line(poseStack, lines, rightPoint, bottom, color[0], color[1], color[2], alpha);
        line(poseStack, lines, bottom, leftPoint, color[0], color[1], color[2], alpha);
        line(poseStack, lines, leftPoint, top, color[0], color[1], color[2], alpha);
    }

    private static void drawDashed(class_4587 poseStack, class_4588 lines, class_243 from, class_243 to, float[] color, float alpha) {
        final double length = from.method_1022(to);
        final int dashes = Math.max(1, (int) (length / 0.8));

        for (int i = 0; i < dashes; i++) {
            final float start = i / (float) dashes;
            final float end = start + 0.5f / dashes;

            line(poseStack, lines, from.method_35590(to, start), from.method_35590(to, end), color[0], color[1], color[2], alpha);
        }

    }

    /**
     * Floating labels above each camera keyframe
     */
    private static void drawLabels(class_4587 poseStack, class_4597 buffers, CameraEditorSession session, class_4184 camera) {
        final class_327 font = class_310.method_1551().field_1772;

        for (int i = 0; i < session.keyframeCount(); i++) {
            final EditorKeyframe keyframe = session.keyframes().get(i);
            final String text = "#" + (i + 1) + " · " + keyframe.durationTicks + "t";
            final int color = (i == session.selectedIndex()) ? 0xFFF2CE60 : 0xFFFFFFFF;

            poseStack.method_22903();
            poseStack.method_22904(keyframe.position.field_1352, keyframe.position.field_1351 + 0.55, keyframe.position.field_1350);
            poseStack.method_22907(camera.method_23767());
            poseStack.method_22905(-0.02f, -0.02f, 0.02f);

            font.method_27521(text, -font.method_1727(text) / 2f, 0f, color, false, poseStack.method_23760().method_23761(), buffers, class_327.class_6415.field_33994, 0x40000000, 0xF000F0);

            poseStack.method_22909();
        }

    }

    private static float[] gradient(float time) {
        final float t = class_3532.method_15363(time, 0f, 1f);

        return new float[] {
                class_3532.method_16439(t, COLOR_START[0], COLOR_END[0]),
                class_3532.method_16439(t, COLOR_START[1], COLOR_END[1]),
                class_3532.method_16439(t, COLOR_START[2], COLOR_END[2])
        };

    }

    private static void line(class_4587 poseStack, class_4588 consumer, class_243 from, class_243 to, float r, float g, float b, float a) {
        localLine(poseStack, consumer, (float) from.field_1352, (float) from.field_1351, (float) from.field_1350, (float) to.field_1352, (float) to.field_1351, (float) to.field_1350, r, g, b, a);
    }

    private static void localLine(class_4587 poseStack, class_4588 consumer, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
        final class_4587.class_4665 pose = poseStack.method_23760();

        final float dx = x2 - x1;
        final float dy = y2 - y1;
        final float dz = z2 - z1;

        final float length = class_3532.method_15355(dx * dx + dy * dy + dz * dz);
        if (length < 1.0E-4f) {
            return;
        }

        final float nx = dx / length;
        final float ny = dy / length;
        final float nz = dz / length;

        consumer.method_22918(pose.method_23761(), x1, y1, z1).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz);
        consumer.method_22918(pose.method_23761(), x2, y2, z2).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz);
    }

    private static void localBox(class_4587 poseStack, class_4588 lines, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, float r, float g, float b, float a) {
        localLine(poseStack, lines, minX, minY, minZ, maxX, minY, minZ, r, g, b, a);
        localLine(poseStack, lines, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, a);
        localLine(poseStack, lines, maxX, maxY, minZ, minX, maxY, minZ, r, g, b, a);
        localLine(poseStack, lines, minX, maxY, minZ, minX, minY, minZ, r, g, b, a);

        localLine(poseStack, lines, minX, minY, maxZ, maxX, minY, maxZ, r, g, b, a);
        localLine(poseStack, lines, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, a);
        localLine(poseStack, lines, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
        localLine(poseStack, lines, minX, maxY, maxZ, minX, minY, maxZ, r, g, b, a);

        localLine(poseStack, lines, minX, minY, minZ, minX, minY, maxZ, r, g, b, a);
        localLine(poseStack, lines, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, a);
        localLine(poseStack, lines, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, a);
        localLine(poseStack, lines, minX, maxY, minZ, minX, maxY, maxZ, r, g, b, a);
    }

    public enum PickKind {
        KEYFRAME,
        HANDLE_IN,
        HANDLE_OUT,
        AXIS_X,
        AXIS_Y,
        AXIS_Z,
        RING_YAW,
        RING_PITCH
    }

    public record PickRay(
            class_243 origin,
            class_243 direction
    ) {
        ;;
    }

    public record PickResult(
            PickKind kind,
            int index,
            class_243 position,
            double distanceAlongRay
    ) {
        ;;
    }

}
