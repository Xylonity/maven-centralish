package dev.xylonity.knightlib.api.client.armor;

import dev.xylonity.knightlib.client.animation.KnightLibPose;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.client.animation.model.VanillaModel;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_572;
import net.minecraft.class_630;

/**
 * Vanilla humanoid armor model with a {@link KnightLibModel} underneath.
 */
public abstract class KnightLibArmorModel extends class_572<class_1309> {

    private final KnightLibModel animationModel;

    protected KnightLibArmorModel(class_630 root) {
        this(root, new VanillaModel(root));
    }

    protected KnightLibArmorModel(class_630 root, KnightLibModel animationModel) {
        super(root);
        this.animationModel = animationModel;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public final void copyPropertiesFrom(class_572<?> source) {
        ((class_572) source).method_2818(this);
    }

    /**
     * Mutable model driven by KnightLib's animation controllers
     */
    public final KnightLibModel animationModel() {
        return animationModel;
    }

    /**
     * Composes the current animation over the current pose supplied by vanilla
     */
    public void composeWithWearer(class_572<?> source, KnightLibPose animatedPose, KnightLibPose restPose) {
        animationModel.resetPose();
        copyPropertiesFrom(source);
        animationModel.applyPoseDelta(animatedPose, restPose);
    }

    /**
     * Shows only the parts that belong to {@code slot}, matching vanilla's own armor visibility
     */
    public void prepareForSlot(class_1304 slot) {
        method_2805(false);

        switch (slot) {
            case field_6169 -> {
                field_3398.field_3665 = true;
                field_3394.field_3665 = true;
            }
            case field_6174 -> {
                field_3391.field_3665 = true;
                field_3401.field_3665 = true;
                field_27433.field_3665 = true;
            }
            case field_6172 -> {
                field_3391.field_3665 = true;
                field_3392.field_3665 = true;
                field_3397.field_3665 = true;
            }
            case field_6166 -> {
                field_3392.field_3665 = true;
                field_3397.field_3665 = true;
            }
            default -> {
                ;;
            }

        }

    }

}