package dev.xylonity.knightlib.client.entity.layer;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxHolder;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxManager;
import dev.xylonity.knightlib.network.packets.BoneHitboxAttackC2S;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.jetbrains.annotations.Nullable;

/**
 * Extends vanilla crosshair picking with animated OBBs that define an
 * {@link dev.xylonity.knightlib.api.entity.hitbox.BoneHitbox#onAttacked} behavior.
 */
public final class BoneHitboxPicker {

    private static @Nullable Selection selection;

    private BoneHitboxPicker() {
        ;;
    }

    public static void pick(class_310 minecraft, float partialTick) {
        selection = null;
        if (minecraft.field_1687 == null || minecraft.field_1761 == null || minecraft.field_1724 == null) {
            return;
        }

        final class_1297 camera = minecraft.method_1560();
        if (camera == null) {
            return;
        }

        final double reach = minecraft.field_1724.method_55755();
        final class_243 start = camera.method_5836(partialTick);
        final class_243 end = start.method_1019(camera.method_5828(partialTick).method_1021(reach));

        final class_239 vanillaHit = minecraft.field_1765;
        final double vanillaDistance = vanillaHit == null ? reach : Math.min(reach, vanillaHit.method_17784().method_1022(start));
        final class_1297 vanillaEntity = vanillaHit instanceof class_3966 entityHit ? entityHit.method_17782() : null;

        class_1297 closestOwner = null;
        BoneHitboxManager.RayHit closestHit = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (final class_1297 entity : minecraft.field_1687.method_18112()) {
            if (entity == camera || entity.method_7325() || !entity.method_5863() || !(entity instanceof BoneHitboxHolder holder)) {
                continue;
            }
            if (entity.method_5707(start) > 32d * 32d) {
                continue;
            }

            final BoneHitboxManager manager = holder.getBoneHitboxManager();
            if (manager == null || manager.getOwner() != entity) {
                continue;
            }
            if (!manager.hasAttackableHitboxes()) {
                continue;
            }

            // Coarse cull to prevent computing the hitbox on non-relevant cases
            final class_238 coarse = entity.method_5829().method_1014(4d);
            if (!coarse.method_1006(start) && coarse.method_992(start, end).isEmpty()) {
                continue;
            }

            // Refreshes the client right before ray tracing so the picked OBBs always match the current interpolated pose
            manager.updateClientPose(partialTick);

            final BoneHitboxManager.RayHit hit = manager.rayTraceAttackable(start, end);
            if (hit == null || hit.distance() >= closestDistance) {
                continue;
            }

            final double obstructionDistance = vanillaEntity == entity ? reach : vanillaDistance;
            if (hit.distance() > obstructionDistance + 1.0E-6) {
                continue;
            }

            closestOwner = entity;
            closestHit = hit;
            closestDistance = hit.distance();
        }

        if (closestOwner == null || closestHit == null) {
            return;
        }

        minecraft.field_1765 = new class_3966(closestOwner, closestHit.location());
        minecraft.field_1692 = closestOwner;
        selection = new Selection(closestOwner.method_5628(), closestHit.hitbox().getBoneName());
    }

    /// Returns whether the crosshair currently targets a bone of the given entity, meaning vanilla
    /// entity attacking must be skipped in favor of (attack(entity))
    public static boolean hasSelection(class_1297 target) {
        final Selection current = selection;
        return current != null && current.entityId() == target.method_5628();
    }

    /// Sends the selected bone attack to the server
    public static void attack(class_1297 target) {
        final Selection current = selection;
        if (current == null || current.entityId() != target.method_5628()) {
            return;
        }

        KnightLib.NET.sendToServer(new BoneHitboxAttackC2S(
                current.entityId(),
                current.boneName()
        ));
    }

    private record Selection(
            int entityId,
            String boneName
    ) {
        ;;
    }

}
