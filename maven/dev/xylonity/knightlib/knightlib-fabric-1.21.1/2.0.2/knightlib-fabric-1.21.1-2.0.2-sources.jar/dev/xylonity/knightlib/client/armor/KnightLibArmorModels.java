package dev.xylonity.knightlib.client.armor;

import dev.xylonity.knightlib.api.client.armor.KnightLibArmorModel;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_630;

/**
 * Loader agnostic registry for vanilla armor model layers. Fabric and Forge fill this table through their own registration hooks.
 */
public final class KnightLibArmorModels {

    private static final Map<class_2960, Definition> DEFINITIONS = new HashMap<>();

    public static void register(class_2960 modelId, class_5601 layer, Function<class_630, KnightLibArmorModel> modelFactory, class_2960 texture) {
        DEFINITIONS.put(
                Objects.requireNonNull(modelId, "modelId"),
                new Definition(
                        Objects.requireNonNull(layer, "layer"),
                        Objects.requireNonNull(modelFactory, "modelFactory"),
                        Objects.requireNonNull(texture, "texture")
                )

        );

    }

    public static Definition get(class_2960 modelId) {
        final Definition definition = DEFINITIONS.get(modelId);
        if (definition == null) {
            throw new IllegalStateException("[KnightLib] Armor model is not registered: " + modelId);
        }

        return definition;
    }

    public record Definition(
            class_5601 layer,
            Function<class_630, KnightLibArmorModel> modelFactory,
            class_2960 texture) {
        ;;
    }

}
