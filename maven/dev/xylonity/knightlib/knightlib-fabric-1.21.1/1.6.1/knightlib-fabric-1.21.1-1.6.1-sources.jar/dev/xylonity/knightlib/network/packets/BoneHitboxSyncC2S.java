package dev.xylonity.knightlib.network.packets;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitbox;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxHolder;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxManager;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import dev.xylonity.knightlib.network.ServerboundPacketType;
import io.netty.handler.codec.DecoderException;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Serverbound packet that syncs bone hitbox transforms from the client renderer to the server.
 */
public record BoneHitboxSyncC2S(
        int entityId,
        Map<String, BoneTransform> transforms
) {

    public static final class_2960 ID = KnightLib.of("bone_hitbox");

    public static final ServerboundPacketType<BoneHitboxSyncC2S> TYPE =
            PacketType.serverbound(
                    ID,
                    BoneHitboxSyncC2S.class,
                    PacketCodec.of(BoneHitboxSyncC2S::encode, BoneHitboxSyncC2S::decode),
                    BoneHitboxSyncC2S::handle
            );

    /**
     * Compact representation of a bone's world-space transform
     */
    public record BoneTransform(
            class_243 position,
            Matrix3f rotation,
            @Nullable class_243 halfExtents
    ) {

        public BoneTransform(class_243 position, Matrix3f rotation) {
            this(position, rotation, null);
        }

        public void encode(class_2540 buf) {
            buf.method_52940(position.field_1352);
            buf.method_52940(position.field_1351);
            buf.method_52940(position.field_1350);
            buf.method_52941(rotation.m00);
            buf.method_52941(rotation.m01);
            buf.method_52941(rotation.m02);
            buf.method_52941(rotation.m10);
            buf.method_52941(rotation.m11);
            buf.method_52941(rotation.m12);
            buf.method_52941(rotation.m20);
            buf.method_52941(rotation.m21);
            buf.method_52941(rotation.m22);
            buf.method_52964(halfExtents != null);
            if (halfExtents != null) {
                buf.method_52941((float) halfExtents.field_1352);
                buf.method_52941((float) halfExtents.field_1351);
                buf.method_52941((float) halfExtents.field_1350);
            }

        }

        public static BoneTransform decode(class_2540 buf) {
            final class_243 position = new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble());
            final Matrix3f rotationMatrix = new Matrix3f(
                    buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat()
            );
            class_243 half = null;
            if (buf.readBoolean()) {
                half = new class_243(buf.readFloat(), buf.readFloat(), buf.readFloat());
            }

            return new BoneTransform(position, rotationMatrix, half);
        }

    }

    public static void encode(BoneHitboxSyncC2S packet, class_2540 buf) {
        buf.method_10804(packet.entityId());
        buf.method_10804(packet.transforms().size());
        for (final Map.Entry<String, BoneTransform> entry : packet.transforms().entrySet()) {
            buf.method_10788(entry.getKey(), 64);
            entry.getValue().encode(buf);
        }

    }

    public static BoneHitboxSyncC2S decode(class_2540 buf) {
        final int entityId = buf.method_10816();
        final int count = buf.method_10816();
        if (count < 0 || count > 256) {
            throw new DecoderException("[KnightLib] Too many bone transforms: " + count);
        }

        final Map<String, BoneTransform> transforms = new HashMap<>(count);
        for (int i = 0; i < count; i++) {
            String boneName = buf.method_10800(64);
            transforms.put(boneName, BoneTransform.decode(buf));
        }

        return new BoneHitboxSyncC2S(entityId, transforms);
    }

    private static void handle(BoneHitboxSyncC2S packet, class_3222 sender) {
        if (sender == null) {
            return;
        }

        final class_1297 entity = sender.method_51469().method_8469(packet.entityId());
        if (entity == null) {
            return;
        }

        if (sender.method_5739(entity) > 128) {
            return;
        }
        if (!(entity instanceof BoneHitboxHolder holder)) {
            return;
        }

        final BoneHitboxManager manager = holder.getBoneHitboxManager();
        if (manager == null) {
            return;
        }

        for (final Map.Entry<String, BoneTransform> entry : packet.transforms().entrySet()) {
            final BoneTransform boneTransform = entry.getValue();

            double distSquare = boneTransform.position().method_1025(entity.method_19538());
            // Caped max distance between entity and the obb hitbox
            if (distSquare > 400) {
                continue;
            }

            // Syncs auto-sized half-extents from client to server
            if (boneTransform.halfExtents() != null) {
                final BoneHitbox hitbox = manager.get(entry.getKey());
                if (hitbox != null) {
                    hitbox.setHalfExtents(boneTransform.halfExtents());
                }

            }

            manager.updateBoneTransform(entry.getKey(), boneTransform.position(), boneTransform.rotation());
        }

    }

}