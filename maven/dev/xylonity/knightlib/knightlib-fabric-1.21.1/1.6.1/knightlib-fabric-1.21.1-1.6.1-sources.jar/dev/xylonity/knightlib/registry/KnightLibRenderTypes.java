package dev.xylonity.knightlib.registry;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_757;

public final class KnightLibRenderTypes {

    public static final class_1921 LINES_SEE_THROUGH = new class_1921(
            "knightlib_editor_lines_see_through",
            class_290.field_29337,
            class_293.class_5596.field_27377,
            1536,
            false,
            false,
            () -> {
                RenderSystem.setShader(class_757::method_34535);
                RenderSystem.enableBlend();
                RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
                RenderSystem.lineWidth(Math.max(2.5f, class_310.method_1551().method_22683().method_4489() / 1920f * 2.5f));
                RenderSystem.disableCull();
                RenderSystem.disableDepthTest();
                RenderSystem.depthMask(false);
            },
            () -> {
                RenderSystem.depthMask(true);
                RenderSystem.enableDepthTest();
                RenderSystem.enableCull();
                RenderSystem.disableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.lineWidth(1f);
            }
    ) {
        ;;
    };

    private KnightLibRenderTypes() {
        ;;
    }

}
