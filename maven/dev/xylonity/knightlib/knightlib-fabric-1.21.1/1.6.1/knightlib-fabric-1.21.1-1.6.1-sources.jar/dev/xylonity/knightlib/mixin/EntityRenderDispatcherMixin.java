package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.entity.hitbox.BoneHitbox;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxHolder;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxManager;
import dev.xylonity.knightlib.api.entity.hitbox.OBB;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {

    @Shadow
    public abstract boolean shouldRenderHitBoxes();

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V",
                    ordinal = 0
            )
    )
    private <E extends class_1297> void knightlib$renderOBBHitboxes(E entity, double x, double y, double z, float rotationYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (!shouldRenderHitBoxes() || entity.method_5767() || class_310.method_1551().method_1555()) {
            return;
        }

        final class_4588 lines = buffer.getBuffer(class_1921.method_23594());

        // Renders the bone hitbox OBBs from the given entity
        if (entity instanceof BoneHitboxHolder hitboxHolder) {
            final BoneHitboxManager manager = hitboxHolder.getBoneHitboxManager();
            if (manager != null && manager.isActive()) {
                for (final BoneHitbox hitbox : manager.getAll()) {
                    if (!hitbox.isEnabled()) {
                        continue;
                    }

                    final OBB obb = hitbox.getCurrentOBB();
                    if (obb == null) {
                        continue;
                    }

                    knightlib$renderOBBHitbox(poseStack, lines, obb,
                            entity.method_23317(), entity.method_23318(), entity.method_23321(),
                            1.0f, 0.0f, 0.0f, 1.0f);
                }

            }

        }

    }

    @Unique
    private static void knightlib$renderOBBHitbox(class_4587 poseStack, class_4588 buffer, OBB obb, double entityX, double entityY, double entityZ, float red, float green, float blue, float alpha) {
        final class_243[] worldCorners = obb.getCorners();
        final float[][] corners = new float[8][3];

        for (int i = 0; i < 8; i++) {
            corners[i][0] = (float) (worldCorners[i].field_1352 - entityX);
            corners[i][1] = (float) (worldCorners[i].field_1351 - entityY);
            corners[i][2] = (float) (worldCorners[i].field_1350 - entityZ);
        }

        final Matrix4f pose = poseStack.method_23760().method_23761();
        final Matrix3f normal = poseStack.method_23760().method_23762();

        // Bottom
        knightlib$renderEdge(buffer, pose, normal, corners[0], corners[1], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[1], corners[5], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[5], corners[4], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[4], corners[0], red, green, blue, alpha);

        // Top
        knightlib$renderEdge(buffer, pose, normal, corners[2], corners[3], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[3], corners[7], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[7], corners[6], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[6], corners[2], red, green, blue, alpha);

        // Vertical edges
        knightlib$renderEdge(buffer, pose, normal, corners[0], corners[2], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[1], corners[3], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[4], corners[6], red, green, blue, alpha);
        knightlib$renderEdge(buffer, pose, normal, corners[5], corners[7], red, green, blue, alpha);
    }

    @Unique
    private static void knightlib$renderEdge(class_4588 buffer, Matrix4f pose, Matrix3f normal, float[] a, float[] b, float red, float green, float blue, float alpha) {
        float nx = b[0] - a[0];
        float ny = b[1] - a[1];
        float nz = b[2] - a[2];
        final float length = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (length > 0) {
            nx /= length;
            ny /= length;
            nz /= length;
        }

        Vector3f normalTransform = normal.transform(new Vector3f(nx, ny, nz));
        buffer.method_22918(pose, a[0], a[1], a[2])
                .method_22915(red, green, blue, alpha)
                .method_22914(normalTransform.x(), normalTransform.y(), normalTransform.z());
        buffer.method_22918(pose, b[0], b[1], b[2])
                .method_22915(red, green, blue, alpha)
                .method_22914(normalTransform.x(), normalTransform.y(), normalTransform.z());
    }

}
