package dev.xylonity.knightlib.common.entity.data.internal;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.entity.data.AttachmentType;
import dev.xylonity.knightlib.api.entity.data.PersistentData;
import dev.xylonity.knightlib.network.packets.AttachmentSyncS2C;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Values are saved in 2 places, serialized inside the entity's persistent data (under {@value #ATTACHMENTS_KEY},
 * and deserialized in a per-entity runtime cache to avoid NBT duplication on hot reloads
 */
public final class AttachmentsInternal {

    // Namespaced because on forge the persistent data root is shared across all mods
    public static final String ATTACHMENTS_KEY = "KnightLibAttachments";

    private AttachmentsInternal() {
        ;;
    }

    @SuppressWarnings("unchecked")
    public static <T> T get(class_1297 entity, AttachmentType<T> type) {
        final Map<class_2960, Object> cache = cacheOf(entity);
        final Object cached = cache.get(type.id());
        if (cached != null) {
            return (T) cached;
        }

        T value = null;

        final class_2487 attachments = attachmentsTag(entity, false);
        if (attachments != null && attachments.method_10545(type.id().toString())) {
            try {
                value = type.serializer().read(attachments.method_10580(type.id().toString()));
            }
            catch (Exception exception) {
                KnightLib.LOGGER.warn("Failed to deserialize attachment {} on entity {}, falling back to default", type.id(), entity.method_5667(), exception);
            }

        }

        if (value == null) {
            value = type.defaultValue();
        }

        cache.put(type.id(), value);
        return value;
    }

    public static <T> void set(class_1297 entity, AttachmentType<T> type, T value) {
        if (value == null) {
            remove(entity, type);
            return;
        }

        cacheOf(entity).put(type.id(), value);

        final class_2520 payload = type.serializer().write(value);
        final class_2487 compoundTag = attachmentsTag(entity, true);
        if (compoundTag != null) {
            compoundTag.method_10566(type.id().toString(), payload);
        }

        sendSync(entity, type, payload);
    }

    public static boolean has(class_1297 entity, AttachmentType<?> type) {
        final class_2487 attachments = attachmentsTag(entity, false);
        return attachments != null && attachments.method_10545(type.id().toString());
    }

    public static void remove(class_1297 entity, AttachmentType<?> type) {
        cacheOf(entity).remove(type.id());

        final class_2487 attachments = attachmentsTag(entity, false);
        if (attachments != null) {
            attachments.method_10551(type.id().toString());
        }

        sendSync(entity, type, null);
    }

    /**
     * Applies a raw synced payload to a (client) entity
     */
    public static void apply(class_1297 entity, AttachmentType<?> type, @Nullable class_2520 payload) {
        final Map<class_2960, Object> cache = cacheOf(entity);

        if (payload == null) {
            cache.remove(type.id());

            final class_2487 attachments = attachmentsTag(entity, false);
            if (attachments != null) {
                attachments.method_10551(type.id().toString());
            }

            return;
        }

        final class_2487 compoundTag = attachmentsTag(entity, true);
        if (compoundTag != null) {
            compoundTag.method_10566(type.id().toString(), payload);
        }

        try {
            cache.put(type.id(), type.serializer().read(payload));
        }
        catch (Exception exception) {
            cache.remove(type.id());
            KnightLib.LOGGER.warn("Failed to deserialize synced attachment {} on entity {}", type.id(), entity.method_5628(), exception);
        }

    }

    /**
     * Sends every stored synced attachment of entity to a single player. Used when a player starts tracking the entity (or for self sync)
     */
    public static void syncAllTo(class_1297 entity, class_3222 player) {
        final class_2487 attachments = attachmentsTag(entity, false);
        if (attachments == null || attachments.method_33133()) {
            return;
        }

        for (final String key : attachments.method_10541()) {
            final class_2960 id = class_2960.method_12829(key);
            if (id == null) {
                continue;
            }

            final AttachmentType<?> type = AttachmentType.byId(id);
            if (type == null || !type.isSynced()) {
                continue;
            }

            KnightLib.NET.sendTo(player, AttachmentSyncS2C.TYPE.base(), new AttachmentSyncS2C(entity.method_5628(), id, attachments.method_10580(key)));
        }

    }

    /**
     * Carries attachments over to the freshly created player on respawn
     */
    public static void copyForRespawn(class_3222 oldPlayer, class_3222 newPlayer, boolean wasDeath) {
        final class_2487 oldAttachments = attachmentsTag(oldPlayer, false);
        if (oldAttachments == null || oldAttachments.method_33133()) {
            return;
        }

        final class_2487 copied = new class_2487();
        for (final String key : oldAttachments.method_10541()) {
            final class_2960 id = class_2960.method_12829(key);
            final AttachmentType<?> type = id == null ? null : AttachmentType.byId(id);

            final boolean keep = !wasDeath || (type != null && type.copiesOnDeath());
            if (keep) {
                final class_2520 oldAttachmentsKey = oldAttachments.method_10580(key);
                if (oldAttachmentsKey != null) {
                    final class_2520 tag = copied.method_10566(key, oldAttachmentsKey);
                    if (tag != null) {
                        tag.method_10707();
                    }

                }


            }

        }

        if (!copied.method_33133()) {
            PersistentData.get(newPlayer).method_10566(ATTACHMENTS_KEY, copied);
        }

    }

    private static <T> void sendSync(class_1297 entity, AttachmentType<T> type, @Nullable class_2520 payload) {
        if (!type.isSynced() || !(entity.method_37908() instanceof class_3218)) {
            return;
        }

        final AttachmentSyncS2C message = new AttachmentSyncS2C(entity.method_5628(), type.id(), payload);

        KnightLib.NET.sendToTracking(entity, AttachmentSyncS2C.TYPE.base(), message);
        if (entity instanceof class_3222 player) {
            KnightLib.NET.sendTo(player, AttachmentSyncS2C.TYPE.base(), message);
        }

    }

    @Nullable
    private static class_2487 attachmentsTag(class_1297 entity, boolean create) {
        final class_2487 root = PersistentData.get(entity);
        if (!root.method_10573(ATTACHMENTS_KEY, class_2487.field_33260)) {
            if (!create) {
                return null;
            }

            root.method_10566(ATTACHMENTS_KEY, new class_2487());
        }

        return root.method_10562(ATTACHMENTS_KEY);
    }

    private static Map<class_2960, Object> cacheOf(class_1297 entity) {
        return ((KnightLibPersistentDataAccessor) entity).knightlib$getAttachmentCache();
    }

}