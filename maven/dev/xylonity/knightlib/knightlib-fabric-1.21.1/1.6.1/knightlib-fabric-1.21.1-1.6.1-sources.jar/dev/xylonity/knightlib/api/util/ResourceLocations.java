package dev.xylonity.knightlib.api.util;

import net.minecraft.class_2960;

/**
 * API for creating ResourceLocations across different versions
 */
@SuppressWarnings("removal")
public final class ResourceLocations {

    public static class_2960 of(String namespace, String path) {
        return class_2960.method_60655(namespace, path);
    }

    public static class_2960 minecraft(String path) {
        return of(class_2960.field_33381, path);
    }

    public static class_2960 parse(String location) {
        return class_2960.method_60654(location);
    }

    public static class_2960 tryBuild(String namespace, String path) {
        try {
            return of(namespace, path);
        }
        catch (RuntimeException exception) {
            return null;
        }

    }

    public static class_2960 tryParse(String location) {
        try {
            return parse(location);
        }
        catch (RuntimeException exception) {
            return null;
        }

    }

}
