package dev.xylonity.knightlib.api.armor;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;

/**
 * Armor material abstraction for fast handling the registration process (that differs between 1.20.1 and 1.21.1, which is a headache)
 *
 * <p>Usage:</p>
 * <pre>{@code
 * public static final KnightLibArmorMaterial MAGE = KnightLibArmorMaterial.builder("mage", Companions.MOD_ID)
 *         .defense(3, 8, 6, 3)
 *         .toughness(2)
 *         .knockbackResistance(0)
 *         .durabilityMultiplier(33)
 *         .enchantmentValue(20)
 *         .equipSound(SoundEvents.ARMOR_EQUIP_DIAMOND)
 *         .repairItem(Items.DIAMOND)
 *         .build();
 * }</pre>
 *
 * <p>Then to receive the actual material, use {@code MAGE.get()}. In 1.21 durability is no longer part of
 * {@link class_1741}, so apply {@link #getDurabilityForType(class_1738.class_8051)} on the {@code Item.Properties} of each piece.</p>
 */
public final class KnightLibArmorMaterial {

    private static final EnumMap<class_1738.class_8051, Integer> BASE_DURABILITY = class_156.method_654(
            new EnumMap<>(class_1738.class_8051.class), enumMap -> {
                enumMap.put(class_1738.class_8051.field_41934, 11);
                enumMap.put(class_1738.class_8051.field_41935, 16);
                enumMap.put(class_1738.class_8051.field_41936, 15);
                enumMap.put(class_1738.class_8051.field_41937, 13);
            }

    );

    private final String name;
    private final EnumMap<class_1738.class_8051, Integer> defense;
    private final float toughness;
    private final float knockbackResistance;
    private final int durabilityMultiplier;
    private final int enchantmentValue;
    private final class_6880<class_3414> equipSound;
    private final Supplier<class_1856> repairIngredient;
    private final class_2960 layerTexture;

    private KnightLibArmorMaterial(Builder builder) {
        this.name = builder.modId + ":" + builder.name;
        this.defense = builder.defense;
        this.toughness = builder.toughness;
        this.knockbackResistance = builder.knockbackResistance;
        this.durabilityMultiplier = builder.durabilityMultiplier;
        this.enchantmentValue = builder.enchantmentValue;
        this.equipSound = builder.equipSound;
        this.repairIngredient = builder.repairIngredient;
        this.layerTexture = class_2960.method_60655(builder.modId, builder.name);
    }

    public class_1741 get() {
        return new class_1741(
                defense,
                enchantmentValue,
                equipSound,
                repairIngredient,
                List.of(new class_1741.class_9196(layerTexture)),
                toughness,
                knockbackResistance
        );

    }

    public String getName() {
        return name;
    }

    public int getDurabilityForType(class_1738.class_8051 type) {
        return BASE_DURABILITY.getOrDefault(type, 0) * durabilityMultiplier;
    }

    public static Builder builder(String name, String modId) {
        return new Builder(name, modId);
    }

    public static final class Builder {

        private final String name;
        private final String modId;
        private final EnumMap<class_1738.class_8051, Integer> defense = new EnumMap<>(class_1738.class_8051.class);
        private float toughness = 0f;
        private float knockbackResistance = 0f;
        private int durabilityMultiplier = 15;
        private int enchantmentValue = 9;
        private class_6880<class_3414> equipSound = class_3417.field_14862;
        private Supplier<class_1856> repairIngredient = () -> class_1856.field_9017;

        private Builder(String name, String modId) {
            this.name = name;
            this.modId = modId;
        }

        /**
         * Sets per-slot defense values
         * @param helmet helmet defense
         * @param chestplate chestplate defense
         * @param leggings leggings defense
         * @param boots boots defense
         */
        public Builder defense(int helmet, int chestplate, int leggings, int boots) {
            defense.put(class_1738.class_8051.field_41934, helmet);
            defense.put(class_1738.class_8051.field_41935, chestplate);
            defense.put(class_1738.class_8051.field_41936, leggings);
            defense.put(class_1738.class_8051.field_41937, boots);
            return this;
        }

        public Builder toughness(float toughness) {
            this.toughness = toughness;
            return this;
        }

        public Builder knockbackResistance(float knockbackResistance) {
            this.knockbackResistance = knockbackResistance;
            return this;
        }

        /**
         * Multiplier applied to the base durability per slot (11/16/15/13)
         */
        public Builder durabilityMultiplier(int durabilityMultiplier) {
            this.durabilityMultiplier = durabilityMultiplier;
            return this;
        }

        public Builder enchantmentValue(int enchantmentValue) {
            this.enchantmentValue = enchantmentValue;
            return this;
        }

        public Builder equipSound(class_6880<class_3414> equipSound) {
            this.equipSound = equipSound;
            return this;
        }

        public Builder repairItem(class_1935 item) {
            this.repairIngredient = () -> class_1856.method_8091(item);
            return this;
        }

        public Builder repairIngredient(Supplier<class_1856> ingredient) {
            this.repairIngredient = ingredient;
            return this;
        }

        public KnightLibArmorMaterial build() {
            return new KnightLibArmorMaterial(this);
        }

    }

}