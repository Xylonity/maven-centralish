package dev.xylonity.knightlib.common.recipe;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.xylonity.knightlib.KnightLib;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9695;
import org.jetbrains.annotations.NotNull;

public record ChaliceFillingRecipe(class_1799 input, class_1799 block) implements class_1860<class_9695> {

    private static final class_2960 ID = KnightLib.of("block_filling");

    public static final class_1865<ChaliceFillingRecipe> SERIALIZER = new Serializer();
    public static final class_3956<ChaliceFillingRecipe> RECIPE_TYPE = new Type();

    @Override
    public boolean method_8115(class_9695 inv, @NotNull class_1937 lvl) {
        return class_1799.method_7984(inv.method_59984(0), input);
    }

    @Override
    public @NotNull class_1799 method_8116(@NotNull class_9695 inv, class_7225.@NotNull class_7874 reg) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_8113(int w, int h) {
        return true;
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.@NotNull class_7874 reg) {
        return class_1799.field_8037;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SERIALIZER;
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return RECIPE_TYPE;
    }

    public static class Type implements class_3956<ChaliceFillingRecipe> {

        @Override
        public String toString() {
            return ID.toString();
        }

    }

    public static class Serializer implements class_1865<ChaliceFillingRecipe> {

        private static final MapCodec<ChaliceFillingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1799.field_51397.fieldOf("input").forGetter(ChaliceFillingRecipe::input),
                class_1799.field_51397.fieldOf("block").forGetter(ChaliceFillingRecipe::block)
        ).apply(inst, ChaliceFillingRecipe::new));

        private static final class_9139<class_9129, ChaliceFillingRecipe> STREAM_CODEC = class_9139.method_56435(
                class_1799.field_48349, ChaliceFillingRecipe::input,
                class_1799.field_48349, ChaliceFillingRecipe::block,
                ChaliceFillingRecipe::new
        );

        @Override
        public @NotNull MapCodec<ChaliceFillingRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public @NotNull class_9139<class_9129, ChaliceFillingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }

}
