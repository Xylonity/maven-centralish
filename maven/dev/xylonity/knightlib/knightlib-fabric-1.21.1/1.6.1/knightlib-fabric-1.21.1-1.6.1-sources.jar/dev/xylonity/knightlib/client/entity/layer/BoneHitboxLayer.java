package dev.xylonity.knightlib.client.entity.layer;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitbox;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxHolder;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxManager;
import dev.xylonity.knightlib.network.packets.BoneHitboxSyncC2S;
import org.joml.Matrix3f;
import org.joml.Vector3d;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.cache.object.GeoCube;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

import java.util.*;
import java.util.function.Function;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * A GeoRenderLayer that extracts bone world-space transforms during rendering and syncs them to the server for OBB collision detection
 * <p>
 * <pre>{@code
 * public class TestEntityRenderer extends GeoEntityRenderer<TestEntity> {
 *     public TestEntityRenderer(EntityRendererProvider.Context context) {
 *         super(context, new TestEntityModel());
 *         addRenderLayer(new BoneHitboxLayer<>(this, TestEntity::getBoneHitboxManager));
 *     }
 *
 * }</pre>
 */
public class BoneHitboxLayer<T extends class_1309 & GeoAnimatable & BoneHitboxHolder> extends GeoRenderLayer<T> {

    private final Function<T, BoneHitboxManager> managerGetter;
    private final Map<String, BoneHitboxSyncC2S.BoneTransform> pendingTransforms = new HashMap<>();
    private int lastSyncTick = -1;

    public BoneHitboxLayer(GeoRenderer<T> renderer, Function<T, BoneHitboxManager> managerGetter) {
        super(renderer);
        this.managerGetter = managerGetter;
    }

    /**
     * Enables matrix tracking on all hitbox bones before GeckoLib processes them
     */
    @Override
    public void preRender(class_4587 poseStack, T animatable, BakedGeoModel bakedModel, class_1921 renderType, class_4597 bufferSource, class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        final BoneHitboxManager manager = managerGetter.apply(animatable);
        if (manager == null || !manager.isActive()) {
            return;
        }

        final Set<String> tracked = manager.getTrackedBoneNames();
        if (tracked.isEmpty()) {
            return;
        }

        for (final GeoBone topBone : bakedModel.topLevelBones()) {
            enableTrackingRecursive(topBone, tracked);
        }
    }

    private static void enableTrackingRecursive(GeoBone bone, Set<String> trackedNames) {
        if (trackedNames.contains(bone.getName())) {
            bone.setTrackingMatrices(true);
        }
        for (final GeoBone childBone : bone.getChildBones()) {
            enableTrackingRecursive(childBone, trackedNames);
        }

    }

    @Override
    public void renderForBone(class_4587 poseStack, T animatable, GeoBone bone, class_1921 renderType, class_4597 bufferSource, class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        final BoneHitboxManager manager = managerGetter.apply(animatable);
        if (manager == null || !manager.isActive()) {
            return;
        }

        final Set<String> tracked = manager.getTrackedBoneNames();
        if (!tracked.contains(bone.getName())) {
            return;
        }

        final BoneHitbox hitbox = manager.get(bone.getName());
        if (hitbox != null && hitbox.isAutoSize() && hitbox.getBaseHalfExtents() == null) {
            computeAutoSize(hitbox, bone);
        }

        // World-space position of the bone
        final Vector3d worldPosition = bone.getWorldPosition();

        // Extracts rotation (3x3) from the model matrix
        final Matrix3f boneRotation = new Matrix3f();
        bone.getModelSpaceMatrix().get3x3(boneRotation);

        // Extracts the scale (column lengths) before normalizing
        final float scaleX = columnLength(boneRotation, 0);
        final float scaleY = columnLength(boneRotation, 1);
        final float scaleZ = columnLength(boneRotation, 2);

        // Applies bone scale to the base half-extents
        if (hitbox != null) {
            hitbox.applyScale(scaleX, scaleY, scaleZ);
        }

        // Removes scaling from the rotation matrix
        normalizeColumns(boneRotation);

        // Applies entity body yaw to align with world orientation
        final float bodyYaw = class_3532.method_17821(partialTick, animatable.field_6220, animatable.field_6283);
        final Matrix3f rotation = new Matrix3f().rotateY((float) Math.toRadians(180.0 - bodyYaw));
        rotation.mul(boneRotation);

        final class_243 position = new class_243(worldPosition.x, worldPosition.y, worldPosition.z);

        // Updates the manager with the computed data
        manager.updateBoneTransform(bone.getName(), position, rotation);

        // Includes the current half-extents in sync packet (the server needs them for autosized
        // hitboxes, and they change each frame when bone scale is animated)
        final class_243 halfExtents = (hitbox != null) ? hitbox.getHalfExtents() : null;
        pendingTransforms.put(bone.getName(), new BoneHitboxSyncC2S.BoneTransform(position, rotation, halfExtents));
    }

    @Override
    public void render(class_4587 poseStack, T animatable, BakedGeoModel bakedModel, class_1921 renderType, class_4597 bufferSource, class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        if (pendingTransforms.isEmpty()) {
            return;
        }

        // Sends a sync packet to the server with the bb info of the hitbox
        final int currentTick = animatable.field_6012;
        if (currentTick != lastSyncTick) {
            lastSyncTick = currentTick;
            KnightLib.NET.sendToServer(new BoneHitboxSyncC2S(animatable.method_5628(), new HashMap<>(pendingTransforms)));
        }

        pendingTransforms.clear();
    }

    /**
     * Computes the base half-extents for an auto-sized hitbox by enclosing all cubes of the bone
     */
    private static void computeAutoSize(BoneHitbox hitbox, GeoBone bone) {
        final List<GeoCube> cubes = bone.getCubes();
        if (cubes.isEmpty()) {
            hitbox.setBaseHalfExtents(new class_243(0.1, 0.1, 0.1));
            return;
        }

        double maxX = 0;
        double maxY = 0;
        double maxZ = 0;
        for (final GeoCube cube : cubes) {
            final class_243 size = cube.size();
            final double hx = (size.field_1352 / 2.0) / 16.0;
            final double hy = (size.field_1351 / 2.0) / 16.0;
            final double hz = (size.field_1350 / 2.0) / 16.0;
            maxX = Math.max(maxX, hx);
            maxY = Math.max(maxY, hy);
            maxZ = Math.max(maxZ, hz);
        }

        hitbox.setBaseHalfExtents(new class_243(maxX, maxY, maxZ));
    }

    /**
     * Returns the length of the specified column of a 3x3 matrix
     */
    private static float columnLength(Matrix3f matrix, int column) {
        return switch (column) {
            case 0 -> (float) Math.sqrt(matrix.m00 * matrix.m00 + matrix.m01 * matrix.m01 + matrix.m02 * matrix.m02);
            case 1 -> (float) Math.sqrt(matrix.m10 * matrix.m10 + matrix.m11 * matrix.m11 + matrix.m12 * matrix.m12);
            case 2 -> (float) Math.sqrt(matrix.m20 * matrix.m20 + matrix.m21 * matrix.m21 + matrix.m22 * matrix.m22);
            default -> 1f;
        };

    }

    /**
     * Normalizes the columns of a 3x3 rotation matrix to remove any scale factor
     */
    private static void normalizeColumns(Matrix3f matrix) {
        float len0 = columnLength(matrix, 0);
        float len1 = columnLength(matrix, 1);
        float len2 = columnLength(matrix, 2);

        if (len0 > 1e-6f) {
            matrix.m00 /= len0;
            matrix.m01 /= len0;
            matrix.m02 /= len0;
        }
        if (len1 > 1e-6f) {
            matrix.m10 /= len1;
            matrix.m11 /= len1;
            matrix.m12 /= len1;
        }
        if (len2 > 1e-6f) {
            matrix.m20 /= len2;
            matrix.m21 /= len2;
            matrix.m22 /= len2;
        }
    }

}