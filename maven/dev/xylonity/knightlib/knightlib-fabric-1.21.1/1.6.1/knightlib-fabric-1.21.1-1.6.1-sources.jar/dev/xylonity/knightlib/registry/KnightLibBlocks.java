package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class KnightLibBlocks {

    public static final ResourceRegistry<class_2248> BLOCKS = ResourceDispatcher.create(class_7923.field_41175, KnightLib.MOD_ID);

    public static final ResourceEntry<class_2248> GREAT_CHALICE =
            BLOCKS.register("great_chalice",
                    KnightLib.PLATFORM.createBlock("great_chalice",
                            class_4970.class_2251.method_9637()
                                    .method_31710(class_3620.field_15987)
                                    .method_9629(3f, 6f)
                                    .method_29292()
                                    .method_9626(class_2498.field_27204)
                                    .method_22488(),
                            BlockType.GREAT_CHALICE
                    )
            );

    public enum BlockType {
        GREAT_CHALICE
    }

}
