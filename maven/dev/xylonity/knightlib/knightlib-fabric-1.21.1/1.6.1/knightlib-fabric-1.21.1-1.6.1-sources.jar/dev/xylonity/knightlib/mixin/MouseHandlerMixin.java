package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.client.ClientMouseScrollEvent;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseHandlerMixin {

    @Final
    @Shadow
    private class_310 minecraft;

    @Inject(method = "onScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void knightlib$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        if (window != minecraft.method_22683().method_4490() || minecraft.field_1755 != null || minecraft.field_1724 == null) {
            return;
        }

        final ClientMouseScrollEvent event = new ClientMouseScrollEvent(minecraft, yOffset);
        KnightLibEvents.CLIENT.dispatch(event);

        if (event.isCancelled()) {
            ci.cancel();
        }

    }

}
