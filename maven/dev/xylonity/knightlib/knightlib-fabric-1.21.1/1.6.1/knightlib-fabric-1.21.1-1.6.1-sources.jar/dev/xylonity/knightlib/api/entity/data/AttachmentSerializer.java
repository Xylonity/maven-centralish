package dev.xylonity.knightlib.api.entity.data;

import java.util.UUID;
import java.util.function.Function;
import net.minecraft.class_2338;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2495;
import net.minecraft.class_2497;
import net.minecraft.class_2503;
import net.minecraft.class_2512;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

/**
 * Bridges an attachment value {@code T} and its NBT representation.
 * <br><br>
 * Common primitive serializers are provided as constants. For non-trivial definitions, a function call is probably needed here
 *
 * @see AttachmentType
 */
public interface AttachmentSerializer<T> {

    class_2520 write(T value);

    T read(class_2520 tag);

    AttachmentSerializer<Integer> INT = of(class_2497::method_23247, tag -> ((class_2514) tag).method_10701());
    AttachmentSerializer<Long> LONG = of(class_2503::method_23251, tag -> ((class_2514) tag).method_10699());
    AttachmentSerializer<Float> FLOAT = of(class_2494::method_23244, tag -> ((class_2514) tag).method_10700());
    AttachmentSerializer<Double> DOUBLE = of(class_2489::method_23241, tag -> ((class_2514) tag).method_10697());
    AttachmentSerializer<Boolean> BOOLEAN = of(value -> class_2481.method_23233(value ? (byte) 1 : (byte) 0), tag -> ((class_2514) tag).method_10698() != 0);
    AttachmentSerializer<String> STRING = of(class_2519::method_23256, class_2520::method_10714);
    AttachmentSerializer<class_2487> COMPOUND = of(class_2487::method_10553, tag -> ((class_2487) tag).method_10553());
    AttachmentSerializer<UUID> UUID_VALUE = of(class_2512::method_25929, class_2512::method_25930);
    AttachmentSerializer<class_2338> BLOCK_POS = of(class_2512::method_10692, tag -> {
        final int[] values = ((class_2495) tag).method_10588();
        return new class_2338(values[0], values[1], values[2]);
    });

    /**
     * Helper to build a serializer for method references
     */
    static <T> AttachmentSerializer<T> of(Function<T, class_2520> writer, Function<class_2520, T> reader) {
        return new AttachmentSerializer<>() {

            @Override
            public class_2520 write(T value) {
                return writer.apply(value);
            }

            @Override
            public T read(class_2520 tag) {
                return reader.apply(tag);
            }

        };

    }

}
