package dev.xylonity.knightlib.client.platform;

import net.minecraft.class_1087;
import net.minecraft.class_2960;

public interface KnightLibClientPlatform {

    class_1087 getAdditionalModel(class_2960 modelLocation);

}
