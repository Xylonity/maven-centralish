package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1297;
import net.minecraft.class_3222;

/**
 * Fired when a player starts tracking an entity (the entity enters the player's view distance)
 */
public final class PlayerStartTrackingEvent extends KnightLibEvent {

    private final class_3222 player;
    private final class_1297 target;

    public PlayerStartTrackingEvent(class_3222 player, class_1297 target) {
        this.player = player;
        this.target = target;
    }

    public class_3222 getPlayer() {
        return player;
    }

    public class_1297 getTarget() {
        return target;
    }

}
