package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import dev.xylonity.knightlib.network.ServerboundPacketType;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

@SuppressWarnings("unchecked")
public class KnightLibNetworkFabric implements KnightLibNetwork {

    private final Map<class_2960, class_8710.class_9154<KnightLibPayload>> typeById = new ConcurrentHashMap<>();
    private final Map<Class<?>, class_2960> classToId = new ConcurrentHashMap<>();

    @Override
    public KnightLibNetwork createEndpoint(String modId, String protocol) {
        return this;
    }

    @Override
    public <T> void registerClientbound(PacketType<T> type, Consumer<T> clientHandler) {
        final class_8710.class_9154<KnightLibPayload> payloadType = memoize(type);
        PayloadTypeRegistry.playS2C().register(payloadType, streamCodec(payloadType, type.codec()));

        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            registerClientReceiver(payloadType, clientHandler);
        }

    }

    @Override
    public <T> void registerServerbound(PacketType<T> type, BiConsumer<T, class_3222> serverHandler) {
        final class_8710.class_9154<KnightLibPayload> payloadType = memoize(type);
        PayloadTypeRegistry.playC2S().register(payloadType, streamCodec(payloadType, type.codec()));

        ServerPlayNetworking.registerGlobalReceiver(payloadType, (payload, context) ->
                serverHandler.accept((T) payload.message(), context.player()));
    }

    @Override
    public <T> void register(ClientboundPacketType<T> type) {
        this.registerClientbound(type.base(), type.handler());
    }

    @Override
    public <T> void register(ServerboundPacketType<T> type) {
        this.registerServerbound(type.base(), type.handler());
    }

    @Override
    public <T> void sendToServer(T message) {
        if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT) {
            KnightLib.LOGGER.warn("[KnightLib] sendToServer called on the dedicated server for {}", message.getClass().getName());
            return;
        }

        final class_2960 id = classToId.get(message.getClass());
        if (id == null) {
            throw new IllegalStateException("[KnightLib] No packet registered for message: " + message.getClass().getName());
        }

        ClientPlayNetworking.send(new KnightLibPayload(typeById.get(id), message));
    }

    @Override
    public <T> void sendTo(class_3222 player, PacketType<T> type, T message) {
        if (player == null) {
            return;
        }

        ServerPlayNetworking.send(player, new KnightLibPayload(typeById.get(type.id()), message));
    }

    @Override
    public <T> void sendToAll(MinecraftServer server, PacketType<T> type, T message) {
        if (server == null) {
            return;
        }

        for (final class_3222 player : PlayerLookup.all(server)) {
            ServerPlayNetworking.send(player, new KnightLibPayload(typeById.get(type.id()), message));
        }
    }

    @Override
    public <T> void sendToPlayers(class_1937 level, PacketType<T> type, T message) {
        if (!(level instanceof class_3218 serverLevel)) {
            return;
        }

        for (final class_3222 player : PlayerLookup.world(serverLevel)) {
            ServerPlayNetworking.send(player, new KnightLibPayload(typeById.get(type.id()), message));
        }
    }

    @Override
    public <T> void sendToTracking(class_1937 level, class_2338 pos, PacketType<T> type, T message) {
        if (!(level instanceof class_3218 serverLevel)) {
            return;
        }

        for (final class_3222 player : PlayerLookup.tracking(serverLevel, pos)) {
            ServerPlayNetworking.send(player, new KnightLibPayload(typeById.get(type.id()), message));
        }
    }

    @Override
    public <T> void sendToTracking(class_1297 entity, PacketType<T> type, T message) {
        if (!(entity.method_37908() instanceof class_3218)) {
            return;
        }

        for (final class_3222 player : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(player, new KnightLibPayload(typeById.get(type.id()), message));
        }
    }

    private <T> class_8710.class_9154<KnightLibPayload> memoize(PacketType<T> type) {
        classToId.put(type.clazz(), type.id());
        return typeById.computeIfAbsent(type.id(), class_8710.class_9154::new);
    }

    private <T> class_9139<class_9129, KnightLibPayload> streamCodec(class_8710.class_9154<KnightLibPayload> payloadType, PacketCodec<T> codec) {
        return class_9139.method_56437(
                (buf, payload) -> codec.encode((T) payload.message(), buf),
                buf -> new KnightLibPayload(payloadType, codec.decode(buf))
        );

    }

    private <T> void registerClientReceiver(class_8710.class_9154<KnightLibPayload> payloadType, Consumer<T> clientHandler) {
        ClientPlayNetworking.registerGlobalReceiver(payloadType, (payload, context) ->
                clientHandler.accept((T) payload.message()));
    }

    private record KnightLibPayload(
            class_9154<KnightLibPayload> type,
            Object message
    ) implements class_8710 {
        ;;
    }

}
