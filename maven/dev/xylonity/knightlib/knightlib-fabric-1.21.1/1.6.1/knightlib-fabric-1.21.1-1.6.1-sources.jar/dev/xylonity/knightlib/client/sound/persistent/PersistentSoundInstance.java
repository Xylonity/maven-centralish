package dev.xylonity.knightlib.client.sound.persistent;

import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/**
 * Tickable sound instance that tracks an entity's position and supports volume fade in/out.
 */
public final class PersistentSoundInstance extends class_1101 {

    private final class_1297 entity;
    private final float baseVolume;

    private float targetVolume;
    private float volumeStep;
    private boolean fadingOut;

    public PersistentSoundInstance(class_3414 event, class_3419 source, class_1297 entity, float volume, float pitch) {
        super(event, source, class_1113.method_43221());
        this.entity = entity;
        this.baseVolume = volume;
        this.targetVolume = volume;
        this.field_5446 = true;
        this.field_5451 = 0;
        this.field_5442 = volume;
        this.field_5441 = pitch;
        this.field_5439 = (float) entity.method_23317();
        this.field_5450 = (float) entity.method_23320();
        this.field_5449 = (float) entity.method_23321();
    }

    @Override
    public void method_16896() {
        if (entity.method_31481()) {
            this.method_24876();
            return;
        }

        this.field_5439 = (float) entity.method_23317();
        this.field_5450 = (float) entity.method_23320();
        this.field_5449 = (float) entity.method_23321();

        if (this.field_5442 != targetVolume) {
            this.field_5442 += volumeStep;

            boolean overshot = (volumeStep > 0)
                    ? this.field_5442 >= targetVolume
                    : this.field_5442 <= targetVolume;

            if (overshot) {
                this.field_5442 = targetVolume;
            }

            if (fadingOut && this.field_5442 <= 0.0f) {
                this.field_5442 = 0.0f;
                this.method_24876();
            }

        }

    }

    public void fadeIn(int ticks) {
        if (ticks <= 0) {
            this.field_5442 = baseVolume;
            this.targetVolume = baseVolume;
            return;
        }

        this.field_5442 = 0f;
        this.targetVolume = baseVolume;
        this.volumeStep = baseVolume / ticks;
        this.fadingOut = false;
    }

    public boolean fadeOut(int ticks) {
        if (method_4793()) {
            return false;
        }

        if (ticks <= 0) {
            this.method_24876();
            return true;
        }

        this.targetVolume = 0.0f;
        this.volumeStep = -(this.field_5442 / ticks);
        this.fadingOut = true;
        return true;
    }

    public boolean isFadingOut() {
        return fadingOut;
    }

    public void stopImmediately() {
        this.method_24876();
    }

}