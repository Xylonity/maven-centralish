package dev.xylonity.knightlib.client.screen.camera;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

/**
 * Camera editor additional params and color specs
 */
public final class CameraEditorWidgets {

    public static final int ACCENT = 0xFFE8C04A;

    private static final int TEXT = 0xFFE2E6EE;
    private static final int TEXT_FAINT = 0xFF565E6E;

    private static final int FILL = 0xE8161923;
    private static final int FILL_HOVER = 0xF0232837;
    private static final int BORDER = 0xFF3A4152;
    private static final int BORDER_HOVER = 0xFF57617A;

    private static final int PRIMARY_FILL = 0xE82B2312;
    private static final int PRIMARY_FILL_HOVER = 0xF03D311A;
    private static final int PRIMARY_BORDER = 0xFF8A742F;
    private static final int PRIMARY_BORDER_HOVER = 0xFFC7A83E;
    private static final int PRIMARY_TEXT = 0xFFF0D178;

    private static final int DANGER_FILL = 0xE8231318;
    private static final int DANGER_FILL_HOVER = 0xF0361B23;
    private static final int DANGER_BORDER = 0xFF5C2B34;
    private static final int DANGER_BORDER_HOVER = 0xFF95434F;
    private static final int DANGER_TEXT = 0xFFFF7A85;

    private CameraEditorWidgets() {
        ;;
    }

    private static int fillFor(Style style, boolean hover) {
        return switch (style) {
            case NORMAL -> hover ? FILL_HOVER : FILL;
            case PRIMARY -> hover ? PRIMARY_FILL_HOVER : PRIMARY_FILL;
            case DANGER -> hover ? DANGER_FILL_HOVER : DANGER_FILL;
        };

    }

    private static int borderFor(Style style, boolean hover) {
        return switch (style) {
            case NORMAL -> hover ? BORDER_HOVER : BORDER;
            case PRIMARY -> hover ? PRIMARY_BORDER_HOVER : PRIMARY_BORDER;
            case DANGER -> hover ? DANGER_BORDER_HOVER : DANGER_BORDER;
        };

    }

    private static int textFor(Style style, boolean active) {
        if (!active) {
            return TEXT_FAINT;
        }

        return switch (style) {
            case NORMAL -> TEXT;
            case PRIMARY -> PRIMARY_TEXT;
            case DANGER -> DANGER_TEXT;
        };

    }

    private static void drawBox(class_332 graphics, int x, int y, int width, int height, int fill, int border) {
        graphics.method_25294(x, y, x + width, y + height, fill);
        graphics.method_25294(x, y, x + width, y + 1, border);
        graphics.method_25294(x, y + height - 1, x + width, y + height, border);
        graphics.method_25294(x, y, x + 1, y + height, border);
        graphics.method_25294(x + width - 1, y, x + width, y + height, border);
    }

    /**
     * A flat push button
     */
    public static class FlatButton extends class_4264 {

        private final Style style;
        private final Runnable onPress;

        public FlatButton(int x, int y, int width, int height, class_2561 message, Style style, Runnable onPress) {
            super(x, y, width, height, message);

            this.style = style;
            this.onPress = onPress;
        }

        @Override
        public void method_25306() {
            onPress.run();
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            final boolean hover = field_22763 && method_25367();

            drawBox(graphics, method_46426(), method_46427(), field_22758, field_22759, fillFor(style, hover), borderFor(style, hover));

            final class_327 font = class_310.method_1551().field_1772;
            graphics.method_51439(font, method_25369(), method_46426() + (field_22758 - font.method_27525(method_25369())) / 2, method_46427() + (field_22759 - 8) / 2, textFor(style, field_22763), false);
        }

        @Override
        protected void method_47399(class_6382 output) {
            method_37021(output);
        }

    }

    /**
     * An on/off pill with a state dot
     */
    public static class FlatToggle extends class_4264 {

        private final Consumer<Boolean> onChange;
        private boolean value;

        public FlatToggle(int x, int y, int width, int height, class_2561 label, boolean initial, Consumer<Boolean> onChange) {
            super(x, y, width, height, label);

            this.value = initial;
            this.onChange = onChange;
        }

        public static int widthFor(class_327 font, String label) {
            return font.method_1727(label) + 22;
        }

        @Override
        public void method_25306() {
            value = !value;
            onChange.accept(value);
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            final boolean hover = field_22763 && method_25367();
            final Style style = value ? Style.PRIMARY : Style.NORMAL;

            drawBox(graphics, method_46426(), method_46427(), field_22758, field_22759, fillFor(style, hover), borderFor(style, hover));

            final int dotY = method_46427() + field_22759 / 2 - 2;
            graphics.method_25294(method_46426() + 5, dotY, method_46426() + 9, dotY + 4, !field_22763 ? TEXT_FAINT : (value ? ACCENT : TEXT_FAINT));

            final class_327 font = class_310.method_1551().field_1772;
            graphics.method_51439(font, method_25369(), method_46426() + 13, method_46427() + (field_22759 - 8) / 2, textFor(style, field_22763), false);
        }

        @Override
        protected void method_47399(class_6382 output) {
            method_37021(output);
        }

    }

    /**
     * Integer tick slider with a label
     */
    public static class FlatSlider extends class_357 {

        private final String label;
        private final String suffix;
        private final int min;
        private final int max;
        private final IntConsumer onChange;

        public FlatSlider(int x, int y, int width, int height, String label, int min, int max, int initial, IntConsumer onChange, String suffix) {
            super(x, y, width, height, class_2561.method_43473(), (class_3532.method_15340(initial, min, max) - min) / (double) (max - min));

            this.label = label;
            this.suffix = suffix;
            this.min = min;
            this.max = max;
            this.onChange = onChange;

            method_25346();
        }

        private int currentTicks() {
            return min + (int) Math.round(field_22753 * (max - min));
        }

        @Override
        protected void method_25346() {
            method_25355(class_2561.method_43470(label + ": " + currentTicks() + "t" + suffix));
        }

        @Override
        protected void method_25344() {
            onChange.accept(currentTicks());
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            final boolean hover = field_22763 && method_25367();

            drawBox(graphics, method_46426(), method_46427(), field_22758, field_22759, fillFor(Style.NORMAL, hover), borderFor(Style.NORMAL, hover));

            final int travel = field_22758 - 4;
            final int fillWidth = (int) Math.round(field_22753 * travel);

            if (fillWidth > 0) {
                graphics.method_25294(method_46426() + 2, method_46427() + field_22759 - 4, method_46426() + 2 + fillWidth, method_46427() + field_22759 - 2, 0x66E8C04A);
            }

            final int handleX = class_3532.method_15340(method_46426() + 2 + fillWidth, method_46426() + 2, method_46426() + field_22758 - 3);
            graphics.method_25294(handleX, method_46427() + 2, handleX + 1, method_46427() + field_22759 - 2, hover ? ACCENT : 0xFFB9C0CF);

            final class_327 font = class_310.method_1551().field_1772;
            graphics.method_51439(font, method_25369(), method_46426() + (field_22758 - font.method_27525(method_25369())) / 2, method_46427() + (field_22759 - 8) / 2, textFor(Style.NORMAL, field_22763), false);
        }

    }

    public enum Style {
        NORMAL,
        PRIMARY,
        DANGER
    }

}