package dev.xylonity.knightlib.client.camera.editor;

import dev.xylonity.knightlib.api.camera.path.impl.CameraKeyframe;
import dev.xylonity.knightlib.api.util.KnightLibEasings;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

/**
 * Mutable keyframe of the client-side editor session. Null tangents mean "auto" (the CR spline is drawn automatically)
 */
public final class EditorKeyframe {

    public class_243 position;
    public float yaw;
    public float pitch;

    public int durationTicks;
    public KnightLibEasings easing;
    public boolean chained = false;

    @Nullable
    public class_243 inTangent;
    @Nullable
    public class_243 outTangent;
    public boolean linkedHandles = true;

    public EditorKeyframe(class_243 position, float yaw, float pitch, int durationTicks, KnightLibEasings easing) {
        this.position = position;
        this.yaw = yaw;
        this.pitch = pitch;
        this.durationTicks = durationTicks;
        this.easing = easing;
    }

    public boolean hasCustomTangents() {
        return inTangent != null || outTangent != null;
    }

    public void resetTangents() {
        inTangent = null;
        outTangent = null;
    }

    /**
     * Sets the outgoing tangent from a dragged handle position
     */
    public void dragOutHandle(class_243 handlePosition) {
        final class_243 tangent = handlePosition.method_1020(position).method_1021(3.0);

        outTangent = tangent;
        if (linkedHandles) {
            inTangent = tangent;
        }

    }

    /**
     * Sets the incoming tangent from a dragged handle position
     */
    public void dragInHandle(class_243 handlePosition) {
        final class_243 tangent = position.method_1020(handlePosition).method_1021(3.0);

        inTangent = tangent;
        if (linkedHandles) {
            outTangent = tangent;
        }

    }

    /**
     * Expands/shrinks the outgoing tangent in place
     */
    public void scaleOutTangent(double factor, class_243 resolvedOut) {
        final class_243 tangent = resolvedOut.method_1021(factor);

        outTangent = tangent;
        if (linkedHandles) {
            inTangent = tangent;
        }

    }

    /**
     * Expands/shrinks the incoming tangent in place
     */
    public void scaleInTangent(double factor, class_243 resolvedIn) {
        final class_243 tangent = resolvedIn.method_1021(factor);

        inTangent = tangent;
        if (linkedHandles) {
            outTangent = tangent;
        }

    }

    public CameraKeyframe toImmutable() {
        return new CameraKeyframe(position, yaw, pitch, durationTicks, easing, chained, inTangent, outTangent);
    }

}