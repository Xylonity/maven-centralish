package dev.xylonity.knightlib.client.platform;

import net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class KnightLibClientPlatformFabric implements KnightLibClientPlatform {

    @Override
    public class_1087 getAdditionalModel(class_2960 modelLocation) {
        final class_1092 modelManager = class_310.method_1551().method_1554();
        final class_1087 model = ((FabricBakedModelManager) modelManager).getModel(modelLocation);
        return model != null ? model : modelManager.method_4744();
    }

}
