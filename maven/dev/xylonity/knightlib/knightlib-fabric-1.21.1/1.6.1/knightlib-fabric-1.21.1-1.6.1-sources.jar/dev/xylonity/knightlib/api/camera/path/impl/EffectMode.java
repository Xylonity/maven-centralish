package dev.xylonity.knightlib.api.camera.path.impl;

import net.minecraft.class_3532;

/**
 * Intensity shape of an {@link EffectKeyframe} window over its tick range
 */
public enum EffectMode {
    IN(0),
    OUT(1),
    FULL(2),
    HOLD(3);

    private final int id;

    EffectMode(int id) {
        this.id = id;
    }

    public int id() {
        return id;
    }

    /**
     * Intensity at a normalized progress through the window
     */
    public float intensityAt(float progress) {
        final float clampedProgress = class_3532.method_15363(progress, 0f, 1f);
        return switch (this) {
            case IN -> 0.5f + 0.5f * class_3532.method_15362((float) Math.PI * clampedProgress);
            case OUT -> 0.5f - 0.5f * class_3532.method_15362((float) Math.PI * clampedProgress);
            case FULL -> class_3532.method_15374((float) Math.PI * clampedProgress);
            case HOLD -> 1f;
        };

    }

    public static EffectMode byId(int id) {
        for (final EffectMode mode : values()) {
            if (mode.id == id) {
                return mode;
            }

        }

        return FULL;
    }

}
