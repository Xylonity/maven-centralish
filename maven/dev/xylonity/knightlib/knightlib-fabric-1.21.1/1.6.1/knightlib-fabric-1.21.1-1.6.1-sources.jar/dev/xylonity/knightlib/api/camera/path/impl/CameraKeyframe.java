package dev.xylonity.knightlib.api.camera.path.impl;

import dev.xylonity.knightlib.api.util.KnightLibEasings;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import org.jetbrains.annotations.Nullable;

/**
 * A single point of a {@link CameraPath}.
 *
 * @param position absolute world position of the camera
 * @param yaw camera yaw in degrees
 * @param pitch camera pitch in degrees
 * @param durationTicks time to travel from the previous keyframe to this one
 * @param easing easing applied to the travel of this segment (for chained runs, the easing of the run's first segment wins)
 * @param chained whether the easing flows through this keyframe from the previous segment
 * @param inTangent velocity of the curve arriving at this keyframe
 * @param outTangent velocity of the curve leaving this keyframe
 */
public record CameraKeyframe(
        class_243 position,
        float yaw,
        float pitch,
        int durationTicks,
        KnightLibEasings easing,
        boolean chained,
        @Nullable class_243 inTangent,
        @Nullable class_243 outTangent
) {

    public CameraKeyframe {
        durationTicks = Math.max(0, durationTicks);
        easing = (easing == null) ? KnightLibEasings.SMOOTHSTEP : easing;
    }

    public CameraKeyframe(class_243 position, float yaw, float pitch, int durationTicks, KnightLibEasings easing) {
        this(position, yaw, pitch, durationTicks, easing, false, null, null);
    }

    public void encode(class_2540 buf) {
        buf.method_52940(position.field_1352);
        buf.method_52940(position.field_1351);
        buf.method_52940(position.field_1350);

        buf.method_52941(yaw);
        buf.method_52941(pitch);

        buf.method_10804(durationTicks);
        buf.method_10804(easing.id());
        buf.method_52964(chained);

        encodeTangent(buf, inTangent);
        encodeTangent(buf, outTangent);
    }

    public static CameraKeyframe decode(class_2540 buf) {
        final class_243 position = new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble());

        final float yaw = buf.readFloat();
        final float pitch = buf.readFloat();

        final int durationTicks = buf.method_10816();
        final KnightLibEasings easing = KnightLibEasings.byId(buf.method_10816());
        final boolean chained = buf.readBoolean();

        final class_243 inTangent = decodeTangent(buf);
        final class_243 outTangent = decodeTangent(buf);

        return new CameraKeyframe(position, yaw, pitch, durationTicks, easing, chained, inTangent, outTangent);
    }

    private static void encodeTangent(class_2540 buf, @Nullable class_243 tangent) {
        buf.method_52964(tangent != null);
        if (tangent != null) {
            buf.method_52940(tangent.field_1352);
            buf.method_52940(tangent.field_1351);
            buf.method_52940(tangent.field_1350);
        }

    }

    @Nullable
    private static class_243 decodeTangent(class_2540 buf) {
        return buf.readBoolean() ? new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble()) : null;
    }

}