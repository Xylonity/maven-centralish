package dev.xylonity.knightlib.common.item.blockitem;

import dev.xylonity.knightlib.client.item.renderer.GenericBlockItemRenderer;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_756;

public class GenericBlockItem extends class_1747 implements GeoItem {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private final String name;

    public GenericBlockItem(class_2248 pBlock, class_1793 pProperties, String name) {
        super(pBlock, pProperties);
        this.name = name;
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            private GeoItemRenderer<GenericBlockItem> renderer = null;

            @Override
            public class_756 getGeoItemRenderer() {
                if (this.renderer == null) {
                    this.renderer = new GenericBlockItemRenderer(name);
                }

                return this.renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) { ;; }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

}
