package dev.xylonity.knightlib.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPathManager;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderManager;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderRenderContext;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderRenderStage;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {

    @Final
    @Shadow
    class_310 minecraft;

    @Final
    @Shadow
    private class_4184 mainCamera;

    @Inject(
            method = "renderLevel",
            at = @At("TAIL")
    )
    private void knightlib$afterRenderLevel(class_9779 deltaTracker, CallbackInfo ci) {
        float partialTicks = deltaTracker.method_60637(true);

        Matrix4f projection = new Matrix4f(minecraft.field_1773.method_22973(partialTicks));
        Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());

        class_243 cameraPosition = mainCamera.method_19326();

        PostShaderRenderContext context = new PostShaderRenderContext(
                PostShaderRenderStage.GAME_RENDERER_TAIL,
                partialTicks,
                projection,
                modelView,
                mainCamera,
                cameraPosition
        );

        PostShaderManager.renderStage(context);
    }

    /**
     * Runs right after the gui passes so the camera path is drawn anyway
     */
    @Inject(
            method = "render(Lnet/minecraft/client/DeltaTracker;Z)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;flush()V")
    )
    private void knightlib$renderCameraPathOverlay(class_9779 deltaTracker, boolean renderLevel, CallbackInfo ci) {
        if (renderLevel && minecraft.field_1687 != null) {
            final class_332 graphics = new class_332(minecraft, minecraft.method_22940().method_23000());
            CameraPathManager.renderOverlay(graphics, deltaTracker.method_60637(true));
            graphics.method_51452();
        }

    }

}
