package dev.xylonity.knightlib.client.camera.path;

import dev.xylonity.knightlib.api.util.KnightLibEasings;
import net.minecraft.class_332;
import net.minecraft.class_3532;

/**
 * Black bars at the top and bottom of the screen (cinematic letterbox)
 */
public final class LetterboxOverlay {

    private static final float ANIM_TICKS = 5f;
    private static final float SCREEN_FRACTION = 0.125f;

    private LetterboxOverlay() {
        ;;
    }

    public static float pathIntensity(float ticks, float totalTicks) {
        final float in = class_3532.method_15363(ticks / ANIM_TICKS, 0f, 1f);
        final float out = class_3532.method_15363((totalTicks - ticks) / ANIM_TICKS, 0f, 1f);

        return KnightLibEasings.EASE_OUT_CUBIC.apply(Math.min(in, out));
    }

    public static void render(class_332 graphics, float intensity) {
        if (intensity <= 0f) {
            return;
        }

        final int width = graphics.method_51421();
        final int height = graphics.method_51443();

        int barHeight = Math.round(height * SCREEN_FRACTION * class_3532.method_15363(intensity, 0f, 1f));
        if (barHeight > 0) {
            graphics.method_25294(0, 0, width, barHeight, 0xFF000000);
            graphics.method_25294(0, height - barHeight, width, height, 0xFF000000);
        }

    }

}