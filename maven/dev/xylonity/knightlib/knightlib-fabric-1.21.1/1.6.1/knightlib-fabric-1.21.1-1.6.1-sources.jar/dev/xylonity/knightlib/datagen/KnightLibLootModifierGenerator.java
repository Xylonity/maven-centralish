package dev.xylonity.knightlib.datagen;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.util.ResourceLocations;
import dev.xylonity.knightlib.config.KnightLibConfig;
import dev.xylonity.knightlib.registry.KnightLibItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_7923;

public class KnightLibLootModifierGenerator {

    public static void init() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source) -> {
            if (!id.method_29177().method_12832().startsWith("entities/")) {
                return;
            }

            class_2960 resourceLocation = ResourceLocations.of(id.method_29177().method_12836(), id.method_29177().method_12832().substring("entities/".length()));

            if (!class_7923.field_41177.method_10250(resourceLocation)) {
                return;
            }

            class_1299<?> entityType = class_7923.field_41177.method_10223(resourceLocation);
            if (entityType.method_5891() != class_1311.field_6302) {
                return;
            }
            if (!KnightLibConfig.isEntityAllowedForEssence(entityType)) {
                return;
            }

            if (!KnightLib.isEnabled(KnightLib.Usage.GREEN_ESSENCES)) {
                return;
            }

            class_55.class_56 smallEssencePool = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(KnightLibItems.SMALL_ESSENCE.get())
                            .method_438(class_141.method_621(
                                    class_5662.method_32462(1.0F, 1.0F)
                            ))
                    )
                    .method_356(class_219.method_932(
                            (float) KnightLibConfig.SMALL_ESSENCE_DROP_RATE
                    ));

            class_55.class_56 greatEssencePool = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(KnightLibItems.GREAT_ESSENCE.get())
                            .method_438(class_141.method_621(
                                    class_5662.method_32462(1.0F, 1.0F)
                            ))
                    )
                    .method_356(class_219.method_932(
                            (float) KnightLibConfig.GREAT_ESSENCE_DROP_RATE
                    ));

            tableBuilder.method_336(smallEssencePool).method_336(greatEssencePool);
        });

    }

}
