package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_3222;

/**
 * Fired after a player has respawned (the new player instance is already in the level)
 */
public final class ServerPlayerRespawnEvent extends KnightLibEvent {

    private final class_3222 player;
    private final boolean endConquered;

    public ServerPlayerRespawnEvent(class_3222 player, boolean endConquered) {
        this.player = player;
        this.endConquered = endConquered;
    }

    public class_3222 getPlayer() {
        return player;
    }

    /**
     * True when the respawn was triggered by leaving the End alive rather than by death
     */
    public boolean isEndConquered() {
        return endConquered;
    }

}
