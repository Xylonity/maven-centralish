package dev.xylonity.knightlib.client.entity.data.internal;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.entity.data.AttachmentType;
import dev.xylonity.knightlib.common.entity.data.internal.AttachmentsInternal;
import dev.xylonity.knightlib.network.packets.AttachmentSyncS2C;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * Client-sided attachment sync handling
 */
public final class AttachmentsClient {

    // In case the player isn't loaded yet when it spawns
    private static final Map<Integer, List<AttachmentSyncS2C>> PENDING = new ConcurrentHashMap<>();

    private AttachmentsClient() {
        ;;
    }

    public static void handle(AttachmentSyncS2C message) {
        final class_638 level = class_310.method_1551().field_1687;

        final class_1297 entity = level == null ? null : level.method_8469(message.entityId());
        if (entity == null) {
            if (PENDING.size() >= 1024) {
                PENDING.clear();
            }

            PENDING.computeIfAbsent(message.entityId(), id -> new ArrayList<>()).add(message);
            return;
        }

        apply(entity, message);
    }

    /**
     * Launches remaining payloads in case they are parked down
     */
    public static void onEntityJoin(class_1297 entity) {
        final List<AttachmentSyncS2C> pending = PENDING.remove(entity.method_5628());
        if (pending == null) {
            return;
        }

        for (final AttachmentSyncS2C message : pending) {
            apply(entity, message);
        }

    }

    public static void clearAll() {
        PENDING.clear();
    }

    private static void apply(class_1297 entity, AttachmentSyncS2C message) {
        final AttachmentType<?> type = AttachmentType.byId(message.typeId());
        if (type == null) {
            KnightLib.LOGGER.warn("[CLIENT] Received sync for unknown attachment type {}", message.typeId());
            return;
        }

        AttachmentsInternal.apply(entity, type, message.payload());
    }

}