package dev.xylonity.knightlib.client.camera.path;

import dev.xylonity.knightlib.api.camera.path.impl.CameraEffect;
import dev.xylonity.knightlib.api.camera.path.impl.CameraKeyframe;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPath;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPathSampler;
import dev.xylonity.knightlib.api.camera.path.impl.EffectKeyframe;
import dev.xylonity.knightlib.api.util.KnightLibEasings;
import dev.xylonity.knightlib.mixin.CameraAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_5321;

/**
 * One active camera path playback, where the first sampled frame is captured and builds the shared sampler
 */
public final class CameraPathPlayback {

    private static final long UNSTARTED_TICK = Long.MIN_VALUE;

    private final CameraPath path;
    @Nullable
    private final Runnable onComplete;

    private long startTick = UNSTARTED_TICK;
    private class_5321<class_1937> dimension;

    private CameraPathSampler sampler;

    private final BlurTransitionEffect blur = new BlurTransitionEffect();

    private boolean guiHidden = false;
    private boolean previousHideGui = false;

    public CameraPathPlayback(CameraPath path, @Nullable Runnable onComplete) {
        this.path = path;
        this.onComplete = onComplete;
    }

    /**
     * Overrides the camera transform for this frame.
     * Returns false if the animation is over.
     */
    public boolean apply(class_1657 player, class_4184 camera, float partialTick) {
        final class_1937 level = player.method_37908();
        ensureStarted(level, camera);

        final float ticks = (level.method_8510() - startTick) + partialTick;
        if (level.method_27983() != dimension) {
            return false;
        }

        if (ticks >= sampler.totalTicks()) {
            return applyReturn(camera, ticks - sampler.totalTicks());
        }

        blur.update(intensityOf(CameraEffect.BLUR, ticks));

        final CameraPathSampler.Pose pose = sampler.sample(ticks);

        final CameraAccessor accessor = (CameraAccessor) camera;
        accessor.setRotationAccessor(pose.yaw(), pose.pitch());
        accessor.setPositionAccessor(pose.position().field_1352, pose.position().field_1351, pose.position().field_1350);

        // Keeps the local player visible while the cutscene is playing (otherwise the player will be completely invisible)
        accessor.setDetachedAccessor(true);

        return true;
    }

    /**
     * Blends the camera from the last keyframe back to the player's own camera once the path ends
     */
    private boolean applyReturn(class_4184 camera, float ticksPastEnd) {
        if (path.returnTicks() <= 0 || ticksPastEnd >= path.returnTicks()) {
            return false;
        }

        blur.update(0f);

        final float time = path.returnEasing().apply(ticksPastEnd / path.returnTicks());
        final CameraPathSampler.Pose pose = sampler.sample(sampler.totalTicks());

        final class_243 position = pose.position().method_35590(camera.method_19326(), time);

        final CameraAccessor accessor = (CameraAccessor) camera;
        accessor.setRotationAccessor(class_3532.method_17821(time, pose.yaw(), camera.method_19330()), class_3532.method_16439(time, pose.pitch(), camera.method_19329()));
        accessor.setPositionAccessor(position.field_1352, position.field_1351, position.field_1350);
        accessor.setDetachedAccessor(true);

        return true;
    }

    /**
     * Draws the overlays
     */
    public void renderOverlay(class_332 graphics, float partialTick) {
        if (startTick == UNSTARTED_TICK) {
            return;
        }

        final class_1937 level = class_310.method_1551().field_1687;
        if (level == null || level.method_27983() != dimension) {
            return;
        }

        final float ticks = (level.method_8510() - startTick) + partialTick;

        final float bars = path.letterbox() ? LetterboxOverlay.pathIntensity(ticks, sampler.totalTicks()) : 0f;
        LetterboxOverlay.render(graphics, Math.max(bars, intensityOf(CameraEffect.LETTERBOX, ticks)));

        FadeOverlay.render(graphics, intensityOf(CameraEffect.FADE, ticks));
    }

    public void tickEffects() {
        blur.tick();
    }

    public void restore() {
        if (guiHidden) {
            class_310.method_1551().field_1690.field_1842 = previousHideGui;
            guiHidden = false;
        }

        blur.close();
    }

    public void runCompletion() {
        if (onComplete != null) {
            onComplete.run();
        }

    }

    private void ensureStarted(class_1937 level, class_4184 camera) {
        if (startTick != UNSTARTED_TICK) {
            return;
        }

        startTick = level.method_8510();
        dimension = level.method_27983();

        final List<CameraKeyframe> points = new ArrayList<>(path.keyframes().size() + 1);
        if (path.fromCurrentCamera()) {
            points.add(new CameraKeyframe(camera.method_19326(), camera.method_19330(), camera.method_19329(), 0, KnightLibEasings.LINEAR));
        }

        points.addAll(path.keyframes());

        sampler = CameraPathSampler.of(points, path.smoothPosition(), path.holdTicks());
        blur.setMaxRadius(path.blurRadius());

        // Cutscenes hides the hud
        previousHideGui = class_310.method_1551().field_1690.field_1842;
        class_310.method_1551().field_1690.field_1842 = true;
        guiHidden = true;

    }

    private float intensityOf(CameraEffect effect, float ticks) {
        float intensity = 0f;
        for (final EffectKeyframe window : path.effects()) {
            if (window.effect() == effect) {
                intensity = Math.max(intensity, window.intensityAt(ticks));
            }

        }

        return intensity;
    }

}