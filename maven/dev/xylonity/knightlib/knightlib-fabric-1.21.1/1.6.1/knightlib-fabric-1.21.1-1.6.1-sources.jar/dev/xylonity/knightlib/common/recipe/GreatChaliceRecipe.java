package dev.xylonity.knightlib.common.recipe;

import com.mojang.serialization.MapCodec;
import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.registry.KnightLibItems;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9695;
import org.jetbrains.annotations.NotNull;

public final class GreatChaliceRecipe implements class_1860<class_9695> {

    private static final class_2960 ID = KnightLib.of("great_chalice_interaction");

    public static final class_1865<GreatChaliceRecipe> SERIALIZER = new Serializer();
    public static final class_3956<GreatChaliceRecipe> RECIPE_TYPE = new Type();

    public final class_1799 input = new class_1799(KnightLibItems.EMPTY_GRAIL.get());
    public final class_1799 output = new class_1799(KnightLibItems.FILLED_GRAIL.get());

    @Override
    public boolean method_8115(class_9695 inv, @NotNull class_1937 lvl) {
        return class_1799.method_7984(inv.method_59984(0), input);
    }

    @Override
    public @NotNull class_1799 method_8116(@NotNull class_9695 inv, class_7225.@NotNull class_7874 reg) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int w, int h) {
        return true;
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.@NotNull class_7874 reg) {
        return output.method_7972();
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SERIALIZER;
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return RECIPE_TYPE;
    }

    public static final class Type implements class_3956<GreatChaliceRecipe> {

        @Override
        public String toString() {
            return ID.toString();
        }

    }

    public static final class Serializer implements class_1865<GreatChaliceRecipe> {

        private static final MapCodec<GreatChaliceRecipe> CODEC = MapCodec.unit(GreatChaliceRecipe::new);
        private static final class_9139<class_9129, GreatChaliceRecipe> STREAM_CODEC = class_9139.method_56431(new GreatChaliceRecipe());

        @Override
        public @NotNull MapCodec<GreatChaliceRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public @NotNull class_9139<class_9129, GreatChaliceRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }

}
