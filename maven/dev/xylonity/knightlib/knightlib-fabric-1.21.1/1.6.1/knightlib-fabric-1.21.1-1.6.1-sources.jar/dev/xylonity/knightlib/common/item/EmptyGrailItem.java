package dev.xylonity.knightlib.common.item;

import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.api.interop.GreatChaliceState;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import dev.xylonity.knightlib.registry.KnightLibItems;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

public class EmptyGrailItem extends class_1792 implements IGreatChaliceInteractable {

    public EmptyGrailItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public int getChargesToApply() {
        return -MAX_CHARGES;
    }

    @Override
    public boolean canInteract(GreatChaliceBlockEntity chalice, class_1937 level, class_1657 player) {
        return chalice.isFull() && chalice.getState() == GreatChaliceState.NORMAL;
    }

    @Override
    public @NotNull Set<class_1799> getRewards() {
        return Set.of(new class_1799(KnightLibItems.FILLED_GRAIL.get()));
    }

    @Override
    public @NotNull Set<class_3414> getInteractionSounds() {
        return Set.of(class_3417.field_14978);
    }

    @Override
    public void onPostInteraction(GreatChaliceBlockEntity chalice, class_1657 player, class_1937 level, class_3965 hit) {
        if (level instanceof class_3218 sv) {
            class_5819 rand = sv.method_8409();
            for (int i = 0; i < 25; i++) {
                double px, py, pz;
                double r = 0.7 * Math.sqrt(rand.method_43058());
                double t = rand.method_43058() * Math.PI * 2;
                px = chalice.method_11016().method_10263() + 0.5 + r * Math.cos(t);
                pz = chalice.method_11016().method_10260() + 0.5 + r * Math.sin(t);
                py = chalice.method_11016().method_10264() + 1.0 + rand.method_43058() * 0.3;
                sv.method_14199(class_2398.field_11245, px, py, pz, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }

    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, class_1792.@NotNull class_9635 context, @NotNull List<class_2561> list, @NotNull class_1836 flag) {
        super.method_7851(itemStack, context, list, flag);
        list.add(class_2561.method_43471("tooltip.item.knightlib.empty_grail"));
    }

}
