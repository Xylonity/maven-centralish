package dev.xylonity.knightlib.client.camera.path;

import net.minecraft.class_332;
import net.minecraft.class_3532;

/**
 * Full-screen dip to black used by fade transitions
 */
public final class FadeOverlay {

    private FadeOverlay() {
        ;;
    }

    public static void render(class_332 graphics, float alpha) {
        if (alpha <= 0f) {
            return;
        }

        final int clampedAlpha = class_3532.method_15340((int) (alpha * 255f), 0, 255);
        graphics.method_25294(0, 0, graphics.method_51421(), graphics.method_51443(), clampedAlpha << 24);
    }

}
