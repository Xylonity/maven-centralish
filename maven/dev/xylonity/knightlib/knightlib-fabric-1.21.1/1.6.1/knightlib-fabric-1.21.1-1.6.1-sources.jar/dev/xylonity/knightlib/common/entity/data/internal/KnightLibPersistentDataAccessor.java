package dev.xylonity.knightlib.common.entity.data.internal;

import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public interface KnightLibPersistentDataAccessor {

    class_2487 knightlib$getPersistentData();

    /**
     * Used for runtime cache
     */
    Map<class_2960, Object> knightlib$getAttachmentCache();
}
