package dev.xylonity.knightlib.api.camera.path.impl;

import net.minecraft.class_2540;

/**
 * One screen-effect window on the timeline of a {@link CameraPath}
 *
 * @param effect the screen effect this window plays
 * @param startTick path time at which the window begins (inclusive)
 * @param endTick path time at which the window ends
 * @param mode intensity shape over the window
 */
public record EffectKeyframe(
        CameraEffect effect,
        int startTick,
        int endTick,
        EffectMode mode
) {

    public EffectKeyframe {
        effect = (effect == null) ? CameraEffect.FADE : effect;
        mode = (mode == null) ? EffectMode.FULL : mode;
        startTick = Math.max(0, startTick);
        endTick = Math.max(startTick + 1, endTick);
    }

    public int lengthTicks() {
        return endTick - startTick;
    }

    /**
     * Intensity of this window at the given path time
     */
    public float intensityAt(float ticks) {
        if (ticks < startTick || ticks > endTick) {
            return 0f;
        }

        return mode.intensityAt((ticks - startTick) / (float) lengthTicks());
    }

    public void encode(class_2540 buf) {
        buf.method_10804(effect.id());
        buf.method_10804(startTick);
        buf.method_10804(endTick);
        buf.method_10804(mode.id());
    }

    public static EffectKeyframe decode(class_2540 buf) {
        final CameraEffect effect = CameraEffect.byId(buf.method_10816());
        final int startTick = buf.method_10816();
        final int endTick = buf.method_10816();
        final EffectMode mode = EffectMode.byId(buf.method_10816());

        return new EffectKeyframe(effect, startTick, endTick, mode);
    }

}
