package dev.xylonity.knightlib.common.item.blockitem;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

public class GreatChaliceBlockItem extends GenericBlockItem {

    public GreatChaliceBlockItem(class_2248 pBlock, class_1793 pProperties, String name) {
        super(pBlock, pProperties, name);
    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, class_1792.@NotNull class_9635 context, @NotNull List<class_2561> list, @NotNull class_1836 flag) {
        super.method_7851(itemStack, context, list, flag);
        list.add(class_2561.method_43471("tooltip.item.knightlib.great_chalice"));
    }

}
