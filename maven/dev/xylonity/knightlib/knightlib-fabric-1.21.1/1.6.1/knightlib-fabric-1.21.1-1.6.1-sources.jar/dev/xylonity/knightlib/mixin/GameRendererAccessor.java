package dev.xylonity.knightlib.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_757.class)
public interface GameRendererAccessor {

    @Invoker("loadEffect")
    void loadEffectAccessor(class_2960 location);

}
