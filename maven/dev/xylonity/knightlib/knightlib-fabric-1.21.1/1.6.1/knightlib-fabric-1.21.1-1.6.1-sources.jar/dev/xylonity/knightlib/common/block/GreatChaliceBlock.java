package dev.xylonity.knightlib.common.block;

import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import dev.xylonity.knightlib.config.KnightLibConfig;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_247;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;

public class GreatChaliceBlock extends class_2248 implements class_2343 {

    private static final class_265 SHAPE = Stream.of(
            class_2248.method_9541(0, 7, 0, 2, 16, 16),
            class_2248.method_9541(14, 7, 0, 16, 16, 16),
            class_2248.method_9541(0, 0, 0, 16, 2, 16),
            class_2248.method_9541(0, 5, 0, 16, 7, 16),
            class_2248.method_9541(2, 7, 0, 14, 16, 2),
            class_2248.method_9541(2, 7, 14, 14, 16, 16),
            class_2248.method_9541(4, 2, 4, 12, 5, 12)
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    public GreatChaliceBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 pState, @NotNull class_1922 pLevel, @NotNull class_2338 pPos, @NotNull class_3726 pContext) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2586 method_10123(@NotNull class_2338 pos, @NotNull class_2680 state) {
        return KnightLibBlockEntities.GREAT_CHALICE.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(@NotNull class_1937 pLevel, @NotNull class_2680 pState, @NotNull class_2591<T> pBlockEntityType) {
        return pBlockEntityType == KnightLibBlockEntities.GREAT_CHALICE.get() ? GreatChaliceBlockEntity::tick : null;
    }

    @Override
    public @NotNull class_9062 method_55765(@NotNull class_1799 pStack, @NotNull class_2680 pState, @NotNull class_1937 pLevel, @NotNull class_2338 pPos, @NotNull class_1657 pPlayer, @NotNull class_1268 pHand, @NotNull class_3965 pHit) {

        if (pLevel.field_9236) {
            return class_9062.field_47731;
        }

        if (!(pLevel.method_8321(pPos) instanceof GreatChaliceBlockEntity chalice)) {
            return class_9062.field_47731;
        }

        class_1799 stack = pPlayer.method_5998(pHand);
        if (stack.method_7909() instanceof IGreatChaliceInteractable actor) {
            if (!actor.canInteract(chalice, pLevel, pPlayer)) {
                return class_9062.field_47731;
            }

            actor.onPreInteraction(chalice, pPlayer, pLevel, pHit);

            int total = chalice.getCharges() + actor.getChargesToApply();
            if (total < 0 || total > IGreatChaliceInteractable.MAX_CHARGES) {
                return class_9062.field_47731;
            }

            chalice.setCharges(total);
            if (!pPlayer.method_31549().field_7477) stack.method_7934(actor.shrinkItemAmount());

            if (!actor.getRewards().isEmpty()) {
                for (class_1799 reward : actor.getRewards()) {
                    if (KnightLibConfig.YEET_GRAIL_WHEN_FILLED) {
                        spawnReward(pLevel, pPos, reward, pPlayer);
                    }
                    else {
                        if (!pPlayer.method_31548().method_7394(reward)) {
                            spawnReward(pLevel, pPos, reward, pPlayer);
                        }

                    }

                }

            }

            if (!actor.getInteractionSounds().isEmpty()) {
                for (class_3414 sound : actor.getInteractionSounds()) {
                    pLevel.method_8396(null, pPos, sound, class_3419.field_15245, 1f, 1f);
                }

            }

            if (chalice.getCharges() == IGreatChaliceInteractable.MAX_CHARGES) {
                pLevel.method_8396(null, pPos, actor.getFullChargeSound(), class_3419.field_15245, 1f, 1f);
            }

            actor.onPostInteraction(chalice, pPlayer, pLevel, pHit);

            return class_9062.field_47728;
        }

        return super.method_55765(pStack, pState, pLevel, pPos, pPlayer, pHand, pHit);
    }

    private void spawnReward(class_1937 level, class_2338 pPos, class_1799 reward, class_1657 player) {
        class_1297 entity = new class_1542(level, pPos.method_10263() + 0.5, pPos.method_10264() + player.method_17682() * 0.5, pPos.method_10260(), reward);
        level.method_8649(entity);
    }

}
