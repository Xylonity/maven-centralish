package dev.xylonity.knightlib.client.camera.editor;

import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Camera used while the path editor is open, so keyframes can be placed and manipulated from anywhere without moving the player
 */
public final class EditorFreeCamera {

    private static final float LOOK_SENSITIVITY = 0.15f;
    private static final float VELOCITY_SMOOTHING = 0.55f;

    private class_243 position = class_243.field_1353;
    private class_243 prevPosition = class_243.field_1353;
    private class_243 velocity = class_243.field_1353;

    private float yaw;
    private float pitch;

    private float speed = 0.6f;

    private boolean forward;
    private boolean back;
    private boolean left;
    private boolean right;
    private boolean up;
    private boolean down;
    private boolean sprint;

    public void reset(class_243 position, float yaw, float pitch) {
        this.position = position;
        this.prevPosition = position;
        this.velocity = class_243.field_1353;
        this.yaw = yaw;
        this.pitch = pitch;

        stopMoving();
    }

    public void setInput(boolean forward, boolean back, boolean left, boolean right, boolean up, boolean down, boolean sprint) {
        this.forward = forward;
        this.back = back;
        this.left = left;
        this.right = right;
        this.up = up;
        this.down = down;
        this.sprint = sprint;
    }

    public void stopMoving() {
        setInput(false, false, false, false, false, false, false);
        velocity = class_243.field_1353;
    }

    public void tick() {
        prevPosition = position;

        final class_243 wishedDirection = wishDirection();
        final float amount = speed * (sprint ? 3f : 1f);

        velocity = velocity.method_1021(VELOCITY_SMOOTHING).method_1019(wishedDirection.method_1021(amount * (1f - VELOCITY_SMOOTHING)));
        if (velocity.method_1027() < 1.0E-6) {
            velocity = class_243.field_1353;
        }

        position = position.method_1019(velocity);
    }

    /**
     * Rotates the camera from raw mouse deltas
     */
    public void look(double dxPixels, double dyPixels) {
        yaw = class_3532.method_15393(yaw + (float) (dxPixels * LOOK_SENSITIVITY));
        pitch = class_3532.method_15363(pitch + (float) (dyPixels * LOOK_SENSITIVITY), -90f, 90f);
    }

    public void adjustSpeed(int sign) {
        speed = class_3532.method_15363(sign > 0 ? speed * 1.25f : speed / 1.25f, 0.02f, 10f);
    }

    public float speed() {
        return speed;
    }

    public class_243 position(float partialTick) {
        return prevPosition.method_35590(position, partialTick);
    }

    public class_243 position() {
        return position;
    }

    public void moveTo(class_243 position) {
        this.position = position;
        this.prevPosition = position;
        this.velocity = class_243.field_1353;
    }

    public void setRotation(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public float yaw() {
        return yaw;
    }

    public float pitch() {
        return pitch;
    }

    public class_243 lookDirection() {
        return class_243.method_1030(pitch, yaw);
    }

    private class_243 wishDirection() {
       final class_243 forwardDir = lookDirection();
       final class_243 rightDir = class_243.method_1030(0f, yaw + 90f);

        class_243 wish = class_243.field_1353;
        if (forward) {
            wish = wish.method_1019(forwardDir);
        }
        if (back) {
            wish = wish.method_1020(forwardDir);
        }
        if (right) {
            wish = wish.method_1019(rightDir);
        }
        if (left) {
            wish = wish.method_1020(rightDir);
        }
        if (up) {
            wish = wish.method_1031(0, 1, 0);
        }
        if (down) {
            wish = wish.method_1031(0, -1, 0);
        }

        return wish.method_1027() > 1.0 ? wish.method_1029() : wish;
    }

}