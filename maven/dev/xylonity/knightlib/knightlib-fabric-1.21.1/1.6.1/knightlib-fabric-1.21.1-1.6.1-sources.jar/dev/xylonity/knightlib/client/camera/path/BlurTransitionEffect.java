package dev.xylonity.knightlib.client.camera.path;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPath;
import dev.xylonity.knightlib.mixin.GameRendererAccessor;
import dev.xylonity.knightlib.mixin.PostChainAccessor;
import dev.xylonity.knightlib.mixin.PostPassAccessor;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Blur post chain wrapper for blur transitions (using a derivative post shader based on the blur from 1.21.1's background blur shader)
 */
public final class BlurTransitionEffect {

    private static final class_2960 BLUR_POST_CHAIN = KnightLib.of("shaders/post/camera_blur.json");

    private boolean ownsChain = false;
    private float pendingIntensity = 0f;
    private float maxRadius = CameraPath.DEFAULT_BLUR_RADIUS;

    /**
     * Radius (in pixels) reached at full intensity
     */
    public void setMaxRadius(float radius) {
        this.maxRadius = Math.max(0f, radius);
    }

    public void update(float intensity) {
        pendingIntensity = intensity;

        if (ownsChain) {
            setRadius(Math.max(1f, intensity * maxRadius));
        }

    }

    public void tick() {
        final class_310 minecraft = class_310.method_1551();

        final boolean shouldBlur = pendingIntensity > 0.01f;
        if (shouldBlur && !ownsChain && minecraft.field_1773.method_3183() == null) {
            ((GameRendererAccessor) minecraft.field_1773).loadEffectAccessor(BLUR_POST_CHAIN);
            ownsChain = true;

            setRadius(Math.max(1f, pendingIntensity * maxRadius));
        }
        else if (!shouldBlur && ownsChain) {
            close();
        }

    }

    public void close() {
        if (!ownsChain) {
            return;
        }

        ownsChain = false;
        class_310.method_1551().method_18858(BlurTransitionEffect::shutdownIfOwned);
    }

    private static void shutdownIfOwned() {
        final class_310 minecraft = class_310.method_1551();
        final class_279 chain = minecraft.field_1773.method_3183();
        if (chain != null && BLUR_POST_CHAIN.toString().equals(chain.method_1260())) {
            minecraft.field_1773.method_3207();
        }

    }

    private void setRadius(float radius) {
        final class_279 chain = class_310.method_1551().field_1773.method_3183();
        if (chain == null) {
            return;
        }

        for (final class_283 pass : ((PostChainAccessor) chain).knightlib$getPasses()) {
            ((PostPassAccessor) pass).knightlib$getEffect().method_1275("Radius").method_1251(radius);
        }

    }

}