package dev.xylonity.knightlib.client.camera.editor;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.camera.path.impl.CameraPathManager;
import dev.xylonity.knightlib.client.screen.camera.CameraEditorScreen;
import dev.xylonity.knightlib.mixin.CameraAccessor;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.jetbrains.annotations.Nullable;

public final class CameraPathEditor {

    @Nullable
    private static CameraEditorSession session;
    private static final EditorFreeCamera CAMERA = new EditorFreeCamera();

    private static boolean active = false;
    private static boolean previewing = false;

    private CameraPathEditor() {
        ;;
    }

    public static boolean isActive() {
        return active;
    }

    public static boolean isPreviewing() {
        return previewing;
    }

    public static CameraEditorSession session() {
        if (session == null) {
            session = new CameraEditorSession();
        }

        return session;
    }

    public static EditorFreeCamera freeCamera() {
        return CAMERA;
    }

    public static void toggle() {
        if (active) {
            close();
        }
        else {
            open();
        }

    }

    /**
     * Enters the editor
     */
    public static void open() {
        // The campath is a dev-only system, in real deploy it's disabled
        if (!KnightLib.PLATFORM.isDevelopmentEnvironment()) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return;
        }

        if (!minecraft.field_1724.method_5687(2)) {
            minecraft.field_1724.method_7353(class_2561.method_43470("[KnightLib] The camera editor requires OP level 2").method_27692(class_124.field_1061), true);
            return;
        }

        if (!active) {
            active = true;

            class_4184 camera = minecraft.field_1773.method_19418();
            CAMERA.reset(camera.method_19326(), camera.method_19330(), camera.method_19329());
        }

        minecraft.method_1507(new CameraEditorScreen());
    }

    /**
     * Leaves the editor
     */
    public static void close() {
        final boolean wasPreviewing = previewing;

        active = false;
        previewing = false;

        if (wasPreviewing) {
            CameraPathManager.stop();
        }

        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1755 instanceof CameraEditorScreen) {
            minecraft.method_1507(null);
        }

    }

    /**
     * Called by the editor screen when it is closed by the user (pressing esc)
     */
    public static void onScreenClosed() {
        if (active && !previewing) {
            active = false;
        }

    }

    /**
     * Plays the current session as a real path
     */
    public static void preview() {
        final class_310 minecraft = class_310.method_1551();
        final CameraEditorSession current = session();

        if (current.isEmpty()) {
            if (minecraft.field_1724 != null) {
                minecraft.field_1724.method_7353(class_2561.method_43470("[KnightLib] No keyframes to preview yet"), true);
            }

            return;
        }

        previewing = true;
        if (minecraft.field_1755 instanceof CameraEditorScreen) {
            minecraft.method_1507(null);
        }

        CameraPathManager.play(current.buildPath(), CameraPathEditor::onPreviewFinished);
    }

    /**
     * Preview keybind entrypoint
     */
    public static void togglePreview() {
        if (CameraPathManager.isPlaying()) {
            CameraPathManager.stop();
            onPreviewFinished();
            return;
        }

        preview();
    }

    private static void onPreviewFinished() {
        final boolean reopen = active && previewing;
        previewing = false;

        if (reopen) {
            class_310.method_1551().method_1507(new CameraEditorScreen());
        }

    }

    /**
     * Overrides the camera transform with the freecam, unless a path owns the camera
     */
    public static boolean applyCamera(class_4184 camera, float partialTick) {
        if (!active || previewing || CameraPathManager.isPlaying()) {
            return false;
        }

        final class_243 position = CAMERA.position(partialTick);

        final CameraAccessor accessor = (CameraAccessor) camera;
        accessor.setRotationAccessor(CAMERA.yaw(), CAMERA.pitch());
        accessor.setPositionAccessor(position.field_1352, position.field_1351, position.field_1350);

        // Keeps the local player visible while the camera flies around
        accessor.setDetachedAccessor(true);

        return true;
    }

    public static void tick() {
        if (active && !previewing) {
            CAMERA.tick();
        }

    }

    /**
     * Drops everything
     */
    public static void discard() {
        active = false;
        previewing = false;
        session = null;
    }

}
