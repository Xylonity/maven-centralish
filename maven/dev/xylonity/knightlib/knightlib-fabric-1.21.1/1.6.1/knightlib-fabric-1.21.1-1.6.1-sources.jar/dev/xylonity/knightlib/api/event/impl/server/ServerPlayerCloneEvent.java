package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_3222;

/**
 * Fired when a new player instance is created from an old one (death respawn or returning
 * from the End)
 */
public final class ServerPlayerCloneEvent extends KnightLibEvent {

    private final class_3222 oldPlayer;
    private final class_3222 newPlayer;
    private final boolean wasDeath;

    public ServerPlayerCloneEvent(class_3222 oldPlayer, class_3222 newPlayer, boolean wasDeath) {
        this.oldPlayer = oldPlayer;
        this.newPlayer = newPlayer;
        this.wasDeath = wasDeath;
    }

    public class_3222 getOldPlayer() {
        return oldPlayer;
    }

    public class_3222 getNewPlayer() {
        return newPlayer;
    }

    public boolean wasDeath() {
        return wasDeath;
    }

}
