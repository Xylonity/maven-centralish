package dev.xylonity.knightlib.client.particle;

import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.Arrays;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_703;

public abstract class AbstractRibbonTrailParticle extends class_703 {
    protected static final int MAX_TRAIL_POINTS = 64;
    protected final class_243[] positionBuffer = new class_243[MAX_TRAIL_POINTS];
    protected int bufferIdx = -1;
    public float r;
    public float g;
    public float b;
    protected float ribbonAlpha = 1.0f;

    public AbstractRibbonTrailParticle(class_638 level, double x, double y, double z, double xd, double yd, double zd, float r, float g, float b) {
        super(level, x, y, z);
        this.field_3852 = xd;
        this.field_3869 = yd;
        this.field_3850 = zd;
        this.r = r;
        this.g = g;
        this.b = b;

        // init the entire pos buffer to the starting pos
        Arrays.fill(positionBuffer, new class_243(x, y, z));
    }

    @Override
    public void method_3070() {
        // saves current position into the buffer
        savePosInBuffer();

        field_3858 = field_3874;
        field_3838 = field_3854;
        field_3856 = field_3871;
        method_3069(field_3852, field_3869, field_3850);
        field_3852 *= 0.99;
        field_3869 *= 0.99;
        field_3850 *= 0.99;

        field_3869 -= field_3844;

        if (++field_3866 >= field_3847) method_3085();
    }

    protected void savePosInBuffer() {
        class_243 current = new class_243(field_3874, field_3854, field_3871);
        if (bufferIdx == -1) {
            Arrays.fill(positionBuffer, current);
        }

        if (++bufferIdx >= MAX_TRAIL_POINTS) {
            bufferIdx = 0;
        }

        positionBuffer[bufferIdx] = current;
    }

    @Override
    public void method_3074(@NotNull class_4588 ignored, @NotNull class_4184 camera, float partialTicks) {

        if (bufferIdx < 0) return; // not init

        class_4598 buff = class_310.method_1551().method_22940().method_23000();
        class_4588 vertexConsumer = buff.getBuffer(class_1921.method_23580(getRibbonSprite()));

        class_4587 mPose = new class_4587();

        mPose.method_22903();
        // translation to camera relative coordinates
        mPose.method_22904(-camera.method_19326().field_1352, -camera.method_19326().field_1351, -camera.method_19326().field_1350);

        // interpolated current pos
        class_243 from = new class_243(class_3532.method_16436(partialTicks, field_3858, field_3874), class_3532.method_16436(partialTicks, field_3838, field_3854), class_3532.method_16436(partialTicks, field_3856, field_3871));

        float yaw = -class_3532.field_29847 * camera.method_19330();
        class_243 topOffset = new class_243(0, getRibbonHeight() / 2.0F, 0).method_1024(yaw);
        class_243 botOffset = new class_243(0, -getRibbonHeight() / 2.0F, 0).method_1024(yaw);

        // Building ribbon quads here
        int segments = totalSegments();
        for (int i = 0; i < segments; i++) {
            // sampling the next point along the ribbon
            class_243 samplex = sampleTrailPoint(i * segmentInterval(), partialTicks);
            float u1 = (float) i / segments;
            float u2 = (float) (i + 1) / segments;

            // transformation matrices
            class_4665 pose = mPose.method_23760();
            Matrix4f mat = pose.method_23761();
            Matrix3f norm = pose.method_23762();

            // bott left
            vertexConsumer.method_22918(mat, (float) from.field_1352 + (float) botOffset.field_1352, (float) from.field_1351 + (float) botOffset.field_1351, (float) from.field_1350 + (float) botOffset.field_1350)
                    .method_22915(r, g, b, ribbonAlpha)
                    .method_22913(u1, 1.0F)
                    .method_22922(class_4608.field_21444)
                    .method_60803(method_3068(partialTicks))
                    .method_60831(pose, 0, 1, 0);

            // bott right
            vertexConsumer.method_22918(mat, (float) samplex.field_1352 + (float) botOffset.field_1352, (float) samplex.field_1351 + (float) botOffset.field_1351, (float) samplex.field_1350 + (float) botOffset.field_1350)
                    .method_22915(r, g, b, ribbonAlpha)
                    .method_22913(u2, 1.0F)
                    .method_22922(class_4608.field_21444)
                    .method_60803(method_3068(partialTicks))
                    .method_60831(pose, 0, 1, 0);

            // top right
            vertexConsumer.method_22918(mat, (float) samplex.field_1352 + (float) topOffset.field_1352, (float) samplex.field_1351 + (float) topOffset.field_1351, (float) samplex.field_1350 + (float) topOffset.field_1350)
                    .method_22915(r, g, b, ribbonAlpha)
                    .method_22913(u2, 0.0F)
                    .method_22922(class_4608.field_21444)
                    .method_60803(method_3068(partialTicks))
                    .method_60831(pose, 0, 1, 0);

            // top left
            vertexConsumer.method_22918(mat, (float) from.field_1352 + (float) topOffset.field_1352, (float) from.field_1351 + (float) topOffset.field_1351, (float) from.field_1350 + (float) topOffset.field_1350)
                    .method_22915(r, g, b, ribbonAlpha)
                    .method_22913(u1, 0.0F)
                    .method_22922(class_4608.field_21444)
                    .method_60803(method_3068(partialTicks))
                    .method_60831(pose, 0, 1, 0);

            // builds the next segment
            from = samplex;
        }

        mPose.method_22909();
        buff.method_22993(); // flush to prevent acid
    }

    // Saves the position each tick and 'interpolates' a vector offset so the sqr diff between each saved pos
    // isn't visually leaping
    protected class_243 sampleTrailPoint(int idx, float tick) {
        // circular wrap using bitmask (because MAX_TRAIL_POINTS is power of two)
        class_243 position = positionBuffer[(bufferIdx - idx - 1) & (MAX_TRAIL_POINTS - 1)];
        class_243 subtract = positionBuffer[(bufferIdx - idx) & (MAX_TRAIL_POINTS - 1)].method_1020(position);
        return position.method_1019(subtract.method_1021(tick));
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17831;
    }

    protected int totalSegments() {
        return 20;
    }

    protected int segmentInterval() {
        return 1;
    }

    protected abstract float getRibbonHeight();
    protected abstract class_2960 getRibbonSprite();

}
