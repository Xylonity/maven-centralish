package dev.xylonity.knightlib.network.packets;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.client.entity.data.internal.AttachmentsClient;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

/**
 * Clientbound packet that mirrors a single attachment value of an entity to the client.
 * A null payload means the attachment was removed
 */
public record AttachmentSyncS2C(
        int entityId,
        class_2960 typeId,
        @Nullable class_2520 payload
) {

    public static final class_2960 ID = KnightLib.of("attachment_sync");

    public static final ClientboundPacketType<AttachmentSyncS2C> TYPE =
            PacketType.clientbound(
                    ID,
                    AttachmentSyncS2C.class,
                    PacketCodec.of(AttachmentSyncS2C::encode, AttachmentSyncS2C::decode),
                    AttachmentsClient::handle
            );

    public static void encode(AttachmentSyncS2C packet, class_2540 buf) {
        buf.method_10804(packet.entityId());
        buf.method_10812(packet.typeId());

        final class_2487 wrapper = new class_2487();
        if (packet.payload() != null) {
            wrapper.method_10566("klvalue", packet.payload());
        }

        buf.method_10794(wrapper);
    }

    public static AttachmentSyncS2C decode(class_2540 buf) {
        final int entityId = buf.method_10816();
        final class_2960 typeId = buf.method_10810();

        final class_2487 wrapper = buf.method_10798();
        final class_2520 payload = wrapper != null && wrapper.method_10545("klvalue") ? wrapper.method_10580("klvalue") : null;

        return new AttachmentSyncS2C(entityId, typeId, payload);
    }

}