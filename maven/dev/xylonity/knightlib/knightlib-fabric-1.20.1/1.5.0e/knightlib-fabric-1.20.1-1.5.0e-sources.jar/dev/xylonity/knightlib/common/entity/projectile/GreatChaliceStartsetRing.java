package dev.xylonity.knightlib.common.entity.projectile;

import dev.xylonity.knightlib.common.entity.BaseProjectile;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import software.bernie.geckolib.animatable.GeoEntity;

public class GreatChaliceStartsetRing extends BaseProjectile implements GeoEntity {

    public GreatChaliceStartsetRing(class_1299<? extends BaseProjectile> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Override
    public void method_5773() {
        double px = method_23317();
        double py = method_23318();
        double pz = method_23321();

        super.method_5773();

        this.method_5814(px, py, pz);
    }

    @Override
    public boolean method_5727(double pX, double pY, double pZ) {
        return true;
    }

    @Override
    protected int baseLifetime() {
        return 10;
    }

}
