package dev.xylonity.knightlib.client.shader.post;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.client.shader.post.internal.PostShader;
import dev.xylonity.knightlib.client.shader.post.internal.PostShaderSettings;
import net.minecraft.class_1060;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_280;
import net.minecraft.class_284;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4587;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

/**
 * Base class for post-processing shaders.
 * Provides a "safe" PostChain execution that restores framebuffer, viewport and the common GL state.
 */
public abstract class AbstractPostShader<PSS extends PostShaderSettings> implements PostShader<PSS> {

    private int lastW = -1;
    private int lastH = -1;

    @Override
    public void initOrReload(class_1060 textures, class_3300 resources, class_276 target) {
        this.lastW = -1;
        this.lastH = -1;
    }

    /**
     * Runs a PostChain safely, binding the main render target before and after, restoring the viewport and the common render state
     */
    protected final void process(class_279 chain, float partialTicks, Runnable beforeProcess) {
        if (chain == null) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_276 mainRenderTarget = minecraft.method_1522();

        // The render system may mutate the same instance later on, so a copy of the projection is made
        final Matrix4f oldProjection = RenderSystem.getProjectionMatrix();
        final Matrix4f oldProjectionCopy = (oldProjection == null) ? null : new Matrix4f(oldProjection);

        // Provides a safe identity projection for full-screen passes
        final boolean projectionWasNull = (oldProjection == null);
        if (projectionWasNull) {
            RenderSystem.setProjectionMatrix(new Matrix4f().identity(), class_8251.field_43360);
        }

        // Forces identity model-view for full-screen quad space and then restores afterward
        final class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        modelViewStack.method_34426();
        RenderSystem.applyModelViewMatrix();

        try {
            // Ensures "minecraft:main" is bound and viewport matches it
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            if (beforeProcess != null) {
                beforeProcess.run();
            }

            chain.method_1258(partialTicks);

        }
        finally {
            // Restores the model-view
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();

            // Restores the projection
            if (!projectionWasNull && oldProjectionCopy != null) {
                RenderSystem.setProjectionMatrix(oldProjectionCopy, class_8251.field_43360);
            }

            // Rebinds main and restores the viewport for anything rendered after the postchain
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            // Restores the common render state
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.resetTextureMatrix();
        }

    }

    /**
     * Resizes the shader depending on the window size. Must be called before processing the shader
     */
    protected final void ensureSized(class_279 chain) {
        if (chain == null) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        final int width = minecraft.method_22683().method_4489();
        final int height = minecraft.method_22683().method_4506();

        if (width != lastW || height != lastH) {
            chain.method_1259(width, height);
            lastW = width;
            lastH = height;
        }

    }

    protected final void setUniformInt(class_280 effectInstance, String name, int value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_35649(value);
        }

    }

    protected final void setUniformFloat(class_280 effectInstance, String name, float value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1251(value);
        }

    }

    protected final void setUniformVec2(class_280 effectInstance, String name, float x, float y) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1255(x, y);
        }

    }

    protected final void setUniformVec3(class_280 effectInstance, String name, class_243 vector) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1249((float) vector.field_1352, (float) vector.field_1351, (float) vector.field_1350);
        }

    }

    protected final void setUniformMat4(class_280 effectInstance, String name, Matrix4f matrix) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1250(matrix);
        }

    }

}