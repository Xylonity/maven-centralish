package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.registry.registrar.KnightLibResourceRegistryFabric;
import net.minecraft.class_2378;

public class KnightLibRegistrarFabric implements KnightLibRegistrar {

    @Override
    public <T> ResourceRegistry<T> create(class_2378<T> type, String modid) {
        return new KnightLibResourceRegistryFabric<>(type, modid);
    }

}