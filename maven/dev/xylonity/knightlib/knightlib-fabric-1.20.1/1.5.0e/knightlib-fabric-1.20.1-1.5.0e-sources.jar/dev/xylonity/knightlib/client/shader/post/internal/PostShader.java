package dev.xylonity.knightlib.client.shader.post.internal;

import java.util.EnumSet;
import net.minecraft.class_1060;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_332;

/**
 * Generic contract for a client-sided post-processing shader effect
 *
 * A post shader typically runs as {@link net.minecraft.class_279} pass (it processes the final scene
 * buffers) and is driven by a manager that ticks and renders all registered shaders
 *
 * @param <PSS> is the settings payload used when starting/spawning an instance of the shader
 */
public interface PostShader<PSS extends PostShaderSettings> {

    class_2960 id();

    /**
     * Starts (or enqueues) a new instance of the shader with the given settings
     */
    void start(PSS settings);

    void clear();

    void clientTick();

    void renderOverlay(class_332 graphics, float partialTicks);

    /**
     * Render hook with full render context. The manager calls this only for fixed stages
     */
    default void renderStage(PostShaderRenderContext context) {
        ;;
    }

    /**
     * Declares which render stages this shader wants to run on
     */
    default EnumSet<PostShaderRenderStage> stages() {
        return EnumSet.noneOf(PostShaderRenderStage.class);
    }

    /**
     * Called when shaders/resources are (re)loaded or when the main render target changes size
     */
    default void initOrReload(class_1060 textures, class_3300 resources, class_276 target) {
        ;;
    }

    default void onLogout() {
        clear();
    }

}
