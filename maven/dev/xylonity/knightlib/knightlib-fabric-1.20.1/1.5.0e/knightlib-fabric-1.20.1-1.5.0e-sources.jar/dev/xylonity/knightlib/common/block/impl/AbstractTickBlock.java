package dev.xylonity.knightlib.common.block.impl;

import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;

/**
 * This class defines the functionality of a block capable of handling synchronized ticking without relying
 * on a BlockEntity. There are various ways to achieve this process, and this implementation provides a
 * functional solution.
 *
 * @author Xylonity
 */
public abstract class AbstractTickBlock extends class_2248 implements ITickBlockTracker {

    public AbstractTickBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public void method_9588(@NotNull class_2680 blockState, @NotNull class_3218 level, @NotNull class_2338 blockPos, @NotNull class_5819 randomSource) {

        // Override this method and implement your custom logic.
        // DO NOT call the super method. Instead, ensure you call this.scheduleTick(level, blockPos).

        this.scheduleTick(level, blockPos);
    }

    @Override
    public void method_9615(@NotNull class_2680 blockState, @NotNull class_1937 level, @NotNull class_2338 blockPos, @NotNull class_2680 newState, boolean b) {
        if (!level.field_9236) {
            addTickBlock(blockPos, this);
            scheduleTick(level, blockPos);
        }
    }

    @Override
    public void method_9536(@NotNull class_2680 blockState, class_1937 level, @NotNull class_2338 blockPos, @NotNull class_2680 newState, boolean movedByPiston) {
        if (!level.field_9236) {
            removeTickBlock(blockPos);
        }

        super.method_9536(blockState, level, blockPos, newState, movedByPiston);
    }

    public void scheduleTick(class_1937 pLevel, class_2338 pPos) {
        if (pLevel instanceof class_3218 serverLevel) {
            serverLevel.method_39279(pPos, this, 1);
        }
    }

}
