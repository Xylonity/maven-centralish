package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;

public class KnightLibBlockEntities {

    public static final ResourceRegistry<class_2591<?>> BLOCK_ENTITIES = ResourceDispatcher.create(class_7923.field_41181, KnightLib.MOD_ID);

    public static final ResourceEntry<class_2591<GreatChaliceBlockEntity>> GREAT_CHALICE;

    static {
        GREAT_CHALICE = BLOCK_ENTITIES.register("great_chalice", KnightLib.PLATFORM.createBlockEntityType(GreatChaliceBlockEntity::new, KnightLibBlocks.GREAT_CHALICE, "great_chalice"));
    }

    @FunctionalInterface
    public interface BlockEntityFactory<T extends class_2586> {
        T create(class_2338 pos, class_2680 state);
    }

}
