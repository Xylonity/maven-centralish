package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_310;

/**
 * Fired when an entity is added to the client level
 */
public final class ClientEntityJoinLevelEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_1937 level;
    private final class_1297 entity;

    public ClientEntityJoinLevelEvent(class_310 client, class_1937 level, class_1297 entity) {
        this.client = client;
        this.level = level;
        this.entity = entity;
    }

    public class_310 getClient() {
        return client;
    }

    public class_1937 getLevel() {
        return level;
    }

    public class_1297 getEntity() {
        return entity;
    }

}
