package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_7923;

public class KnightLibParticles {

    public static final ResourceRegistry<class_2396<?>> PARTICLES = ResourceDispatcher.create(class_7923.field_41180, KnightLib.MOD_ID);

    public static final ResourceEntry<class_2400> STARSET = PARTICLES.register("starset", KnightLib.PLATFORM.createParticle(true));

}
