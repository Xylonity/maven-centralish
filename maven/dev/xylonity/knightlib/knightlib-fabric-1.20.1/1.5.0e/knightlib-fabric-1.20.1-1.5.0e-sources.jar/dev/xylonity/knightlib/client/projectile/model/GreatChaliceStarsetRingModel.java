package dev.xylonity.knightlib.client.projectile.model;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class GreatChaliceStarsetRingModel extends GeoModel<GreatChaliceStartsetRing> {

    @Override
    public class_2960 getModelResource(GreatChaliceStartsetRing animatable) {
        return new class_2960(KnightLib.MOD_ID, "geo/great_chalice_starset_ring.geo.json");
    }

    @Override
    public class_2960 getTextureResource(GreatChaliceStartsetRing animatable) {
        int frames = 10;
        int perTick = 1;

        int frameIndex = (animatable.field_6012 / perTick) % frames;
        return new class_2960(KnightLib.MOD_ID, String.format("textures/entity/great_chalice_starset_ring_%d.png", frameIndex));
    }

    @Override
    public class_2960 getAnimationResource(GreatChaliceStartsetRing animatable) {
        return null;
    }

}
