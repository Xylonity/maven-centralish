package dev.xylonity.knightlib.common.item.blockitem;

import dev.xylonity.knightlib.client.item.renderer.GenericBlockItemRenderer;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.RenderProvider;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_756;

public class GenericBlockItem extends class_1747 implements GeoItem {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final Supplier<Object> renderProvider = GeoItem.makeRenderer(this);

    private final String name;

    public GenericBlockItem(class_2248 pBlock, class_1793 pProperties, String name) {
        super(pBlock, pProperties);
        this.name = name;
    }

    @Override
    public void createRenderer(Consumer<Object> consumer) {
        consumer.accept(new RenderProvider() {
            private GeoItemRenderer<GenericBlockItem> renderer = null;

            @Override
            public class_756 getCustomRenderer() {
                if (this.renderer == null) {
                    this.renderer = new GenericBlockItemRenderer(name);

                }
                return this.renderer;
            }
        });
    }

    @Override
    public Supplier<Object> getRenderProvider() {
        return this.renderProvider;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) { ;; }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

}
