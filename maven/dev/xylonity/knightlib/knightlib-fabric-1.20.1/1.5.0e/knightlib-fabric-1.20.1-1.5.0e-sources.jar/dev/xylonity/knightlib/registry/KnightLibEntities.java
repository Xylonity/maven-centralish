package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_7923;

public class KnightLibEntities {

    public static final ResourceRegistry<class_1299<?>> ENTITIES = ResourceDispatcher.create(class_7923.field_41177, KnightLib.MOD_ID);

    public static final ResourceEntry<class_1299<GreatChaliceStartsetRing>> GREAT_CHALICE_STARSET_RING;

    static {
        GREAT_CHALICE_STARSET_RING = ENTITIES.registerEntity("great_chalice_starset_ring", GreatChaliceStartsetRing::new, class_1311.field_17715, 0.1f, 0.1f, List.of(class_1299.class_1300::method_5901, b -> b.method_27299(128), b -> b.method_27300(1)));
    }

}
