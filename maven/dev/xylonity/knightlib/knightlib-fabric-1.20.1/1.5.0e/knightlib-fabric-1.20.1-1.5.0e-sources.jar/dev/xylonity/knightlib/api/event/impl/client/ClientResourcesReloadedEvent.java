package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_310;
import net.minecraft.class_3300;

/**
 * Fired after client resources (textures, sounds...) are reloaded (F3+T)
 */
public final class ClientResourcesReloadedEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_3300 resourceManager;

    public ClientResourcesReloadedEvent(class_310 client, class_3300 resourceManager) {
        this.client = client;
        this.resourceManager = resourceManager;
    }

    @Override
    public boolean isSticky() {
        return true;
    }

    public class_310 getClient() {
        return client;
    }

    public class_3300 getResourceManager() {
        return resourceManager;
    }

}
