package dev.xylonity.knightlib.impl.internal;

import net.minecraft.class_332;
import net.minecraft.class_345;

@FunctionalInterface
public interface LegacyCustomBossBarRenderer {
    void render(class_332 gui, class_345 boss, int x, int y);
}