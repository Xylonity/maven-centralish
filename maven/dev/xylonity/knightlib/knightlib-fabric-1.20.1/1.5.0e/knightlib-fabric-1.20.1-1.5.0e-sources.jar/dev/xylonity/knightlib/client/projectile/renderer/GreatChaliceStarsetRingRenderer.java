package dev.xylonity.knightlib.client.projectile.renderer;

import dev.xylonity.knightlib.client.projectile.model.GreatChaliceStarsetRingModel;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class GreatChaliceStarsetRingRenderer extends GeoEntityRenderer<GreatChaliceStartsetRing> {

    public GreatChaliceStarsetRingRenderer(class_5617.class_5618 renderManager) {
        super(renderManager, new GreatChaliceStarsetRingModel());
    }

}