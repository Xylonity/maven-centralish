package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import net.minecraft.class_2378;

public interface KnightLibRegistrar {
    <T> ResourceRegistry<T> create(class_2378<T> type, String modid);
}