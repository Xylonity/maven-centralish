package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.KnightLibFabric;
import dev.xylonity.knightlib.common.recipe.GreatChaliceRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public final class KnightLibRecipes {

    public static void init() { ;; }

    public static final class_1865<GreatChaliceRecipe> CHALICE_SERIALIZER;
    public static final class_3956<GreatChaliceRecipe> CHALICE_TYPE;

    static {
        CHALICE_SERIALIZER = class_2378.method_10230(class_7923.field_41189, new class_2960(KnightLib.MOD_ID, "great_chalice_interaction"), GreatChaliceRecipe.SERIALIZER);
        CHALICE_TYPE = class_2378.method_10230(class_7923.field_41188, new class_2960(KnightLib.MOD_ID, "great_chalice_interaction"), GreatChaliceRecipe.RECIPE_TYPE);
    }

}
