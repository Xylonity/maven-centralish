package dev.xylonity.knightlib.api.interop;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

/**
 * Defines multiple states the chalice can permute between
 */
public enum GreatChaliceState implements class_3542 {
    EMPTY, NORMAL, CHAOTIC;

    @Override
    public @NotNull String method_15434() {
        return name().toLowerCase();
    }

}
