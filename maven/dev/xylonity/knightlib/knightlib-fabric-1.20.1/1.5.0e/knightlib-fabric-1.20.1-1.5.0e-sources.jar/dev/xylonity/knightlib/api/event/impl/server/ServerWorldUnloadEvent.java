package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

/**
 * Fired when a server world is unloaded
 */
public final class ServerWorldUnloadEvent extends KnightLibEvent {

    private final MinecraftServer server;
    private final class_3218 level;

    public ServerWorldUnloadEvent(MinecraftServer server, class_3218 level) {
        this.server = server;
        this.level = level;
    }

    public MinecraftServer server() {
        return server;
    }

    public class_3218 level() {
        return level;
    }

}
