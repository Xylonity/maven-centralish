package dev.xylonity.knightlib.client.blockentity.model;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class GreatChaliceModel extends GeoModel<GreatChaliceBlockEntity> {

    @Override
    public class_2960 getModelResource(GreatChaliceBlockEntity animatable) {
        return new class_2960(KnightLib.MOD_ID, "geo/great_chalice.geo.json");
    }

    @Override
    public class_2960 getTextureResource(GreatChaliceBlockEntity animatable) {
        return switch (animatable.getState()) {
            case CHAOTIC -> new class_2960(KnightLib.MOD_ID, "textures/block/great_chalice_chaotic.png");
            default -> // EMPTY/NORMAL
                    new class_2960(KnightLib.MOD_ID, "textures/block/great_chalice.png");
        };
    }

    @Override
    public class_2960 getAnimationResource(GreatChaliceBlockEntity animatable) {
        return new class_2960(KnightLib.MOD_ID, "animations/great_chalice.animation.json");
    }

}