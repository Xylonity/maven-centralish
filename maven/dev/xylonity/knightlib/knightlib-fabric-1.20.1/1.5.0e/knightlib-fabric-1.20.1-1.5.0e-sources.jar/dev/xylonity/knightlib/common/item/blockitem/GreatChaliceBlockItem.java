package dev.xylonity.knightlib.common.item.blockitem;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

public class GreatChaliceBlockItem extends GenericBlockItem {

    public GreatChaliceBlockItem(class_2248 pBlock, class_1793 pProperties, String name) {
        super(pBlock, pProperties, name);
    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, @Nullable class_1937 level, @NotNull List<class_2561> list, @NotNull class_1836 flag) {
        super.method_7851(itemStack, level, list, flag);
        list.add(class_2561.method_43471("tooltip.item.knightlib.great_chalice"));
    }

}
