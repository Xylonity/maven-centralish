package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.client.ClientComputeCameraAnglesEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public class CameraMixin {

    @Inject(method = "setup", at = @At("TAIL"))
    private void knightlib$onSetup(class_1922 blockGetter, class_1297 cameraEntity, boolean detached, boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        if (blockGetter instanceof class_1937 && cameraEntity instanceof class_1657) {
            final class_310 minecraft = class_310.method_1551();
            KnightLibEvents.CLIENT.dispatch(new ClientComputeCameraAnglesEvent(minecraft, (class_4184) (Object) this, cameraEntity, partialTick));
        }

    }

}