package dev.xylonity.knightlib.common.block.impl;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

/**
 * Tracks an `AbstractTickBlock` tick counter for each block instance to avoid inheriting multiple
 * scheduled ticks into a single block instance, "killing" in some way vanilla parallelism.
 *
 * @author Xylonity
 */
public interface ITickBlockTracker {

    Map<class_2338, class_2248> blockTickMap = new HashMap<>();
    Map<class_2338, Integer> tickCounts = new HashMap<>();

    default void addTickBlock(class_2338 pos, class_2248 block) {
        blockTickMap.put(pos, block);
        tickCounts.put(pos, 0);
    }

    default void removeTickBlock(class_2338 pos) {
        blockTickMap.remove(pos);
        tickCounts.remove(pos);
    }

    default int getTickCount(class_2338 pos) {
        return tickCounts.getOrDefault(pos, 0);
    }

    default void incrementTickCount(class_2338 pos) {
        tickCounts.put(pos, getTickCount(pos) + 1);
    }

    default class_2248 getTickBlock(class_2338 pos) {
        return blockTickMap.get(pos);
    }

    default void resetTickCount(class_2338 pos) {
        tickCounts.put(pos, 0);
    }

}
