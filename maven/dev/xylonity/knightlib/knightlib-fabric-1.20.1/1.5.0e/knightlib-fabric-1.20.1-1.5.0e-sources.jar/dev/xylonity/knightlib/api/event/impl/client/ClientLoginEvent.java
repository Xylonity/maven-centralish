package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_310;

/**
 * Fired when client connects to the server
 */
public final class ClientLoginEvent extends KnightLibEvent {

    private final class_310 client;

    public ClientLoginEvent(class_310 client) {
        this.client = client;
    }

    public class_310 getClient() {
        return client;
    }

}
