package dev.xylonity.knightlib.client.shader.post.internal;

import org.joml.Matrix4f;

import javax.annotation.Nullable;
import net.minecraft.class_243;
import net.minecraft.class_4184;

public final class PostShaderRenderContext {

    public final PostShaderRenderStage stage;
    public final float partialTicks;

    @Nullable
    public final Matrix4f projection;
    @Nullable
    public final Matrix4f modelView;

    @Nullable
    public final Matrix4f inverseProjection;

    public final class_4184 camera;
    public final class_243 cameraPosition;

    public PostShaderRenderContext(PostShaderRenderStage stage, float partialTicks, Matrix4f projection, Matrix4f modelView, class_4184 camera, class_243 cameraPosition) {
        this.stage = stage;
        this.partialTicks = partialTicks;
        this.projection = projection;
        this.modelView = modelView;
        this.camera = camera;
        this.cameraPosition = cameraPosition;

        this.inverseProjection = (projection == null) ? null : new Matrix4f(projection).invert(new Matrix4f());
    }

}