package dev.xylonity.knightlib.registry.registrar;

import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

@SuppressWarnings("unchecked")
public class KnightLibResourceRegistryFabric<T> implements ResourceRegistry<T> {

    private final String modid;
    private final class_2378<T> registry;
    private final List<ResourceEntry<T>> entries = new ArrayList<>();

    public KnightLibResourceRegistryFabric(class_2378<T> type, String modid) {
        this.modid = modid;
        this.registry = type;
    }

    @Override
    public <I extends T> ResourceEntry<I> register(String name, Supplier<? extends I> supplier) {
        class_2960 id = new class_2960(modid, name);

        I object = supplier.get();
        class_2378.method_10230(registry, id, object);
        KnightLibResourceEntryFabric<I> entry = new KnightLibResourceEntryFabric<>(object, id);
        entries.add((ResourceEntry<T>) entry);

        return entry;
    }

    @Override
    public Collection<ResourceEntry<T>> getEntries() {
        return List.copyOf(entries);
    }

    @Override
    public String getNamespace() {
        return this.modid;
    }

    /**
     * Entries are registered through static instancing anyway
     */
    @Override
    public void init() { ;; }

}