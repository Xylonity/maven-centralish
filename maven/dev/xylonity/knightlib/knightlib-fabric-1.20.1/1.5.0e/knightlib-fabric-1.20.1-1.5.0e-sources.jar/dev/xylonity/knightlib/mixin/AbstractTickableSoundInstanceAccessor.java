package dev.xylonity.knightlib.mixin;

import net.minecraft.class_1101;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1101.class)
public interface AbstractTickableSoundInstanceAccessor {

    @Invoker("stop")
    void stopAccessor();

}
