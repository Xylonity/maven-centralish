package dev.xylonity.knightlib.impl.internal;

import dev.xylonity.knightlib.api.music.IBossMusicProvider;
import dev.xylonity.knightlib.mixin.AbstractTickableSoundInstanceAccessor;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_1101;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public final class BossMusicManager {
    private static final Map<Integer, class_1101> ACTIVE = new Int2ObjectOpenHashMap<>();

    private BossMusicManager() { ;; }

    public static void clientTick(class_310 mc) {
        class_1657 player = mc.field_1724;
        if (player == null) return;

        ACTIVE.values().removeIf(class_1101::method_4793);

        for (IBossMusicProvider entity : BossMusicRegistry.getAll()) {
            class_1297 e = (class_1297) entity;
            int id = e.method_5628();
            if (ACTIVE.containsKey(id)) continue;
            if (!entity.shouldPlayBossMusic(player)) continue;

            class_1101 sound = new AbstractLoopSound(entity, entity.soundSource());
            mc.method_1483().method_4873(sound);
            ACTIVE.put(id, sound);
        }
    }

    public static void clear() {
        for (class_1101 sound : ACTIVE.values()) {
            ((AbstractTickableSoundInstanceAccessor) sound).stopAccessor();
        }

        ACTIVE.clear();
    }

}
