package dev.xylonity.knightlib.api.scheduler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;

public final class TickScheduler {
    private static final byte SERVER = 0;
    private static final byte CLIENT = 1;
    private static final byte BOTH = 2;

    private static final Map<class_1937, PriorityQueue<ScheduledTask>> SERVER_TASKS = new ConcurrentHashMap<>(4);
    private static final Map<class_1937, PriorityQueue<ScheduledTask>> CLIENT_TASKS = new ConcurrentHashMap<>(2);
    private static final Map<class_1937, PriorityQueue<ScheduledTask>> COMMON_TASKS = new ConcurrentHashMap<>(4);
    private static final Map<class_1937, Long> LEVEL_TICK_COUNTER = new ConcurrentHashMap<>();

    private static final List<class_1937> LEVELS_TO_CLEAN = new ArrayList<>();

    public static void schedule(class_1937 level, Runnable runnable, int delay, byte type) {
        if (level == null || runnable == null || delay < 0) return;

        ScheduledTask task = new ScheduledTask(getOrCreateTickCounter(level) + delay, runnable);
        switch (type) {
            case SERVER:
                if (!level.method_8608()) getOrCreateQueue(SERVER_TASKS, level).add(task);
                break;
            case CLIENT:
                if (level.method_8608()) getOrCreateQueue(CLIENT_TASKS, level).add(task);
                break;
            case BOTH:
                getOrCreateQueue(COMMON_TASKS, level).add(task);
                break;
            default:
                break;
        }

    }

    /**
     * Schedule in time a task on the server
     * @param level the level where the task is scheduled
     * @param runnable the executable task
     * @param delay the delay in ticks
     */
    public static void scheduleServer(class_1937 level, Runnable runnable, int delay) {
        schedule(level, runnable, delay, SERVER);
    }

    /**
     * Schedule in time a task on the client
     * @param level the level where the task is scheduled
     * @param runnable the executable task
     * @param delay the delay in ticks
     */
    public static void scheduleClient(class_1937 level, Runnable runnable, int delay) {
        schedule(level, runnable, delay, CLIENT);
    }

    /**
     * Schedule in time a task on both sides
     * @param level the level where the task is scheduled
     * @param runnable the executable task
     * @param delay the delay in ticks
     */
    public static void scheduleBoth(class_1937 level, Runnable runnable, int delay) {
        schedule(level, runnable, delay, BOTH);
    }

    public static void markForClean(class_1937 level) {
        if (level != null) {
            synchronized (LEVELS_TO_CLEAN) {
                LEVELS_TO_CLEAN.add(level);
            }
        }

    }

    public static void clean() {
        synchronized (LEVELS_TO_CLEAN) {
            if (!LEVELS_TO_CLEAN.isEmpty()) {
                for (class_1937 level : LEVELS_TO_CLEAN) {
                    SERVER_TASKS.remove(level);
                    CLIENT_TASKS.remove(level);
                    COMMON_TASKS.remove(level);
                    LEVEL_TICK_COUNTER.remove(level);
                }

                LEVELS_TO_CLEAN.clear();
            }

        }

    }

    public static boolean hasTasks() {
        return !SERVER_TASKS.isEmpty() || !CLIENT_TASKS.isEmpty() || !COMMON_TASKS.isEmpty();
    }

    private static PriorityQueue<ScheduledTask> getOrCreateQueue(Map<class_1937, PriorityQueue<ScheduledTask>> map, class_1937 level) {
        return map.computeIfAbsent(level, lvl -> new PriorityQueue<>());
    }

    private static long getOrCreateTickCounter(class_1937 level) {
        return LEVEL_TICK_COUNTER.computeIfAbsent(level, lvl -> 0L);
    }

    public static void incrementTick(class_1937 level) {
        LEVEL_TICK_COUNTER.put(level, getOrCreateTickCounter(level) + 1);
    }

    public static void processServerTasks(class_1937 level) {
        PriorityQueue<ScheduledTask> queue = SERVER_TASKS.get(level);

        if (queue == null || queue.isEmpty()) return;

        while (!queue.isEmpty()) {
            ScheduledTask top = queue.peek();
            if (top.execAt > getOrCreateTickCounter(level)) break;

            queue.poll();
            top.execute();
        }

    }

    public static void processClientTasks(class_1937 level) {
        PriorityQueue<ScheduledTask> queue = CLIENT_TASKS.get(level);

        if (queue == null || queue.isEmpty()) return;

        while (!queue.isEmpty()) {
            ScheduledTask top = queue.peek();

            if (top.execAt > getOrCreateTickCounter(level)) break;

            queue.poll();
            top.execute();
        }

    }

    public static void processCommonTasks(class_1937 level) {
        PriorityQueue<ScheduledTask> queue = COMMON_TASKS.get(level);

        if (queue == null || queue.isEmpty()) return;

        while (!queue.isEmpty()) {
            ScheduledTask top = queue.peek();

            if (top.execAt > getOrCreateTickCounter(level)) break;

            queue.poll();
            top.execute();
        }

    }

    public static final class ScheduledTask implements Comparable<ScheduledTask> {
        private final long execAt;
        private final Runnable runnable;

        private ScheduledTask(long executeAtTick, Runnable runnable) {
            this.execAt = executeAtTick;
            this.runnable = runnable;
        }

        @Override
        public int compareTo(ScheduledTask other) {
            return Long.compare(this.execAt, other.execAt);
        }

        public void execute() {
            runnable.run();
        }

    }

}