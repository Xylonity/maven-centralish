package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_310;

/**
 * Fired when the local client is disconnecting from the server
 */
public final class ClientLogoutEvent extends KnightLibEvent {

    private final class_310 client;

    public ClientLogoutEvent(class_310 client) {
        this.client = client;
    }

    public class_310 getClient() {
        return client;
    }

}
