package dev.xylonity.knightlib.common.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.jetbrains.annotations.NotNull;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class BaseProjectile extends class_1676 implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final class_2940<Integer> LIFETIME = class_2945.method_12791(BaseProjectile.class, class_2943.field_13327);

    public BaseProjectile(class_1299<? extends class_1676> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (field_6012 >= getLifetime()) this.method_5650(class_5529.field_26999);
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(LIFETIME, baseLifetime());
    }

    public int getLifetime() {
        return this.field_6011.method_12789(LIFETIME);
    }

    public void setLifetime(int lifetime) {
        this.field_6011.method_12778(LIFETIME, lifetime);
    }

    @Override
    public void method_5749(@NotNull class_2487 pCompound) {
        super.method_5749(pCompound);
        if (pCompound.method_10545("Lifetime")) {
            this.setLifetime(pCompound.method_10550("Lifetime"));
        }
    }

    @Override
    public void method_5652(@NotNull class_2487 pCompound) {
        super.method_5652(pCompound);
        pCompound.method_10569("Lifetime", this.getLifetime());
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) { ;; }

    protected abstract int baseLifetime();

}
