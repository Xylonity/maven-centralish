package dev.xylonity.knightlib.common.item;

import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.api.interop.GreatChaliceState;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

public class SmallEssenceItem extends class_1792 implements IGreatChaliceInteractable {

    public SmallEssenceItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public int getChargesToApply() {
        return 1;
    }

    @Override
    public boolean canInteract(GreatChaliceBlockEntity chalice, class_1937 level, class_1657 player) {
        return chalice.getState() == GreatChaliceState.NORMAL || chalice.getState() == GreatChaliceState.EMPTY;
    }

    @Override
    public void onPostInteraction(GreatChaliceBlockEntity chalice, class_1657 player, class_1937 level, class_3965 hit) {
        IGreatChaliceInteractable.super.onPostInteraction(chalice, player, level, hit);
        if (chalice.getState() == GreatChaliceState.EMPTY) chalice.setState(GreatChaliceState.NORMAL);
    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, @Nullable class_1937 level, @NotNull List<class_2561> list, @NotNull class_1836 flag) {
        super.method_7851(itemStack, level, list, flag);
        list.add(class_2561.method_43471("tooltip.item.knightlib.small_essence"));
    }

}
