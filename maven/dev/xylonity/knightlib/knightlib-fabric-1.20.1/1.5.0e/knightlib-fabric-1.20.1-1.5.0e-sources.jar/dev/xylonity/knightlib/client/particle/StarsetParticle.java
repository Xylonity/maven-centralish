package dev.xylonity.knightlib.client.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.NotNull;

import java.util.Random;

public class StarsetParticle extends class_4003 {
    private final class_4002 spritesset;

    public StarsetParticle(class_638 world, double x, double y, double z, class_4002 sprites, double velX, double velY, double velZ) {
        super(world, x, y + 0.5, z, 0.0, 0.0, 0.0);

        this.field_17867 = 0.55f;
        this.field_3861 = 1F;
        this.field_3842 = 1F;
        this.field_3859 = 1F;
        this.field_3847 = new Random().nextInt(0, 15) + 20;
        this.method_18142(sprites);
        this.spritesset = sprites;
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    @Override
    public void method_3074(@NotNull class_4588 pBuffer, @NotNull class_4184 pRenderInfo, float pPartialTicks) {
        super.method_3074(pBuffer, pRenderInfo, pPartialTicks);
    }

    @Override
    public void method_3070() {
        super.method_3070();
        this.method_18142(spritesset);
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 spriteSet) {
            this.sprites = spriteSet;
        }

        public class_703 createParticle(@NotNull class_2400 particleType, @NotNull class_638 level, double x, double y, double z, double dx, double dy, double dz) {
            return new StarsetParticle(level, x, y, z, this.sprites, dx, dy, dz);
        }
    }

}