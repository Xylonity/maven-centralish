package dev.xylonity.knightlib.api.bossbar;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.network.packets.BossBarLinkS2C;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3222;

/**
 * Custom implementation of `ServerBossEvent` that stores the actual entity.
 */
public class TrackedServerBossEvent extends class_3213 {

    private final class_1297 owner;

    public TrackedServerBossEvent(class_1297 owner, class_2561 name, class_1260 color, class_1261 overlay) {
        super(name, color, overlay);
        this.owner = owner;
    }

    @Override
    public void method_14088(class_3222 player) {
        super.method_14088(player);

        BossBarLinkS2C packet = new BossBarLinkS2C(
                this.method_5407(),
                owner.method_5628(),
                owner.method_5667(),
                owner.method_5864().method_40124().method_40237().method_29177(),
                owner.method_37908().method_27983().method_29177()
        );

        KnightLib.NET.sendTo(player, BossBarLinkS2C.TYPE.base(), packet);
    }

}
