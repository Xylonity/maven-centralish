package dev.xylonity.knightlib.registry.registrar;

import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import net.minecraft.class_2960;

/**
 * Wraps a RegistryObject to implement ResourceEntry exposing both abstracts
 */
public class KnightLibResourceEntryFabric<T> implements ResourceEntry<T> {

    private final T entry;
    private final class_2960 id;

    public KnightLibResourceEntryFabric(T entry, class_2960 id) {
        this.entry = entry;
        this.id = id;
    }

    @Override
    public T get() {
        return entry;
    }

    @Override
    public class_2960 getId() {
        return id;
    }

}