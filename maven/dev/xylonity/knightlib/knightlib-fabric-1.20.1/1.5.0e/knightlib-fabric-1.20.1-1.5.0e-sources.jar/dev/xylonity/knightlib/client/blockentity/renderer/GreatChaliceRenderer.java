package dev.xylonity.knightlib.client.blockentity.renderer;

import dev.xylonity.knightlib.client.blockentity.model.GreatChaliceModel;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class GreatChaliceRenderer extends GeoBlockRenderer<GreatChaliceBlockEntity> {

    public GreatChaliceRenderer(class_5614.class_5615 rendererDispatcher) {
        super(new GreatChaliceModel());
    }

    @Override
    public void renderRecursively(class_4587 poseStack, GreatChaliceBlockEntity animatable, GeoBone bone, class_1921 renderType, class_4597 bufferSource, class_4588 buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (bone.getName().equals("liquid")) {
            if (animatable.getCharges() == 0) return;

            poseStack.method_22903();

            if (animatable.getCharges() > 0) {
                float yOffset = ((animatable.getCharges() / 12f) * 8f) / 16f;
                poseStack.method_46416(bone.getPosX(),  yOffset, bone.getPosZ());
            }

            super.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha);

            poseStack.method_22909();
            return;
        }

        super.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha);
    }

}