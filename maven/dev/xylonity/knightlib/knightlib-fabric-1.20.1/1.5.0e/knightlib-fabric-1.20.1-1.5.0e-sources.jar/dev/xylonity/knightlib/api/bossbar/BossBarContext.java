package dev.xylonity.knightlib.api.bossbar;

import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_345;
import org.jetbrains.annotations.Nullable;

public record BossBarContext(class_345 event, @Nullable class_1297 entity, @Nullable class_2960 entityType) {
    ;;
}
