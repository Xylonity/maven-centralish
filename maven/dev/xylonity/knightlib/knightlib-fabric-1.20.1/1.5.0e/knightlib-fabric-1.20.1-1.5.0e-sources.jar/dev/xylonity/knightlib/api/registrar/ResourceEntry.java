package dev.xylonity.knightlib.api.registrar;

import java.util.function.Supplier;
import net.minecraft.class_2960;

/**
 * Wrapper that handles one entry in a ResourceRegistry.
 * Example usage:
 * <pre>
 * {@code
 * public static final ResourceEntry<Item> FILLED_GRAIL = ITEMS.register("filled_grail", () -> new FilledGrailItem(new Item.Properties()));
 * }
 * </pre>
 * @param <T> The type of the entry.
 */
public interface ResourceEntry<T> extends Supplier<T> {

    /**
     * Returns the main registered object (entity, item, block, etc.)
     */
    @Override
    T get();

    /**
     * Namespace and name of the object encapsulated
     */
    class_2960 getId();
}