package dev.xylonity.knightlib.common.recipe;

import com.google.gson.JsonObject;
import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.KnightLibFabric;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import dev.xylonity.knightlib.registry.KnightLibItems;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import org.jetbrains.annotations.NotNull;

public record ChaliceFillingRecipe(class_1799 input, class_1799 block) implements class_1860<class_1277> {

    private static final class_2960 ID = new class_2960(KnightLib.MOD_ID, "block_filling");

    public static final class_1865<ChaliceFillingRecipe> SERIALIZER = new Serializer();
    public static final class_3956<ChaliceFillingRecipe> RECIPE_TYPE = new Type();

    @Override
    public boolean matches(class_1277 inv, @NotNull class_1937 lvl) {
        return class_1799.method_7984(inv.method_5438(0), input);
    }

    @Override
    public @NotNull class_1799 assemble(@NotNull class_1277 inv, @NotNull class_5455 reg) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_8113(int w, int h) {
        return true;
    }

    @Override
    public @NotNull class_1799 method_8110(@NotNull class_5455 reg) {
        return class_1799.field_8037;
    }

    @Override
    public @NotNull class_2960 method_8114() {
        return ID;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SERIALIZER;
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return RECIPE_TYPE;
    }

    public static class Type implements class_3956<ChaliceFillingRecipe> {

        @Override
        public String toString() {
            return ID.toString();
        }

    }

    public static class Serializer implements class_1865<ChaliceFillingRecipe> {
        @Override
        public @NotNull ChaliceFillingRecipe method_8121(@NotNull class_2960 id, @NotNull JsonObject json) {
            return new ChaliceFillingRecipe(new class_1799(KnightLibItems.SMALL_ESSENCE.get()), new class_1799(KnightLibBlocks.GREAT_CHALICE.get()));
        }

        @Override
        public ChaliceFillingRecipe method_8122(@NotNull class_2960 id, @NotNull class_2540 buf) {
            class_1799 input = buf.method_10819();
            class_1799 block = buf.method_10819();
            return new ChaliceFillingRecipe(input, block);
        }

        @Override
        public void toNetwork(@NotNull class_2540 buf, @NotNull ChaliceFillingRecipe rec) {
            buf.method_10793(rec.input);
            buf.method_10793(rec.block);
        }
    }

}