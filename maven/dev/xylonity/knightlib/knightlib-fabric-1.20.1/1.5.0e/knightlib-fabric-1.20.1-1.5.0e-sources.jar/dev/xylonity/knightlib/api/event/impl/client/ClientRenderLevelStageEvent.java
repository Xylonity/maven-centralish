package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.client.shader.post.internal.PostShaderRenderStage;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Matrix4f;

/**
 * Fired at specific stages during level rendering (e.g. AFTER_WEATHER, AFTER_TRANSLUCENT, etc.)
 */
public class ClientRenderLevelStageEvent extends KnightLibEvent {

    private final class_310 client;
    private final PostShaderRenderStage stage;
    private final float partialTick;

    private final Matrix4f projection;
    private final Matrix4f modelView;

    private final class_4184 camera;
    private final class_243 cameraPos;

    public ClientRenderLevelStageEvent(class_310 client, PostShaderRenderStage stage, float partialTick, Matrix4f projection, Matrix4f modelView, class_4184 camera, class_243 cameraPos) {
        this.client = client;
        this.stage = stage;
        this.partialTick = partialTick;
        this.projection = projection;
        this.modelView = modelView;
        this.camera = camera;
        this.cameraPos = cameraPos;
    }

    public class_310 getClient() {
        return client;
    }

    public PostShaderRenderStage getStage() {
        return stage;
    }

    public float getPartialTick() {
        return partialTick;
    }

    public Matrix4f getProjection() {
        return projection;
    }

    public Matrix4f getModelView() {
        return modelView;
    }

    public class_4184 getCamera() {
        return camera;
    }

    public class_243 getCameraPosition() {
        return cameraPos;
    }

}
