package dev.xylonity.knightlib.network;

import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Automatic wrapper for server bound (C2S) packets. It also carries the default handler (runnable content of the packet).
 * Always check that the sender is not null and validate message contents (entity existence, range checks, etc.) before
 * mutating world state
 * @param <T>
 */
public final class ServerboundPacketType<T> {

    private final PacketType<T> base;
    private final BiConsumer<T, class_3222> serverHandler;

    public ServerboundPacketType(class_2960 id, Class<T> clazz, PacketCodec<T> codec, BiConsumer<T, class_3222> serverHandler) {
        this.base = new PacketType<>(id, clazz, codec);
        this.serverHandler = serverHandler;
    }

    /**
     * Returns the pure {@link PacketType} (id, class, codec) with no handler attached
     */
    public PacketType<T> base() {
        return base;
    }

    /**
     * Returns the default server handler (runnable) associated with this packet type
     */
    public BiConsumer<T, class_3222> handler() {
        return serverHandler;
    }

}
