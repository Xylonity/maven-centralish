package dev.xylonity.knightlib.impl.internal;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class BossBarLinks {

    public static final BossBarLinks INSTANCE = new BossBarLinks();
    private final Map<UUID, Ref> byBossId = new Object2ObjectOpenHashMap<>();

    public static final class Ref {
        public final int entityId;
        public final UUID entityUuid;
        public final class_2960 entityType;
        public final class_2960 dimension;

        public Ref(int id, UUID uuid, class_2960 type, class_2960 dimension) {
            this.entityId = id;
            this.entityUuid = uuid;
            this.entityType = type;
            this.dimension = dimension;
        }

        public @Nullable class_1297 resolve() {
            class_310 minecraft = class_310.method_1551();

            if (minecraft.field_1687 == null) {
                return null;
            }

            if (!minecraft.field_1687.method_27983().method_29177().equals(dimension)) {
                return null;
            }

            return minecraft.field_1687.method_8469(entityId);
        }

    }

    public void put(UUID bossId, Ref ref) {
        byBossId.put(bossId, ref);
    }

    public @Nullable Ref get(UUID bossId) {
        return byBossId.get(bossId);
    }

    public void remove(UUID bossId) {
        byBossId.remove(bossId);
    }

    public void clear() {
        byBossId.clear();
    }

}
