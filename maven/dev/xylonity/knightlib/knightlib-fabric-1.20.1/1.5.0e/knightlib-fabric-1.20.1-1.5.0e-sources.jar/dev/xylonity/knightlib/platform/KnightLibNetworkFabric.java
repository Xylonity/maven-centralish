package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketType;
import dev.xylonity.knightlib.network.ServerboundPacketType;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

@SuppressWarnings("unchecked")
public class KnightLibNetworkFabric implements KnightLibNetwork {

    private final Map<Class<?>, PacketType<?>> classToType = new ConcurrentHashMap<>();
    private final Map<class_2960, Boolean> clientHandlers = new ConcurrentHashMap<>();

    @Override
    public KnightLibNetwork createEndpoint(String modId, String protocol) {
        return this;
    }

    @Override
    public <T> void registerClientbound(PacketType<T> type, Consumer<T> clientHandler) {
        memoize(type);

        if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT) {
            return;
        }

        if (clientHandlers.putIfAbsent(type.id(), Boolean.TRUE) != null) {
            return;
        }

        ClientPlayNetworking.registerGlobalReceiver(
                type.id(), (client, handler, buf, sender) -> {
                    T msg = type.codec().decode(buf);
                    client.execute(() -> clientHandler.accept(msg));
                }

        );

    }

    @Override
    public <T> void registerServerbound(PacketType<T> type, BiConsumer<T, class_3222> serverHandler) {
        memoize(type);

        ServerPlayNetworking.registerGlobalReceiver(
                type.id(), (server, player, handler, buf, sender) -> {
                    T message = type.codec().decode(buf);
                    server.execute(() -> serverHandler.accept(message, player));
                }

        );

    }

    @Override
    public <T> void register(ClientboundPacketType<T> type) {
        this.registerClientbound(type.base(), type.handler());
    }

    @Override
    public <T> void register(ServerboundPacketType<T> type) {
        this.registerServerbound(type.base(), type.handler());
    }

    @Override
    public <T> void sendToServer(T message) {
        PacketType<T> type = (PacketType<T>) classToType.get(message.getClass());
        if (type == null) {
            throw new IllegalStateException("[KnightLib] No packet registered for message: " + message.getClass().getName());
        }

        if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT) {
            KnightLib.LOGGER.warn("sendToServer called on server for {}", type.id());
            return;
        }

        class_2540 buf = new class_2540(Unpooled.buffer());
        type.codec().encode(message, buf);
        ClientPlayNetworking.send(type.id(), buf);
    }

    @Override
    public <T> void sendTo(class_3222 player, PacketType<T> type, T message) {
        if (player == null) {
            return;
        }

        class_2540 buf = new class_2540(Unpooled.buffer());
        type.codec().encode(message, buf);
        ServerPlayNetworking.send(player, type.id(), buf);
    }

    @Override
    public <T> void sendToAll(MinecraftServer server, PacketType<T> type, T message) {
        if (server == null) {
            return;
        }

        class_2540 bufToRelease = new class_2540(Unpooled.buffer());
        type.codec().encode(message, bufToRelease);

        for (class_3222 player : server.method_3760().method_14571()) {
            class_2540 copy = new class_2540(bufToRelease.copy());
            ServerPlayNetworking.send(player, type.id(), copy);
        }

        bufToRelease.release();
    }

    @Override
    public <T> void sendToPlayers(class_1937 level, PacketType<T> type, T message) {
        if (!(level instanceof class_3218 serverLevel)) {
            return;
        }

        class_2540 bufToRelease = new class_2540(Unpooled.buffer());
        type.codec().encode(message, bufToRelease);

        for (class_3222 player : PlayerLookup.world(serverLevel)) {
            class_2540 copy = new class_2540(bufToRelease.copy());
            ServerPlayNetworking.send(player, type.id(), copy);
        }

        bufToRelease.release();
    }

    @Override
    public <T> void sendToTracking(class_1937 level, class_2338 pos, PacketType<T> type, T message) {
        if (!(level instanceof class_3218 serverLevel)) {
            return;
        }

        class_2540 bufToRelease = new class_2540(Unpooled.buffer());
        type.codec().encode(message, bufToRelease);

        for (class_3222 player : PlayerLookup.tracking(serverLevel, pos)) {
            class_2540 copy = new class_2540(bufToRelease.copy());
            ServerPlayNetworking.send(player, type.id(), copy);
        }

        bufToRelease.release();
    }

    @Override
    public <T> void sendToTracking(class_1297 entity, PacketType<T> type, T message) {
        if (!(entity.method_37908() instanceof class_3218)) {
            return;
        }

        class_2540 bufToRelease = new class_2540(Unpooled.buffer());
        type.codec().encode(message, bufToRelease);

        for (class_3222 player : PlayerLookup.tracking(entity)) {
            class_2540 copy = new class_2540(bufToRelease.copy());
            ServerPlayNetworking.send(player, type.id(), copy);
        }

        bufToRelease.release();
    }

    private <T> void memoize(PacketType<T> type) {
        classToType.put(type.clazz(), type);
    }

}