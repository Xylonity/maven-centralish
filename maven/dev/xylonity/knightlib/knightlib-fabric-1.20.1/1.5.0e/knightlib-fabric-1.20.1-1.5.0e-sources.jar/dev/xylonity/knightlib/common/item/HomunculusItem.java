package dev.xylonity.knightlib.common.item;

import dev.xylonity.knightlib.api.interop.IHomunculusInteractable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

public class HomunculusItem extends class_1792 {

    public HomunculusItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1269 method_7884(@NotNull class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_1799 stack = context.method_8041();

        if (level.method_8320(pos).method_26204() instanceof IHomunculusInteractable actor) {
            if (!actor.canInteract(context)) {
                return class_1269.field_5814;
            }

            actor.onPreInteraction(context);

            if (!level.field_9236) stack.method_7934(actor.shrinkItemAmount());

            if (!actor.getInteractionSounds().isEmpty()) {
                for (class_3414 sound : actor.getInteractionSounds()) {
                    level.method_8396(null, pos, sound, class_3419.field_15245, 1f, 1f);
                }
            }

            actor.onPostInteraction(context);

            return class_1269.field_5812;
        }

        return super.method_7884(context);
    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, @Nullable class_1937 level, @NotNull List<class_2561> list, @NotNull class_1836 flag) {
        list.add(class_2561.method_43471("tooltip.item.knightlib.homunculus"));
    }

}
