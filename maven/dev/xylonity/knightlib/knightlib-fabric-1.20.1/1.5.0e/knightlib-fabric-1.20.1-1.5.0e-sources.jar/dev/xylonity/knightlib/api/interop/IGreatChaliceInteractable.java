package dev.xylonity.knightlib.api.interop;

import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import dev.xylonity.knightlib.registry.KnightLibEntities;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3965;

/**
 * Defines how an item should interact with the Great Chalice.
 */
public interface IGreatChaliceInteractable {

    /**
     * Great chalice maximum charges
     */
    int MAX_CHARGES = 12;

    /**
     * Returns the number of charges to add/remove to the chalice.
     *
     * @return the charge delta to apply to the chalice
     */
    int getChargesToApply();

    /**
     * Determines how many items should be consumed from this stack during the interaction.
     *
     * @return the number of items to remove
     */
    default int shrinkItemAmount() {
        return 1;
    }

    /**
     * Determines if this item can interact with the chalice in its current state.
     * Charge amount and the chalice state must be checked here.
     *
     * @param chalice the chalice from the interaction
     * @param level the level where the interaction is done
     * @param player the player performing the interaction
     * @return true if the interaction should proceed, false if not
     */
    boolean canInteract(GreatChaliceBlockEntity chalice, class_1937 level, class_1657 player);

    /**
     * Called immediately before the main interaction logic is processed.
     *
     * @param chalice the chalice from the interaction
     * @param player the player performing the action
     * @param level the level where the interaction is done
     * @param hit the blockhit info
     */
    default void onPreInteraction(GreatChaliceBlockEntity chalice, class_1657 player, class_1937 level, class_3965 hit) {
        ;;
    }

    /**
     * Called after the main interaction logic has been successfully processed.
     * This won't be triggered if the interaction isn't successful
     *
     * @param chalice the chalice from the interaction
     * @param player the player performing the action
     * @param level the level where the interaction is done
     * @param hit the blockhit info
     */
    default void onPostInteraction(GreatChaliceBlockEntity chalice, class_1657 player, class_1937 level, class_3965 hit) {
        GreatChaliceStartsetRing ring = KnightLibEntities.GREAT_CHALICE_STARSET_RING.get().method_5883(level);
        if (ring != null) {
            ring.method_5814(chalice.method_11016().method_10263() + 0.5f, chalice.method_11016().method_10264() + 0.015, chalice.method_11016().method_10260() + 0.5f);
            level.method_8649(ring);
        }

    }

    /**
     * Provides a set of item stacks to spawn as rewards when the interaction completes.
     * Items will be spawned over the chalice for the player to collect.
     *
     * @return the set of items to spawn
     */
    default @NotNull Set<class_1799> getRewards() {
        return Set.of();
    }

    /**
     * Provides a set of sound effects to play when the interaction occurs.
     * All sounds will be played at the chalice's location.
     *
     * @return a set of sounds to play
     */
    default @NotNull Set<class_3414> getInteractionSounds() {
        return Set.of(class_3417.field_14834);
    }

    /**
     * Returns the sound to play if the chalice reaches its maximum capacity.
     *
     * @return the sound event
     */
    default @NotNull class_3414 getFullChargeSound() {
        return class_3417.field_14709;
    }

}