package dev.xylonity.knightlib.client.event;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.client.*;
import dev.xylonity.knightlib.api.event.impl.interop.TickPhase;
import dev.xylonity.knightlib.client.shader.post.internal.PostShaderRenderStage;
import dev.xylonity.knightlib.client.blockentity.renderer.GreatChaliceRenderer;
import dev.xylonity.knightlib.client.projectile.renderer.GreatChaliceStarsetRingRenderer;
import dev.xylonity.knightlib.client.particle.StarsetParticle;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import dev.xylonity.knightlib.registry.KnightLibEntities;
import dev.xylonity.knightlib.registry.KnightLibParticles;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

public final class KnightLibFabricClientEvents {

    private static class_1937 lastLevel = null;

    public static void init() {
        EntityRendererRegistry.register(
                KnightLibEntities.GREAT_CHALICE_STARSET_RING.get(),
                GreatChaliceStarsetRingRenderer::new
        );

        BlockEntityRendererRegistry.register(
                KnightLibBlockEntities.GREAT_CHALICE.get(),
                GreatChaliceRenderer::new
        );

        ParticleFactoryRegistry.getInstance().register(
                KnightLibParticles.STARSET.get(),
                StarsetParticle.Provider::new
        );

        onEntityLoadOrUnloadEvents();
        onLogoutOrLoginEvents();
        onRenderGuiEvents();
        onClientTickEvents();
        onRenderLevelEvents();
        onClientLevelTrackingEvents();
        onClientResourcesReloadEvents();
    }

    private static void onEntityLoadOrUnloadEvents() {
        ClientEntityEvents.ENTITY_LOAD.register((entity, level) -> {
            final class_310 minecraft = class_310.method_1551();
            KnightLibEvents.CLIENT.dispatch(new ClientEntityJoinLevelEvent(minecraft, level, entity));
        });

        ClientEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            final class_310 minecraft = class_310.method_1551();
            KnightLibEvents.CLIENT.dispatch(new ClientEntityLeaveLevelEvent(minecraft, level, entity));
        });

    }

    private static void onLogoutOrLoginEvents() {
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            KnightLibEvents.CLIENT.dispatch(new ClientLogoutEvent(client));
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            KnightLibEvents.CLIENT.dispatch(new ClientLoginEvent(client));
        });

    }

    private static void onRenderGuiEvents() {
        HudRenderCallback.EVENT.register((guiGraphics, tickDelta) -> {
            final class_310 minecraft = class_310.method_1551();
            KnightLibEvents.CLIENT.dispatch(new ClientRenderGuiEvent(minecraft, guiGraphics, tickDelta));
        });

    }

    private static void onClientTickEvents() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            KnightLibEvents.CLIENT.dispatch(new ClientTickEvent(client, TickPhase.START));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            KnightLibEvents.CLIENT.dispatch(new ClientTickEvent(client, TickPhase.END));
        });

    }

    private static void onRenderLevelEvents() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
            final class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1687 == null) {
                return;
            }

            final float partialTick = context.tickDelta();

            final Matrix4f projection = new Matrix4f(context.projectionMatrix());
            final Matrix4f modelView  = new Matrix4f(context.matrixStack().method_23760().method_23761());

            final class_243 cameraPosition = context.camera().method_19326();

            KnightLibEvents.CLIENT.dispatch(new ClientRenderLevelStageEvent(
                    minecraft,
                    PostShaderRenderStage.AFTER_TRANSLUCENT_BLOCKS,
                    partialTick,
                    projection,
                    modelView,
                    context.camera(),
                    cameraPosition
            ));
        });

        WorldRenderEvents.END.register(context -> {
            final class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1687 == null) {
                return;
            }

            final float partialTick = context.tickDelta();

            final Matrix4f projection = new Matrix4f(context.projectionMatrix());
            final Matrix4f modelView  = new Matrix4f(context.matrixStack().method_23760().method_23761());

            final class_243 cameraPosition = context.camera().method_19326();

            KnightLibEvents.CLIENT.dispatch(new ClientRenderLevelStageEvent(
                    minecraft,
                    PostShaderRenderStage.AFTER_LEVEL,
                    partialTick,
                    projection,
                    modelView,
                    context.camera(),
                    cameraPosition
            ));

        });

    }

    private static void onClientLevelTrackingEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            final class_1937 current = client.field_1687;

            if (current == lastLevel) {
                return;
            }

            if (lastLevel != null) {
                KnightLibEvents.CLIENT.dispatch(new ClientWorldUnloadEvent(client, lastLevel));
            }

            if (current != null) {
                KnightLibEvents.CLIENT.dispatch(new ClientWorldLoadEvent(client, current));
            }

            lastLevel = current;
        });

    }

    private static void onClientResourcesReloadEvents() {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {

                    private static final class_2960 ID = KnightLib.of("client_resources_reloaded");

                    @Override
                    public class_2960 getFabricId() {
                        return ID;
                    }

                    @Override
                    public void method_14491(@NotNull class_3300 resourceManager) {
                        class_310 minecraft = class_310.method_1551();
                        KnightLibEvents.CLIENT.dispatch(new ClientResourcesReloadedEvent(minecraft, resourceManager));
                    }

                }
        );

    }

}