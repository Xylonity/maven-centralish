package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

/**
 * Fired when a living entity dies. Can be cancelled to prevent the death
 */
public class LivingDeathEvent extends KnightLibEvent {

    private final class_1309 entity;
    private final class_1282 source;
    private boolean cancelled;

    public LivingDeathEvent(class_1309 entity, class_1282 source) {
        this.entity = entity;
        this.source = source;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_1282 getSource() {
        return source;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

}