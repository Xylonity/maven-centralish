package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import java.io.IOException;
import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;

/**
 * Event to register core shaders (ShaderInstance)
 */
public abstract class ShaderRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public abstract void register(class_2960 id, class_293 format, Consumer<class_5944> onLoaded) throws IOException;

}