package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;

/**
 * Event to register block entity renderers
 */
public abstract class BlockEntityRendererRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public <T extends class_2586> void register(ResourceEntry<class_2591<T>> blockEntityEntry, class_5614<T> rendererProvider) {
        register(blockEntityEntry.get(), rendererProvider);
    }

    public abstract <T extends class_2586> void register(class_2591<T> blockEntityType, class_5614<T> rendererProvider);

}