package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1937;
import net.minecraft.class_310;

/**
 * Fired when a client world is loaded (joining server, loading singleplayer)
 */
public final class ClientWorldLoadEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_1937 level;

    public ClientWorldLoadEvent(class_310 client, class_1937 level) {
        this.client = client;
        this.level = level;
    }

    public class_310 getClient() {
        return client;
    }

    public class_1937 getLevel() {
        return level;
    }

}
