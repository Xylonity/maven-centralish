package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Fired every frame during GUI rendering, after the game GUI is drawn
 */
public final class ClientRenderGuiEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_332 guiGraphics;
    private final float partialTick;

    public ClientRenderGuiEvent(class_310 client, class_332 guiGraphics, float partialTick) {
        this.client = client;
        this.guiGraphics = guiGraphics;
        this.partialTick = partialTick;
    }

    @Override
    public boolean isSticky() {
        return false;
    }

    public class_310 client() {
        return client;
    }

    public class_332 guiGraphics() {
        return guiGraphics;
    }

    public float partialTick() {
        return partialTick;
    }
}
