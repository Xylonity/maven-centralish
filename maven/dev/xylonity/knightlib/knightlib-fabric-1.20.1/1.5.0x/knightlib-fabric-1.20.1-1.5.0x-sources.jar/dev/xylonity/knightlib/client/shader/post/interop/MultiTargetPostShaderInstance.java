package dev.xylonity.knightlib.client.shader.post.interop;

import net.minecraft.class_276;

public interface MultiTargetPostShaderInstance {
    class_276 target(String name);
    String keyId();
}
