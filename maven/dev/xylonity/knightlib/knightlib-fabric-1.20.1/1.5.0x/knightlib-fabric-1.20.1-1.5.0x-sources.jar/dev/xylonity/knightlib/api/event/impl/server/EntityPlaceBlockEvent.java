package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Fired when an entity places a block
 */
public class EntityPlaceBlockEvent extends KnightLibEvent {

    private final class_1937 level;
    private final class_2338 clickedPosition;
    private final class_2680 placedBlock;
    private final class_1297 entity;
    private boolean cancelled;

    public EntityPlaceBlockEvent(class_1937 level, class_2338 clickedPosition, class_2680 placedBlock, class_1297 entity) {
        this.level = level;
        this.clickedPosition = clickedPosition;
        this.placedBlock = placedBlock;
        this.entity = entity;
    }

    public class_1937 getLevel() {
        return level;
    }

    public class_2338 getClickedPosition() {
        return clickedPosition;
    }

    public class_2680 getPlacedBlock() {
        return placedBlock;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

}