package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.EntityRendererRegistrationEvent;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

public class EntityRendererRegistrationEventFabric extends EntityRendererRegistrationEvent {

    @Override
    public <T extends class_1297> void register(class_1299<T> entityType, class_5617<T> rendererProvider) {
        EntityRendererRegistry.register(entityType, rendererProvider);
    }

}