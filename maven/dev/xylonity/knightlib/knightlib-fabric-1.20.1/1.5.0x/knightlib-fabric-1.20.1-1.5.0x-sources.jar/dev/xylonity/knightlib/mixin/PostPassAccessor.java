package dev.xylonity.knightlib.mixin;

import net.minecraft.class_280;
import net.minecraft.class_283;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_283.class)
public interface PostPassAccessor {

    @Accessor("effect")
    class_280 knightlib$getEffect();

}
