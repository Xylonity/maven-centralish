package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.event.impl.interop.TickPhase;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Fired at the start/end of each client-side player tick
 */
public final class ClientPlayerTickEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_746 player;
    private final TickPhase phase;

    public ClientPlayerTickEvent(class_310 client, class_746 player, TickPhase phase) {
        this.client = client;
        this.player = player;
        this.phase = phase;
    }

    public class_310 getClient() {
        return client;
    }

    public class_746 getPlayer() {
        return player;
    }

    public TickPhase getPhase() {
        return phase;
    }

}