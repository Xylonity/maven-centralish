package dev.xylonity.knightlib.api.event.impl.server;

import com.mojang.brigadier.CommandDispatcher;
import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

/**
 * Fired when commands are being registered (provides the dispatcher for direct command registration)
 */
public final class CommandRegistrationEvent extends KnightLibEvent {

    private final CommandDispatcher<class_2168> dispatcher;
    private final class_7157 buildContext;
    private final class_2170.class_5364 commandSelection;

    public CommandRegistrationEvent(CommandDispatcher<class_2168> dispatcher, class_7157 buildContext, class_2170.class_5364 commandSelection) {
        this.dispatcher = dispatcher;
        this.buildContext = buildContext;
        this.commandSelection = commandSelection;
    }

    public CommandDispatcher<class_2168> getDispatcher() {
        return dispatcher;
    }

    public class_7157 getBuildContext() {
        return buildContext;
    }

    public class_2170.class_5364 getCommandSelection() {
        return commandSelection;
    }

}