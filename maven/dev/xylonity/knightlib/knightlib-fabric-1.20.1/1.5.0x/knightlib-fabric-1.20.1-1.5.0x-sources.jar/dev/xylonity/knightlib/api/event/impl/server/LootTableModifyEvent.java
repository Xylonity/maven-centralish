package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_55;

/**
 * Fired when a loot table is being loaded, allowing modification via pool injection
 */
public final class LootTableModifyEvent extends KnightLibEvent {

    private final class_2960 id;
    private final List<class_55.class_56> pendingPools = new ArrayList<>();

    public LootTableModifyEvent(class_2960 id) {
        this.id = id;
    }

    /**
     * The resource location of the loot table being loaded.
     * For example {@code minecraft:entities/zombie} or {@code minecraft:chests/stronghold}
     */
    public class_2960 getId() {
        return id;
    }

    /**
     * Adds a loot pool to this table
     */
    public void addPool(class_55.class_56 pool) {
        pendingPools.add(pool);
    }

    /**
     * Returns all pools. Internal
     */
    public List<class_55.class_56> getPendingPools() {
        return Collections.unmodifiableList(pendingPools);
    }

    public boolean isEntityTable() {
        return id.method_12832().startsWith("entities/");
    }

    public boolean isChestTable() {
        return id.method_12832().startsWith("chests/");
    }

}