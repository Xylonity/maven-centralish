package dev.xylonity.knightlib.api.network;

import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketType;
import dev.xylonity.knightlib.network.ServerboundPacketType;
import dev.xylonity.knightlib.platform.KnightLibNetwork;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public final class NetworkEndpoint {

    private final KnightLibNetwork network;

    public NetworkEndpoint(KnightLibNetwork backend) {
        this.network = backend;
    }

    public <T> void registerClientbound(PacketType<T> type, Consumer<T> clientHandler) {
        network.registerClientbound(type, clientHandler);
    }

    public <T> void registerServerbound(PacketType<T> type, BiConsumer<T, class_3222> serverHandler) {
        network.registerServerbound(type, serverHandler);
    }

    public <T> void register(ClientboundPacketType<T> type) {
        network.register(type);
    }

    public <T> void register(ServerboundPacketType<T> type) {
        network.register(type);
    }

    public <T> void sendToServer(T msg) {
        network.sendToServer(msg);
    }

    public <T> void sendTo(class_3222 player, PacketType<T> type, T msg) {
        network.sendTo(player, type, msg);
    }

    public <T> void sendToAll(MinecraftServer server, PacketType<T> type, T msg) {
        network.sendToAll(server, type, msg);
    }

    public <T> void sendToPlayers(class_1937 level, PacketType<T> type, T msg) {
        network.sendToPlayers(level, type, msg);
    }

    public <T> void sendToTracking(class_1937 level, class_2338 pos, PacketType<T> type, T msg) {
        network.sendToTracking(level, pos, type, msg);
    }

    public <T> void sendToTracking(class_1297 entity, PacketType<T> type, T msg) {
        network.sendToTracking(entity, type, msg);
    }

}
