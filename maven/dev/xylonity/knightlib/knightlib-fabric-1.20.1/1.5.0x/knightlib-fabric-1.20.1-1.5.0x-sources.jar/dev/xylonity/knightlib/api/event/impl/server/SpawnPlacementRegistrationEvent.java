package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1317;
import net.minecraft.class_2902;

/**
 * Event to register custom spawn placement rules for entities
 */
public abstract class SpawnPlacementRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public abstract <T extends class_1308> void register(
            class_1299<T> entityType,
            class_1317.class_1319 placementType,
            class_2902.class_2903 heightmapType,
            class_1317.class_4306<T> predicate
    );

}