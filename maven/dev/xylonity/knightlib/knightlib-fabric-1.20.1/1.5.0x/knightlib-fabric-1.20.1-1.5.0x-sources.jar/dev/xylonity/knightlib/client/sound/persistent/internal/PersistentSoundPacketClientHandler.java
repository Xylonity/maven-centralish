package dev.xylonity.knightlib.client.sound.persistent.internal;

import dev.xylonity.knightlib.api.sound.persistent.KnightLibPersistentSounds;
import dev.xylonity.knightlib.network.packets.PersistentSoundTickS2C;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_310;

/**
 * Client handler for {@link PersistentSoundTickS2C}
 */
public final class PersistentSoundPacketClientHandler {

    private PersistentSoundPacketClientHandler() {
        ;;
    }

    public static void handle(PersistentSoundTickS2C packet) {
        final class_1937 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        final class_1297 entity = level.method_8469(packet.entityId());
        if (entity == null) {
            return;
        }

        KnightLibPersistentSounds.tick(entity, packet.names());
    }

}
