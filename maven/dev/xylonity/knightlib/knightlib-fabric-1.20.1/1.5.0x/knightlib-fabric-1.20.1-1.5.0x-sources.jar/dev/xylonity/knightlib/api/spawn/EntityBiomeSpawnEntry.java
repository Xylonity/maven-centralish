package dev.xylonity.knightlib.api.spawn;

import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_6880;

/**
 * Immutable descriptor for a mob biome spawn entry.
 * <br><br>
 * Spawn placement rules are registered separately via {@link dev.xylonity.knightlib.api.event.impl.server.SpawnPlacementRegistrationEvent}
 */
public final class EntityBiomeSpawnEntry<T extends class_1308> {

    private final Predicate<class_6880<class_1959>> biomeFilter;
    private final Supplier<class_1299<T>> entityType;
    private final class_1311 category;

    private final int weight;
    private final int minCount;
    private final int maxCount;

    public EntityBiomeSpawnEntry(
            Supplier<class_1299<T>> entityType,
            class_1311 category,
            int weight,
            int minCount,
            int maxCount,
            Predicate<class_6880<class_1959>> biomeFilter
    ) {
        this.entityType = entityType;
        this.category = category;
        this.weight = weight;
        this.minCount = minCount;
        this.maxCount = maxCount;
        this.biomeFilter = biomeFilter;
    }

    public class_1299<T> getEntityType() {
        return entityType.get();
    }

    public Supplier<class_1299<T>> getEntityTypeSupplier() {
        return entityType;
    }

    public class_1311 getCategory() {
        return category;
    }

    public int getWeight() {
        return weight;
    }

    public int getMinCount() {
        return minCount;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public Predicate<class_6880<class_1959>> getBiomeFilter() {
        return biomeFilter;
    }

}