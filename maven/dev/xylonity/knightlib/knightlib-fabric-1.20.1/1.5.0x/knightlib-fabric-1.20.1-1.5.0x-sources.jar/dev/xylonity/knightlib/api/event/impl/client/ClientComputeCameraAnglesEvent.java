package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4184;

/**
 * Fired when camera angles can be adjusted
 */
public final class ClientComputeCameraAnglesEvent extends KnightLibEvent {

    private final class_310 client;
    private final class_4184 camera;
    private final class_1297 cameraEntity;
    private final float partialTick;

    public ClientComputeCameraAnglesEvent(class_310 client, class_4184 camera, class_1297 cameraEntity, float partialTick) {
        this.client = client;
        this.camera = camera;
        this.cameraEntity = cameraEntity;
        this.partialTick = partialTick;
    }

    public class_310 getClient() {
        return client;
    }

    public class_4184 getCamera() {
        return camera;
    }

    public class_1297 getCameraEntity() {
        return cameraEntity;
    }

    public float getPartialTick() {
        return partialTick;
    }

}
