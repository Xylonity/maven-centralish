package dev.xylonity.knightlib.api.spawn;

import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;

/**
 * Entity per-biome spawn registration API.
 * <br><br>
 * The registration process is deferred to {@link EntityBiomeSpawnBuilder}
 */
public final class KnightLibEntityBiomeSpawns {

    private static final List<EntityBiomeSpawnEntry<?>> ENTRIES = new ArrayList<>();
    private static volatile boolean frozen = false;

    private KnightLibEntityBiomeSpawns() {
        ;;
    }

    /**
     * Creates a builder for a new spawn entry.
     *
     * @param entityType the entity in this context
     * @param category the category for spawning
     */
    public static <T extends class_1308> EntityBiomeSpawnBuilder<T> builder(Supplier<class_1299<T>> entityType, class_1311 category) {
        return new EntityBiomeSpawnBuilder<>(entityType, category);
    }

    /**
     * Creates a builder for a new spawn entry using a {@link ResourceEntry} (just in case the compiler complains).
     *
     * @param entityEntry the entity in this context
     * @param category the category for spawning
     */
    public static <T extends class_1308> EntityBiomeSpawnBuilder<T> builder(ResourceEntry<class_1299<T>> entityEntry, class_1311 category) {
        return new EntityBiomeSpawnBuilder<>(entityEntry, category);
    }

    /**
     * Adds a finalized entry to the registry. Internal
     */
    static <T extends class_1308> void addEntry(EntityBiomeSpawnEntry<T> entry) {
        if (frozen) {
            throw new IllegalStateException(
                    "[KnightLib] Cannot register entity biome spawns after the registry has been frozen."
            );

        }

        ENTRIES.add(entry);
    }

    /**
     * Returns all registered spawn entries. Internal
     */
    public static List<EntityBiomeSpawnEntry<?>> getEntries() {
        return Collections.unmodifiableList(ENTRIES);
    }

    /**
     * Prevents further entries from being registered (mainly for fabric, just in case). Internal
     */
    public static void freeze() {
        frozen = true;
    }

}