package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.AdditionalModelsRegistrationEvent;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_2960;
import java.util.ArrayList;
import java.util.List;

public class AdditionalModelsRegistrationEventFabric extends AdditionalModelsRegistrationEvent {

    private final List<class_2960> models = new ArrayList<>();

    @Override
    public void register(class_2960 modelLocation) {
        models.add(modelLocation);
    }

    public void applyToFabric() {
        ModelLoadingPlugin.register(pluginContext -> {
            for (class_2960 model : models) {
                pluginContext.addModels(model);
            }

        });

    }

}