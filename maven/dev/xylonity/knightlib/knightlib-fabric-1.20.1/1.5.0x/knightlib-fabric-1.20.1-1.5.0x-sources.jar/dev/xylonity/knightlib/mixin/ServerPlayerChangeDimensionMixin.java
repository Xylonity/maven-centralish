package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.PlayerChangedDimensionEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class ServerPlayerChangeDimensionMixin {

    @Inject(method = "changeDimension", at = @At("RETURN"))
    private void knightlib$afterChangeDimension(class_3218 destination, CallbackInfoReturnable<class_1297> cir) {
        final class_3222 self = (class_3222) (Object) this;
        if (cir.getReturnValue() == null) {
            return;
        }

        final class_5321<class_1937> origin = self.method_37908().method_27983();
        KnightLibEvents.SERVER.dispatch(new PlayerChangedDimensionEvent(
                self.field_13995, self, origin, destination.method_27983()
        ));
    }

}