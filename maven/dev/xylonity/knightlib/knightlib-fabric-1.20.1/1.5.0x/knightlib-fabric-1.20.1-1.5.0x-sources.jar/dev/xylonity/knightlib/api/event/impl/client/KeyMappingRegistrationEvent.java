package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_304;

/**
 * Event to register custom keybindings
 */
public abstract class KeyMappingRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    /**
     * Registers a specific keybind
     * 
     * @param keyMapping the keymapping to register (must be built before registering it)
     */
    public abstract void registerKeyMapping(class_304 keyMapping);

    public void registerKeyMappings(class_304... keyMappings) {
        for (class_304 keyMapping : keyMappings) {
            registerKeyMapping(keyMapping);
        }

    }

}