package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.BlockEntityRendererRegistrationEvent;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;

public class BlockEntityRendererRegistrationEventFabric extends BlockEntityRendererRegistrationEvent {

    @Override
    public <T extends class_2586> void register(class_2591<T> blockEntityType, class_5614<T> rendererProvider) {
        BlockEntityRendererRegistry.register(blockEntityType, rendererProvider);
    }

}