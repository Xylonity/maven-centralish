package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.LivingHurtEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1309.class)
public class LivingEntityHurtMixin {

    @ModifyVariable(method = "hurt", at = @At("HEAD"), argsOnly = true)
    private float knightlib$onHurt(float amount, class_1282 source) {
        final class_1309 self = (class_1309) (Object) this;
        final LivingHurtEvent event = new LivingHurtEvent(self, source, amount);
        KnightLibEvents.SERVER.dispatch(event);

        if (event.isCancelled()) {
            return 0f;
        }

        return event.getAmount();
    }

}