package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;

/**
 * Fired after a player has changed dimension
 */
public class PlayerChangedDimensionEvent extends KnightLibEvent {

    private final MinecraftServer server;
    private final class_3222 player;
    private final class_5321<class_1937> origin;
    private final class_5321<class_1937> destination;

    public PlayerChangedDimensionEvent(MinecraftServer server, class_3222 player, class_5321<class_1937> origin, class_5321<class_1937> destination) {
        this.server = server;
        this.player = player;
        this.origin = origin;
        this.destination = destination;
    }

    public MinecraftServer getServer() {
        return server;
    }

    public class_3222 getPlayer() {
        return player;
    }

    public class_5321<class_1937> getOrigin() {
        return origin;
    }

    public class_5321<class_1937> getDestination() {
        return destination;
    }

}