package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.client.shader.post.interop.PostShaderManager;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderRenderContext;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderRenderStage;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {

    @Final
    @Shadow
    class_310 minecraft;

    @Final
    @Shadow
    private class_4184 mainCamera;

    @Inject(
            method = "renderLevel",
            at = @At("TAIL")
    )
    private void knightlib$afterRenderLevel(float partialTicks, long finishTimeNano, class_4587 poseStack, CallbackInfo ci) {
        Matrix4f projection = new Matrix4f(minecraft.field_1773.method_22973(partialTicks));
        Matrix4f modelView = new Matrix4f(poseStack.method_23760().method_23761());

        class_243 cameraPosition = mainCamera.method_19326();

        PostShaderRenderContext context = new PostShaderRenderContext(
                PostShaderRenderStage.GAME_RENDERER_TAIL,
                partialTicks,
                projection,
                modelView,
                mainCamera,
                cameraPosition
        );

        PostShaderManager.renderStage(context);
    }

}
