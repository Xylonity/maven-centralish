package dev.xylonity.knightlib.api.sound.persistent.impl;

import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/**
 * Immutable descriptor for a named persistent (looping) sound within a {@link PersistentSoundProfile}.
 * The entity attached decides when to play this sound (by name)
 */
public final class PersistentSound {

    private final String name;
    private final Supplier<class_3414> event;

    private final float volume;
    private final float pitch;

    private final class_3419 source;

    private final int fadeInTicks;
    private final int fadeOutTicks;

    private final @Nullable Supplier<class_3414> onStartSound;
    private final @Nullable Supplier<class_3414> onStopSound;

    private final float onStartVolume;
    private final float onStopVolume;

    PersistentSound(
            String name,
            Supplier<class_3414> event,
            float volume,
            float pitch,
            class_3419 source,
            int fadeInTicks,
            int fadeOutTicks,
            @Nullable Supplier<class_3414> onStartSound,
            @Nullable Supplier<class_3414> onStopSound,
            float onStartVolume,
            float onStopVolume
    ) {
        this.name = name;
        this.event = event;
        this.volume = volume;
        this.pitch = pitch;
        this.source = source;
        this.fadeInTicks = fadeInTicks;
        this.fadeOutTicks = fadeOutTicks;
        this.onStartSound = onStartSound;
        this.onStopSound = onStopSound;
        this.onStartVolume = onStartVolume;
        this.onStopVolume = onStopVolume;
    }

    public String getName() {
        return name;
    }

    public class_3414 getEvent() {
        return event.get();
    }

    public float getVolume() {
        return volume;
    }

    public float getPitch() {
        return pitch;
    }

    public class_3419 getSource() {
        return source;
    }

    public int getFadeInTicks() {
        return fadeInTicks;
    }

    public int getFadeOutTicks() {
        return fadeOutTicks;
    }

    public boolean hasOnStart() {
        return onStartSound != null;
    }

    public boolean hasOnStop() {
        return onStopSound != null;
    }

    public @Nullable class_3414 getOnStartSound() {
        return onStartSound != null ? onStartSound.get() : null;
    }

    public @Nullable class_3414 getOnStopSound() {
        return onStopSound != null ? onStopSound.get() : null;
    }

    public float getOnStartVolume() {
        return onStartVolume;
    }

    public float getOnStopVolume() {
        return onStopVolume;
    }

}