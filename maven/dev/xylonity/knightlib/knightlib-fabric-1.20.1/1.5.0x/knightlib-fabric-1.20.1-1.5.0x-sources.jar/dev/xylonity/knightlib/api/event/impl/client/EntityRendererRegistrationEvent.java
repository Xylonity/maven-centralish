package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

/**
 * Event to register entity renderers
 */
public abstract class EntityRendererRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public <T extends class_1297> void register(ResourceEntry<class_1299<T>> entityEntry, class_5617<T> rendererProvider) {
        register(entityEntry.get(), rendererProvider);
    }

    public abstract <T extends class_1297> void register(class_1299<T> entityType, class_5617<T> rendererProvider);

}