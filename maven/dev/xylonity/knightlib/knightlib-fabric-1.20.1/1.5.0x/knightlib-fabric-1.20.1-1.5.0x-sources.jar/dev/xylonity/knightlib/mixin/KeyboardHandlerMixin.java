package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.client.ClientKeyInputEvent;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {

    @Inject(method = "keyPress", at = @At("TAIL"))
    private void knightlib$onKeyPress(long window, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        if (window == class_310.method_1551().method_22683().method_4490()) {
            KnightLibEvents.CLIENT.dispatch(new ClientKeyInputEvent(key, scanCode, action, modifiers));
        }

    }

}