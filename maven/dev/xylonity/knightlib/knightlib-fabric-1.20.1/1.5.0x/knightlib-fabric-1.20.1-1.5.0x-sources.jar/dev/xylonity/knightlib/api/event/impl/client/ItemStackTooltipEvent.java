package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/**
 * Fired when an item tooltip is being gathered, allowing modification of tooltip lines.
 * The tooltip list is mutable, so observers can add, remove, or reorder lines
 */
public final class ItemStackTooltipEvent extends KnightLibEvent {

    private final class_1799 itemStack;
    private final List<class_2561> tooltipLines;
    private final class_1836 flag;

    public ItemStackTooltipEvent(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 flag) {
        this.itemStack = itemStack;
        this.tooltipLines = tooltipLines;
        this.flag = flag;
    }

    public class_1799 getItemStack() {
        return itemStack;
    }

    /**
     * Mutable list of tooltip components.
     */
    public List<class_2561> getTooltipLines() {
        return tooltipLines;
    }

    public class_1836 getFlag() {
        return flag;
    }

}