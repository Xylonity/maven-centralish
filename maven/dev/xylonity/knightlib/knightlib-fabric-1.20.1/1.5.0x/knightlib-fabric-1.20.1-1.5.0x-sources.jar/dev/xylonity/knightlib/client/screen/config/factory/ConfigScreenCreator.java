package dev.xylonity.knightlib.client.screen.config.factory;

import dev.xylonity.knightlib.client.screen.config.ConfigBridgeScreen;
import dev.xylonity.knightlib.client.screen.config.KnightLibConfigScreen;
import dev.xylonity.knightlib.config.interop.ConfigRegistry;
import java.util.List;
import net.minecraft.class_437;

public final class ConfigScreenCreator {

    /**
     * Creates the appropriate config screen for a mod.
     * If the mod has a single config, returns the config editor directly.
     * If the mod has multiple configs, returns a selector screen.
     */
    public static class_437 createScreen(String modId, class_437 parent) {
        List<Class<?>> configs = ConfigRegistry.getConfigs(modId);
        if (configs.isEmpty()) {
            return parent;
        }

        if (configs.size() == 1) {
            return new KnightLibConfigScreen(parent, configs.get(0));
        }

        return new ConfigBridgeScreen(parent, modId, configs);
    }

}