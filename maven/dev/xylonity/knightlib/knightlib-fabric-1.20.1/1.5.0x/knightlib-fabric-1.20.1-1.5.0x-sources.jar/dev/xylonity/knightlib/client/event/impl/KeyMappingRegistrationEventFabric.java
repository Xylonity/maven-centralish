package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.KeyMappingRegistrationEvent;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;

public class KeyMappingRegistrationEventFabric extends KeyMappingRegistrationEvent {

    @Override
    public void registerKeyMapping(class_304 keyMapping) {
        KeyBindingHelper.registerKeyBinding(keyMapping);
    }

}