package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.ParticleProviderRegistrationEvent;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_707;
import java.util.function.Function;

public class ParticleProviderRegistrationEventFabric extends ParticleProviderRegistrationEvent {

    @Override
    public <T extends class_2394> void register(class_2396<T> particleType, Function<class_4002, class_707<T>> provider) {
        ParticleFactoryRegistry.getInstance().register(particleType, provider::apply);
    }

}