package dev.xylonity.knightlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.Map;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_283;

@Mixin(class_279.class)
public interface PostChainAccessor {

    @Accessor("passes")
    List<class_283> knightlib$getPasses();

    @Accessor("customRenderTargets")
    Map<String, class_276> knightlib$getTargets();

}