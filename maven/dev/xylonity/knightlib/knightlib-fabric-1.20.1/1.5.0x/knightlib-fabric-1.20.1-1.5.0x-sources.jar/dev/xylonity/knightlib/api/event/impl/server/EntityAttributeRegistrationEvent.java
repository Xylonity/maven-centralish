package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;

/**
 * Event to register entity attributes
 */
public abstract class EntityAttributeRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public <T extends class_1309> void register(ResourceEntry<class_1299<T>> entityEntry, Supplier<class_5132.class_5133> attributes) {
        register(entityEntry.get(), attributes);
    }

    public abstract <T extends class_1309> void register(class_1299<T> entityType, Supplier<class_5132.class_5133> attributes);

}