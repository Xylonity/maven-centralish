package dev.xylonity.knightlib.config.interop;

import dev.xylonity.knightlib.api.config.AutoConfig;
import dev.xylonity.knightlib.client.screen.config.ConfigBridgeScreen;
import dev.xylonity.knightlib.client.screen.config.KnightLibConfigScreen;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_437;

/**
 * Core registrar that maps modIds to their config classes.
 * Used internally by KnightLib to know which config screens to build
 * and by loader-specific code to hook into the mod menu.
 *
 * <p>{@code ConfigComposer} handles registration, don't interact with this class.</p>
 */
public final class ConfigRegistry {

    private static final ConcurrentHashMap<String, List<Class<?>>> CONFIGS = new ConcurrentHashMap<>();

    public static void register(String modId, Class<?> configClass) {
        CONFIGS.computeIfAbsent(modId, string -> Collections.synchronizedList(new ArrayList<>())).add(configClass);
    }

    /**
     * Returns all config classes registered for a given mod, sorted by {@link AutoConfig#order()}.
     */
    public static List<Class<?>> getConfigs(String modId) {
        List<Class<?>> list = CONFIGS.get(modId);
        if (list == null) {
            return Collections.emptyList();
        }

        List<Class<?>> sorted = new ArrayList<>(list);
        sorted.sort(Comparator.comparingInt(clazz -> {
            AutoConfig meta = clazz.getAnnotation(AutoConfig.class);
            return meta != null ? meta.order() : 0;
        }));

        return Collections.unmodifiableList(sorted);
    }

    /**
     * Returns all registered mod IDs that have at least one config.
     */
    public static Set<String> getRegisteredMods() {
        return Collections.unmodifiableSet(CONFIGS.keySet());
    }

    /**
     * Creates the appropriate config screen for a mod.
     * If the mod has a single config, returns the config editor directly.
     * If the mod has multiple configs, returns a selector screen.
     */
    public static class_437 createScreen(String modId, class_437 parent) {
        List<Class<?>> configs = getConfigs(modId);
        if (configs.isEmpty()) {
            return parent;
        }

        if (configs.size() == 1) {
            return new KnightLibConfigScreen(parent, configs.get(0));
        }

        return new ConfigBridgeScreen(parent, modId, configs);
    }

}