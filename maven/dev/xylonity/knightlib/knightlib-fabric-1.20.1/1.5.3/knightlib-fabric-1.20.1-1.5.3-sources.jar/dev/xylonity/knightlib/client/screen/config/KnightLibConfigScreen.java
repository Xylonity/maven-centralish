package dev.xylonity.knightlib.client.screen.config;

import dev.xylonity.knightlib.api.util.KnightLibEasings;
import dev.xylonity.knightlib.config.interop.ConfigManager;
import dev.xylonity.knightlib.api.config.AutoConfig;
import dev.xylonity.knightlib.api.config.ConfigEntry;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1074;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5481;
import net.minecraft.class_6382;

public class KnightLibConfigScreen extends class_437 {

    private final class_437 parent;
    private final Class<?> configClass;
    private final AutoConfig meta;
    private final int accent;

    private ConfigPanel panel;
    private CategorySidebar sidebar;
    private SearchBox searchBox;

    private final Map<Field, Object> snapshot = new LinkedHashMap<>();

    // Preserved across resizes so the screen rebuilds in the same state
    private String selectedCategory = null;
    private String searchQuery = "";

    private final long openedAt = class_156.method_658();

    private static final int HEADER_HEIGHT = 46;
    private static final int DEFAULT_ACCENT = 0xFF4A9EFF;

    private final class_310 field_22787 = class_310.method_1551();

    public KnightLibConfigScreen(class_437 parent, Class<?> configClass) {
        super(class_2561.method_43470(resolveTitle(configClass)));
        this.parent = parent;
        this.configClass = configClass;
        this.meta = configClass.getAnnotation(AutoConfig.class);
        this.accent = meta != null ? meta.accentColor() : DEFAULT_ACCENT;
        takeSnapshot();
    }

    private void takeSnapshot() {
        for (Field field : configClass.getDeclaredFields()) {
            if (field.getAnnotation(ConfigEntry.class) == null) {
                continue;
            }

            field.setAccessible(true);
            try {
                snapshot.put(field, field.get(null));
            }
            catch (Exception ignored) {
                ;;
            }

        }

    }

    private void restoreSnapshot() {
        for (Map.Entry<Field, Object> entry : snapshot.entrySet()) {
            try {
                ConfigManager.setPrimitive(entry.getKey(), entry.getValue());
            }
            catch (Exception ignored) {
                ;;
            }

        }

    }

    @Override
    protected void method_25426() {
        final int panelTop = HEADER_HEIGHT + 6;
        final int panelBottom = this.field_22790 - 36;

        final List<Field> entryFields = new ArrayList<>();
        final Map<String, Integer> categoryCounts = new LinkedHashMap<>();
        for (Field field : configClass.getDeclaredFields()) {
            ConfigEntry entry = field.getAnnotation(ConfigEntry.class);
            if (entry == null) {
                continue;
            }

            field.setAccessible(true);
            entryFields.add(field);
            categoryCounts.merge(entry.category().trim(), 1, Integer::sum);
        }

        final boolean hasSidebar = categoryCounts.size() >= 2;
        final int sidebarWidth = hasSidebar ? class_3532.method_15340(this.field_22789 / 5, 84, 120) : 0;
        final int panelLeft = hasSidebar ? 10 + sidebarWidth + 6 : 16;

        this.panel = new ConfigPanel(panelLeft, panelTop, this.field_22789 - panelLeft - 10, Math.max(0, panelBottom - panelTop), accent);

        if (hasSidebar) {
            this.sidebar = new CategorySidebar(10, panelTop, sidebarWidth, Math.max(0, panelBottom - panelTop), accent, categoryCounts, entryFields.size(),
                    key -> {
                        selectedCategory = key;
                        panel.setCategory(key);
                    });
            this.sidebar.setSelectedKey(selectedCategory);
            this.method_37063(this.sidebar);
        }
        else {
            this.sidebar = null;
            this.selectedCategory = null;
        }

        this.method_37063(this.panel);

        final int searchWidth = Math.min(200, this.field_22789 / 3);
        final int searchX = this.field_22789 - searchWidth - 14;
        final int searchY = (HEADER_HEIGHT - 16) / 2 - 1;

        this.searchBox = new SearchBox(this.field_22793, searchX, searchY, searchWidth, 16, accent);
        this.searchBox.method_1863(q -> {
            searchQuery = q;
            if (this.panel != null) {
                this.panel.setQuery(q);
            }
            if (this.sidebar != null) {
                this.sidebar.setDimmed(!q.isBlank());
            }

        });
        this.method_37063(this.searchBox);

        for (Field field : entryFields) {
            this.panel.addEntry(field, field.getAnnotation(ConfigEntry.class), snapshot.get(field));
        }

        this.panel.setCategory(selectedCategory);
        if (!searchQuery.isEmpty()) {
            this.searchBox.method_1852(searchQuery);
        }

        final int buttonWidth = 90;
        final int buttonHeight = 18;
        final int gap = 8;
        final int totalWidth = buttonWidth * 3 + gap * 2;
        final int sx = (this.field_22789 - totalWidth) / 2;
        final int buttonY = this.field_22790 - 26;

        method_37063(new FlatButton(sx, buttonY, buttonWidth, buttonHeight,
                class_5244.field_24334,
                button -> {
                    panel.applyToFields(); ConfigManager.save(configClass); field_22787.method_1507(parent);
                },
                accent, true).withEntranceDelay(60));

        method_37063(new FlatButton(sx + buttonWidth + gap, buttonY, buttonWidth, buttonHeight,
                class_2561.method_43471("knightlib.config.cancel"),
                button -> {
                    restoreSnapshot(); field_22787.method_1507(parent);
                },
                accent).withEntranceDelay(120));

        method_37063(new FlatButton(sx + (buttonWidth + gap) * 2, buttonY, buttonWidth, buttonHeight,
                class_2561.method_43471("knightlib.config.reset_all"),
                button -> panel.resetAllToDefault(),
                accent).withEntranceDelay(180));
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        if (panel != null) {
            panel.applyToFields();
        }

        super.method_25410(minecraft, width, height);
    }

    @Override
    public void method_25393() {
        if (searchBox != null) {
            searchBox.method_1865();
        }

        if (panel != null) {
            panel.tickPanel();
        }

        super.method_25393();
    }

    @Override
    public boolean method_25404(int key, int scancode, int modifiers) {
        if (key == GLFW.GLFW_KEY_F && method_25441() && searchBox != null) {
            this.method_25395(searchBox);
            searchBox.method_25365(true);
            return true;
        }

        return super.method_25404(key, scancode, modifiers);
    }

    @Override
    public void method_25419() {
        panel.applyToFields(); ConfigManager.save(configClass); field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, field_22789, field_22790, 0xFF0E0E0E);

        renderBackgroundGlow(graphics);
        renderHeader(graphics);
        renderHeaderInfo(graphics);

        super.method_25394(graphics, mouseX, mouseY, partialTick);

        renderModifiedCounter(graphics);

        if (panel != null) {
            panel.renderPendingTooltip(graphics, field_22793, field_22789, field_22790);
        }

    }

    private void renderBackgroundGlow(class_332 graphics) {
        // Soft wash behind the header title
        final float breath = 0.85f + 0.15f * (float) Math.sin(class_156.method_658() / 1300.0);
        final int[] ac = rgb(accent);
        final int glowW = Math.min(220, field_22789 / 2);
        for (int x = 0; x < glowW; x += 2) {
            final float t = (float) x / glowW;
            final int alpha = (int) (0x0A * (1f - t * t) * breath);
            if (alpha > 0) {
                graphics.method_25294(x, 0, x + 2, HEADER_HEIGHT, (alpha << 24) | (ac[0] << 16) | (ac[1] << 8) | ac[2]);
            }

        }

        // Bottom vignette
        for (int i = 0; i < 24; i++) {
            final int alpha = (int) (26 * ((float) i / 24) * ((float) i / 24));
            if (alpha > 0) {
                graphics.method_25294(0, field_22790 - 24 + i, field_22789, field_22790 - 23 + i, alpha << 24);
            }

        }

    }

    private void renderHeader(class_332 graphics) {
        for (int i = 0; i < HEADER_HEIGHT; i++) {
            final int alpha = Math.max(0, 60 - i * 2);
            if (alpha > 0) {
                graphics.method_25294(0, i, field_22789, i + 1, alpha << 24);
            }

        }

        final String title = resolveTitle(configClass).toUpperCase(Locale.ROOT);
        final String description = meta != null ? meta.description() : "";
        final boolean hasDescription = !description.isEmpty();

        final int titleY = hasDescription ? 12 : 19;

        // title and description slide in
        final long now = class_156.method_658();
        final float t = KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((now - openedAt) / 240f, 0f, 1f));
        final float t2 = KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((now - openedAt - 80) / 240f, 0f, 1f));

        // Accent bar next to the title
        final int barH = (int) ((field_22793.field_2000 + 3) * t);
        if (barH > 0) {
            graphics.method_25294(14, titleY - 2, 17, titleY - 2 + barH, accent);
            graphics.method_25294(17, titleY - 2, 18, titleY - 2 + barH, withAlpha(accent, 0x50));
        }

        final int titleAlpha = (int) (0xFF * t);
        if (titleAlpha >= 0x10) {
            graphics.method_51433(field_22793, title, 23 - (int) ((1f - t) * 6f), titleY, withAlpha(0xFFFFFF, titleAlpha), false);
        }

        final int descriptionAlpha = (int) (0xFF * t2);
        if (hasDescription && descriptionAlpha >= 0x10) {
            graphics.method_51433(field_22793, description, 23 - (int) ((1f - t2) * 6f), titleY + field_22793.field_2000 + 4, withAlpha(0x888888, descriptionAlpha), false);
        }

    }

    private void renderHeaderInfo(class_332 graphics) {
        if (panel == null) {
            return;
        }

        final String text;
        if (!searchQuery.isBlank()) {
            final int results = panel.visibleCount();
            text = class_1074.method_4662(results == 1 ? "knightlib.config.result" : "knightlib.config.results", results);
        }
        else {
            final int total = snapshot.size();
            text = class_1074.method_4662(total == 1 ? "knightlib.config.option" : "knightlib.config.options", total) + (meta != null ? " · " + meta.file() + ".toml" : "");
        }

        final int alpha = (int) (0xFF * KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((class_156.method_658() - openedAt - 120) / 240f, 0f, 1f)));
        if (alpha >= 0x10) {
            graphics.method_51433(field_22793, text, field_22789 - 14 - field_22793.method_1727(text), 34, withAlpha(0x4A4A4A, alpha), false);
        }

    }

    private void renderModifiedCounter(class_332 graphics) {
        if (panel == null) {
            return;
        }

        final int modified = panel.countModified();
        if (modified <= 0) {
            return;
        }

        final String text = class_1074.method_4662(modified == 1 ? "knightlib.config.change" : "knightlib.config.changes", modified);
        final int textX = field_22789 - 14 - field_22793.method_1727(text);
        final int textY = field_22790 - 22;

        // dot next to the pending changes counter
        final int[] ac = rgb(accent);
        graphics.method_25294(textX - 8, textY + 2, textX - 4, textY + 6, 0xFF000000 | (ac[0] << 16) | (ac[1] << 8) | ac[2]);

        graphics.method_51433(field_22793, text, textX, textY, withAlpha(accent, 0xE0), false);
    }

    static String resolveTitle(Class<?> clazz) {
        AutoConfig autoConfig = clazz.getAnnotation(AutoConfig.class);
        if (autoConfig != null && !autoConfig.title().isEmpty()) {
            return autoConfig.title();
        }
        if (autoConfig != null) {
            return prettify(autoConfig.file());
        }

        return clazz.getSimpleName();
    }

    static String prettify(String name) {
        String[] parts = name.replace('_', ' ').replace('-', ' ').split("\\s+");
        StringBuilder stringBuilder = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }

            if (!stringBuilder.isEmpty()) {
                stringBuilder.append(' ');
            }

            stringBuilder.append(Character.toUpperCase(part.charAt(0)));

            if (part.length() > 1) {
                stringBuilder.append(part.substring(1).toLowerCase());
            }

        }

        return stringBuilder.toString();
    }

    static int[] rgb(int argb) {
        return new int[] {
                (argb >> 16) & 0xFF,
                (argb >> 8) & 0xFF,
                argb & 0xFF
        };

    }

    static int withAlpha(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    static int mixRgb(int from, int to, float t) {
        final int red = (int) (((from >> 16) & 0xFF) + ((((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * t));
        final int green = (int) (((from >> 8) & 0xFF) + ((((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * t));
        final int blue = (int) ((from & 0xFF) + (((to & 0xFF) - (from & 0xFF)) * t));
        return (red << 16) | (green << 8) | blue;
    }

    static int dimAccent(int accent) {
        final int[] ac = rgb(accent);
        return ((ac[0] * 11 / 20) << 16) | ((ac[1] * 11 / 20) << 8) | (ac[2] * 11 / 20);
    }

    static void drawNotchedBorder(class_332 graphics, int x0, int y0, int x1, int y1, int color) {
        graphics.method_25294(x0 + 2, y0, x1 - 2, y0 + 1, color);
        graphics.method_25294(x0 + 2, y1 - 1, x1 - 2, y1, color);
        graphics.method_25294(x0, y0 + 2, x0 + 1, y1 - 2, color);
        graphics.method_25294(x1 - 1, y0 + 2, x1, y1 - 2, color);
        graphics.method_25294(x0 + 1, y0 + 1, x0 + 2, y0 + 2, color);
        graphics.method_25294(x1 - 2, y0 + 1, x1 - 1, y0 + 2, color);
        graphics.method_25294(x0 + 1, y1 - 2, x0 + 2, y1 - 1, color);
        graphics.method_25294(x1 - 2, y1 - 2, x1 - 1, y1 - 1, color);
    }

    static void drawCard(class_332 graphics, int x0, int y0, int x1, int y1, int bg, int border) {
        graphics.method_25294(x0 + 1, y0 + 1, x1 - 1, y1 - 1, bg);
        drawNotchedBorder(graphics, x0, y0, x1, y1, border);
    }

    static void drawCardHoverFx(class_332 graphics, int left, int top, int width, int height, float anim, int accent, int seed) {
        if (anim <= 0.1f || height < 12) {
            return;
        }

        final int[] ac = rgb(accent);
        final long time = class_156.method_658();

        for (int i = 0; i < 7; i++) {
            final long period = 1700L + Math.floorMod((long) seed * 31L + i * 197L, 900L);
            final long offset = Math.floorMod((long) seed * 137L + i * 311L, period);
            final float phase = Math.floorMod(time + offset, period) / (float) period;

            final float fx = Math.floorMod((long) seed * 53L + i * 419L, 1000L) / 1000f;
            final float sway = (float) Math.sin(phase * Math.PI * 2.0 + i * 1.3) * 2f;
            final int px = (int) (left + 5 + fx * (width - 10) + sway);
            final int py = (int) (top + height - 4 - phase * (height - 8));

            final float life = (float) Math.sin(phase * Math.PI);
            final int alpha = (int) (life * anim * 0x66);
            if (alpha < 6) {
                continue;
            }

            final int size = (i % 3 == 0) ? 2 : 1;
            graphics.method_25294(px, py, px + size, py + size, (alpha << 24) | (ac[0] << 16) | (ac[1] << 8) | ac[2]);
        }

    }

    static void playClickSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_15015.comp_349(), 1.0F));
    }

    static class CategorySidebar extends class_339 {

        private record Item(
                String key,
                String label,
                int count)
        {
            ;;
        }

        private final List<Item> items = new ArrayList<>();
        private final float[] hoverAnims;
        private final int accent;
        private final Consumer<String> onSelect;
        private final long revealStart = class_156.method_658();

        private int selected = 0;
        private boolean dimmed = false;
        private double scroll = 0;
        private float indicatorY = Float.NaN;

        private static final int ITEM_HEIGHT = 20;
        private static final int ITEM_GAP = 2;
        private static final int TOP_PAD = 18;

        CategorySidebar(int x, int y, int width, int height, int accent, Map<String, Integer> categoryCounts, int total, Consumer<String> onSelect) {
            super(x, y, width, height, class_2561.method_43473());
            this.accent = accent;
            this.onSelect = onSelect;

            items.add(new Item(null, class_1074.method_4662("knightlib.config.category.all"), total));
            for (Map.Entry<String, Integer> entry : categoryCounts.entrySet()) {
                items.add(new Item(entry.getKey(), entry.getKey().isEmpty() ? class_1074.method_4662("knightlib.config.category.general") : prettify(entry.getKey()), entry.getValue()));
            }

            this.hoverAnims = new float[items.size()];
        }

        void setSelectedKey(String key) {
            selected = 0;
            for (int i = 0; i < items.size(); i++) {
                if (Objects.equals(items.get(i).key, key)) {
                    selected = i;
                    break;
                }

            }

        }

        void setDimmed(boolean dimmed) {
            this.dimmed = dimmed;
        }

        private int contentHeight() {
            return TOP_PAD + items.size() * (ITEM_HEIGHT + ITEM_GAP);
        }

        private boolean scrollable() {
            return contentHeight() > field_22759;
        }

        @Override
        protected void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            if (!field_22764) {
                return;
            }

            final int x = method_46426();
            final int y = method_46427();
            final int addX = x + field_22758;
            final int addY = y + field_22759;

            graphics.method_25294(x, y, addX, addY, 0xFF101010);

            // Inner shadow at top edge
            for (int i = 0; i < 4; i++) {
                graphics.method_25294(x, y + i, addX, y + i + 1, (Math.max(0, 30 - i * 8)) << 24);
            }

            graphics.method_44379(x, y, addX, addY);

            final float dim = dimmed ? 0.35f : 1f;
            final long now = class_156.method_658();

            graphics.method_51433(class_310.method_1551().field_1772, class_1074.method_4662("knightlib.config.categories").toUpperCase(Locale.ROOT), x + 8, y + 6 - (int) scroll, withAlpha(0x585858, (int) (0xFF * dim)), false);

            final int[] ac = rgb(accent);
            int itemY = y + TOP_PAD - (int) scroll;

            for (int i = 0; i < items.size(); i++) {
                final Item item = items.get(i);

                final float entrance = KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((now - revealStart - i * 40L) / 180f, 0f, 1f));
                final int slide = (int) ((1f - entrance) * -12f);

                final boolean isSelected = i == selected;
                final boolean hovered = !dimmed && mx >= x && mx < addX && my >= itemY && my < itemY + ITEM_HEIGHT && my >= y && my < addY;

                final float target = hovered ? 1f : 0f;
                hoverAnims[i] += (target - hoverAnims[i]) * 0.15f;
                final float e = KnightLibEasings.SMOOTHSTEP.apply(hoverAnims[i]);

                final int bgAlpha = (int) ((isSelected ? 0x30 : 0x12 + 0x18 * e) * entrance * dim);
                graphics.method_25294(x + 3 + slide, itemY, addX - 3 + slide, itemY + ITEM_HEIGHT, (bgAlpha << 24) | 0x1A1A1A);

                // Faint accent bar on hover
                if (!isSelected && e > 0.02f) {
                    final int barAlpha = (int) (0x66 * e * entrance * dim);
                    graphics.method_25294(x + 3 + slide, itemY, x + 5 + slide, itemY + ITEM_HEIGHT, (barAlpha << 24) | (ac[0] << 16) | (ac[1] << 8) | ac[2]);
                }

                final int textAlpha = (int) (0xFF * Math.max(0.1f, entrance) * dim);
                if (textAlpha >= 0x10) {
                    final class_310 minecraft = class_310.method_1551();
                    final int labelColor = isSelected ? 0xE8E8E8 : (hovered ? 0xC8C8C8 : 0x808080);
                    final int textY = itemY + (ITEM_HEIGHT - minecraft.field_1772.field_2000) / 2 + 1;

                    final String count = String.valueOf(item.count);
                    final int countX = addX - 8 - minecraft.field_1772.method_1727(count) + slide;

                    // Long labels scroll back and forth
                    final int labelX = x + 10 + slide;
                    final int labelMaxX = countX - 4;
                    if (minecraft.field_1772.method_1727(item.label) <= labelMaxX - labelX) {
                        graphics.method_51433(minecraft.field_1772, item.label, labelX, textY, withAlpha(labelColor, textAlpha), false);
                    }
                    else {
                        method_49605(graphics, minecraft.field_1772, class_2561.method_43470(item.label), labelX, itemY, labelMaxX, itemY + ITEM_HEIGHT, withAlpha(labelColor, textAlpha));
                    }

                    final int countColor = isSelected ? (accent & 0x00FFFFFF) : 0x505050;
                    graphics.method_51433(minecraft.field_1772, count, countX, textY, withAlpha(countColor, textAlpha), false);
                }

                itemY += ITEM_HEIGHT + ITEM_GAP;
            }

            // Selection indicator slides between items
            final float indicatorTarget = TOP_PAD + selected * (ITEM_HEIGHT + ITEM_GAP);
            if (Float.isNaN(indicatorY) || Math.abs(indicatorTarget - indicatorY) < 0.5f) {
                indicatorY = indicatorTarget;
            }
            else {
                indicatorY += (indicatorTarget - indicatorY) * 0.25f;
            }

            final int barY = y + (int) indicatorY - (int) scroll;
            final int indicatorAlpha = (int) (0xFF * dim);
            graphics.method_25294(x + 3, barY, x + 5, barY + ITEM_HEIGHT, (indicatorAlpha << 24) | (ac[0] << 16) | (ac[1] << 8) | ac[2]);

            graphics.method_44380();

            drawNotchedBorder(graphics, x, y, addX, addY, 0xFF1C1C20);
        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            if (!field_22764 || dimmed || button != 0 || mx < method_46426() || mx >= method_46426() + field_22758 || my < method_46427() || my >= method_46427() + field_22759) {
                return false;
            }

            int itemY = method_46427() + TOP_PAD - (int) scroll;
            for (int i = 0; i < items.size(); i++) {
                if (my >= itemY && my < itemY + ITEM_HEIGHT) {
                    if (i != selected) {
                        selected = i;
                        method_25354(class_310.method_1551().method_1483());
                        onSelect.accept(items.get(i).key);
                    }

                    return true;
                }

                itemY += ITEM_HEIGHT + ITEM_GAP;
            }

            return true;
        }

        @Override
        public boolean method_25401(double mx, double my, double d) {
            if (!field_22764 || !scrollable() || mx < method_46426() || mx >= method_46426() + field_22758 || my < method_46427() || my >= method_46427() + field_22759) {
                return false;
            }

            scroll = class_3532.method_15350(scroll - d * 16.0, 0, Math.max(0, contentHeight() - field_22759));

            return true;
        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

    }

    static class ConfigPanel extends class_339 {

        private final List<EntryRow> allRows = new ArrayList<>();
        private final List<EntryRow> visibleRows = new ArrayList<>();

        private double scroll = 0;
        private double targetScroll = 0;
        private boolean draggingScrollbar = false;
        private int dragOffset = 0;
        private EntryRow focused = null;
        final int accent;

        private String query = "";
        private String category = null;
        private long revealStart = class_156.method_658();

        private List<class_2561> pendingTooltip = null;
        private EntryRow pendingTooltipRow = null;
        private EntryRow tooltipRow = null;
        private long tooltipSince = 0;
        private int tooltipX;
        private int tooltipY;

        private float scrollbarAnim = 0f;

        private static final int ROW_GAP = 4;
        private static final int PADDING = 8;
        private static final int CATEGORY_HEIGHT = 18;

        ConfigPanel(int x, int y, int width, int height, int accent) {
            super(x, y, width, height, class_2561.method_43473());
            this.accent = accent;
        }

        void tickPanel() {
            for (EntryRow entryRow : visibleRows) {
                if (entryRow.widget instanceof class_342 editBox) {
                    editBox.method_1865();
                }

            }

        }

        void addEntry(Field field, ConfigEntry configEntry, Object snapshotValue) {
            allRows.add(new EntryRow(field, configEntry, snapshotValue, accent));
            visibleRows.add(allRows.get(allRows.size() - 1));

            recalcLayout();
        }

        void setQuery(String query) {
            this.query = query == null ? "" : query;
            applyFilter();
        }

        void setCategory(String category) {
            this.category = category;
            applyFilter();
        }

        private void applyFilter() {
            visibleRows.clear();

            final boolean searching = !query.isBlank();
            final String content = query.toLowerCase().replace('_', ' ');

            for (EntryRow entryRow : allRows) {
                if (searching) {
                    if (entryRow.matchesSearch(content)) {
                        visibleRows.add(entryRow);
                    }

                }
                else if (category == null || entryRow.categoryKey().equals(category)) {
                    visibleRows.add(entryRow);
                }

            }

            recalcLayout();

            revealStart = class_156.method_658();
            targetScroll = 0;
            scroll = 0;
        }

        private boolean showHeaders() {
            if (!query.isBlank() || category == null) {
                Set<String> keys = new HashSet<>();
                for (EntryRow entryRow : visibleRows) {
                    keys.add(entryRow.categoryKey());
                }

                return keys.size() > 1;
            }

            return false;
        }

        void applyToFields() {
            for (EntryRow entryRow : allRows) {
                entryRow.writeToField();
            }

        }

        void resetAllToDefault() {
            for (EntryRow entryRow : allRows) {
                entryRow.resetToDefault();
            }

        }

        int visibleCount() {
            return visibleRows.size();
        }

        int countModified() {
            int count = 0;
            for (EntryRow entryRow : allRows) {
                if (entryRow.isModified()) {
                    count++;
                }

            }

            return count;
        }

        private int contentWidth() {
            return field_22758 - 16;
        }

        private int rowLeft() {
            return method_46426() + PADDING;
        }

        private int topPad() {
            return showHeaders() ? 4 : PADDING;
        }

        private void recalcLayout() {
            int width = contentWidth();
            for (EntryRow entryRow : visibleRows) {
                entryRow.recalcHeight(width);
            }

            clampScroll();
        }

        private int totalContentHeight() {
            final boolean headers = showHeaders();
            int height = topPad();
            String lastCategory = null;
            for (int i = 0; i < visibleRows.size(); i++) {
                if (i > 0) {
                    height += ROW_GAP;
                }

                String category = visibleRows.get(i).categoryKey();
                if (headers && !category.equals(lastCategory)) {
                    height += CATEGORY_HEIGHT;
                }

                lastCategory = category;
                height += visibleRows.get(i).height;
            }

            // Bottom margin
            return height + PADDING;
        }

        private boolean scrollable() {
            return totalContentHeight() > field_22759;
        }

        private void clampScroll() {
            double max = Math.max(0, totalContentHeight() - field_22759);
            targetScroll = Math.max(0, Math.min(max, targetScroll));
            scroll = Math.max(0, Math.min(max, scroll));
        }

        @Override
        protected void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            if (!field_22764) {
                return;
            }

            pendingTooltip = null;
            pendingTooltipRow = null;

            if (!draggingScrollbar && scroll != targetScroll) {
                double dragging = targetScroll - scroll;
                scroll = Math.abs(dragging) < 0.5 ? targetScroll : scroll + dragging * 0.25;

                clampScroll();
            }

            final int x = method_46426();
            final int y = method_46427();
            final int addX = x + field_22758;
            final int addY = y + field_22759;
            graphics.method_25294(x, y, addX, addY, 0xFF111111);

            // Inner shadow at top edge
            for (int i = 0; i < 4; i++) {
                graphics.method_25294(x, y + i, addX, y + i + 1, (Math.max(0, 30 - i * 8)) << 24);
            }

            graphics.method_44379(x, y, addX, addY);

            if (visibleRows.isEmpty()) {
                renderEmptyState(graphics, x, y, addY);
            }

            final boolean headers = showHeaders();
            final long now = class_156.method_658();
            final int rowLength = rowLeft();
            final int rowWidth = contentWidth();
            int categoryY = y + topPad() - (int) scroll;
            String lastCategory = null;

            for (int i = 0; i < visibleRows.size(); i++) {
                EntryRow row = visibleRows.get(i);
                if (i > 0) {
                    categoryY += ROW_GAP;
                }

                String category = row.categoryKey();
                if (headers && !category.equals(lastCategory)) {
                    if (categoryY + CATEGORY_HEIGHT >= y && categoryY <= addY) {
                        renderCategoryHeader(graphics, category.isEmpty() ? class_1074.method_4662("knightlib.config.category.general") : category, rowLength, categoryY, rowWidth);
                    }

                    categoryY += CATEGORY_HEIGHT;
                }

                lastCategory = category;

                int rowH = row.height;
                if (categoryY + rowH >= y && categoryY <= addY) {
                    boolean inPanel = mx >= x && mx <= addX && my >= y && my <= addY;
                    boolean hovered = inPanel && mx >= rowLength && mx <= rowLength + rowWidth && my >= categoryY && my <= categoryY + rowH;

                    final float entrance = KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((now - revealStart - Math.min(i, 12) * 35L) / 170f, 0f, 1f));
                    row.render(graphics, i, categoryY, rowLength, rowWidth, mx, my, hovered, entrance, partialTick);

                    if (hovered) {
                        captureTooltip(row, mx, my, rowLength, rowWidth);
                    }

                }
                else {
                    row.hoverStart = 0;
                }

                categoryY += rowH;
            }

            graphics.method_44380();

            if (pendingTooltipRow != tooltipRow) {
                tooltipRow = pendingTooltipRow;
                tooltipSince = class_156.method_658();
            }

            renderEdgeFades(graphics, x, y, addX, addY);

            drawNotchedBorder(graphics, x, y, addX, addY, 0xFF1E1E22);

            renderScrollbar(graphics, mx, my);
        }

        private void renderEdgeFades(class_332 graphics, int x, int y, int addX, int addY) {
            final double maxScroll = Math.max(0, totalContentHeight() - field_22759);

            if (scroll > 1) {
                for (int i = 0; i < 10; i++) {
                    final float t = 1f - i / 10f;
                    graphics.method_25294(x, y + i, addX - 4, y + i + 1, ((int) (0xD0 * t * t) << 24) | 0x111111);
                }

            }

            if (scroll < maxScroll - 1) {
                for (int i = 0; i < 10; i++) {
                    final float t = 1f - i / 10f;
                    graphics.method_25294(x, addY - 1 - i, addX - 4, addY - i, ((int) (0xD0 * t * t) << 24) | 0x111111);
                }

            }

        }

        private void renderEmptyState(class_332 graphics, int x, int y, int addY) {
            final class_310 minecraft = class_310.method_1551();
            final String text = query.isBlank() ? class_1074.method_4662("knightlib.config.empty") : class_1074.method_4662("knightlib.config.empty_search", query);
            final int textY = y + (addY - y - minecraft.field_1772.field_2000) / 2;

            graphics.method_51433(minecraft.field_1772, text, x + (field_22758 - minecraft.field_1772.method_1727(text)) / 2, textY, 0xFF4A4A4A, false);
        }

        private void captureTooltip(EntryRow row, int mx, int my, int rowLeft, int rowWidth) {
            if (mx > rowLeft + rowWidth - row.widget.method_25368() - 30) {
                if (row.hoverStart == 0) {
                    row.hoverStart = class_156.method_658();
                }

                return;
            }

            if (row.hoverStart == 0) {
                row.hoverStart = class_156.method_658();
            }

            if (class_156.method_658() - row.hoverStart < 450) {
                return;
            }

            List<class_2561> lines = row.tooltipLines();
            if (!lines.isEmpty()) {
                pendingTooltip = lines;
                pendingTooltipRow = row;
                tooltipX = mx;
                tooltipY = my;
            }

        }

        void renderPendingTooltip(class_332 graphics, class_327 font, int screenWidth, int screenHeight) {
            if (pendingTooltip == null || pendingTooltip.isEmpty()) {
                return;
            }

            final float fade = KnightLibEasings.EASE_OUT_QUAD.apply(class_3532.method_15363((class_156.method_658() - tooltipSince) / 120f, 0f, 1f));
            final int textAlpha = (int) (0xFF * fade);
            if (textAlpha < 0x10) {
                return;
            }

            final int maxTextWidth = 200;
            final List<class_5481> wrapped = new ArrayList<>();
            for (class_2561 line : pendingTooltip) {
                wrapped.addAll(font.method_1728(line, maxTextWidth));
            }

            int textWidth = 0;
            for (class_5481 seq : wrapped) {
                textWidth = Math.max(textWidth, font.method_30880(seq));
            }

            final int paddingX = 6;
            final int paddingY = 5;
            final int boxWidth = textWidth + paddingX * 2;
            final int boxHeight = wrapped.size() * (font.field_2000 + 1) - 1 + paddingY * 2;

            int x = tooltipX + 10;
            int y = tooltipY - boxHeight - 4;
            if (x + boxWidth > screenWidth - 4) {
                x = screenWidth - 4 - boxWidth;
            }
            if (y < 4) {
                y = tooltipY + 12;
            }
            if (y + boxHeight > screenHeight - 4) {
                y = screenHeight - 4 - boxHeight;
            }

            y += (int) ((1f - fade) * 3f);

            graphics.method_51448().method_22903();
            graphics.method_51448().method_46416(0, 0, 400);

            final int boxBg = ((int) (0xF2 * fade) << 24) | 0x121214;
            final int boxBorder = withAlpha(mixRgb(0x2E2E32, dimAccent(accent), 0.4f), textAlpha);
            drawCard(graphics, x, y, x + boxWidth, y + boxHeight, boxBg, boxBorder);

            final class_310 minecraft = class_310.method_1551();
            int lineY = y + paddingY;
            for (class_5481 seq : wrapped) {
                graphics.method_51430(minecraft.field_1772, seq, x + paddingX, lineY, withAlpha(0xDDDDDD, textAlpha), false);
                lineY += minecraft.field_1772.field_2000 + 1;
            }

            graphics.method_51448().method_22909();
        }

        private void renderCategoryHeader(class_332 graphics, String category, int x, int y, int width) {
            final class_310 minecraft = class_310.method_1551();
            final String label = prettify(category).toUpperCase();
            final int labelW = minecraft.field_1772.method_1727(label);
            final int textX = x + 12;
            final int lineY = y + 8;
            final int lineEnd = x + width;

            int[] rgbAccent = rgb(accent);
            graphics.method_25294(x + 3, lineY - 2, x + 6, lineY + 1, 0xFF000000 | (rgbAccent[0] << 16) | (rgbAccent[1] << 8) | rgbAccent[2]);

            graphics.method_51433(minecraft.field_1772, label, textX, y + 4, 0xFF585858, false);

            int lineStart = textX + labelW + 6;
            if (lineStart < lineEnd) {
                graphics.method_25294(lineStart, lineY, lineEnd, lineY + 1, 0x20FFFFFF);
            }

        }

        private void renderScrollbar(class_332 graphics, int mx, int my) {
            if (!scrollable()) {
                return;
            }

            // Momentum
            final boolean engaged = draggingScrollbar || Math.abs(targetScroll - scroll) > 0.5 || (isIn(mx, my) && mx >= method_46426() + field_22758 - 10);
            scrollbarAnim += ((engaged ? 1f : 0f) - scrollbarAnim) * 0.1f;

            final int contentHeight = totalContentHeight();
            final int newX = method_46426() + field_22758 - 4;
            final int newY = method_46427();
            final int newHeight = field_22759;
            final double maxSwap = Math.max(1, contentHeight - field_22759);
            final int thumbHeight = Math.max(20, (int) (newHeight * ((double) field_22759 / contentHeight)));
            final int thumbY = newY + (int) ((newHeight - thumbHeight) * (scroll / maxSwap));

            final int trackAlpha = (int) (0x08 + 0x10 * scrollbarAnim);
            graphics.method_25294(newX, newY, newX + 3, newY + newHeight, (trackAlpha << 24) | 0x00FFFFFF);

            final int thumbColor = mixRgb(0x3E3E44, accent & 0x00FFFFFF, scrollbarAnim);
            final int thumbAlpha = (int) (0x90 + 0x6F * scrollbarAnim);
            graphics.method_25294(newX, thumbY, newX + 3, thumbY + thumbHeight, (thumbAlpha << 24) | thumbColor);
        }

        @Override
        public boolean method_25401(double mx, double my, double d) {
            if (!field_22764 || !isIn(mx, my) || !scrollable()) {
                return false;
            }

            draggingScrollbar = false;
            targetScroll -= d * 24.0;

            clampScroll();

            return true;
        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            if (!field_22764 || !field_22763 || !isIn(mx, my)) {
                return false;
            }

            if (scrollable()) {
                int tx = method_46426() + field_22758 - 6;
                if (mx >= tx) {
                    final int contentHeight = totalContentHeight();
                    final double maxSroll = Math.max(1, contentHeight - field_22759);
                    final int thumbH = Math.max(20, (int) (field_22759 * ((double) field_22759 / contentHeight)));
                    final int thumbY = method_46427() + (int) ((field_22759 - thumbH) * (scroll / maxSroll));
                    if (my >= thumbY && my <= thumbY + thumbH) {
                        draggingScrollbar = true;
                        dragOffset = (int) my - thumbY;
                    }
                    else {
                        double t = (my - method_46427()) / (double) field_22759;
                        targetScroll = t * maxSroll;
                        scroll = targetScroll;

                        clampScroll();
                    }

                    return true;
                }

            }

            final boolean headers = showHeaders();
            int contentY = method_46427() + topPad() - (int) scroll;
            String lastCategory = null;
            for (int i = 0; i < visibleRows.size(); i++) {
                final EntryRow row = visibleRows.get(i);
                if (i > 0) {
                    contentY += ROW_GAP;
                }

                final String category = row.categoryKey();
                if (headers && !category.equals(lastCategory)) {
                    contentY += CATEGORY_HEIGHT;
                }

                lastCategory = category;
                if (my >= contentY && my <= contentY + row.height && mx >= rowLeft() && mx <= rowLeft() + contentWidth()) {
                    if (row.clickedReset(mx, my, button, rowLeft(), contentY, contentWidth())) {
                        clearFocused();
                        return true;
                    }

                    if (row.mouseClicked(mx, my, button)) {
                        setFocusedRow(row);
                        return true;
                    }

                    clearFocused();

                    return true;
                }

                contentY += row.height;
            }

            clearFocused();

            return false;
        }

        @Override
        public boolean method_25403(double mx, double my, int button, double dx, double dy) {
            if (draggingScrollbar && scrollable()) {
                final int contentHeight = totalContentHeight();
                final double maxS = Math.max(1, contentHeight - field_22759);
                final int thumbH = Math.max(20, (int) (field_22759 * ((double) field_22759 / contentHeight)));
                final int span = field_22759 - thumbH;
                if (span <= 0) {
                    return true;
                }

                double maxed = Math.max(0, Math.min(1, ((my - dragOffset - method_46427()) / span)));

                targetScroll = maxed * maxS;
                scroll = targetScroll;

                clampScroll();

                return true;
            }

            return focused != null && focused.mouseDragged(mx, my, button, dx, dy);
        }

        @Override
        public boolean method_25406(double mx, double my, int button) {
            if (draggingScrollbar) {
                draggingScrollbar = false;

                return true;
            }

            return focused != null && focused.mouseReleased(mx, my, button);
        }

        @Override
        public boolean method_25404(int key, int s, int m) {
            return (focused != null && focused.keyPressed(key, s, m)) || super.method_25404(key, s, m);
        }

        @Override
        public boolean method_25400(char c, int m) {
            return (focused != null && focused.charTyped(c, m)) || super.method_25400(c, m);
        }

        private boolean isIn(double mx, double my) {
            return mx >= method_46426() && mx <= method_46426() + field_22758 && my >= method_46427() && my <= method_46427() + field_22759;
        }

        private void clearFocused() {
            if (focused != null) {
                focused.setFocused(false);
                focused = null;
            }

        }

        private void setFocusedRow(EntryRow entryRow) {
            if (focused == entryRow) {
                return;
            }

            if (focused != null) {
                focused.setFocused(false);
            }

            focused = entryRow;
            if (entryRow != null) {
                entryRow.setFocused(true);
            }

        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

    }

    private static class EntryRow {

        final Field field;
        final ConfigEntry meta;
        final class_2561 label;
        final String description;
        final class_339 widget;
        final String searchIndex;
        final int accent;
        final Object snapshotValue;
        final Object defaultValue;

        float hoverAnim = 0f;
        long hoverStart = 0;
        int height = 36;
        int descriptionLines = 0;
        int descriptionMaxWidth = 0;

        private List<class_2561> cachedTooltip = null;
        private List<class_5481> descriptionCache = List.of();

        EntryRow(Field field, ConfigEntry meta, Object snapshotValue, int accent) {
            this.field = field;
            this.meta = meta;
            this.accent = accent;
            this.snapshotValue = snapshotValue;
            this.defaultValue = ConfigManager.getCodeDefault(field);
            this.label = class_2561.method_43470(prettify(field.getName()));
            this.description = meta.comment().trim();
            this.searchIndex = (field.getName() + " " + prettify(field.getName()) + " " + meta.category() + " " + description).toLowerCase().replace('_', ' ');
            this.widget = createWidget();
        }

        String categoryKey() {
            return meta.category().trim();
        }

        boolean matchesSearch(String query) {
            for (String chunk : query.split("\\s+")) {
                if (!chunk.isEmpty() && !searchIndex.contains(chunk)) {
                    return false;
                }

            }

            return true;
        }

        void setFocused(boolean focused) {
            widget.method_25365(focused);

            if (widget instanceof class_342 editBox) {
                editBox.method_25365(focused);
            }

        }

        void recalcHeight(int rowWidth) {
            final class_310 minecraft = class_310.method_1551();
            final int lineHeight = minecraft.field_1772.field_2000;
            final int avail = rowWidth - widget.method_25368() - 54;

            descriptionMaxWidth = Math.min(avail, (int) (rowWidth * 0.5f));
            descriptionCache = (!description.isEmpty() && descriptionMaxWidth > 30) ? minecraft.field_1772.method_1728(class_2561.method_43470(description), descriptionMaxWidth) : List.of();
            descriptionLines = descriptionCache.size();

            final int contentHeight = lineHeight + (descriptionLines > 0 ? 2 + descriptionLines * lineHeight : 0);
            height = Math.max(Math.max(contentHeight + 12, widget.method_25364() + 12), 30);
        }

        private class_339 createWidget() {
            final class_310 minecraft = class_310.method_1551();
            final Class<?> type = field.getType();
            try {
                if (type == boolean.class) {
                    return new ToggleButton(0, 0, 44, 18, field.getBoolean(null), accent);
                }

                if (meta.slider() && Double.isFinite(meta.min()) && Double.isFinite(meta.max())) {
                    boolean isInt = type == int.class || type == long.class;
                    return new ConfigSlider(0, 0, 120, 18, meta.min(), meta.max(), ((Number) field.get(null)).doubleValue(), isInt, accent);
                }

                if (type.isEnum()) {
                    return new EnumCycleButton(0, 0, 100, 18, (Enum<?>[]) type.getEnumConstants(), (Enum<?>) field.get(null), accent);
                }

                final String value = String.valueOf(field.get(null));
                final StyledEditBox box = new StyledEditBox(minecraft.field_1772, 0, 0, value.length() > 20 ? 200 : 120, 18, class_2561.method_43473(), accent);

                box.method_1880(512);
                box.method_1852(value);
                box.setValidator(validatorFor(type));

                return box;
            }
            catch (Exception exception) {
                final class_342 box = new StyledEditBox(minecraft.field_1772, 0, 0, 120, 18, class_2561.method_43473(), accent);
                box.method_1852("");
                return box;
            }

        }

        private static Predicate<String> validatorFor(Class<?> type) {
            if (type == int.class) {
                return raw -> raw.isBlank() || parseIntSafe(raw, Integer.MIN_VALUE) != Integer.MIN_VALUE || raw.trim().equals(String.valueOf(Integer.MIN_VALUE));
            }
            if (type == long.class) {
                return raw -> raw.isBlank() || parseLongSafe(raw, Long.MIN_VALUE) != Long.MIN_VALUE || raw.trim().equals(String.valueOf(Long.MIN_VALUE));
            }
            if (type == float.class || type == double.class) {
                return raw -> {
                    if (raw.isBlank()) {
                        return true;
                    }
                    try {
                        Double.parseDouble(raw.trim());
                        return true;
                    }
                    catch (NumberFormatException exception) {
                        return false;
                    }

                };

            }

            return raw -> true;
        }

        /** Current widget value, converted back to the field's domain. Null when unparsable. */
        private Object currentValue() {
            final Class<?> type = field.getType();
            if (widget instanceof ToggleButton toggleButton) {
                return toggleButton.isToggled();
            }
            if (widget instanceof ConfigSlider configSlider) {
                return configSlider.getValueRaw();
            }
            if (widget instanceof EnumCycleButton enumCycleButton) {
                return enumCycleButton.getCurrent();
            }
            if (widget instanceof class_342 box) {
                final String raw = box.method_1882().trim();
                if (type == String.class) {
                    return box.method_1882();
                }
                if (raw.isEmpty()) {
                    return null;
                }
                try {
                    if (type == int.class) {
                        return Integer.decode(raw.startsWith("#") ? "0x" + raw.substring(1) : raw);
                    }
                    if (type == long.class) {
                        return Long.decode(raw.startsWith("#") ? "0x" + raw.substring(1) : raw);
                    }
                    if (type == float.class) {
                        return Float.parseFloat(raw);
                    }
                    if (type == double.class) {
                        return Double.parseDouble(raw);
                    }

                }
                catch (NumberFormatException exception) {
                    return null;
                }

            }

            return null;
        }

        boolean isModified() {
            if (snapshotValue == null) {
                return false;
            }

            final Object current = currentValue();
            if (current == null) {
                return false;
            }

            if (current instanceof Number number && snapshotValue instanceof Number snapNumber) {
                return Math.abs(number.doubleValue() - snapNumber.doubleValue()) > 1e-6;
            }

            return !current.equals(snapshotValue);
        }

        List<class_2561> tooltipLines() {
            if (cachedTooltip != null) {
                return cachedTooltip;
            }

            final List<class_2561> lines = new ArrayList<>();
            final String note = meta.note().trim();
            if (!note.isEmpty()) {
                lines.add(class_2561.method_43470(note));
            }

            if (defaultValue != null) {
                lines.add(class_2561.method_43469("knightlib.config.tooltip.default", formatValue(defaultValue)).method_27694(style -> style.method_36139(0x7A7A7A)));
            }

            if (Double.isFinite(meta.min()) && Double.isFinite(meta.max())) {
                final boolean isInt = field.getType() == int.class || field.getType() == long.class;
                final String min = isInt ? String.valueOf((long) meta.min()) : trimDouble(meta.min());
                final String max = isInt ? String.valueOf((long) meta.max()) : trimDouble(meta.max());
                lines.add(class_2561.method_43469("knightlib.config.tooltip.range", min, max).method_27694(style -> style.method_36139(0x7A7A7A)));
            }

            if (widget instanceof ConfigSlider) {
                lines.add(class_2561.method_43471("knightlib.config.tooltip.slider_hint").method_27694(style -> style.method_36139(0x5A5A5A)));
            }

            if (meta.requiresRestart()) {
                lines.add(class_2561.method_43471("knightlib.config.tooltip.requires_restart").method_27694(style -> style.method_36139(0xFF8844)));
            }

            cachedTooltip = lines;

            return lines;
        }

        private static String formatValue(Object value) {
            if (value instanceof Double d) {
                return trimDouble(d);
            }
            if (value instanceof Float f) {
                return trimDouble(f);
            }
            if (value instanceof Enum<?> e) {
                return prettify(e.name());
            }

            return String.valueOf(value);
        }

        private static String trimDouble(double value) {
            if (value == Math.floor(value) && !Double.isInfinite(value)) {
                return String.valueOf((long) value);
            }

            return String.valueOf(value);
        }

        void writeToField() {
            try {
                final Class<?> type = field.getType();
                if (type == boolean.class && widget instanceof ToggleButton toggleButton) {
                    field.setBoolean(null, toggleButton.isToggled()); return;
                }
                if (widget instanceof ConfigSlider configSlider) {
                    double valueRaw = configSlider.getValueRaw();
                    if (type == int.class) {
                        field.setInt(null, (int) valueRaw);
                    }
                    else if (type == long.class) {
                        field.setLong(null, (long) valueRaw);
                    }
                    else if (type == float.class) {
                        field.setFloat(null, (float) valueRaw);
                    }
                    else {
                        field.setDouble(null, valueRaw);
                    }

                    return;
                }
                if (widget instanceof EnumCycleButton enumCycleButton) {
                    field.set(null, enumCycleButton.getCurrent()); return;
                }
                if (widget instanceof class_342 box) {
                    String raw = box.method_1882().trim();
                    if (type == String.class) {
                        field.set(null, box.method_1882());
                        return;
                    }

                    if (raw.isEmpty()) {
                        return;
                    }
                    if (type == int.class) {
                        field.setInt(null, parseIntSafe(raw, field.getInt(null)));
                    }
                    else if (type == long.class) {
                        field.setLong(null, parseLongSafe(raw, field.getLong(null)));
                    }
                    else if (type == float.class) {
                        try {
                            field.setFloat(null, Float.parseFloat(raw));
                        }
                        catch (NumberFormatException ignored) {
                            ;;
                        }
                    }
                    else if (type == double.class) {
                        try {
                            field.setDouble(null, Double.parseDouble(raw));
                        }
                        catch (NumberFormatException ignored) {
                            ;;
                        }

                    }

                }

            }
            catch (Exception ignored) {
                ;;
            }

        }

        void resetToDefault() {
            if (defaultValue == null) {
                return;
            }
            try {
                if (widget instanceof ToggleButton toggleButton && defaultValue instanceof Boolean bool) {
                    toggleButton.setToggled(bool);
                }
                else if (widget instanceof ConfigSlider configSlider && defaultValue instanceof Number number) {
                    configSlider.setValueRaw(number.doubleValue());
                }
                else if (widget instanceof EnumCycleButton enumCycleButton && defaultValue instanceof Enum<?> enumType) {
                    enumCycleButton.setCurrent(enumType);
                }
                else if (widget instanceof class_342 box) {
                    box.method_1852(String.valueOf(defaultValue));
                }

            }
            catch (Exception ignored) {
                ;;
            }

        }

        void render(class_332 graphics, int index, int top, int left, int width, int mx, int my, boolean hovered, float entrance, float partialTick) {
            final class_310 minecraft = class_310.method_1551();
            final int lineHeight = minecraft.field_1772.field_2000;

            if (!hovered) {
                hoverStart = 0;
            }

            final float target = hovered ? 1f : 0f;
            final float diff = target - hoverAnim;
            hoverAnim += diff * 0.12f;
            if (Math.abs(diff) < 0.005f) {
                hoverAnim = target;
            }

            float e = KnightLibEasings.SMOOTHSTEP.apply(hoverAnim);

            // Entrance slide (from the right) and fade
            final int slide = (int) ((1f - entrance) * 16f);
            left += slide;

            final int alpha = (int) (0xFF * entrance);
            final int[] accent = rgb(this.accent);

            final int accentDim = dimAccent(this.accent);
            final int bg = (alpha << 24) | mixRgb(0x151517, 0x1B1B1F, e);
            final int border = (alpha << 24) | mixRgb(0x26262A, accentDim, e);
            drawCard(graphics, left, top, left + width, top + height, bg, border);

            drawCardHoverFx(graphics, left, top, width, height, e * entrance, this.accent, index * 73 + field.getName().hashCode());

            float textFade = 1f;
            if (widget instanceof StyledEditBox box) {
                widget.method_25358(box.layoutWidth(width - 40));
                textFade = 1f - box.expandProgress();
            }

            final int textAlpha = (int) (alpha * textFade);
            final int contentH = lineHeight + (descriptionLines > 0 ? 2 + descriptionLines * lineHeight : 0);
            final int contentTop = top + (height - contentH) / 2;
            final int labelX = left + 10;

            if (textAlpha >= 0x10) {
                graphics.method_51439(minecraft.field_1772, label, labelX, contentTop, withAlpha(mixRgb(0xC4C4C4, 0xFFFFFF, e), textAlpha), false);

                int afterLabel = labelX + minecraft.field_1772.method_27525(label);

                if (meta.requiresRestart()) {
                    graphics.method_51433(minecraft.field_1772, "⟳", afterLabel + 4, contentTop, withAlpha(0xFF8844, textAlpha), false);
                    afterLabel += 4 + minecraft.field_1772.method_1727("⟳");
                }

                // Modified indicator
                if (isModified()) {
                    graphics.method_25294(afterLabel + 5, contentTop + 2, afterLabel + 8, contentTop + 5, (textAlpha << 24) | (accent[0] << 16) | (accent[1] << 8) | accent[2]);
                }

            }

            // Description
            if (!descriptionCache.isEmpty() && textAlpha >= 0x10) {
                int commentY = contentTop + lineHeight + 2;
                for (class_5481 line : descriptionCache) {
                    graphics.method_51430(minecraft.field_1772, line, labelX, commentY, withAlpha(mixRgb(0x646464, 0x8C8C8C, e), textAlpha), false);
                    commentY += lineHeight;
                }

            }

            final int widgetX = left + width - widget.method_25368() - 8;
            final int widgetY = top + (height - widget.method_25364()) / 2;

            widget.method_46421(widgetX);
            widget.method_46419(widgetY);

            // Per-entry reset button
            if (e > 0.3f && defaultValue != null) {
                final int resetX = widgetX - 24;
                final int resetY = top + (height - 18) / 2;
                final boolean resetHovered = mx >= resetX && mx < resetX + 18 && my >= resetY && my < resetY + 18;
                final int resetAlpha = (int) (0xFF * (e - 0.3f) / 0.7f);

                final int boxBg = withAlpha(resetHovered ? 0x202024 : 0x1A1A1C, resetAlpha);
                final int boxBorder = withAlpha(resetHovered ? accentDim : 0x2E2E32, resetAlpha);
                drawCard(graphics, resetX, resetY, resetX + 18, resetY + 18, boxBg, boxBorder);

                if (resetAlpha >= 0x10) {
                    final int resetColor = resetHovered ? withAlpha(this.accent & 0x00FFFFFF, resetAlpha) : withAlpha(0x8A8A8A, resetAlpha);
                    final float glyphScale = 2.4f;
                    final float glyphW = minecraft.field_1772.method_1727("↺") * glyphScale;
                    final float glyphH = minecraft.field_1772.field_2000 * glyphScale;

                    graphics.method_51448().method_22903();
                    graphics.method_51448().method_46416(resetX + (18 - glyphW) / 2f + 1.5f, resetY + (18 - glyphH) / 2f - 0.5f, 0);
                    graphics.method_51448().method_22905(glyphScale, glyphScale, 1f);
                    graphics.method_51433(minecraft.field_1772, "↺", 0, 0, resetColor, false);
                    graphics.method_51448().method_22909();
                }

            }

            widget.method_25394(graphics, mx, my, partialTick);
        }

        boolean clickedReset(double mx, double my, int button, int rowLeft, int rowTop, int rowWidth) {
            if (button != 0 || hoverAnim <= 0.3f || defaultValue == null) {
                return false;
            }

            final int widgetX = rowLeft + rowWidth - widget.method_25368() - 8;
            final int resetX = widgetX - 24;
            final int resetY = rowTop + (height - 18) / 2;
            if (mx >= resetX && mx < resetX + 18 && my >= resetY && my < resetY + 18) {
                resetToDefault();
                playClickSound();
                return true;
            }

            return false;
        }

        boolean mouseClicked(double mx, double my, int button) {
            return widget.method_25402(mx, my, button);
        }

        boolean mouseReleased(double mx, double my, int button) {
            return widget.method_25406(mx, my, button);
        }

        boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            return widget.method_25403(mx, my, button, dx, dy);
        }

        boolean keyPressed(int key, int s, int m) {
            return widget.method_25404(key, s, m);
        }

        boolean charTyped(char c, int m) {
            return widget.method_25400(c, m);
        }

        private static int parseIntSafe(String safe, int fallback) {
            try {
                safe = safe.trim();
                if (safe.startsWith("#")) {
                    safe = "0x" + safe.substring(1);
                }

                if (safe.startsWith("0x") || safe.startsWith("0X")) {
                    return Integer.decode(safe);
                }

                return Integer.parseInt(safe);
            }
            catch (Exception exception) {
                return fallback;
            }

        }

        private static long parseLongSafe(String safe, long fallback) {
            try {
                safe = safe.trim();
                if (safe.startsWith("#")) {
                    safe = "0x" + safe.substring(1);
                }

                if (safe.startsWith("0x") || safe.startsWith("0X")) {
                    return Long.decode(safe);
                }

                return Long.parseLong(safe);
            }
            catch (Exception exception) {
                return fallback;
            }

        }

    }

    static class SearchBox extends class_342 {

        private float focusAnim = 0f;
        private final int accent;

        SearchBox(class_327 font, int x, int y, int width, int height, int accent) {
            super(font, x, y, width, height, class_2561.method_43470("Search"));
            this.accent = accent;
            method_1858(false);
            method_1868(0xFFCCCCCC);
            method_1860(0xFF555555);
            method_1880(128);
            method_47404(class_2561.method_43471("knightlib.config.search"));
        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            // Clears "x" zone at the right edge when there is text
            if (button == 0 && !method_1882().isEmpty()) {
                final int zoneX = method_46426() + method_25368() - 12;
                if (mx >= zoneX && mx < method_46426() + method_25368() && my >= method_46427() && my < method_46427() + method_25364()) {
                    method_1852("");
                    playClickSound();
                    return true;
                }

            }

            return super.method_25402(mx, my, button);
        }

        @Override
        public void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            final int x0 = method_46426();
            final int y0 = method_46427();
            final int width = method_25368();
            final int height = method_25364();
            final int x1 = x0 + width;
            final int y1 = y0 + height;

            final boolean hovered = mx >= x0 && mx < x1 && my >= y0 && my < y1;
            final boolean active = hovered || method_25370();

            focusAnim = active ? Math.min(1f, focusAnim + 0.12f) : Math.max(0f, focusAnim - 0.06f);

            // Card
            final int borderTarget = method_25370() ? (this.accent & 0x00FFFFFF) : dimAccent(this.accent);
            final int boxBorder = 0xFF000000 | mixRgb(0x26262A, borderTarget, focusAnim);
            drawCard(graphics, x0, y0, x1, y1, 0xFF151517, boxBorder);

            // Magnifying glass icon (for the search box)
            final class_310 minecraft = class_310.method_1551();
            final int[] accent = rgb(this.accent);
            final float time = focusAnim;
            final int iconRed = (int) (0x48 + ((accent[0] - 0x48) * time));
            final int iconGreen = (int) (0x48 + ((accent[1] - 0x48) * time));
            final int iconBlue = (int) (0x48 + ((accent[2] - 0x48) * time));
            final int iconColor = 0xFF000000 | (iconRed << 16) | (iconGreen << 8) | iconBlue;
            final float scale = 2.45f;
            final int iconOriginX = x0 + 3;
            final int iconOriginY = y0 + (height - (int)(minecraft.field_1772.field_2000 * scale)) / 2 - 3;

            graphics.method_51448().method_22903();

            graphics.method_51448().method_46416(iconOriginX, iconOriginY, 0);
            graphics.method_51448().method_22905(scale, scale, 1f);
            graphics.method_51433(minecraft.field_1772, "⌕", 0, 0, iconColor, false);

            graphics.method_51448().method_22909();

            // Clear "x" when there is text
            if (!method_1882().isEmpty()) {
                final boolean clearHovered = mx >= x1 - 12 && mx < x1 && my >= y0 && my < y1;
                graphics.method_51433(minecraft.field_1772, "×", x1 - 9, y0 + (height - minecraft.field_1772.field_2000) / 2 + 1, clearHovered ? this.accent : 0xFF666666, false);
            }

            // Renders text shifted past the icon
            final int textPaddingX = 20;
            final int lineHeight = minecraft.field_1772.field_2000;
            final int offsetY = (height - lineHeight) / 2 + 1;

            graphics.method_51448().method_22903();

            graphics.method_51448().method_46416(textPaddingX, offsetY, 0);

            super.method_48579(graphics, mx - textPaddingX, my - offsetY, partialTick);

            graphics.method_51448().method_22909();
        }

    }

    static class ToggleButton extends class_339 {

        private boolean toggled;
        private float animation;
        private final int accent;

        ToggleButton(int x, int y, int width, int height, boolean initial, int accent) {
            super(x, y, width, height, class_2561.method_43473());
            this.toggled = initial;
            this.animation = initial ? 1f : 0f;
            this.accent = accent;
        }

        boolean isToggled() {
            return toggled;
        }

        void setToggled(boolean toggled) {
            this.toggled = toggled;
            animation = toggled ? 1f : 0f;
        }

        @Override
        public void method_25348(double mx, double my) {
            toggled = !toggled;
        }

        @Override
        protected void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            animation = toggled ? Math.min(1f, animation + 0.2f) : Math.max(0f, animation - 0.2f);
            final float e = KnightLibEasings.SMOOTHSTEP.apply(animation);

            final int x0 = method_46426();
            final int y0 = method_46427();
            final int width = method_25368();
            final int height = method_25364();
            final int[] accent = rgb(this.accent);
            final int dark = 0xFF000000 | ((accent[0] / 4) << 16) | ((accent[1] / 4) << 8) | (accent[2] / 4);

            final int border = lerp(0xFF3A3A3E, 0xFF000000 | dimAccent(this.accent), e);
            drawCard(graphics, x0, y0, x0 + width, y0 + height, lerp(0xFF2A2A2E, dark, e), border);

            final int padding = 3;
            final int knobWidth = 14;
            final int knobX = x0 + padding + (int) ((width - knobWidth - padding * 2) * e);

            graphics.method_25294(knobX, y0 + padding, knobX + knobWidth, y0 + height - padding, lerp(0xFF555555, this.accent, e));

            // Soft glow
            if (e > 0.5f) {
                final int glowAlpha = (int) (0x30 * (e - 0.5f) * 2f);
                graphics.method_25294(knobX - 1, y0 + padding, knobX, y0 + height - padding, (glowAlpha << 24) | (accent[0] << 16) | (accent[1] << 8) | accent[2]);
                graphics.method_25294(knobX + knobWidth, y0 + padding, knobX + knobWidth + 1, y0 + height - padding, (glowAlpha << 24) | (accent[0] << 16) | (accent[1] << 8) | accent[2]);
            }

            // ON/OFF label
            final class_310 minecraft = class_310.method_1551();
            final int textY = y0 + (height - minecraft.field_1772.field_2000) / 2 + 1;
            if (e > 0.6f) {
                final int alpha = (int) (0xFF * (e - 0.6f) / 0.4f);
                if (alpha >= 0x10) {
                    graphics.method_51433(minecraft.field_1772, "ON", x0 + 6, textY, withAlpha(this.accent & 0x00FFFFFF, alpha), false);
                }

            }
            else if (e < 0.4f) {
                final int alpha = (int) (0xFF * (0.4f - e) / 0.4f);
                if (alpha >= 0x10) {
                    final String text = "OFF";
                    graphics.method_51433(minecraft.field_1772, text, x0 + width - 5 - minecraft.field_1772.method_1727(text), textY, withAlpha(0x666666, alpha), false);
                }

            }

        }

        private static int lerp(int from, int origin, float t) {
            final int finalAlpha = (from >> 24) & 0xFF;
            final int finalRed = (from >> 16) & 0xFF;
            final int finalGreen = (from >> 8) & 0xFF;
            final int finalBlue = from & 0xFF;
            final int totalAlpha = (origin >> 24) & 0xFF;
            final int totalRed = (origin >> 16) & 0xFF;
            final int totalGreen = (origin >> 8) & 0xFF;
            final int totalBlue = origin & 0xFF;
            return ((finalAlpha + (int) ((totalAlpha - finalAlpha) * t)) << 24) | ((finalRed + (int) ((totalRed - finalRed) * t)) << 16) | ((finalGreen + (int) ((totalGreen - finalGreen) * t)) << 8)  | (finalBlue + (int) ((totalBlue - finalBlue) * t));
        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

    }

    static class ConfigSlider extends class_339 {

        private final double min;
        private final double max;
        private double value;
        private final boolean intMode;
        private final int accent;
        private boolean dragging = false;
        private float activeAnim = 0f;

        // Ctrl+Shift+click switches to inline text entry for exact values
        private boolean editing = false;
        private String editBuffer = "";

        ConfigSlider(int x, int y, int w, int h, double min, double max, double value, boolean intMode, int accent) {
            super(x, y, w, h, class_2561.method_43473());
            this.min = min;
            this.max = max;
            this.value = Math.max(min, Math.min(max, value));
            this.intMode = intMode;
            this.accent = accent;
        }

        double getValueRaw() {
            return intMode ? Math.round(value) : value;
        }

        void setValueRaw(double value) {
            this.value = Math.max(min, Math.min(max, value));
        }

        private double frac() {
            return max <= min ? 0 : (value - min) / (max - min);
        }

        private void fromMouse(double mx) {
            double maxed = Math.max(0, Math.min(1, (mx - method_46426()) / (double) method_25368()));
            value = min + maxed * (max - min);
            if (intMode) {
                value = Math.round(value);
            }

        }

        @Override
        public void method_25348(double mx, double my) {
            if (editing) {
                commitEdit();
                return;
            }

            if (class_437.method_25441() && class_437.method_25442()) {
                editing = true;
                editBuffer = formatCurrent();
                return;
            }

            dragging = true;
            fromMouse(mx);
        }

        @Override
        protected void method_25349(double mx, double my, double dx, double dy) {
            if (dragging) {
                fromMouse(mx);
            }

        }

        @Override
        public void method_25357(double mx, double my) {
            dragging = false;
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);

            if (!focused && editing) {
                commitEdit();
            }

        }

        @Override
        public boolean method_25404(int key, int s, int m) {
            if (!editing) {
                return false;
            }

            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                commitEdit();
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                editing = false;
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editBuffer.isEmpty()) {
                    editBuffer = editBuffer.substring(0, editBuffer.length() - 1);
                }

                return true;
            }

            return false;
        }

        @Override
        public boolean method_25400(char c, int m) {
            if (!editing) {
                return false;
            }

            if (Character.isDigit(c) || c == '-' || (!intMode && (c == '.' || c == ','))) {
                editBuffer += (c == ',' ? '.' : c);
            }

            return true;
        }

        private void commitEdit() {
            editing = false;
            try {
                setValueRaw(Double.parseDouble(editBuffer.trim()));
                if (intMode) {
                    value = Math.round(value);
                }

            }
            catch (NumberFormatException ignored) {
                ;;
            }

        }

        private String formatCurrent() {
            if (intMode) {
                return String.valueOf((long) getValueRaw());
            }

            final double raw = getValueRaw();
            if (raw == Math.floor(raw) && !Double.isInfinite(raw)) {
                return String.valueOf((long) raw);
            }

            return String.format(Locale.ROOT, "%.6f", raw).replaceAll("0+$", "").replaceAll("\\.$", "");
        }


        @Override
        protected void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            final int x0 = method_46426();
            final int y0 = method_46427();
            final int width = method_25368();
            final int height = method_25364();
            final int[] accent = rgb(this.accent);

            final boolean hovered = mx >= x0 && mx < x0 + width && my >= y0 && my < y0 + height;
            activeAnim = (hovered || dragging) ? Math.min(1f, activeAnim + 0.15f) : Math.max(0f, activeAnim - 0.1f);

            final class_310 minecraft = class_310.method_1551();

            if (editing) {
                drawCard(graphics, x0, y0, x0 + width, y0 + height, 0xFF161618, this.accent);

                final boolean caret = (class_156.method_658() / 400L) % 2 == 0;
                final String text = editBuffer + (caret ? "_" : "");
                graphics.method_51433(minecraft.field_1772, text, x0 + (width - minecraft.field_1772.method_1727(text)) / 2, y0 + (height - minecraft.field_1772.field_2000) / 2 + 1, 0xFFE8E8E8, false);
                return;
            }

            final int border = mixRgb(0x3A3A3E, dimAccent(this.accent), activeAnim);
            drawCard(graphics, x0, y0, x0 + width, y0 + height, 0xFF1A1A1C, 0xFF000000 | border);

            int fillWidth = (int) (width * frac());
            if (fillWidth > 1) {
                final float boost = 1f + activeAnim * 0.4f;
                final int fr = Math.min(255, (int) (accent[0] / 3f * boost));
                final int fg = Math.min(255, (int) (accent[1] / 3f * boost));
                final int fb = Math.min(255, (int) (accent[2] / 3f * boost));
                graphics.method_25294(x0 + 1, y0 + 1, Math.min(x0 + fillWidth, x0 + width - 1), y0 + height - 1, 0xFF000000 | (fr << 16) | (fg << 8) | fb);
            }

            int thumbX = x0 + Math.max(0, Math.min(width - 3, fillWidth - 1));
            graphics.method_25294(thumbX, y0, thumbX + 3, y0 + height, this.accent);

            if (activeAnim > 0.05f) {
                final int glowAlpha = (int) (0x50 * activeAnim);
                graphics.method_25294(thumbX - 1, y0 + 1, thumbX, y0 + height - 1, (glowAlpha << 24) | (accent[0] << 16) | (accent[1] << 8) | accent[2]);
                graphics.method_25294(thumbX + 3, y0 + 1, thumbX + 4, y0 + height - 1, (glowAlpha << 24) | (accent[0] << 16) | (accent[1] << 8) | accent[2]);
            }

            final String text = intMode ? String.valueOf((long) getValueRaw()) : String.format("%.3f", getValueRaw());
            graphics.method_51433(minecraft.field_1772, text, x0 + (width - minecraft.field_1772.method_1727(text)) / 2, y0 + (height - minecraft.field_1772.field_2000) / 2 + 1, 0xFFD0D0D0, false);
        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

    }

    static class EnumCycleButton extends class_339 {

        private final Enum<?>[] values;
        private int idx;
        private float hoverAnim = 0f;
        private final int accent;

        EnumCycleButton(int x, int y, int width, int height, Enum<?>[] values, Enum<?> current, int accent) {
            super(x, y, width, height, class_2561.method_43473());
            this.values = values;
            this.accent = accent;
            this.idx = 0;
            for (int i = 0; i < values.length; i++) {
                if (values[i] == current) {
                    idx = i;
                    break;
                }

            }

        }

        Enum<?> getCurrent() {
            return values[idx];
        }

        void setCurrent(Enum<?> value) {
            for (int i = 0; i < values.length; i++) {
                if (values[i] == value) {
                    idx = i;
                    return;
                }

            }

        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            if (!field_22763 || !field_22764 || (button != 0 && button != 1) || !method_25361(mx, my)) {
                return false;
            }

            method_25354(class_310.method_1551().method_1483());
            idx = Math.floorMod(idx + (button == 1 ? -1 : 1), values.length);

            return true;
        }

        @Override
        protected void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            final int x0 = method_46426();
            final int y0 = method_46427();
            final int width = method_25368();
            final int height = method_25364();
            final boolean hovering = mx >= x0 && mx < x0 + width && my >= y0 && my < y0 + height;
            hoverAnim = hovering ? Math.min(1f, hoverAnim + 0.15f) : Math.max(0f, hoverAnim - 0.1f);

            final int border = 0xFF000000 | mixRgb(0x3A3A3E, dimAccent(accent), KnightLibEasings.SMOOTHSTEP.apply(hoverAnim));
            drawCard(graphics, x0, y0, x0 + width, y0 + height, 0xFF18181A, border);

            if (values.length > 1 && values.length <= 12) {
                final int pipsW = values.length * 3 - 1;
                int pipX = x0 + (width - pipsW) / 2;
                final int[] ac = rgb(accent);
                for (int i = 0; i < values.length; i++) {
                    final int color = i == idx ? (0xFF000000 | (ac[0] << 16) | (ac[1] << 8) | ac[2]) : 0xFF333333;
                    graphics.method_25294(pipX, y0 + height - 3, pipX + 2, y0 + height - 2, color);
                    pipX += 3;
                }

            }

            final class_310 minecraft = class_310.method_1551();
            final String text = prettify(values[idx].name());

            graphics.method_51433(minecraft.field_1772, text, x0 + (width - minecraft.field_1772.method_1727(text)) / 2, y0 + (height - minecraft.field_1772.field_2000) / 2, 0xFFD0D0D0, false);

            final int alphaY = y0 + (height - minecraft.field_1772.field_2000) / 2 + 1;
            graphics.method_51433(minecraft.field_1772, "←", x0 + 3, alphaY, border, false);
            graphics.method_51433(minecraft.field_1772, "→", x0 + width - 10, alphaY, border, false);
        }

        @Override
        protected void method_47399(class_6382 narrationElementOutput) {
            ;;
        }

    }

    static class StyledEditBox extends class_342 {

        private float focusAnim = 0f;
        private float expandAnim = 0f;
        private final int baseWidth;
        private final int accent;
        private Predicate<String> validator = raw -> true;

        StyledEditBox(net.minecraft.class_327 font, int x, int y, int width, int height, class_2561 message, int accent) {
            super(font, x, y, width, height, message);
            this.baseWidth = width;
            this.accent = accent;
            method_1858(false);
            method_1868(0xFFD0D0D0);
            method_1860(0xFF666666);
            method_1880(512);
        }

        void setValidator(Predicate<String> validator) {
            this.validator = validator;
        }

        int layoutWidth(int expandedMax) {
            final float target = method_25370() ? 1f : 0f;
            expandAnim += (target - expandAnim) * 0.2f;
            if (Math.abs(target - expandAnim) < 0.01f) {
                expandAnim = target;
            }

            if (expandedMax <= baseWidth || expandAnim <= 0f) {
                return baseWidth;
            }

            return baseWidth + (int) ((expandedMax - baseWidth) * KnightLibEasings.SMOOTHSTEP.apply(expandAnim));
        }

        float expandProgress() {
            return KnightLibEasings.SMOOTHSTEP.apply(expandAnim);
        }

        @Override
        public void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            final int x0 = method_46426();
            final int y0 = method_46427();
            final int x1 = x0 + method_25368();
            final int y1 = y0 + method_25364();
            boolean enable = (mx >= x0 && mx < x1 && my >= y0 && my < y1) || method_25370();
            focusAnim = enable ? Math.min(1f, focusAnim + 0.15f) : Math.max(0f, focusAnim - 0.1f);

            final boolean valid = validator.test(method_1882());

            final int borderTarget = method_25370() ? (accent & 0x00FFFFFF) : dimAccent(accent);
            final int border = !valid ? 0xFFCC4444 : 0xFF000000 | mixRgb(0x3A3A3E, borderTarget, focusAnim);
            drawCard(graphics, x0, y0, x1, y1, valid ? 0xFF161618 : 0xFF221214, border);

            int lineHeight = class_310.method_1551().field_1772.field_2000;
            int offsetY = (this.field_22759 - lineHeight) / 2 + 1;
            int paddingX = 5;

            graphics.method_44379(x0 + 1, y0 + 1, x1 - 1, y1 - 1);

            graphics.method_51448().method_22903();
            graphics.method_51448().method_46416(paddingX, offsetY, 0);
            super.method_48579(graphics, mx - paddingX, my - offsetY, partialTick);
            graphics.method_51448().method_22909();

            graphics.method_44380();
        }

    }

    static class FlatButton extends class_4185 {

        private float hoverAnim = 0f;
        private final int accent;
        private final boolean primary;

        private final long createdAt = class_156.method_658();
        private int entranceDelay = 0;
        private int entranceAlpha = 0xFF;

        FlatButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress, int accent) {
            this(x, y, width, height, message, onPress, accent, false);
        }

        FlatButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress, int accent, boolean primary) {
            super(x, y, width, height, message, onPress, class_4185.field_40754);
            this.accent = accent;
            this.primary = primary;
        }

        FlatButton withEntranceDelay(int delayMs) {
            this.entranceDelay = delayMs;
            return this;
        }

        @Override
        public void method_48579(class_332 graphics, int mx, int my, float partialTick) {
            final float entrance = KnightLibEasings.EASE_OUT_CUBIC.apply(class_3532.method_15363((class_156.method_658() - createdAt - entranceDelay) / 180f, 0f, 1f));
            entranceAlpha = (int) (0xFF * entrance);
            if (entranceAlpha < 0x10) {
                return;
            }

            final int rise = (int) ((1f - entrance) * 4f);
            final int x0 = method_46426();
            final int y0 = method_46427() + rise;
            final int x1 = x0 + method_25368();
            final int y1 = y0 + method_25364();
            boolean hovering = mx >= x0 && mx < x1 && my >= y0 && my < y1;
            hoverAnim = hovering ? Math.min(1f, hoverAnim + 0.15f) : Math.max(0f, hoverAnim - 0.1f);

            if (primary) {
                renderPrimary(graphics, x0, y0, x1, y1);
            }
            else {
                renderSecondary(graphics, x0, y0, x1, y1);
            }

            final class_310 minecraft = class_310.method_1551();
            final int textColor = !field_22763 ? 0x666666 : (primary ? 0xFFFFFF : 0xD0D0D0);
            graphics.method_27534(minecraft.field_1772, method_25369(), x0 + field_22758 / 2, y0 + (this.field_22759 - minecraft.field_1772.field_2000) / 2 + 1, withAlpha(textColor, entranceAlpha));
        }

        private void renderPrimary(class_332 graphics, int x0, int y0, int x1, int y1) {
            final int[] ac = rgb(accent);

            final float boost = 0.32f + hoverAnim * 0.18f;
            final int red = (int) (ac[0] * boost);
            final int green = (int) (ac[1] * boost);
            final int blue = (int) (ac[2] * boost);

            drawCard(graphics, x0, y0, x1, y1, (entranceAlpha << 24) | (red << 16) | (green << 8) | blue, withAlpha(accent & 0x00FFFFFF, entranceAlpha));
        }

        private void renderSecondary(class_332 graphics, int x0, int y0, int x1, int y1) {
            final float e = KnightLibEasings.SMOOTHSTEP.apply(hoverAnim);
            final int bg = (entranceAlpha << 24) | mixRgb(0x161618, 0x1E1E22, e);
            final int border = (entranceAlpha << 24) | mixRgb(0x2A2A2E, dimAccent(accent), e);

            drawCard(graphics, x0, y0, x1, y1, bg, border);
        }

    }

}