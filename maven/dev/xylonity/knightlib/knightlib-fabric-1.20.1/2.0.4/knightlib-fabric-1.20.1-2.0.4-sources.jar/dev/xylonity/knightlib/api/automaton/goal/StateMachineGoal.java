package dev.xylonity.knightlib.api.automaton.goal;

import dev.xylonity.knightlib.api.automaton.Automaton;
import java.util.EnumSet;
import java.util.function.Supplier;
import net.minecraft.class_1352;

/**
 * Bridges an {@link Automaton} into vanilla's {@link class_1352} system.
 *
 * @param <E> entity type
 * @param <S> state enum type
 */
public class StateMachineGoal<E, S extends Enum<S>> extends class_1352 {

    private final E entity;
    private final Supplier<Automaton<E, S>> automaton;

    public StateMachineGoal(E entity, Automaton<E, S> automaton) {
        this(entity, () -> automaton);
    }

    public StateMachineGoal(E entity, Supplier<Automaton<E, S>> automaton) {
        this.entity = entity;
        this.automaton = automaton;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        return true;
    }

    @Override
    public void method_6269() {
        automaton.get().start(entity);
    }

    @Override
    public void method_6270() {
        automaton.get().stop(entity);
    }

    @Override
    public void method_6268() {
        automaton.get().tick(entity);
    }

    @Override
    public boolean method_38846() {
        return true;
    }

}