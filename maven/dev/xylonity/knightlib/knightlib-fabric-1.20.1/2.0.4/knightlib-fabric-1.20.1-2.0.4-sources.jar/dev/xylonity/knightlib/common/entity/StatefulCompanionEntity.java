package dev.xylonity.knightlib.common.entity;

import dev.xylonity.knightlib.api.automaton.Automaton;
import dev.xylonity.knightlib.api.automaton.AutomatonHandler;
import dev.xylonity.knightlib.api.automaton.StatefulEntity;
import dev.xylonity.knightlib.api.automaton.goal.StateMachineGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class StatefulCompanionEntity<E extends StatefulCompanionEntity<E, S>, S extends Enum<S>> extends class_1321 implements StatefulEntity<E, S> {

    private static final class_2940<Integer> CURRENT_STATE = class_2945.method_12791(StatefulCompanionEntity.class, class_2943.field_13327);

    private AutomatonHandler<E, S> automatonHandler;

    protected StatefulCompanionEntity(class_1299<? extends class_1321> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    protected void method_5693() {
        super.method_5693();
        this.method_5841().method_12784(CURRENT_STATE, getDefaultState().ordinal());
    }

    @Override
    public void method_5773() {
        super.method_5773();
        getAutomatonHandler().tick();
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new StateMachineGoal<>(selfEntity(), this::getAutomaton));
    }

    @Override
    public AutomatonHandler<E, S> getAutomatonHandler() {
        if (automatonHandler == null) {
            automatonHandler = AutomatonHandler.of(selfEntity(), CURRENT_STATE, this::buildAutomaton, getDefaultState());
        }

        return automatonHandler;
    }

    @Override
    public boolean method_5643(@NotNull class_1282 source, float amount) {
        boolean wasHurt = super.method_5643(source, amount);

        if (wasHurt) {
            getAutomatonHandler().onHurt(source, amount);
        }

        return wasHurt;
    }

    @Override
    public void method_6078(@NotNull class_1282 damageSource) {
        getAutomatonHandler().onDeath();
        super.method_6078(damageSource);
    }

    @Override
    public void method_5980(@Nullable class_1309 target) {
        class_1309 previous = method_5968();
        super.method_5980(target);
        getAutomatonHandler().onTargetChanged(previous, target);
    }

    @Override
    public boolean method_37222(@NotNull class_1293 effectInstance, @Nullable class_1297 source) {
        boolean applied = super.method_37222(effectInstance, source);

        if (applied) {
            getAutomatonHandler().onEffectAdded(effectInstance);
        }

        return applied;
    }

    @SuppressWarnings("unchecked")
    protected final E selfEntity() {
        return (E) this;
    }

    @NotNull
    protected abstract Automaton<E, S> buildAutomaton();

    @NotNull
    protected abstract S getDefaultState();

}