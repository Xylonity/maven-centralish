package dev.xylonity.knightlib.api.automaton;

import javax.annotation.Nullable;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2940;
import java.util.function.Supplier;

/**
 * Per entity link between a {@link class_1308} and its {@link Automaton}. Builds the automaton on the server, syncs the current
 * state to clients and forwards the vanilla hooks to it. See {@link StatefulEntity}
 *
 * @param <E> entity type
 * @param <S> state enum type
 *
 * @author Xylonity
 */
public final class AutomatonHandler<E extends class_1308, S extends Enum<S>> {

    private final E entity;
    private final class_2940<Integer> stateAccessor;
    private final Supplier<Automaton<E, S>> factory;
    private final S defaultState;
    private final S[] states;

    @Nullable
    private Automaton<E, S> automaton;

    private AutomatonHandler(E entity, class_2940<Integer> stateAccessor, Supplier<Automaton<E, S>> factory, S defaultState) {
        this.entity = entity;
        this.stateAccessor = stateAccessor;
        this.factory = factory;
        this.defaultState = defaultState;
        this.states = defaultState.getDeclaringClass().getEnumConstants();
    }

    /**
     * @param stateAccessor synced integer holding the current state, defined by the entity with the default state's ordinal
     */
    public static <E extends class_1308, S extends Enum<S>> AutomatonHandler<E, S> of(E entity, class_2940<Integer> stateAccessor, Supplier<Automaton<E, S>> factory, S defaultState) {
        return new AutomatonHandler<>(entity, stateAccessor, factory, defaultState);
    }

    /**
     * Returns the automaton
     */
    @Nullable
    public Automaton<E, S> getAutomaton() {
        if (automaton == null && !entity.method_37908().field_9236) {
            automaton = factory.get();
        }

        return automaton;
    }

    public S getCurrentState() {
        final int ordinal = entity.method_5841().method_12789(stateAccessor);
        return ordinal >= 0 && ordinal < states.length ? states[ordinal] : defaultState;
    }

    /**
     * Syncs the current state to clients, must be called every tick
     */
    public void tick() {
        if (getAutomaton() != null) {
            entity.method_5841().method_12778(stateAccessor, automaton.currentState().ordinal());
        }

    }

    public void onHurt(class_1282 source, float amount) {
        if (automaton != null) {
            automaton.onDamaged(entity, source, amount);
        }

    }

    public void onDeath() {
        if (automaton != null) {
            automaton.onDeath(entity);
        }

    }

    public void onTargetChanged(@Nullable class_1309 previous, @Nullable class_1309 target) {
        if (automaton != null) {
            automaton.onTargetChanged(entity, previous, target);
        }

    }

    public void onEffectAdded(class_1293 effectInstance) {
        if (automaton != null) {
            automaton.onEffectAdded(entity, effectInstance);
        }

    }

}
