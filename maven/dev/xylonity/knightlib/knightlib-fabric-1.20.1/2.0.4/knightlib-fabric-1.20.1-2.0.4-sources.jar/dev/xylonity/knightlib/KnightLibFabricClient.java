package dev.xylonity.knightlib;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.client.ClientProxy;
import dev.xylonity.knightlib.client.event.KnightLibClientEvents;
import dev.xylonity.knightlib.client.event.KnightLibFabricClientEvents;
import net.fabricmc.api.ClientModInitializer;

public class KnightLibFabricClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        KnightLib.PROXY = new ClientProxy();

        // Event hooks
        KnightLibFabricClientEvents.init();

        // Internal event registrar
        KnightLibEvents.CLIENT.register(KnightLibClientEvents.class);

        KnightLib.PROXY.updatePersistentSoundsEngine();

        // Event hooks
        KnightLibFabricClientEvents.dispatchRegistrationEvents();
    }

}