package dev.xylonity.knightlib.api.entity.hitbox;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;

/**
 * Defines a hitbox attached to a specific GeckoLib bone.
 * <p>
 * Each hitbox has a size (half-extents or derived from the bone geometry), an optional offset from the
 * bone pivot, a target filter, and a hit cooldown (hit behavior is not defined here, refer to {@link BoneHitboxManager#onHit}).
 * <p>
 * <pre>{@code
 * // Explicit size
 * BoneHitbox axeTip = BoneHitbox.create("axe_tip", 0.4, 0.4, 0.8)
 *     .cooldown(10);
 *
 * // Autosized from the bone's cubes in the model
 * BoneHitbox axeTip2 = BoneHitbox.create("axeTip2")
 *     .cooldown(10);
 * }</pre>
 */
public class BoneHitbox {

    private final String boneName;
    private @Nullable class_243 baseHalfExtents;
    private @Nullable class_243 halfExtents;
    private final boolean autoSize;

    private class_243 offset = class_243.field_1353;
    private int cooldownTicks = 10;
    private boolean enabled = true;
    private Predicate<class_1297> filter = entity -> entity instanceof class_1309;

    private @Nullable OBB currentOBB;
    private final Map<Integer, Integer> hitCooldowns = new HashMap<>();

    private BoneHitbox(String boneName, @Nullable class_243 halfExtents, boolean autoSize) {
        this.boneName = boneName;
        this.baseHalfExtents = halfExtents;
        this.halfExtents = halfExtents;
        this.autoSize = autoSize;
    }

    /**
     * Creates a bone hitbox with explicit half-extents (in blocks)
     *
     * @param boneName the name of the GeckoLib bone to attach to
     * @param halfX half-width (X axis)
     * @param halfY half-height (Y axis)
     * @param halfZ half-depth (Z axis)
     */
    public static BoneHitbox create(String boneName, double halfX, double halfY, double halfZ) {
        return new BoneHitbox(boneName, new class_243(halfX, halfY, halfZ), false);
    }

    /**
     * Creates a bone hitbox with uniform explicit size (in blocks)
     */
    public static BoneHitbox create(String boneName, double halfSize) {
        return create(boneName, halfSize, halfSize, halfSize);
    }

    /**
     * Creates a bone hitbox whose size is automatically derived from the bone's cube geometry in the GeckoLib
     * model. The hitbox will encompass all cubes of the bone.
     * <p>
     * The position is always the bone's pivot point.
     */
    public static BoneHitbox create(String boneName) {
        return new BoneHitbox(boneName, null, true);
    }

    /**
     * Sets the cooldown (in ticks) before this hitbox can hit the same entity again
     */
    public BoneHitbox cooldown(int ticks) {
        this.cooldownTicks = ticks;
        return this;
    }

    /**
     * Offset from the bone pivot (in blocks), in the bone's local coordinate space
     */
    public BoneHitbox offset(double x, double y, double z) {
        this.offset = new class_243(x, y, z);
        return this;
    }

    /**
     * Predicate to filter which entities can be hit
     */
    public BoneHitbox filter(Predicate<class_1297> filter) {
        this.filter = filter;
        return this;
    }

    public String getBoneName() {
        return boneName;
    }

    /**
     * Returns the effective half-extents (base * bone scale), or {@code null} if not yet computed
     */
    public @Nullable class_243 getHalfExtents() {
        return halfExtents;
    }

    /**
     * Returns the base half-extents before bone scale is applied
     */
    public @Nullable class_243 getBaseHalfExtents() {
        return baseHalfExtents;
    }

    public boolean isAutoSize() {
        return autoSize;
    }

    public class_243 getOffset() {
        return offset;
    }

    public int getCooldownTicks() {
        return cooldownTicks;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Predicate<class_1297> getFilter() {
        return filter;
    }

    public @Nullable OBB getCurrentOBB() {
        return currentOBB;
    }

    /**
     * Sets the base half-extents. Used by the render layer when autosizing from bone cubes, or by the server when
     * receiving autosized dimensions from the client
     */
    public void setBaseHalfExtents(class_243 baseHalfExtents) {
        this.baseHalfExtents = baseHalfExtents;
        this.halfExtents = baseHalfExtents;
    }

    /**
     * Sets the effective half-extents directly (already scaled). Used by the server when receiving the scaled
     * dimensions from the sync packet
     */
    public void setHalfExtents(@Nullable class_243 halfExtents) {
        this.halfExtents = halfExtents;
    }

    /**
     * Applies bone scale to the base half-extents, updating the effective size
     *
     * @param scaleX scale factor along the bone's local X axis
     * @param scaleY scale factor along the bone's local Y axis
     * @param scaleZ scale factor along the bone's local Z axis
     */
    public void applyScale(float scaleX, float scaleY, float scaleZ) {
        if (baseHalfExtents == null) {
            return;
        }

        this.halfExtents = new class_243(
                baseHalfExtents.field_1352 * scaleX,
                baseHalfExtents.field_1351 * scaleY,
                baseHalfExtents.field_1350 * scaleZ
        );
    }

    /**
     * Updates the OBB from the bone's world-space position and rotation (the offset is applied in the bone's
     * local coordinate space before converting to world space)
     */
    public void updateFromBoneTransform(class_243 boneWorldPos, Matrix3f boneWorldRotation) {
        if (halfExtents == null) {
            return;
        }

        class_243 worldOffset = class_243.field_1353;
        if (offset.method_1027() > 0) {
            float ox = (float) offset.field_1352;
            float oy = (float) offset.field_1351;
            float oz = (float) offset.field_1350;
            worldOffset = new class_243(
                    boneWorldRotation.m00() * ox + boneWorldRotation.m10() * oy + boneWorldRotation.m20() * oz,
                    boneWorldRotation.m01() * ox + boneWorldRotation.m11() * oy + boneWorldRotation.m21() * oz,
                    boneWorldRotation.m02() * ox + boneWorldRotation.m12() * oy + boneWorldRotation.m22() * oz
            );

        }

        this.currentOBB = new OBB(boneWorldPos.method_1019(worldOffset), halfExtents, boneWorldRotation);
    }

    /**
     * Checks if the given entity is on cooldown (recently hit by this hitbox)
     */
    public boolean isOnCooldown(class_1297 target) {
        Integer remaining = hitCooldowns.get(target.method_5628());
        return remaining != null && remaining > 0;
    }

    /**
     * Puts the given entity on cooldown
     */
    public void applyCooldown(class_1297 target) {
        hitCooldowns.put(target.method_5628(), cooldownTicks);
    }

    /**
     * Ticks down all cooldowns
     */
    public void tickCooldowns() {
        hitCooldowns.entrySet().removeIf(entry -> {
            entry.setValue(entry.getValue() - 1);
            return entry.getValue() <= 0;
        });

    }

    /**
     * Clears all active cooldowns
     */
    public void clearCooldowns() {
        hitCooldowns.clear();
    }

}
