package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.common.recipe.GreatChaliceRecipe;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public final class KnightLibRecipeTypes {

    public static final ResourceRegistry<class_3956<?>> RECIPE_TYPES = ResourceDispatcher.create(class_7923.field_41188, KnightLib.MOD_ID);

    public static final ResourceEntry<class_3956<GreatChaliceRecipe>> CHALICE_TYPE = RECIPE_TYPES.register("great_chalice_interaction", () -> GreatChaliceRecipe.RECIPE_TYPE);

}
