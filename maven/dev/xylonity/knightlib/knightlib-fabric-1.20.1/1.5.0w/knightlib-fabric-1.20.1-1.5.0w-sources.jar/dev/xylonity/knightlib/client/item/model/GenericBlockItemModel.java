package dev.xylonity.knightlib.client.item.model;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.item.blockitem.GenericBlockItem;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;


public class GenericBlockItemModel extends GeoModel<GenericBlockItem> {

    private final String name;

    public GenericBlockItemModel(String name) {
        this.name = name;
    }

    @Override
    public class_2960 getModelResource(GenericBlockItem animatable) {
        return KnightLib.of("geo/" + name + ".geo.json");
    }

    @Override
    public class_2960 getTextureResource(GenericBlockItem animatable) {
        return KnightLib.of("textures/block/" + name + ".png");
    }

    @Override
    public class_2960 getAnimationResource(GenericBlockItem animatable) {
        return null;
    }

}
