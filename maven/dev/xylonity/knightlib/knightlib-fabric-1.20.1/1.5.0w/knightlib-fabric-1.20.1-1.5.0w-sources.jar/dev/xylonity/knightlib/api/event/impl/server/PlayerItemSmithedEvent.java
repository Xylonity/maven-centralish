package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/**
 * Fired when a player takes the result item from a smithing table
 */
public class PlayerItemSmithedEvent extends KnightLibEvent {

    private final class_1657 player;
    private final class_1799 result;
    private final class_1263 inputSlots;

    public PlayerItemSmithedEvent(class_1657 player, class_1799 result, class_1263 inputSlots) {
        this.player = player;
        this.result = result;
        this.inputSlots = inputSlots;
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1799 getResult() {
        return result;
    }

    public class_1263 getInputSlots() {
        return inputSlots;
    }

}