package dev.xylonity.knightlib.api.entity.hitbox;

import net.minecraft.class_238;
import net.minecraft.class_243;
import org.joml.Matrix3f;
import org.joml.Vector3f;

/**
 * Oriented Bounding Box (a rotation aware 3D box, unlike AABBs, which are aligned by axis).
 * Using the Separating Axis Theorem (SAT) for intersection tests.
 */
public class OBB {

    private class_243 center;
    private final class_243 halfExtents;
    private final Vector3f[] axes = new Vector3f[3];

    public OBB(final class_243 center, final class_243 halfExtents, final Matrix3f rotation) {
        this.center = center;
        this.halfExtents = halfExtents;
        this.axes[0] = rotation.getColumn(0, new Vector3f());
        this.axes[1] = rotation.getColumn(1, new Vector3f());
        this.axes[2] = rotation.getColumn(2, new Vector3f());
    }

    public class_243 getCenter() {
        return center;
    }

    public class_243 getHalfExtents() {
        return halfExtents;
    }

    public Vector3f[] getAxes() {
        return axes;
    }

    public void setCenter(class_243 center) {
        this.center = center;
    }

    /**
     * Tests intersection with an axis-aligned bounding box using SAT.
     * An AABB is just an OBB with identity rotation, so I test 15 potential separating axes (3 from this OBB, 3 from
     * the AABB, and 9 cross products).
     */
    public boolean intersects(final class_238 aabb) {
        final class_243 aabbCenter = aabb.method_1005();
        final class_243 aabbHalf = new class_243(
                (aabb.field_1320 - aabb.field_1323) * 0.5,
                (aabb.field_1325 - aabb.field_1322) * 0.5,
                (aabb.field_1324 - aabb.field_1321) * 0.5
        );

        final Vector3f[] aabbAxes = {
                new Vector3f(1, 0, 0),
                new Vector3f(0, 1, 0),
                new Vector3f(0, 0, 1)
        };

        return satTest(aabbCenter, aabbHalf, aabbAxes);
    }

    /**
     * Tests intersection with another OBB using SAT
     */
    public boolean intersects(final OBB other) {
        return satTest(other.center, other.halfExtents, other.axes);
    }

    private boolean satTest(final class_243 otherCenter, final class_243 otherHalf, final Vector3f[] otherAxes) {
        final Vector3f center = new Vector3f(
                (float) (otherCenter.field_1352 - this.center.field_1352),
                (float) (otherCenter.field_1351 - this.center.field_1351),
                (float) (otherCenter.field_1350 - this.center.field_1350)
        );

        final float[] aHalf = {
                (float) halfExtents.field_1352,
                (float) halfExtents.field_1351,
                (float) halfExtents.field_1350
        };
        final float[] bHalf = {
                (float) otherHalf.field_1352,
                (float) otherHalf.field_1351,
                (float) otherHalf.field_1350
        };

        // Tests 3 axes from this OBB
        for (int i = 0; i < 3; i++) {
            if (isSeparating(axes[i], center, aHalf, bHalf, otherAxes)) {
                return false;
            }

        }

        // Tests 3 axes from the other box
        for (int i = 0; i < 3; i++) {
            if (isSeparating(otherAxes[i], center, aHalf, bHalf, otherAxes)) {
                return false;
            }

        }

        // Tests 9 cross-product axes
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                final Vector3f cross = new Vector3f();
                axes[i].cross(otherAxes[j], cross);
                if (cross.lengthSquared() < 1e-6f) {
                    // Parallel axes
                    continue;
                }

                cross.normalize();
                if (isSeparating(cross, center, aHalf, bHalf, otherAxes)) {
                    return false;
                }
            }

        }

        return true;
    }

    private boolean isSeparating(final Vector3f axis, final Vector3f center, float[] aHalf, float[] bHalf, final Vector3f[] otherAxes) {
        final float projection = Math.abs(axis.dot(center));

        float aExtent = 0;
        for (int i = 0; i < 3; i++) {
            aExtent += aHalf[i] * Math.abs(axis.dot(axes[i]));
        }

        float bExtent = 0;
        for (int i = 0; i < 3; i++) {
            bExtent += bHalf[i] * Math.abs(axis.dot(otherAxes[i]));
        }

        return projection > aExtent + bExtent;
    }

    /**
     * Expands the OBB half-extents by the given amount
     */
    public OBB inflate(double amount) {
        return new OBB(center, halfExtents.method_1031(amount, amount, amount), toMatrix());
    }

    /**
     * Reconstructs the rotation matrix from the stored axes
     */
    public Matrix3f toMatrix() {
        final Matrix3f matrix = new Matrix3f();
        matrix.setColumn(0, axes[0]);
        matrix.setColumn(1, axes[1]);
        matrix.setColumn(2, axes[2]);
        return matrix;
    }

    /**
     * Computes the AABB that fully encloses this OBB
     */
    public class_238 enclosingAABB() {
        float rx = 0;
        float ry = 0;
        float rz = 0;
        for (int i = 0; i < 3; i++) {
            final float h = (float) halfExtent(i);
            rx += Math.abs(axes[i].x()) * h;
            ry += Math.abs(axes[i].y()) * h;
            rz += Math.abs(axes[i].z()) * h;
        }

        return new class_238(
                center.field_1352 - rx, center.field_1351 - ry, center.field_1350 - rz,
                center.field_1352 + rx, center.field_1351 + ry, center.field_1350 + rz
        );
    }

    /**
     * Ray-OBB intersection test using the slab method in the OBB's local coordinate space.
     * Returns the distance along the ray to the hit point, or -1 if there is no intersection.
     *
     * @param start ray origin (world space)
     * @param end ray end (world space)
     * @return distance to intersection, or -1 if none
     */
    public double rayIntersects(final class_243 start, final class_243 end) {
        final class_243 direction = end.method_1020(start);
        final double rayLength = direction.method_1033();
        if (rayLength < 1e-8) {
            return -1;
        }

        // Transforms the ray into the OBB local space
        final class_243 delta = start.method_1020(center);
        final double[] origins = {
                dot(delta, axes[0]),
                dot(delta, axes[1]),
                dot(delta, axes[2])
        };
        final double[] directions = {
                dot(direction, axes[0]),
                dot(direction, axes[1]),
                dot(direction, axes[2])
        };
        final double[] halfs = {
                halfExtents.field_1352,
                halfExtents.field_1351,
                halfExtents.field_1350
        };

        double tMin = 0;
        double tMax = 1;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(directions[i]) < 1e-8) {
                // If the ray is parallel it must be inside
                if (origins[i] < -halfs[i] || origins[i] > halfs[i]) {
                    return -1;
                }

            }
            else {
                final double invD = 1.0 / directions[i];
                double t1 = (-halfs[i] - origins[i]) * invD;
                double t2 = (halfs[i] - origins[i]) * invD;
                if (t1 > t2) {
                    double tmp = t1;
                    t1 = t2;
                    t2 = tmp;
                }

                tMin = Math.max(tMin, t1);
                tMax = Math.min(tMax, t2);
                if (tMin > tMax) {
                    return -1;
                }
            }

        }

        return tMin * rayLength;
    }

    private static double dot(class_243 vector, Vector3f axis) {
        return vector.field_1352 * axis.x() + vector.field_1351 * axis.y() + vector.field_1350 * axis.z();
    }

    /**
     * Returns the 8 corners of the OBB in world space
     */
    public class_243[] getCorners() {
        final class_243[] corners = new class_243[8];
        final double hx = halfExtents.field_1352;
        final double hy = halfExtents.field_1351;
        final double hz = halfExtents.field_1350;
        final class_243 ax = toVec3(axes[0]);
        final class_243 ay = toVec3(axes[1]);
        final class_243 az = toVec3(axes[2]);

        int idx = 0;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                for (int sz = -1; sz <= 1; sz += 2) {
                    corners[idx++] = center
                            .method_1019(ax.method_1021(sx * hx))
                            .method_1019(ay.method_1021(sy * hy))
                            .method_1019(az.method_1021(sz * hz));
                }
            }

        }

        return corners;
    }

    private static class_243 toVec3(Vector3f vector) {
        return new class_243(vector.x(), vector.y(), vector.z());
    }

    private double halfExtent(int i) {
        return switch (i) {
            case 0 -> halfExtents.field_1352;
            case 1 -> halfExtents.field_1351;
            case 2 -> halfExtents.field_1350;
            default -> 0;
        };

    }

}
