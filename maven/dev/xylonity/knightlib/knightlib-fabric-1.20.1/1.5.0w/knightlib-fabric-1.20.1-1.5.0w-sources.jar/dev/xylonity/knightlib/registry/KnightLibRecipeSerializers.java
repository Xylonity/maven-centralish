package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.common.recipe.GreatChaliceRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_7923;

public final class KnightLibRecipeSerializers {

    public static final ResourceRegistry<class_1865<?>> RECIPE_SERIALIZERS = ResourceDispatcher.create(class_7923.field_41189, KnightLib.MOD_ID);

    public static final ResourceEntry<class_1865<GreatChaliceRecipe>> CHALICE_SERIALIZER = RECIPE_SERIALIZERS.register("great_chalice_interaction", () -> GreatChaliceRecipe.SERIALIZER);

}
