package dev.xylonity.knightlib.client.sound.persistent.internal;

import dev.xylonity.knightlib.api.sound.persistent.KnightLibPersistentSounds;
import dev.xylonity.knightlib.api.sound.persistent.impl.PersistentSoundProfile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * Internal implementation of {@link KnightLibPersistentSounds.PersistentSoundEngine}
 */
public final class ClientPersistentSoundEngine implements KnightLibPersistentSounds.PersistentSoundEngine {

    /**
     * One tracker per entity id
     */
    private final Map<Integer, PersistentSoundTracker> trackers = new HashMap<>();

    @Override
    public void tick(class_1297 entity, String... names) {
        if (entity == null || names.length == 0) {
            return;
        }

        final int id = entity.method_5628();
        PersistentSoundTracker tracker = trackers.get(id);

        // First call for this entity locates its matching profile and creates a tracker for it
        if (tracker == null) {
            final PersistentSoundProfile<?> profile = findProfile(entity);
            if (profile == null) {
                return;
            }

            tracker = new PersistentSoundTracker(profile);
            trackers.put(id, tracker);
        }

        tracker.tick(entity, Set.of(names));
    }

    @Override
    public void stopAll(class_1297 entity) {
        if (entity == null) {
            return;
        }

        final PersistentSoundTracker tracker = trackers.remove(entity.method_5628());
        if (tracker != null) {
            tracker.stopAll();
        }
    }

    @Override
    public void clearAll() {
        for (final PersistentSoundTracker tracker : trackers.values()) {
            tracker.stopAll();
        }

        trackers.clear();
    }

    @Override
    public void endClientTick() {
        final class_638 level = class_310.method_1551().field_1687;

        final Iterator<Map.Entry<Integer, PersistentSoundTracker>> iterator = trackers.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<Integer, PersistentSoundTracker> entry = iterator.next();
            final class_1297 entity = level != null ? level.method_8469(entry.getKey()) : null;
            final PersistentSoundTracker tracker = entry.getValue();

            tracker.sweep(entity);
            if (tracker.isEmpty()) {
                iterator.remove();
            }

        }

    }

    private PersistentSoundProfile<?> findProfile(class_1297 entity) {
        for (final PersistentSoundProfile<?> profile : KnightLibPersistentSounds.getProfiles()) {
            if (profile.matches(entity)) {
                return profile;
            }

        }

        return null;
    }

}