package dev.xylonity.knightlib.network.packets;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.sound.persistent.KnightLibPersistentSounds;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Clientbound packet emitted by {@link KnightLibPersistentSounds#tickShared(class_1297, String...)}. Each tracking client resolves
 * the entity by id and feeds the persistent sounds engine just like a local tick() call
 */
public record PersistentSoundTickS2C(
        int entityId,
        String[] names
) {

    public static final class_2960 ID = KnightLib.of("persistent_sound_tick");

    public static final ClientboundPacketType<PersistentSoundTickS2C> TYPE =
            PacketType.clientbound(
                    ID,
                    PersistentSoundTickS2C.class,
                    PacketCodec.of(PersistentSoundTickS2C::encode, PersistentSoundTickS2C::decode),
                    PersistentSoundTickS2C::handle
            );

    public static void encode(PersistentSoundTickS2C packet, class_2540 buf) {
        buf.method_10804(packet.entityId());
        buf.method_10804(packet.names().length);
        for (final String name : packet.names()) {
            buf.method_10814(name);
        }

    }

    public static PersistentSoundTickS2C decode(class_2540 buf) {
        final int entityId = buf.method_10816();
        final int count = buf.method_10816();
        final String[] names = new String[count];
        for (int i = 0; i < count; i++) {
            names[i] = buf.method_19772();
        }

        return new PersistentSoundTickS2C(entityId, names);
    }

    private static void handle(PersistentSoundTickS2C packet) {
        final class_1937 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        final class_1297 entity = level.method_8469(packet.entityId());
        if (entity == null) {
            return;
        }

        KnightLibPersistentSounds.tick(entity, packet.names());
    }

}
