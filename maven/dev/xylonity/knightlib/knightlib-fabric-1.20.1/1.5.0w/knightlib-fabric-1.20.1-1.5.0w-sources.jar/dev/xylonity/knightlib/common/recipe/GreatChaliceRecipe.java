package dev.xylonity.knightlib.common.recipe;

import com.google.gson.JsonObject;
import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.registry.KnightLibItems;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

public final class GreatChaliceRecipe implements class_1860<class_1277> {

    private static final class_2960 ID = KnightLib.of("great_chalice_interaction");

    public static final class_1865<GreatChaliceRecipe> SERIALIZER = new Serializer();
    public static final class_3956<GreatChaliceRecipe> RECIPE_TYPE = new Type();

    public final class_1799 input = new class_1799(KnightLibItems.EMPTY_GRAIL.get());
    public final class_1799 output = new class_1799(KnightLibItems.FILLED_GRAIL.get());

    @Override
    public boolean matches(class_1277 inv, @NotNull class_1937 lvl) {
        return class_1799.method_7984(inv.method_5438(0), input);
    }

    @Override
    public @NotNull class_1799 assemble(@NotNull class_1277 inv, @NotNull class_5455 reg) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int w, int h) {
        return true;
    }

    @Override
    public @NotNull class_1799 method_8110(@NotNull class_5455 reg) {
        return output.method_7972();
    }

    @Override
    public @NotNull class_2960 method_8114() {
        return ID;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SERIALIZER;
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return RECIPE_TYPE;
    }

    public static final class Type implements class_3956<GreatChaliceRecipe> {

        @Override
        public String toString() {
            return ID.toString();
        }

    }

    public static final class Serializer implements class_1865<GreatChaliceRecipe> {
        @Override
        public @NotNull GreatChaliceRecipe method_8121(@NotNull class_2960 id, @NotNull JsonObject json) {
            return new GreatChaliceRecipe();
        }

        @Override
        public GreatChaliceRecipe method_8122(@NotNull class_2960 id, @NotNull class_2540 buf) {
            return new GreatChaliceRecipe();
        }

        @Override
        public void toNetwork(@NotNull class_2540 buf, @NotNull GreatChaliceRecipe rec) { ;; }
    }

}
