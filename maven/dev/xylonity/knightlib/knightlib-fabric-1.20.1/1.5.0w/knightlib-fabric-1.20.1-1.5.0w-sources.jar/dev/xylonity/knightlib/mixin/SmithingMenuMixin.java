package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.PlayerItemSmithedEvent;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4861;
import net.minecraft.class_4862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4862.class)
public abstract class SmithingMenuMixin extends class_4861 {

    private SmithingMenuMixin() {
        super(null, 0, null, null);
    }

    @Inject(method = "onTake", at = @At("HEAD"))
    private void knightlib$onSmithingTake(class_1657 player, class_1799 stack, CallbackInfo ci) {
        KnightLibEvents.SERVER.dispatch(new PlayerItemSmithedEvent(player, stack, this.field_22480));
    }

}