package dev.xylonity.knightlib.client.shader.post;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1060;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_332;

public final class PostShaderManager {

    private static final Map<class_2960, PostShader<?>> POST_SHADERS = new LinkedHashMap<>();

    private PostShaderManager() {
        ;;
    }

    /**
     * Registers a post shader and immediately reloads it against the current client resources
     */
    public static void register(PostShader<?> postShader) {
        POST_SHADERS.put(postShader.id(), postShader);

        final class_310 minecraft = class_310.method_1551();
        postShader.initOrReload(
                minecraft.method_1531(),
                minecraft.method_1478(),
                minecraft.method_1522()
        );
    }

    @SuppressWarnings("unchecked")
    public static <PSS extends PostShaderSettings> PostShader<PSS> get(class_2960 id) {
        return (PostShader<PSS>) POST_SHADERS.get(id);
    }

    public static Collection<PostShader<?>> all() {
        return POST_SHADERS.values();
    }

    public static <PSS extends PostShaderSettings> void start(class_2960 id, PSS settings) {
        final PostShader<PSS> postShader = get(id);
        if (postShader != null) {
            postShader.start(settings);
        }

    }

    /**
     * Per-tick update for all shaders present in the current level
     */
    public static void clientTick() {
        final class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 == null) {
            return;
        }

        for (PostShader<?> postShader : POST_SHADERS.values()) {
            postShader.clientTick();
        }

    }

    public static void renderOverlay(class_332 graphics, float partialTicks) {
        for (PostShader<?> postShader : POST_SHADERS.values()) {
            postShader.renderOverlay(graphics, partialTicks);
        }

    }

    /**
     * Each shader declares which stages it can be rendered into
     * @see PostShaderRenderStage
     */
    public static void renderStage(PostShaderRenderContext context) {
        for (PostShader<?> postShader : POST_SHADERS.values()) {
            if (postShader.stages().contains(context.stage)) {
                postShader.renderStage(context);
            }

        }

    }

    /**
     * Called when the client triggers a disconnection. Safely clears each shader
     */
    public static void onLogout() {
        for (PostShader<?> postShader : POST_SHADERS.values()) {
            postShader.onLogout();
        }

    }

    /**
     * Reinitializes all shaders after a client resource reload is performed
     * @see dev.xylonity.knightlib.api.event.impl.client.ClientResourcesReloadedEvent event that should be triggered
     */
    public static void onRegisterShaders(class_1060 textures, class_3300 resources, class_276 target) {
        for (PostShader<?> postShader : POST_SHADERS.values()) {
            postShader.initOrReload(textures, resources, target);
        }

    }

}