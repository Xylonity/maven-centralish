package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.MenuScreenRegistrationEvent;
import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_437;

public class MenuScreenRegistrationEventFabric extends MenuScreenRegistrationEvent {

    @Override
    public <M extends class_1703, S extends class_437 & class_3936<M>> void register(class_3917<M> menuType, MenuScreenRegistrationEvent.ScreenFactory<M, S> screenFactory) {
        ScreenRegistry.register(menuType, screenFactory::create);
    }

}