package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/**
 * Fired when an entity successfully crafts an item
 */
public class PlayerItemCraftedEvent extends KnightLibEvent {

    private final class_1657 player;
    private final class_1799 crafted;
    private final class_1263 craftMatrix;

    public PlayerItemCraftedEvent(class_1657 player, class_1799 crafted, class_1263 craftMatrix) {
        this.player = player;
        this.crafted = crafted;
        this.craftMatrix = craftMatrix;
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1799 getCrafted() {
        return crafted;
    }

    public class_1263 getCraftMatrix() {
        return craftMatrix;
    }

}