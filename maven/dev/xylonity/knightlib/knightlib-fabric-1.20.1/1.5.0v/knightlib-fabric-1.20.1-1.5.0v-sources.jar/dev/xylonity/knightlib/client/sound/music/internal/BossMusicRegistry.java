package dev.xylonity.knightlib.client.sound.music.internal;

import dev.xylonity.knightlib.api.sound.music.IBossMusicProvider;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;

/**
 * Caches entity music providers to optimize performance by avoiding repeated constant player bb searches
 * for nearby entities each tick, which reduces unnecessary complexity on the client.
 */
public final class BossMusicRegistry {

    private static final Map<Integer, IBossMusicProvider> ENTITIES = new ConcurrentHashMap<>();

    private BossMusicRegistry() {
        ;;
    }

    public static void register(IBossMusicProvider provider) {
        final class_1297 entity = (class_1297) provider;
        ENTITIES.put(entity.method_5628(), provider);
    }

    public static void unregister(IBossMusicProvider provider) {
        final class_1297 entity = (class_1297) provider;
        ENTITIES.remove(entity.method_5628());
    }

    public static void unregisterById(int entityId) {
        ENTITIES.remove(entityId);
    }

    public static Collection<IBossMusicProvider> getAll() {
        return ENTITIES.values();
    }

    public static void clear() {
        ENTITIES.clear();
    }

}