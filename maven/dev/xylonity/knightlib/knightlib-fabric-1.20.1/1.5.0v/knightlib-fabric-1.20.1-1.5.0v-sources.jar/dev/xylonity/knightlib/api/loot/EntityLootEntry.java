package dev.xylonity.knightlib.api.loot;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_6862;

/**
 * Immutable descriptor for an entity loot drop entry
 */
public final class EntityLootEntry {

    private final Supplier<class_1792> item;
    private final class_6862<class_1299<?>> entityTag;
    private final Supplier<Float> chance;
    private final float minCount;
    private final float maxCount;

    EntityLootEntry(
            Supplier<class_1792> item,
            class_6862<class_1299<?>> entityTag,
            Supplier<Float> chance,
            float minCount,
            float maxCount
    ) {
        this.item = item;
        this.entityTag = entityTag;
        this.chance = chance;
        this.minCount = minCount;
        this.maxCount = maxCount;
    }

    public class_1792 getItem() {
        return item.get();
    }

    public Supplier<class_1792> getItemSupplier() {
        return item;
    }

    public class_6862<class_1299<?>> getEntityTag() {
        return entityTag;
    }

    public float getChance() {
        return chance.get();
    }

    public float getMinCount() {
        return minCount;
    }

    public float getMaxCount() {
        return maxCount;
    }

}