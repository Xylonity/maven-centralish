package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import net.minecraft.class_2591;
import net.minecraft.class_7923;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;

public class KnightLibBlockEntities {

    public static final ResourceRegistry<class_2591<?>> BLOCK_ENTITIES = ResourceDispatcher.create(class_7923.field_41181, KnightLib.MOD_ID);

    public static final ResourceEntry<class_2591<GreatChaliceBlockEntity>> GREAT_CHALICE =
            BLOCK_ENTITIES.registerBlockEntity("great_chalice", GreatChaliceBlockEntity::new, KnightLibBlocks.GREAT_CHALICE);

}
