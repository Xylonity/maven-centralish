package dev.xylonity.knightlib.api.loot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_141;
import net.minecraft.class_2048;
import net.minecraft.class_215;
import net.minecraft.class_219;
import net.minecraft.class_44;
import net.minecraft.class_47;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

/**
 * Fast entity loot drop registration API.
 *
 * For more complex loot table modifications (chest loot, custom conditions, etc.), use
 * {@link dev.xylonity.knightlib.api.event.impl.server.LootTableModifyEvent} event.</p>
 */
public final class KnightLibLoot {

    private static final List<EntityLootEntry> ENTITY_ENTRIES = new ArrayList<>();

    private KnightLibLoot() {
        ;;
    }

    /**
     * Creates a builder for a new entity loot drop entry
     */
    public static EntityLootBuilder builder() {
        return new EntityLootBuilder();
    }

    /**
     * Adds a finalized entry to the registry. Internal
     */
    static void addEntry(EntityLootEntry entry) {
        ENTITY_ENTRIES.add(entry);
    }

    /**
     * Returns all registered entity loot entries. Internal
     */
    public static List<EntityLootEntry> getEntityEntries() {
        return Collections.unmodifiableList(ENTITY_ENTRIES);
    }

    /**
     * Builds a {@link class_55.class_56} for a given entity loot entry.
     * The pool includes an entity-tag condition and a random-chance condition,
     * and is safe to inject into any {@code entities/*} loot table.
     */
    public static class_55.class_56 buildPool(EntityLootEntry entry) {

        float min = entry.getMinCount();
        float max = entry.getMaxCount();

        return class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_351(class_77.method_411(entry.getItem())
                        .method_438(class_141.method_621(
                                min == max ? class_44.method_32448(min) : class_5662.method_32462(min, max)
                        )))
                .method_356(class_219.method_932(entry.getChance()))
                .method_356(class_215.method_27865(
                        class_47.class_50.field_935,
                        class_2048.class_2049.method_8916().method_8922(entry.getEntityTag()).method_8920()
                ));
    }

}