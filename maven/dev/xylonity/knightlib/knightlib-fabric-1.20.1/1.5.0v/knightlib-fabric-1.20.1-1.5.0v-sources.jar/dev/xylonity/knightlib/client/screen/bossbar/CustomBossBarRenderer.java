package dev.xylonity.knightlib.client.screen.bossbar;

import dev.xylonity.knightlib.api.bossbar.BossBarContext;
import net.minecraft.class_332;

@FunctionalInterface
public interface CustomBossBarRenderer {

    void render(class_332 gui, BossBarContext ctx, int x, int y);

}
