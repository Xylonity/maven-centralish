package dev.xylonity.knightlib.client.sound.persistent.internal;

import dev.xylonity.knightlib.api.sound.persistent.KnightLibPersistentSounds;
import dev.xylonity.knightlib.api.sound.persistent.impl.PersistentSoundProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;

/**
 * Internal implementation of {@link KnightLibPersistentSounds.PersistentSoundEngine}
 */
public final class ClientPersistentSoundEngine implements KnightLibPersistentSounds.PersistentSoundEngine {

    private final Map<Integer, PersistentSoundTracker> trackers = new HashMap<>();

    @Override
    public void tick(class_1297 entity, String... names) {
        if (entity == null || names.length == 0) {
            return;
        }

        final int id = entity.method_5628();
        PersistentSoundTracker tracker = trackers.get(id);

        if (tracker == null) {
            PersistentSoundProfile<?> profile = findProfile(entity);
            if (profile == null) {
                return;
            }

            tracker = new PersistentSoundTracker(profile);
            trackers.put(id, tracker);
        }

        tracker.tick(entity, Set.of(names));
    }

    @Override
    public void stopAll(class_1297 entity) {
        if (entity == null) {
            return;
        }

        final PersistentSoundTracker tracker = trackers.remove(entity.method_5628());
        if (tracker != null) {
            tracker.stopAll();
        }
    }

    @Override
    public void clearAll() {
        for (PersistentSoundTracker tracker : trackers.values()) {
            tracker.stopAll();
        }

        trackers.clear();
    }

    private PersistentSoundProfile<?> findProfile(class_1297 entity) {
        for (PersistentSoundProfile<?> profile : KnightLibPersistentSounds.getProfiles()) {
            if (profile.matches(entity)) {
                return profile;
            }

        }

        return null;
    }

}