package dev.xylonity.knightlib.common.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.jetbrains.annotations.NotNull;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class AbstractProjectile extends class_1676 implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final class_2940<Integer> LIFETIME = class_2945.method_12791(AbstractProjectile.class, class_2943.field_13327);
    private static final class_2940<Integer> MAX_LIFETIME = class_2945.method_12791(AbstractProjectile.class, class_2943.field_13327);
    private static final class_2940<Float> SIZE = class_2945.method_12791(AbstractProjectile.class, class_2943.field_13320);

    public AbstractProjectile(class_1299<? extends class_1676> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (!method_37908().field_9236) {
            if (getLifetime() == 0) {
                discardEntity();
            }

            setLifetime(getLifetime() - 1);
        }

    }

    protected void discardEntity() {
        this.method_31472();
    }

    @Override
    public boolean method_5727(double x, double y, double z) {
        return true;
    }

    @Override
    public boolean method_5640(double distance) {
        return true;
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(LIFETIME, baseLifetime());
        this.field_6011.method_12784(MAX_LIFETIME, baseLifetime());
        this.field_6011.method_12784(SIZE, 1f);
    }

    public float getSize() {
        return this.field_6011.method_12789(SIZE);
    }

    public void setSize(float size) {
        this.field_6011.method_12778(SIZE, size);
    }

    public int getLifetime() {
        return this.field_6011.method_12789(LIFETIME);
    }

    public void setLifetime(int lifetime) {
        this.field_6011.method_12778(LIFETIME, lifetime);
        if (lifetime > getMaxLifetime()) {
            setMaxLifetime(lifetime);
        }

    }

    public int getMaxLifetime() {
        return this.field_6011.method_12789(MAX_LIFETIME);
    }

    public void setMaxLifetime(int lifetime) {
        this.field_6011.method_12778(MAX_LIFETIME, lifetime);
    }

    @Override
    public void method_5749(@NotNull class_2487 pCompound) {
        super.method_5749(pCompound);
        if (pCompound.method_10545("Lifetime")) {
            this.setLifetime(pCompound.method_10550("Lifetime"));
        }
        if (pCompound.method_10545("MaxLifetime")) {
            this.setLifetime(pCompound.method_10550("MaxLifetime"));
        }
        if (pCompound.method_10545("EntitySize")) {
            this.setSize(pCompound.method_10583("EntitySize"));
        }

    }

    @Override
    public void method_5652(@NotNull class_2487 pCompound) {
        super.method_5652(pCompound);
        pCompound.method_10569("Lifetime", this.getLifetime());
        pCompound.method_10569("MaxLifetime", this.getMaxLifetime());
        pCompound.method_10548("EntitySize", this.getSize());
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        ;;
    }

    protected abstract int baseLifetime();

}
