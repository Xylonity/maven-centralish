package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketType;
import dev.xylonity.knightlib.network.ServerboundPacketType;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public interface KnightLibNetwork {
    KnightLibNetwork createEndpoint(String modId, String protocol);

    <T> void registerClientbound(PacketType<T> type, Consumer<T> clientHandler);
    <T> void registerServerbound(PacketType<T> type, BiConsumer<T, class_3222> serverHandler);
    <T> void register(ClientboundPacketType<T> type);
    <T> void register(ServerboundPacketType<T> type);

    <T> void sendTo(class_3222 player, PacketType<T> type, T msg);
    <T> void sendToServer(T message);
    <T> void sendToAll(MinecraftServer server, PacketType<T> type, T msg);
    <T> void sendToPlayers(class_1937 level, PacketType<T> type, T msg);
    <T> void sendToTracking(class_1937 level, class_2338 pos, PacketType<T> type, T msg);
    <T> void sendToTracking(class_1297 entity, PacketType<T> type, T msg);
}
