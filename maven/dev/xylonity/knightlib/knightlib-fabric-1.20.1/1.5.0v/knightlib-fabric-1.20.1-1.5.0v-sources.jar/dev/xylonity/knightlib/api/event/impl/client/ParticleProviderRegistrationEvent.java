package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import java.util.function.Function;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_707;

/**
 * Event to register particle factories
 */
public abstract class ParticleProviderRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public <T extends class_2394> void register(ResourceEntry<class_2396<T>> particleEntry, Function<class_4002, class_707<T>> provider) {
        register(particleEntry.get(), provider);
    }

    public abstract <T extends class_2394> void register(class_2396<T> particleType, Function<class_4002, class_707<T>> provider);

}