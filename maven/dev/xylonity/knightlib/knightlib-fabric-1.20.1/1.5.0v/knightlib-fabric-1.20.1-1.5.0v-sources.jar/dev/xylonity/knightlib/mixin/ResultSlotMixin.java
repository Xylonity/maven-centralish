package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.event.KnightLibEvents;
import dev.xylonity.knightlib.api.event.impl.server.PlayerItemCraftedEvent;
import net.minecraft.class_1657;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_8566;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1734.class)
public class ResultSlotMixin {

    @Shadow
    @Final
    private class_1657 player;

    @Shadow
    @Final
    private class_8566 craftSlots;

    @Inject(method = "checkTakeAchievements", at = @At("HEAD"))
    private void knightlib$onCraft(class_1799 stack, CallbackInfo ci) {
        KnightLibEvents.SERVER.dispatch(new PlayerItemCraftedEvent(player, stack, craftSlots));
    }

}