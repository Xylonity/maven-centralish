package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_437;

/**
 * Event to register screens and containers
 */
public abstract class MenuScreenRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    @FunctionalInterface
    public interface ScreenFactory<M extends class_1703, S extends class_437 & class_3936<M>> {
        S create(M menu, class_1661 playerInventory, class_2561 title);
    }

    public <M extends class_1703, S extends class_437 & class_3936<M>> void register(ResourceEntry<class_3917<M>> menuEntry, ScreenFactory<M, S> screenFactory) {
        register(menuEntry.get(), screenFactory);
    }

    public abstract <M extends class_1703, S extends class_437 & class_3936<M>> void register(class_3917<M> menuType, ScreenFactory<M, S> screenFactory);

}