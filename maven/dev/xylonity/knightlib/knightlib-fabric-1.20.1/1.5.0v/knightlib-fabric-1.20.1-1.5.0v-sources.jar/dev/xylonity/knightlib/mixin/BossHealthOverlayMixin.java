package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.bossbar.BossBarContext;
import dev.xylonity.knightlib.client.screen.bossbar.BossBarApi;
import dev.xylonity.knightlib.client.screen.bossbar.BossBarLinks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Optional;
import net.minecraft.class_1259;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_345;

@Mixin(class_337.class)
public abstract class BossHealthOverlayMixin {

    @Unique
    private class_345 knightlib$lastEvent;
    @Unique
    private boolean knightlib$skipNextName;

    @Invoker("drawBar")
    public abstract void knightlib$drawBarAccessor(class_332 gui, int x, int y, class_1259 event);

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/BossHealthOverlay;drawBar(Lnet/minecraft/client/gui/GuiGraphics;IILnet/minecraft/world/BossEvent;)V"))
    private void knightlib$drawBar(class_337 self, class_332 gui, int x, int y, class_1259 rawEvent) {
        class_345 boss = (class_345) rawEvent;
        this.knightlib$lastEvent = boss;

        Optional<BossBarApi.BossBarEntry> match = BossBarApi.match(boss);
        if (match.isPresent()) {
            BossBarApi.BossBarEntry entry = match.get();

            BossBarLinks.Reference reference = BossBarLinks.INSTANCE.get(boss.method_5407());
            class_1297 entity = reference != null ? reference.resolve() : null;
            BossBarContext ctx = new BossBarContext(boss, entity, reference != null ? reference.entityType() : null);

            this.knightlib$skipNextName = entry.hideVanillaName();

            if (entry.renderer() != null) {
                entry.renderer().render(gui, ctx, x, y);
                return;
            }

            if (entry.legacyRenderer() != null) {
                entry.legacyRenderer().render(gui, boss, x, y);
                return;
            }

            this.knightlib$skipNextName = false;
            knightlib$drawBarAccessor(gui, x, y, boss);
            return;
        }

        this.knightlib$skipNextName = false;
        knightlib$drawBarAccessor(gui, x, y, boss);
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)I"))
    private int knightlib$shouldSkipName(class_332 gui, class_327 font, class_2561 text, int x, int y, int color) {
        if (this.knightlib$skipNextName) {
            this.knightlib$skipNextName = false;
            return x;
        }

        return gui.method_27535(font, text, x, y, color);
    }

    @ModifyVariable(method = "render", at = @At(value = "STORE", ordinal = 1), index = 3)
    private int knightlib$extraPadding(int j) {
        if (this.knightlib$lastEvent == null) return j;

        return j + BossBarApi.match(this.knightlib$lastEvent).map(BossBarApi.BossBarEntry::extraYPadding).orElse(0);
    }

}
