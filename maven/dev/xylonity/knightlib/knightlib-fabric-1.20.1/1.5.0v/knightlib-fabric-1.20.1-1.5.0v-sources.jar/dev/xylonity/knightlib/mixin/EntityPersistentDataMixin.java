package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.common.entity.data.internal.KnightLibPersistentDataAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityPersistentDataMixin implements KnightLibPersistentDataAccessor {

    @Unique
    private class_2487 knightlib$persistentData = new class_2487();

    @Unique
    public class_2487 knightlib$getPersistentData() {
        return knightlib$persistentData;
    }

    @Inject(method = "saveWithoutId", at = @At("RETURN"))
    private void knightlib$savePersistentData(class_2487 tag, CallbackInfoReturnable<class_2487> cir) {
        if (!knightlib$persistentData.method_33133()) {
            tag.method_10566("KnightLibData", knightlib$persistentData.method_10553());
        }

    }

    @Inject(method = "load", at = @At("RETURN"))
    private void knightlib$loadPersistentData(class_2487 tag, CallbackInfo ci) {
        if (tag.method_10573("KnightLibData", class_2487.field_33260)) {
            knightlib$persistentData = tag.method_10562("KnightLibData");
        }

    }

}