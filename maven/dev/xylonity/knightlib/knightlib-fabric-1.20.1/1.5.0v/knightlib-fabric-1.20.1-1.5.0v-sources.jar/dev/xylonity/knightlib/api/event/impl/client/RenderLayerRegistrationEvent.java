package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;

/**
 * Event to register render layers for blocks and fluids (for example, adding a cutout layer to a custom translucent block)
 */
public abstract class RenderLayerRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public void setBlockLayer(ResourceEntry<class_2248> blockEntry, class_1921 renderType) {
        setBlockLayer(blockEntry.get(), renderType);
    }

    public abstract void setBlockLayer(class_2248 block, class_1921 renderType);

    public void setFluidLayer(ResourceEntry<class_3611> fluidEntry, class_1921 renderType) {
        setFluidLayer(fluidEntry.get(), renderType);
    }

    public abstract void setFluidLayer(class_3611 fluid, class_1921 renderType);

    public void setCutout(class_2248 block) {
        setBlockLayer(block, class_1921.method_23581());
    }

    public void setCutoutMipped(class_2248 block) {
        setBlockLayer(block, class_1921.method_23579());
    }

    public void setTranslucent(class_2248 block) {
        setBlockLayer(block, class_1921.method_23583());
    }

    public void setCutout(ResourceEntry<class_2248> blockEntry) {
        setBlockLayer(blockEntry.get(), class_1921.method_23581());
    }

    public void setCutoutMipped(ResourceEntry<class_2248> blockEntry) {
        setBlockLayer(blockEntry.get(), class_1921.method_23579());
    }

    public void setTranslucent(ResourceEntry<class_2248> blockEntry) {
        setBlockLayer(blockEntry.get(), class_1921.method_23583());
    }

}