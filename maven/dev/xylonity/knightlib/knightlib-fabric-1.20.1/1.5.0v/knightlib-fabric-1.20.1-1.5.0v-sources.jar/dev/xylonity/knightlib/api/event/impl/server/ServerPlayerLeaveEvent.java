package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Fired when a player disconnects from the server
 */
public final class ServerPlayerLeaveEvent extends KnightLibEvent {

    private final MinecraftServer server;
    private final class_3222 player;

    public ServerPlayerLeaveEvent(MinecraftServer server, class_3222 player) {
        this.server = server;
        this.player = player;
    }

    public MinecraftServer getServer() {
        return server;
    }

    public class_3222 getPlayer() {
        return player;
    }

}