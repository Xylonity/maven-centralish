package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import dev.xylonity.knightlib.registry.KnightLibItems;
import java.nio.file.Path;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_4970;

public interface KnightLibPlatform {
    <T extends class_2396<?>> Supplier<T> createParticle(boolean overrideLimiter);
    <T extends class_2248> Supplier<T> createBlock(String id, class_4970.class_2251 properties, KnightLibBlocks.BlockType blockType);
    <T extends class_1792> Supplier<T> createItem(String id, class_1792.class_1793 properties, KnightLibItems.ItemType itemType);

    <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> factory, Supplier<class_2248> block);
    <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> factory, Supplier<class_2248>... blocks);
    <T extends class_1703> class_3917<T> createMenuFactory(ResourceRegistry.MenuFactory<T> supplier);
    <X extends class_1308> class_1792 createSpawnEgg(Supplier<class_1299<X>> entityType, int primaryColor, int secondaryColor, class_1792.class_1793 properties);

    void openMenu(class_3222 player, class_3908 provider, Consumer<class_2540> extraData);

    boolean isPhysicalClient();
    boolean isModLoaded(String modid);

    Path resolveConfigFile(String configFileName);
    Path getConfigPath();

    class_1761.class_7913 creativeTabBuilder();
}