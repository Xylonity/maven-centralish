package dev.xylonity.knightlib.common.entity;

import dev.xylonity.knightlib.api.automaton.Automaton;
import dev.xylonity.knightlib.api.automaton.StateEnum;
import dev.xylonity.knightlib.api.automaton.goal.StateMachineGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class StatefulCompanionEntity<E extends StatefulCompanionEntity<E, S>, S extends Enum<S> & StateEnum> extends class_1321 implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final class_2940<Integer> CURRENT_STATE = class_2945.method_12791(StatefulCompanionEntity.class, class_2943.field_13327);

    private Automaton<E, S> automaton;

    protected StatefulCompanionEntity(class_1299<? extends class_1321> entityType, class_1937 level) {
        super(entityType, level);
        this.field_5985 = true;
    }

    @Override
    protected void method_5693() {
        super.method_5693();
        this.method_5841().method_12784(CURRENT_STATE, getDefaultState().id());
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (!method_37908().field_9236 && getAutomaton() != null) {
            setCurrentState(getAutomaton().currentStateId());
        }

        // Computes a correct smooth yaw rotation when looking at a target position
        if (method_37908().field_9236) {
            computeYawRotation();
        }

    }

    public void setCurrentState(int stateId) {
        this.method_5841().method_12778(CURRENT_STATE, stateId);
    }

    public int getCurrentStateId() {
        return this.method_5841().method_12789(CURRENT_STATE);
    }

    public S getCurrentState() {
        final int id = getCurrentStateId();
        final S[] states = getStateValues();

        for (S state : states) {
            if (state.id() == id) {
                return state;
            }

        }

        return getDefaultState();
    }

    protected void computeYawRotation() {
        field_6283 = class_3532.method_15388(field_6283, method_36454(), 6.0f);
        method_5847(class_3532.method_15388(method_5791(), method_36454(), 12.0f));
    }

    @Override
    protected void method_5959() {
        this.automaton = buildAutomaton();
        this.field_6201.method_6277(1, new StateMachineGoal<>(selfEntity(), automaton));
    }

    public Automaton<E, S> getAutomaton() {
        return automaton;
    }

    @Override
    public boolean method_5643(@NotNull class_1282 source, float amount) {
        boolean wasHurt = super.method_5643(source, amount);

        if (wasHurt && automaton != null && !this.method_37908().field_9236) {
            automaton.onDamaged(selfEntity(), source, amount);
        }

        return wasHurt;
    }

    @Override
    public void method_6078(@NotNull class_1282 damageSource) {
        if (automaton != null && !this.method_37908().field_9236) {
            automaton.onDeath(selfEntity());
        }

        super.method_6078(damageSource);
    }

    @Override
    public void method_5980(@Nullable class_1309 target) {
        class_1309 previous = method_5968();
        super.method_5980(target);

        if (automaton != null && !this.method_37908().field_9236) {
            automaton.onTargetChanged(selfEntity(), previous, target);
        }

    }

    @Override
    public boolean method_37222(@NotNull class_1293 effectInstance, @Nullable class_1297 source) {
        boolean applied = super.method_37222(effectInstance, source);

        if (applied && automaton != null && !this.method_37908().field_9236) {
            automaton.onEffectAdded(selfEntity(), effectInstance);
        }

        return applied;
    }

    @SuppressWarnings("unchecked")
    protected final E selfEntity() {
        return (E) this;
    }

    @NotNull
    protected abstract Automaton<E, S> buildAutomaton();

    @NotNull
    protected abstract S[] getStateValues();

    @NotNull
    protected abstract S getDefaultState();

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        ;;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

}