package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * Fired when an entity finishes using an item
 */
public class LivingUseItemFinishEvent extends KnightLibEvent {

    private final class_1309 entity;
    private final class_1799 item;
    private class_1799 result;

    public LivingUseItemFinishEvent(class_1309 entity, class_1799 item, class_1799 result) {
        this.entity = entity;
        this.item = item;
        this.result = result;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_1799 getItem() {
        return item;
    }

    public class_1799 getResult() {
        return result;
    }

    public void setResult(class_1799 result) {
        this.result = result;
    }

}