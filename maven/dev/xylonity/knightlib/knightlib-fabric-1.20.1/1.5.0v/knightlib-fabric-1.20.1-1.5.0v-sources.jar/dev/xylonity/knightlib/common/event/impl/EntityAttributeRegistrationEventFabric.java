package dev.xylonity.knightlib.common.event.impl;

import dev.xylonity.knightlib.api.event.impl.server.EntityAttributeRegistrationEvent;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;
import java.util.function.Supplier;

public class EntityAttributeRegistrationEventFabric extends EntityAttributeRegistrationEvent {

    @Override
    public <T extends class_1309> void register(class_1299<T> entityType, Supplier<class_5132.class_5133> attributes) {
        FabricDefaultAttributeRegistry.register(entityType, attributes.get());
    }

}