package dev.xylonity.knightlib.api.spawn;

import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_6880;

/**
 * Builder for constructing {@link EntityBiomeSpawnEntry} instances.
 *
 * <pre>
 * {@code
 * KnightLibSpawns.builder(() -> TestingEntities.YEAH.get(), MobCategory.CREATURE)
 *     .spawnRate(15, 1, 3)
 *     .biomeFilter(biome -> biome.is(BiomeTags.IS_FOREST))
 *     .submit();
 * }</pre>
 *
 * Spawn placement rules are registered separately via {@link dev.xylonity.knightlib.api.event.impl.server.SpawnPlacementRegistrationEvent}
 */
public final class EntityBiomeSpawnBuilder<T extends class_1308> {

    private Predicate<class_6880<class_1959>> biomeFilter = biome -> true;
    private final Supplier<class_1299<T>> entityType;
    private final class_1311 category;

    private int weight = 10;
    private int minCount = 1;
    private int maxCount = 1;

    EntityBiomeSpawnBuilder(Supplier<class_1299<T>> entityType, class_1311 category) {
        this.entityType = entityType;
        this.category = category;
    }

    /**
     * Sets the spawn weight and group size range
     */
    public EntityBiomeSpawnBuilder<T> spawnRate(int weight, int minCount, int maxCount) {
        this.weight = weight;
        this.minCount = minCount;
        this.maxCount = maxCount;
        return this;
    }

    /**
     * Sets the predicate that determines which biomes this entity can spawn in
     */
    public EntityBiomeSpawnBuilder<T> biomeFilter(Predicate<class_6880<class_1959>> biomeFilter) {
        this.biomeFilter = biomeFilter;
        return this;
    }

    /**
     * Finalizes and registers this spawn entry.
     * MUST be called during mod initialization.
     */
    public EntityBiomeSpawnEntry<T> submit() {
        final EntityBiomeSpawnEntry<T> entry = new EntityBiomeSpawnEntry<>(
                entityType,
                category,
                weight,
                minCount,
                maxCount,
                biomeFilter
        );

        KnightLibEntityBiomeSpawns.addEntry(entry);

        return entry;
    }

}