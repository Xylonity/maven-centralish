package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.ShaderRegistrationEvent;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import java.io.IOException;
import java.util.function.Consumer;

public class ShaderRegistrationEventFabric extends ShaderRegistrationEvent {

    private final CoreShaderRegistrationCallback.RegistrationContext context;

    public ShaderRegistrationEventFabric(CoreShaderRegistrationCallback.RegistrationContext context) {
        this.context = context;
    }

    @Override
    public void register(class_2960 id, class_293 format, Consumer<class_5944> onLoaded) throws IOException {
        context.register(id, format, onLoaded);
    }

}