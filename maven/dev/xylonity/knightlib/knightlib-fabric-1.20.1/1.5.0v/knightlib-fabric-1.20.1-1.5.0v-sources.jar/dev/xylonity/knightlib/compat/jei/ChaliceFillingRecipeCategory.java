package dev.xylonity.knightlib.compat.jei;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.interop.IGreatChaliceInteractable;
import dev.xylonity.knightlib.common.blockentity.GreatChaliceBlockEntity;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import dev.xylonity.knightlib.common.recipe.ChaliceFillingRecipe;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import dev.xylonity.knightlib.registry.KnightLibEntities;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Vector3f;
import software.bernie.geckolib.renderer.GeoBlockRenderer;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class ChaliceFillingRecipeCategory implements IRecipeCategory<ChaliceFillingRecipe> {

    public static final class_2960 UID = new class_2960(KnightLib.MOD_ID, "block_filling");
    public static final RecipeType<ChaliceFillingRecipe> TYPE = new RecipeType<>(UID, ChaliceFillingRecipe.class);
    public static final class_2960 SHADOW = new class_2960(KnightLib.MOD_ID, "textures/gui/shadow.png");

    private GreatChaliceBlockEntity cachedBlockEntity;
    private GreatChaliceStartsetRing cachedEntity;
    private long lastUpdateTime = 0;
    private final IDrawable icon;

    private long lastEntityAppearTime = 0;
    private static final long ENTITY_VISIBLE_DURATION = 500;
    private static final long ENTITY_INTERVAL = 2000;
    private long lastEntityTickAdvanceTime = 0;

    private ChaliceFillingRecipe currentRecipe;

    public ChaliceFillingRecipeCategory(IGuiHelper gui) {
        this.icon = gui.createDrawableIngredient(VanillaTypes.ITEM_STACK, new class_1799(KnightLibBlocks.GREAT_CHALICE.get()));
    }

    @Override
    public @NotNull RecipeType<ChaliceFillingRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return class_2561.method_43471("jei.knightlib.great_chalice_fill_interaction.title");
    }

    @Override
    public int getWidth() {
        return 120;
    }

    @Override
    public int getHeight() {
        return 80;
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, ChaliceFillingRecipe rec, @NotNull IFocusGroup focuses) {
        this.currentRecipe = rec;
        builder.addSlot(RecipeIngredientRole.INPUT, 10, 5).addItemStack(rec.input());
    }

    private GreatChaliceBlockEntity getOrCreateBlockEntity() {
        if (cachedBlockEntity == null) {
            cachedBlockEntity = new GreatChaliceBlockEntity(class_2338.field_10980, KnightLibBlocks.GREAT_CHALICE.get().method_9564());
            cachedBlockEntity.setCharges(IGreatChaliceInteractable.MAX_CHARGES);
        }
        return cachedBlockEntity;
    }

    private GreatChaliceStartsetRing getOrCreateEntity() {
        if (cachedEntity == null) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 != null) {
                cachedEntity = new GreatChaliceStartsetRing(KnightLibEntities.GREAT_CHALICE_STARSET_RING.get(), mc.field_1687);
                cachedEntity.method_5875(true);
            }
        }

        if (cachedEntity != null) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastEntityTickAdvanceTime >= 50) {
                cachedEntity.field_6012++;
                lastEntityTickAdvanceTime = currentTime;
            }
        }

        return cachedEntity;
    }

    private void updateAnimation() {
        long currentTime = System.currentTimeMillis();

        if (lastUpdateTime == 0) {
            lastUpdateTime = currentTime;
        }

        if (currentTime - lastEntityAppearTime >= ENTITY_INTERVAL) {
            lastEntityAppearTime = currentTime;

            GreatChaliceStartsetRing entity = getOrCreateEntity();
            if (entity != null) {
                entity.field_6012 = 0;
            }

            int amountToAdd = 1;
            if (currentRecipe.input().method_7909() instanceof IGreatChaliceInteractable stack) {
                amountToAdd = stack.getChargesToApply();
            }

            GreatChaliceBlockEntity blockEntity = getOrCreateBlockEntity();
            int current = blockEntity.getCharges();
            int next = current + amountToAdd;
            if (next > IGreatChaliceInteractable.MAX_CHARGES) {
                next = 0;
            }
            blockEntity.setCharges(next);
        }


        lastUpdateTime = currentTime;
    }

    @Override
    public void draw(@NotNull ChaliceFillingRecipe recipe, @NotNull IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        RenderSystem.setShaderTexture(0, SHADOW);
        guiGraphics.method_25302(SHADOW, 21, 55, 0, 0, 39, 17);
        // arrow down
        guiGraphics.method_25302(SHADOW, 33, 10, 46, 3, 33, 22);
        // item bg input
        guiGraphics.method_25302(SHADOW, 9, 4, 120, 0, 19, 19);

        updateAnimation();

        GreatChaliceBlockEntity blockEntity = getOrCreateBlockEntity();
        GreatChaliceStartsetRing entity = getOrCreateEntity();

        GeoBlockRenderer<GreatChaliceBlockEntity> blockRenderer = (GeoBlockRenderer<GreatChaliceBlockEntity>) class_310.method_1551().method_31975().method_3550(blockEntity);
        GeoEntityRenderer<GreatChaliceStartsetRing> entityRenderer = null;
        if (entity != null) {
            class_897<?> rawRenderer = class_310.method_1551().method_1561().method_3953(entity);
            if (rawRenderer instanceof GeoEntityRenderer<?>) {
                entityRenderer = (GeoEntityRenderer<GreatChaliceStartsetRing>) rawRenderer;
            }

        }

        if (blockRenderer == null) {
            return;
        }

        class_4587 pose = guiGraphics.method_51448();
        class_4597.class_4598 buffer = guiGraphics.method_51450();

        // chalice
        pose.method_22903();
        pose.method_46416(60, 55, 20);
        pose.method_22905(24f, 24f, 24f);
        pose.method_22907(class_7833.field_40714.rotationDegrees(-25f));
        pose.method_22907(class_7833.field_40716.rotationDegrees(45f));
        pose.method_22907(class_7833.field_40718.rotationDegrees(180f));

        Matrix3f normalMat = pose.method_23760().method_23762();
        Vector3f up = new Vector3f(-1, 10, -1);
        Vector3f front = new Vector3f(-1, 3, -1);
        normalMat.transform(up).normalize();
        normalMat.transform(front).normalize();

        RenderSystem.setupGui3DDiffuseLighting(up, front);

        try {
            float partialTicks = (float)((System.currentTimeMillis() - lastUpdateTime) / 50.0);
            blockRenderer.method_3569(blockEntity, partialTicks, pose, buffer, class_765.method_23687(15, 15), class_4608.field_21444);
        } catch (Exception e) {
            blockRenderer.method_3569(blockEntity, class_310.method_1551().method_1488(), pose, buffer, class_765.method_23687(15, 15), class_4608.field_21444);
        }

        pose.method_22909();

        // entity
        if (entity != null && (System.currentTimeMillis() - lastEntityAppearTime < ENTITY_VISIBLE_DURATION) && entityRenderer != null) {
            pose.method_22903();
            pose.method_22904(60, 66, 27.5);
            pose.method_22905(24f, 24f, 24f);
            pose.method_22907(class_7833.field_40714.rotationDegrees(-25f));
            pose.method_22907(class_7833.field_40716.rotationDegrees(45f));
            pose.method_22907(class_7833.field_40718.rotationDegrees(180f));

            //RenderSystem.setupGui3DDiffuseLighting(up, front);

            entityRenderer.method_3936(entity, 0, class_310.method_1551().method_1488(), pose, buffer, class_765.method_23687(15, 15));

            pose.method_22909();
        }

        buffer.method_22993();
    }

}