package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import dev.xylonity.knightlib.api.event.impl.interop.TickPhase;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Fired at the start/end of each server-side player tick
 */
public final class ServerPlayerTickEvent extends KnightLibEvent {

    private final MinecraftServer server;
    private final class_3222 player;
    private final TickPhase phase;

    public ServerPlayerTickEvent(MinecraftServer server, class_3222 player, TickPhase phase) {
        this.server = server;
        this.player = player;
        this.phase = phase;
    }

    public MinecraftServer getServer() {
        return server;
    }

    public class_3222 getPlayer() {
        return player;
    }

    public TickPhase getPhase() {
        return phase;
    }

}