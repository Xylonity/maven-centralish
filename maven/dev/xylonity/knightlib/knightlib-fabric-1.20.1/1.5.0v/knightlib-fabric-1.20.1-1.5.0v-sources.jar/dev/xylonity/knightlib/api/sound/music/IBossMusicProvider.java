package dev.xylonity.knightlib.api.sound.music;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

/**
 * Client-sided abstraction. Implement this interface on the entity you want to play boss music.
 * The entity is registered and unregistered automatically within the BossMusicRegistry wrapper.
 */
@FunctionalInterface
public interface IBossMusicProvider {

    /**
     * The music must be an instance of AbstractLoopSound
     * @return the music to play
     */
    @NotNull
    class_3414 getBossMusic();

    /**
     * Predicate if the player selected should play the boss music or not
     * @param listener the player that listens to the music
     */
    default boolean shouldPlayBossMusic(class_1657 listener) {
        final class_1297 entity = (class_1297) this;
        return entity.method_5805() && listener.method_5858(entity) <= getMusicRangeSqr();
    }

    default class_3419 soundSource() {
        return class_3419.field_15247;
    }

    /**
     * Entity's internal music range cap
     */
    default double getMusicRangeSqr() {
        return 64 * 64;
    }

    default int getFadeIn() {
        return 40;
    }

    default int getFadeOut() {
        return 40;
    }

}