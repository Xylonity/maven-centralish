package dev.xylonity.knightlib.network.packets;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.client.screen.bossbar.BossBarLinks;
import dev.xylonity.knightlib.network.ClientboundPacketType;
import dev.xylonity.knightlib.network.PacketCodec;
import dev.xylonity.knightlib.network.PacketType;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Clientbound packet that links a bossbar entry with an entity reference on the client
 */
public record BossBarLinkS2C(
        UUID bossEventId,
        int entityId,
        UUID entityUuid,
        class_2960 entityType,
        class_2960 dimension
) {

    public static final class_2960 ID = KnightLib.of("bossbar_link");

    public static final ClientboundPacketType<BossBarLinkS2C> TYPE =
            PacketType.clientbound(
                    ID,
                    BossBarLinkS2C.class,
                    PacketCodec.of(BossBarLinkS2C::encode, BossBarLinkS2C::decode),
                    message -> BossBarLinks.INSTANCE.put(message.bossEventId(), new BossBarLinks.Reference(message.entityId(), message.entityUuid(), message.entityType(), message.dimension()))
            );

    public static void encode(BossBarLinkS2C packet, class_2540 buf) {
        buf.method_10797(packet.bossEventId);
        buf.method_10804(packet.entityId);
        buf.method_10797(packet.entityUuid);
        buf.method_10812(packet.entityType);
        buf.method_10812(packet.dimension);
    }

    public static BossBarLinkS2C decode(class_2540 buf) {
        return new BossBarLinkS2C(
                buf.method_10790(),
                buf.method_10816(),
                buf.method_10790(),
                buf.method_10810(),
                buf.method_10810()
        );

    }

}
