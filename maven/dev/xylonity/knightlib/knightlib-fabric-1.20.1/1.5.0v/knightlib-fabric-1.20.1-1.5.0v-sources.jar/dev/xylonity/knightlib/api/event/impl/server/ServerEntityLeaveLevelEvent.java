package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

/**
 * Fired when an entity leaves a server-side level
 */
public final class ServerEntityLeaveLevelEvent extends KnightLibEvent {

    private final MinecraftServer server;
    private final class_3218 level;
    private final class_1297 entity;

    public ServerEntityLeaveLevelEvent(MinecraftServer server, class_3218 level, class_1297 entity) {
        this.server = server;
        this.level = level;
        this.entity = entity;
    }

    public MinecraftServer getServer() {
        return server;
    }

    public class_3218 getLevel() {
        return level;
    }

    public class_1297 getEntity() {
        return entity;
    }

}