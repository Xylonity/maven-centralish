package dev.xylonity.knightlib.client.sound.music.internal;

import dev.xylonity.knightlib.api.sound.music.IBossMusicProvider;
import dev.xylonity.knightlib.client.sound.music.AbstractLoopSound;
import dev.xylonity.knightlib.mixin.AbstractTickableSoundInstanceAccessor;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_1101;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class BossMusicManager {

    private static final Map<Integer, class_1101> ACTIVE = new Int2ObjectOpenHashMap<>();

    private BossMusicManager() {
        ;;
    }

    public static void clientTick(class_310 minecraft) {
        final class_746 player = minecraft.field_1724;
        if (player == null) {
            return;
        }

        ACTIVE.values().removeIf(class_1101::method_4793);

        for (IBossMusicProvider musicProvider : BossMusicRegistry.getAll()) {
            final class_1297 entity = (class_1297) musicProvider;
            final int id = entity.method_5628();
            if (ACTIVE.containsKey(id)) {
                continue;
            }
            if (!musicProvider.shouldPlayBossMusic(player)) {
                continue;
            }

            class_1101 abstractLoopSound = new AbstractLoopSound(musicProvider, musicProvider.soundSource());

            minecraft.method_1483().method_4873(abstractLoopSound);

            ACTIVE.put(id, abstractLoopSound);
        }

    }

    public static void clear() {
        for (class_1101 sound : ACTIVE.values()) {
            ((AbstractTickableSoundInstanceAccessor) sound).stopAccessor();
        }

        ACTIVE.clear();
    }

}
