package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.event.impl.client.RenderLayerRegistrationEvent;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;

public class RenderLayerRegistrationEventFabric extends RenderLayerRegistrationEvent {

    @Override
    public void setBlockLayer(class_2248 block, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putBlock(block, renderType);
    }

    @Override
    public void setFluidLayer(class_3611 fluid, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putFluid(fluid, renderType);
    }

}