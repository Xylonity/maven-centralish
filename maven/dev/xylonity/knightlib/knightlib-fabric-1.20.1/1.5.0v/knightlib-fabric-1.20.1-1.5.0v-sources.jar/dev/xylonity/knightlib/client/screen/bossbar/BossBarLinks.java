package dev.xylonity.knightlib.client.screen.bossbar;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class BossBarLinks {

    public static final BossBarLinks INSTANCE = new BossBarLinks();
    private final Map<UUID, Reference> byBossId = new Object2ObjectOpenHashMap<>();

    public record Reference(
            int entityId,
            UUID entityUuid,
            class_2960 entityType,
            class_2960 dimension
    ) {

        public @Nullable class_1297 resolve() {
            final class_310 minecraft = class_310.method_1551();

            if (minecraft.field_1687 == null) {
                return null;
            }

            if (!minecraft.field_1687.method_27983().method_29177().equals(dimension)) {
                return null;
            }

            final class_1297 entity = minecraft.field_1687.method_8469(entityId);
            if (entity != null && entity.method_5667().equals(entityUuid)) {
                return entity;
            }

            return null;
        }

    }

    public void put(UUID bossId, Reference reference) {
        byBossId.put(bossId, reference);
    }

    public @Nullable BossBarLinks.Reference get(UUID bossId) {
        return byBossId.get(bossId);
    }

    public void remove(UUID bossId) {
        byBossId.remove(bossId);
    }

    public void clear() {
        byBossId.clear();
    }

}
