package dev.xylonity.knightlib.client.sound.music;

import dev.xylonity.knightlib.api.sound.music.IBossMusicProvider;
import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_746;

public class AbstractLoopSound extends class_1101 {

    private final IBossMusicProvider boss;
    private final int fadeIn, fadeOut;
    private int fadeInCounter, fadeOutCounter;
    private boolean fadingOut;

    public AbstractLoopSound(IBossMusicProvider boss, class_3419 src) {
        super(boss.getBossMusic(), src, class_1113.method_43221());
        this.boss = boss;
        this.field_5446 = true;
        this.field_18936 = true;
        this.field_5442 = 0f;
        this.field_5441 = 1f;
        this.field_5440 = class_1114.field_5478;
        this.fadeIn = boss.getFadeIn();
        this.fadeOut = boss.getFadeOut();
        this.fadeInCounter = fadeIn;
        this.fadeOutCounter = fadeOut;
    }

    @Override
    public boolean method_4785() {
        return true;
    }

    @Override
    public void method_16896() {

        final class_746 player = class_310.method_1551().field_1724;

        if (player == null) {
            return;
        }

        if (!boss.shouldPlayBossMusic(player) && !fadingOut) {
            fadingOut = true;
            fadeOutCounter = fadeOut;
        }

        if (fadingOut) {
            field_5442 = (float) fadeOutCounter / fadeOut;
            if (--fadeOutCounter <= 0) {
                method_24876();
            }

        }
        else if (fadeInCounter > 0) {
            field_5442 = 1f - (float) fadeInCounter-- / fadeIn;
        }
        else {
            field_5442 = 1f;
        }

    }

}
