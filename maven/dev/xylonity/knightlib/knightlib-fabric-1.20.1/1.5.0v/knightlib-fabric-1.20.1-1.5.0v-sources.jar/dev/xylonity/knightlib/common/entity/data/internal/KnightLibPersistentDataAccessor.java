package dev.xylonity.knightlib.common.entity.data.internal;

import net.minecraft.class_2487;

public interface KnightLibPersistentDataAccessor {
    class_2487 knightlib$getPersistentData();
}