package dev.xylonity.knightlib.api.event.impl.server;

import dev.xylonity.knightlib.api.event.KnightLibEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

/**
 * Fired when an entity is hurt
 */
public class LivingHurtEvent extends KnightLibEvent {

    private final class_1309 entity;
    private final class_1282 source;
    private float amount;
    private boolean cancelled;

    public LivingHurtEvent(class_1309 entity, class_1282 source, float amount) {
        this.entity = entity;
        this.source = source;
        this.amount = amount;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_1282 getSource() {
        return source;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

}