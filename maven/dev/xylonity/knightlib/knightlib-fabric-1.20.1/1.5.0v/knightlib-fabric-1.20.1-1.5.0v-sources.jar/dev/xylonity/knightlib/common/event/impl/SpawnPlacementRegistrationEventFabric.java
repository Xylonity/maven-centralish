package dev.xylonity.knightlib.common.event.impl;

import dev.xylonity.knightlib.api.event.impl.server.SpawnPlacementRegistrationEvent;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1317;
import net.minecraft.class_2902;

public class SpawnPlacementRegistrationEventFabric extends SpawnPlacementRegistrationEvent {

    @Override
    public <T extends class_1308> void register(class_1299<T> entityType, class_1317.class_1319 placementType, class_2902.class_2903 heightmapType, class_1317.class_4306<T> predicate) {
        class_1317.method_20637(entityType, placementType, heightmapType, predicate);
    }

}