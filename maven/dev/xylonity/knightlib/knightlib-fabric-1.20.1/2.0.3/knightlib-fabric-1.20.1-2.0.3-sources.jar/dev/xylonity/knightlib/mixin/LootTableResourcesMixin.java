package dev.xylonity.knightlib.mixin;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.xylonity.knightlib.api.loot.EntityLootEntry;
import dev.xylonity.knightlib.api.loot.KnightLibLoot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3503;
import net.minecraft.class_3505;
import net.minecraft.class_39;
import net.minecraft.class_4309;
import net.minecraft.class_55;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8490;

@Mixin(class_4309.class)
public abstract class LootTableResourcesMixin {

    @Inject(method = "scanDirectory", at = @At("RETURN"))
    private static void knightlib$injectEntityDrops(class_3300 resources, String directory, Gson gson, Map<class_2960, JsonElement> elements, CallbackInfo ci) {
        if (directory.equals("loot_tables")) {
            final List<EntityLootEntry> entries = KnightLibLoot.getEntityEntries();
            if (entries.isEmpty()) {
                return;
            }

            final class_3503<class_1299<?>> loader = new class_3503<>(class_7923.field_41177::method_17966, class_3505.method_40099(class_7924.field_41266));
            final Map<class_2960, Collection<class_1299<?>>> tags = loader.method_33176(resources);

            for (int index = 0; index < entries.size(); index++) {
                final EntityLootEntry entry = entries.get(index);
                final Set<class_2960> targets = new HashSet<>();
                for (final class_1299<?> type : tags.getOrDefault(entry.getEntityTag().comp_327(), List.of())) {
                    targets.add(type.method_16351());
                }

                targets.remove(class_39.field_844);

                JsonObject pool = null;
                for (final class_2960 target : targets) {
                    final JsonElement element = elements.get(target);
                    if (element == null || !element.isJsonObject()) {
                        continue;
                    }

                    final JsonObject table = element.getAsJsonObject();
                    if (table.has("pools") && !table.get("pools").isJsonArray()) {
                        // Malformed mainly
                        continue;
                    }

                    if (pool == null) {
                        pool = class_8490.field_44498.method_51203().toJsonTree(KnightLibLoot.buildPool(entry).method_355(), class_55.class).getAsJsonObject();
                        pool.addProperty("name", "knightlib:entity_drop_" + index);
                    }

                    if (!table.has("pools")) {
                        table.add("pools", new JsonArray());
                    }

                    table.getAsJsonArray("pools").add(pool.deepCopy());
                }

            }

        }

    }

}