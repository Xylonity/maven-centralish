package dev.xylonity.knightlib.client.shader;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.event.impl.client.ShaderRegistrationEvent;
import java.io.IOException;
import java.util.Objects;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_5944;

public final class KnightLibShaders {

    private static final class_2960 ENTITY_UNSHADED_EMISSIVE = KnightLib.of("rendertype_entity_unshaded_emissive");

    private static class_5944 entityEmissive;

    public static void register(ShaderRegistrationEvent event) throws IOException {
        event.register(ENTITY_UNSHADED_EMISSIVE, class_290.field_1580, shader -> entityEmissive = shader);
    }

    public static class_5944 getEntityEmissive() {
        return Objects.requireNonNull(entityEmissive, "KnightLib emissive shader has not been loaded properly");
    }

}