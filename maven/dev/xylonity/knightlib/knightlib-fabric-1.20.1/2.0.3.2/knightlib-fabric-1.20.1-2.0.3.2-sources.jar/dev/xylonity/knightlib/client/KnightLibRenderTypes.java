package dev.xylonity.knightlib.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.client.shader.KnightLibShaders;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_757;

public final class KnightLibRenderTypes {

    private static final Function<class_2960, class_1921> ENTITY_EMISSIVE = class_156.method_34866(texture -> createEntityUnshadedEmissive(texture, false));
    private static final Function<class_2960, class_1921> ENTITY_EMISSIVE_DEPTH = class_156.method_34866(texture -> createEntityUnshadedEmissive(texture, true));

    private static class_1921 createEntityUnshadedEmissive(class_2960 texture, boolean writeDepth) {
        final class_1921 emissive = class_1921.method_42600(texture);
        return new class_1921(
                writeDepth ? "knightlib_entity_unshaded_emissive_depth" : "knightlib_entity_unshaded_emissive",
                class_290.field_1580,
                class_293.class_5596.field_27382,
                256,
                true,
                true,
                () -> {
                    emissive.method_23516();
                    RenderSystem.setShader(KnightLibShaders::getEntityEmissive);
                    if (writeDepth) {
                        RenderSystem.depthMask(true);
                    }

                },
                emissive::method_23518
        ) {
            ;;
        };

    }

    public static final class_1921 LINES_SEE_THROUGH = new class_1921(
            "knightlib_editor_lines_see_through",
            class_290.field_29337,
            class_293.class_5596.field_27377,
            1536,
            false,
            false,
            () -> {
                RenderSystem.setShader(class_757::method_34535);
                RenderSystem.enableBlend();
                RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
                RenderSystem.lineWidth(Math.max(2.5f, class_310.method_1551().method_22683().method_4489() / 1920f * 2.5f));
                RenderSystem.disableCull();
                RenderSystem.disableDepthTest();
                RenderSystem.depthMask(false);
            },
            () -> {
                RenderSystem.depthMask(true);
                RenderSystem.enableDepthTest();
                RenderSystem.enableCull();
                RenderSystem.disableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.lineWidth(1f);
            }
    ) {
        ;;
    };

    public static class_1921 entityEmissive(class_2960 texture) {
        return entityEmissive(texture, true);
    }

    public static class_1921 entityEmissive(class_2960 texture, boolean writeDepth) {
        return (writeDepth ? ENTITY_EMISSIVE_DEPTH : ENTITY_EMISSIVE).apply(texture);
    }

}