package dev.xylonity.knightlib.client.animation.layer.impl;

import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.layer.KnightLibTextureLayer;
import dev.xylonity.knightlib.client.KnightLibRenderTypes;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_765;

/**
 * Render layer for a trivial fullbright texture pass over the current animated model.
 * Depth pass must be enabled for opaque layers.
 */
public class KnightLibEmissiveLayer<T> extends KnightLibTextureLayer<T> {

    private final boolean writeDepth;

    public KnightLibEmissiveLayer(Function<T, class_2960> texture) {
        this(texture, true);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, boolean writeDepth) {
        super(texture);
        this.writeDepth = writeDepth;
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, int tint) {
        this(texture, tint, true);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, int tint, boolean writeDepth) {
        super(texture, tint);
        this.writeDepth = writeDepth;
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, ToIntFunction<T> tint) {
        this(texture, tint, true);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, ToIntFunction<T> tint, boolean writeDepth) {
        super(texture, tint);
        this.writeDepth = writeDepth;
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, KnightLibColor tint) {
        this(texture, tint, true);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, KnightLibColor tint, boolean writeDepth) {
        super(texture, tint);
        this.writeDepth = writeDepth;
    }

    @Override
    protected class_1921 getRenderType(KnightLibRenderLayerContext<T> context, class_2960 texture, int resolvedColor) {
        return KnightLibRenderTypes.entityEmissive(texture, writeDepth);
    }

    @Override
    protected int getPackedLight(KnightLibRenderLayerContext<T> context) {
        return class_765.field_32767;
    }

}