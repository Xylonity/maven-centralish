package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import dev.xylonity.knightlib.registry.KnightLibItems;
import java.util.function.Supplier;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3917;
import net.minecraft.class_4970;

public interface KnightLibPlatform {
    <T extends class_2396<?>> Supplier<T> createParticle(boolean overrideLimiter);
    <T extends class_2248> Supplier<T> createBlock(String id, class_4970.class_2251 properties, KnightLibBlocks.BlockType blockType);
    <T extends class_1792> Supplier<T> createItem(String id, class_1792.class_1793 properties, KnightLibItems.ItemType itemType);
    <T extends class_2586> Supplier<class_2591<T>> createBlockEntityType(KnightLibBlockEntities.BlockEntityFactory<T> factory, Supplier<class_2248> block, String id);

    <T extends class_1703> class_3917<T> createMenuFactory(ResourceRegistry.MenuFactory<T> supplier);

    class_1761.class_7913 creativeTabBuilder();
}