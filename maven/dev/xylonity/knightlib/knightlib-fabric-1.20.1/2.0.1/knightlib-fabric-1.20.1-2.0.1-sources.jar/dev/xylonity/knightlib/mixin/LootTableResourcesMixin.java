package dev.xylonity.knightlib.mixin;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import dev.xylonity.knightlib.api.loot.EntityLootTableInjector;
import dev.xylonity.knightlib.api.loot.KnightLibLoot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_4309;

@Mixin(class_4309.class)
public abstract class LootTableResourcesMixin {

    @Inject(method = "scanDirectory", at = @At("RETURN"))
    private static void knightlib$injectEntityDrops(class_3300 resources, String directory, Gson gson,
                                                   Map<class_2960, JsonElement> elements, CallbackInfo ci) {
        if (directory.equals("loot_tables")) {
            EntityLootTableInjector.inject(resources, elements, KnightLibLoot.getEntityEntries());
        }
    }
}
