package dev.xylonity.knightlib.api.loot;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3503;
import net.minecraft.class_3505;
import net.minecraft.class_39;
import net.minecraft.class_55;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8490;

/** Applies registered entity drops before loot tables are deserialized. Internal. */
public final class EntityLootTableInjector {

    private EntityLootTableInjector() {
    }

    public static void inject(class_3300 resources, Map<class_2960, JsonElement> tables,
                              List<EntityLootEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }

        // Registry tags are not bound yet on first load, and still contain the old
        // values during /reload. Resolve this reload's pack stack with the native
        // loader so nested tags, replace, optional entries and loader extensions work.
        class_3503<class_1299<?>> loader = new class_3503<>(class_7923.field_41177::method_17966,
                class_3505.method_40099(class_7924.field_41266));
        Map<class_2960, Collection<class_1299<?>>> tags = loader.method_33176(resources);

        for (int index = 0; index < entries.size(); index++) {
            EntityLootEntry entry = entries.get(index);
            Set<class_2960> targets = new HashSet<>();
            for (class_1299<?> type : tags.getOrDefault(entry.getEntityTag().comp_327(), List.of())) {
                targets.add(type.method_16351());
            }
            targets.remove(class_39.field_844);

            JsonObject pool = null;
            for (class_2960 target : targets) {
                JsonElement element = tables.get(target);
                if (element == null || !element.isJsonObject()) {
                    continue;
                }

                JsonObject table = element.getAsJsonObject();
                if (table.has("pools") && !table.get("pools").isJsonArray()) {
                    // Leave malformed tables to the normal loot parser's diagnostics.
                    continue;
                }

                if (pool == null) {
                    pool = class_8490.field_44498.method_51203().toJsonTree(KnightLibLoot.buildPool(entry).method_355(),
                            class_55.class).getAsJsonObject();
                    pool.addProperty("name", "knightlib:entity_drop_" + index);
                }

                if (!table.has("pools")) {
                    table.add("pools", new JsonArray());
                }
                table.getAsJsonArray("pools").add(pool.deepCopy());
            }
        }
    }
}
