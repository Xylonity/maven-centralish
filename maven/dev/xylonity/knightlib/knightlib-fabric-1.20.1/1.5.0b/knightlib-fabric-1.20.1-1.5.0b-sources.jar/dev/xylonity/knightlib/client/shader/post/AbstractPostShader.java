package dev.xylonity.knightlib.client.shader.post;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.client.shader.post.internal.PostShader;
import dev.xylonity.knightlib.client.shader.post.internal.PostShaderSettings;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

/**
 * Base class for post-processing shaders.
 * Provides a "safe" PostChain execution that restores framebuffer, viewport and the common GL state.
 */
public abstract class AbstractPostShader<PSS extends PostShaderSettings> implements PostShader<PSS> {

    /**
     * Runs a PostChain safely, binding the main render target before and after, restoring the viewport and the common render state
     */
    protected final void process(class_279 chain, float partialTicks, Runnable beforeProcess) {
        final class_310 minecraft = class_310.method_1551();
        final class_276 mainRenderTarget = minecraft.method_1522();

        final Matrix4f oldProjection = RenderSystem.getProjectionMatrix();
        final boolean projectionWasNull = (oldProjection == null);
        if (projectionWasNull) {
            RenderSystem.setProjectionMatrix(new Matrix4f().identity(), class_8251.field_43360);
        }

        final class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        modelViewStack.method_34426();
        RenderSystem.applyModelViewMatrix();

        try {
            // Ensures "minecraft:main" is the current main target
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            if (beforeProcess != null) {
                beforeProcess.run();
            }

            chain.method_1258(partialTicks);
        }
        finally {
            // Restores the matrices
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();
            if (!projectionWasNull) {
                RenderSystem.setProjectionMatrix(oldProjection, class_8251.field_43360);
            }

            // Restores the framebuffer/viewport for the rest of the frame
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            // Restores the common render state
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.resetTextureMatrix();
        }

    }

}