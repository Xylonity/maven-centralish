package dev.xylonity.knightlib.api.entity.hitbox;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import org.joml.Matrix3f;

/**
 * Supplies authoritative world-space bone transforms on the server
 */
@FunctionalInterface
public interface BoneHitboxPoseProvider {

    void updatePose(class_1309 owner, BoneTransformSink transforms);

    @FunctionalInterface
    interface BoneTransformSink {

        /**
         * Updates a bone pivot, world rotation and model scale for the current server tick
         */
        void update(String boneName, class_243 worldPosition, Matrix3f worldRotation, float scaleX, float scaleY, float scaleZ);

        default void update(String boneName, class_243 worldPosition, Matrix3f worldRotation) {
            update(boneName, worldPosition, worldRotation, 1f, 1f, 1f);
        }

    }

}
