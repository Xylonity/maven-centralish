package dev.xylonity.knightlib.common.entity.projectile;

import dev.xylonity.knightlib.common.entity.AbstractProjectile;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public class GreatChaliceStartsetRing extends AbstractProjectile {

    public GreatChaliceStartsetRing(class_1299<? extends AbstractProjectile> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Override
    public void method_5773() {
        double px = method_23317();
        double py = method_23318();
        double pz = method_23321();

        super.method_5773();

        this.method_5814(px, py, pz);
    }

    @Override
    protected int baseLifetime() {
        return 10;
    }

}
