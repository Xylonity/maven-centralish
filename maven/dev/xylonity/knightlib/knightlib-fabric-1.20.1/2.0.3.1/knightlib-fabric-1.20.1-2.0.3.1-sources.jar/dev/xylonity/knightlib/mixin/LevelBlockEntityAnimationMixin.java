package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.animation.internal.BlockEntityAnimationTicker;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Runs every registered blockentity animation handler once per logical level tick
 */
@Mixin(class_1937.class)
public abstract class LevelBlockEntityAnimationMixin {

    @Inject(method = "tickBlockEntities", at = @At("RETURN"))
    private void knightlib$tickBlockEntityAnimations(CallbackInfo ci) {
        BlockEntityAnimationTicker.tick((class_1937) (Object) this);
    }

}
