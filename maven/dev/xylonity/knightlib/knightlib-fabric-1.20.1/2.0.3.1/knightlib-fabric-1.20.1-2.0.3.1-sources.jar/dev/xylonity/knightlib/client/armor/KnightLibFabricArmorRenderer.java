package dev.xylonity.knightlib.client.armor;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.client.armor.KnightLibArmorRenderer;
import dev.xylonity.knightlib.api.item.KnightLibRenderedArmorItem;
import dev.xylonity.knightlib.client.texture.KnightLibAnimatedTextures;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_7923;

public final class KnightLibFabricArmorRenderer implements ArmorRenderer {

    private final class_1792 item;
    private final KnightLibRenderedArmorItem renderedArmorItem;

    private KnightLibArmorRenderer renderer;
    private boolean warnedMissingTexture;

    public KnightLibFabricArmorRenderer(class_1792 item, KnightLibRenderedArmorItem renderedArmorItem) {
        this.item = item;
        this.renderedArmorItem = renderedArmorItem;
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffers, class_1799 stack, class_1309 entity, class_1304 slot, int light, class_572<class_1309> contextModel) {
        final KnightLibArmorRenderer armorRenderer = renderer();
        final class_2960 texture = armorRenderer.getTextureLocation(stack, entity, slot, null);
        if (texture == null) {
            warnMissingTexture();
            return;
        }

        ArmorRenderer.renderPart(
                poseStack, buffers, light, stack,
                armorRenderer.prepareModel(entity, stack, slot, contextModel),
                KnightLibAnimatedTextures.resolve(texture)
        );

    }

    private void warnMissingTexture() {
        if (warnedMissingTexture) {
            return;
        }

        warnedMissingTexture = true;
        KnightLib.LOGGER.warn(
                "Armor renderer for {} returned no texture, so the equipped stack will " + "not be rendered", class_7923.field_41178.method_10221(item)
        );

    }

    private KnightLibArmorRenderer renderer() {
        if (renderer != null) {
            return renderer;
        }

        final Object armorRendererFactory = renderedArmorItem.armorRendererFactory().get();
        if (!(armorRendererFactory instanceof KnightLibArmorRenderer armorRenderer)) {
            final String type = armorRendererFactory == null ? "null" : armorRendererFactory.getClass().getName();
            throw new IllegalStateException("[KnightLib] Armor renderer factory for " + class_7923.field_41178.method_10221(item) + " returned " + type + " instead of a KnightLibArmorRenderer");
        }

        renderer = armorRenderer;
        return renderer;
    }

}