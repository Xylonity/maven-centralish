package dev.xylonity.knightlib.client.projectile.renderer;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.renderer.KnightLibEntityRenderer;
import dev.xylonity.knightlib.common.entity.projectile.GreatChaliceStartsetRing;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import org.jetbrains.annotations.NotNull;

public class GreatChaliceStarsetRingRenderer extends KnightLibEntityRenderer<GreatChaliceStartsetRing> {

    public GreatChaliceStarsetRingRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    protected KnightLibModelSource defineModel(GreatChaliceStartsetRing ring) {
        return KnightLibModelSource.geo(KnightLib.of("geo/great_chalice_starset_ring.geo.json"));
    }

    @Override
    public @NotNull class_2960 getTextureLocation(@NotNull GreatChaliceStartsetRing ring) {
        return KnightLib.of("textures/entity/great_chalice_starset_ring_" + ring.field_6012 % 10 + ".png");
    }

}