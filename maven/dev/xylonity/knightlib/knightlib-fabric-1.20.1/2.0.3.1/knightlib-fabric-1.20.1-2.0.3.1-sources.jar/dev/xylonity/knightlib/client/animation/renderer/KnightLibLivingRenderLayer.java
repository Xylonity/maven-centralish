package dev.xylonity.knightlib.client.animation.renderer;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.model.KnightLibLivingModel;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_922;

/**
 * Render layer for a trivial layer within the vanilla's rendering pipeline
 */
final class KnightLibLivingRenderLayer<T extends class_1309 & KnightLibAnimatable> extends class_3887<T, KnightLibLivingModel<T>> {

    private final KnightLibRenderLayer<T> layer;

    public KnightLibLivingRenderLayer(class_3883<T, KnightLibLivingModel<T>> parent, KnightLibRenderLayer<T> layer) {
        super(parent);
        this.layer = layer;
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffers, int packedLight, T entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        final KnightLibLivingModel<T> parentModel = method_17165();
        final KnightLibModel model = parentModel.activeModel();
        if (model == null) {
            return;
        }

        final int packedOverlay = class_922.method_23622(entity, 0f);
        final double renderTime = entity.method_37908().method_8510() + partialTick;
        final KnightLibRenderLayerContext<T> context = new KnightLibRenderLayerContext<>(
                entity, model, poseStack, buffers, packedLight, packedOverlay,
                parentModel.renderColor().toArgb(), partialTick, renderTime, null, true
        );

        layer.renderIsolated(context);
    }

}