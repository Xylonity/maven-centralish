package dev.xylonity.knightlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_630;
import java.util.List;

@Mixin(class_630.class)
public interface ModelPartAccessor {

    @Accessor("children")
    Map<String, class_630> knightlib$getChildren();

    @Accessor("cubes")
    List<class_630.class_628> knightlib$getCubes();

}
