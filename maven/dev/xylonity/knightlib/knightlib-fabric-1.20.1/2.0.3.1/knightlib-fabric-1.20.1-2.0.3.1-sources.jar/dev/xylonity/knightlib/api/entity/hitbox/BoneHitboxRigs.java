package dev.xylonity.knightlib.api.entity.hitbox;

import dev.xylonity.knightlib.api.entity.hitbox.internal.GeoBoneHitboxRig;
import java.util.Objects;
import net.minecraft.class_2960;

/**
 * Built-in authoritative rig factories
 */
public final class BoneHitboxRigs {

    private BoneHitboxRigs() {
        ;;
    }

    /**
     * Loads geometry and animations from assets packaged in the mod jar
     */
    public static BoneHitboxRig geo(class_2960 geometry, class_2960 animations) {
        return new GeoBoneHitboxRig(Objects.requireNonNull(geometry, "geometry"), Objects.requireNonNull(animations, "animations"));
    }

    public static BoneHitboxRig geo(class_2960 geometry) {
        return new GeoBoneHitboxRig(Objects.requireNonNull(geometry, "geometry"), null);
    }

}
