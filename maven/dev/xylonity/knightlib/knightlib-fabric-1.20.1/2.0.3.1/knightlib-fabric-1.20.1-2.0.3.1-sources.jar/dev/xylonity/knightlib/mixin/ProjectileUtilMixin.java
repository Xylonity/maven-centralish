package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxHolder;
import dev.xylonity.knightlib.api.entity.hitbox.BoneHitboxManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3966;

/**
 * Lets projectiles collide with animated attackable bone hitboxes, as vanilla only raytraces aabbs
 */
@Mixin(class_1675.class)
public abstract class ProjectileUtilMixin {

    @Inject(
            method = "getEntityHitResult(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;F)Lnet/minecraft/world/phys/EntityHitResult;",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void knightlib$clipBoneHitboxes(class_1937 level, class_1297 projectile, class_243 start, class_243 end, class_238 boundingBox, Predicate<class_1297> filter, float inflation, CallbackInfoReturnable<class_3966> cir) {
        final class_3966 vanillaHit = cir.getReturnValue();
        double bestDistanceSqr = vanillaHit == null
                ? Double.POSITIVE_INFINITY
                : vanillaHit.method_17784().method_1025(start);

        class_1297 bestEntity = null;
        class_243 bestLocation = null;
        for (final class_1297 candidate : level.method_8333(projectile, boundingBox.method_1014(2d), filter)) {
            if (!(candidate instanceof BoneHitboxHolder holder)) {
                continue;
            }

            final BoneHitboxManager manager = holder.getBoneHitboxManager();
            if (manager == null || !manager.isActive() || manager.getOwner() != candidate) {
                continue;
            }

            if (level.field_9236) {
                manager.updateClientPose(1f);
            }

            final class_243 hit = manager.clipAttackable(start, end);
            if (hit == null) {
                continue;
            }

            final double distanceSqr = hit.method_1025(start);
            if (distanceSqr < bestDistanceSqr) {
                bestDistanceSqr = distanceSqr;
                bestEntity = candidate;
                bestLocation = hit;
            }

        }

        if (bestEntity != null) {
            cir.setReturnValue(new class_3966(bestEntity, bestLocation));
        }

    }

}