package dev.xylonity.knightlib.common.item.blockitem;

import dev.xylonity.knightlib.api.animation.KnightLibItemAnimations;
import dev.xylonity.knightlib.api.item.KnightLibRenderedItem;
import dev.xylonity.knightlib.client.item.GenericRenderedBlockItemRenderer;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

/**
 * Generic block item rendered with KnightLib's item renderer.
 *
 * The renderer resolves {@code geo/<path>.geo.json} and {@code textures/block/<path>.png} in the namespace supplied by {@code rendererId}.
 */
public class GenericRenderedBlockItem extends class_1747 implements KnightLibRenderedItem {

    private final class_2960 rendererId;

    public GenericRenderedBlockItem(class_2248 block, class_1793 properties, class_2960 rendererId) {
        super(block, properties);
        this.rendererId = Objects.requireNonNull(rendererId, "rendererId");
    }

    public class_2960 rendererId() {
        return rendererId;
    }

    /**
     * Stub that matches forge's optional item hook
     */
    public boolean shouldCauseReequipAnimation(class_1799 oldStack, class_1799 newStack, boolean slotChanged) {
        return KnightLibItemAnimations.shouldCauseReequipAnimation(oldStack, newStack);
    }

    /**
     * Client-only factory used by the loader adapters when this item first needs to be rendered.
     *
     * When using this, create a synthetic method (() -> ()), don't call the lambda directly, so
     * no client-sided classes are loaded on the server.
     */
    @Override
    public Supplier<Object> rendererFactory() {
        return () -> new GenericRenderedBlockItemRenderer(rendererId);
    }

}
