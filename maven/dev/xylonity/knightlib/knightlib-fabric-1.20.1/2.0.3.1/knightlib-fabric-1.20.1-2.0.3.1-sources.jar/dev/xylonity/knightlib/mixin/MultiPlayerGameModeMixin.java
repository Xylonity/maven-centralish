package dev.xylonity.knightlib.mixin;

import dev.xylonity.knightlib.client.entity.layer.BoneHitboxPicker;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {

    @Shadow
    protected abstract void ensureHasSentCarriedItem();

    /**
     * Replaces the vanilla attack packet with a bone aware one
     */
    @Inject(
            method = "attack",
            at = @At("HEAD"),
            cancellable = true
    )
    private void knightlib$attackBoneHitbox(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (!BoneHitboxPicker.hasSelection(target)) {
            return;
        }

        // Must precede the attack packet
        ensureHasSentCarriedItem();
        BoneHitboxPicker.attack(target);

        if (!player.method_7325()) {
            player.method_7324(target);
            // Forge already resets it inside Player#attack but Fabric does not (thanks again fabric)
            player.method_7350();
        }

        ci.cancel();
    }

}