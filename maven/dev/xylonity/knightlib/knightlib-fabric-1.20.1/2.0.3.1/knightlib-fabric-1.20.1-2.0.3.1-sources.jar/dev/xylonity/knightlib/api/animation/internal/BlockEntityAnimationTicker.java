package dev.xylonity.knightlib.api.animation.internal;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2586;

/**
 * Internal registry used to tick animatable blockentities independently of vanilla block tickers
 */
public final class BlockEntityAnimationTicker {

    private static final Map<class_1937, Set<class_2586>> BY_LEVEL = new WeakHashMap<>();

    private BlockEntityAnimationTicker() {
        ;;
    }

    public static void register(class_2586 blockEntity) {
        if (!(blockEntity instanceof KnightLibAnimatable) || blockEntity.method_10997() == null || blockEntity.method_11015()) {
            return;
        }

        synchronized (BY_LEVEL) {
            removeFromAll(blockEntity);
            BY_LEVEL.computeIfAbsent(blockEntity.method_10997(), ignored -> Collections.newSetFromMap(new WeakHashMap<>()))
                    .add(blockEntity);
        }

    }

    public static void unregister(class_2586 blockEntity) {
        synchronized (BY_LEVEL) {
            removeFromAll(blockEntity);
        }

    }

    public static void tick(class_1937 level) {
        final List<class_2586> snapshot;
        synchronized (BY_LEVEL) {
            final Set<class_2586> blockEntities = BY_LEVEL.get(level);
            if (blockEntities == null || blockEntities.isEmpty()) {
                return;
            }

            blockEntities.removeIf(blockEntity -> blockEntity == null || blockEntity.method_11015() || blockEntity.method_10997() != level);
            snapshot = new ArrayList<>(blockEntities);
        }

        for (final class_2586 blockEntity : snapshot) {
            if (blockEntity instanceof KnightLibAnimatable animatable) {
                animatable.tickAnimations();
            }

        }

    }

    public static void clear(class_1937 level) {
        synchronized (BY_LEVEL) {
            BY_LEVEL.remove(level);
        }

    }

    private static void removeFromAll(class_2586 target) {
        BY_LEVEL.values().removeIf(blockEntities -> {
            blockEntities.remove(target);
            return blockEntities.isEmpty();
        });

    }

}
