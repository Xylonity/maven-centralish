package dev.xylonity.knightlib.api.item;

import dev.xylonity.knightlib.api.animation.KnightLibAnim;
import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.api.animation.KnightLibAnimationHandler;
import dev.xylonity.knightlib.api.animation.KnightLibItemAnimationControllerRegistrar;
import dev.xylonity.knightlib.api.animation.KnightLibItemAnimations;
import dev.xylonity.knightlib.api.animation.KnightLibKeyframeEvent;
import dev.xylonity.knightlib.api.util.KnightLibEasings;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;

/**
 * Common per-stack animation API shared by ordinary custom-rendered items and equipped armor.
 *
 * <p>An {@code Item} is a singleton, so every method receives the particular stack whose
 * controllers are being queried or changed.</p>
 */
public interface KnightLibAnimatedItem {

    /**
     * Declares animation selection rules evaluated locally once per client tick
     */
    default void registerAnimationControllers(KnightLibItemAnimationControllerRegistrar controllers) {
        ;;
    }

    /**
     * Returns this stack's animation handler
     */
    default KnightLibAnimationHandler getAnimationHandler(class_1799 stack, @Nullable class_1937 level) {
        return KnightLibItemAnimations.getAnimationHandler(this, stack, level);
    }

    /**
     * Plays a pre-declared animation command on this stack
     */
    default void playAnimation(class_1799 stack, @Nullable class_1937 level, KnightLibAnim anim) {
        getAnimationHandler(stack, level).play(anim);
    }

    /**
     * Plays an animation once on the main controller with the default transition
     */
    default void playAnimation(class_1799 stack, @Nullable class_1937 level, String animation) {
        playAnimation(stack, level, KnightLibAnimationHandler.MAIN_CONTROLLER, animation,
                KnightLibAnimatable.DEFAULT_TRANSITION_TICKS,
                KnightLibAnimatable.DEFAULT_TRANSITION_EASING, 1f);
    }

    default void playAnimation(class_1799 stack, @Nullable class_1937 level, String animation, int transitionTicks) {
        playAnimation(stack, level, KnightLibAnimationHandler.MAIN_CONTROLLER, animation, transitionTicks, KnightLibAnimatable.DEFAULT_TRANSITION_EASING, 1f);
    }

    default void playAnimation(class_1799 stack, @Nullable class_1937 level, String controller, String animation, int transitionTicks, KnightLibEasings transitionEasing) {
        playAnimation(stack, level, controller, animation, transitionTicks, transitionEasing, 1f);
    }

    /**
     * Plays an animation on the named controller for this particular stack
     */
    default void playAnimation(class_1799 stack, @Nullable class_1937 level, String controller, String animation, int transitionTicks, KnightLibEasings transitionEasing, float speed) {
        getAnimationHandler(stack, level).play(controller, animation, transitionTicks, transitionEasing, speed);
    }

    default void stopAnimation(class_1799 stack, @Nullable class_1937 level) {
        stopAnimation(stack, level, KnightLibAnimationHandler.MAIN_CONTROLLER, KnightLibAnimatable.DEFAULT_TRANSITION_TICKS);
    }

    /**
     * Stops a named controller and blends it back to the rest pose
     */
    default void stopAnimation(class_1799 stack, @Nullable class_1937 level, String controller, int transitionTicks) {
        getAnimationHandler(stack, level).stop(controller, transitionTicks);
    }

    default @Nullable String getActiveAnimation(class_1799 stack, @Nullable class_1937 level, String controller) {
        return getAnimationHandler(stack, level).getActiveAnimation(controller);
    }

    default boolean isAnimationActive(class_1799 stack, @Nullable class_1937 level, String animation) {
        return getAnimationHandler(stack, level).isAnimationActive(animation);
    }

    /**
     * Internal for animation ticking
     */
    default void tickAnimations(class_1799 stack, @Nullable class_1937 level) {
        getAnimationHandler(stack, level).tick();
    }

    /**
     * Called on the client when a keyframe is crossed
     */
    default void onAnimationKeyframe(class_1799 stack, KnightLibKeyframeEvent event) {
        ;;
    }

    /**
     * Called on the client when an animation step ends
     */
    default void onAnimationFinished(class_1799 stack, String controller, String animation) {
        ;;
    }

}