package dev.xylonity.knightlib.client.animation.layer.impl;

import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.layer.KnightLibTextureLayer;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

/**
 * Render layer for a trivial texture pass over the current animated model
 */
public class KnightLibOverlayLayer<T> extends KnightLibTextureLayer<T> {

    public KnightLibOverlayLayer(Function<T, class_2960> texture) {
        super(texture);
    }

    public KnightLibOverlayLayer(Function<T, class_2960> texture, int tint) {
        super(texture, tint);
    }

    public KnightLibOverlayLayer(Function<T, class_2960> texture, ToIntFunction<T> tint) {
        super(texture, tint);
    }

    public KnightLibOverlayLayer(Function<T, class_2960> texture, KnightLibColor tint) {
        super(texture, tint);
    }

    @Override
    protected class_1921 getRenderType(KnightLibRenderLayerContext<T> context, class_2960 texture, int resolvedColor) {
        return KnightLibColor.fromArgb(resolvedColor).isTranslucent()
                ? class_1921.method_23580(texture)
                : class_1921.method_23578(texture);
    }

}