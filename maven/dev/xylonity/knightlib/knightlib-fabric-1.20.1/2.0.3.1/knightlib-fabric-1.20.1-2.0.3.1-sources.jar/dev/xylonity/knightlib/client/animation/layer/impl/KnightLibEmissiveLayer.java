package dev.xylonity.knightlib.client.animation.layer.impl;

import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.layer.KnightLibTextureLayer;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_765;

/**
 * Render layer for a trivial fullbright texture pass over the current animated model
 */
public class KnightLibEmissiveLayer<T> extends KnightLibTextureLayer<T> {

    public KnightLibEmissiveLayer(Function<T, class_2960> texture) {
        super(texture);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, int tint) {
        super(texture, tint);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, ToIntFunction<T> tint) {
        super(texture, tint);
    }

    public KnightLibEmissiveLayer(Function<T, class_2960> texture, KnightLibColor tint) {
        super(texture, tint);
    }

    @Override
    protected class_1921 getRenderType(KnightLibRenderLayerContext<T> context, class_2960 texture, int resolvedColor) {
        return class_1921.method_42600(texture);
    }

    @Override
    protected int getPackedLight(KnightLibRenderLayerContext<T> context) {
        return class_765.field_32767;
    }

}