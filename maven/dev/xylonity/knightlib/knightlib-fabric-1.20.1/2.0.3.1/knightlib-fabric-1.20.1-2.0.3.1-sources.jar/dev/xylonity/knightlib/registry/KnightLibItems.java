package dev.xylonity.knightlib.registry;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.common.item.*;
import net.minecraft.class_1792;
import net.minecraft.class_7923;
import dev.xylonity.knightlib.api.registrar.ResourceDispatcher;
import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.api.registrar.ResourceEntry;

public class KnightLibItems {

    public static final ResourceRegistry<class_1792> ITEMS = ResourceDispatcher.create(class_7923.field_41178, KnightLib.MOD_ID);

    public static final ResourceEntry<class_1792> SMALL_ESSENCE = ITEMS.register("small_essence", () -> new SmallEssenceItem(new class_1792.class_1793()));
    public static final ResourceEntry<class_1792> GREAT_ESSENCE = ITEMS.register("great_essence", () -> new GreatEssenceItem(new class_1792.class_1793()));
    public static final ResourceEntry<class_1792> EMPTY_GRAIL = ITEMS.register("empty_grail", () -> new EmptyGrailItem(new class_1792.class_1793()));
    public static final ResourceEntry<class_1792> FILLED_GRAIL = ITEMS.register("filled_grail", () -> new FilledGrailItem(new class_1792.class_1793()));
    public static final ResourceEntry<class_1792> HOMUNCULUS = ITEMS.register("homunculus", () -> new HomunculusItem(new class_1792.class_1793()));

}