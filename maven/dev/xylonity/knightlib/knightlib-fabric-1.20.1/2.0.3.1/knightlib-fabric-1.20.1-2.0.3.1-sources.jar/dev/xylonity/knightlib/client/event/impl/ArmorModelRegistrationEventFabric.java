package dev.xylonity.knightlib.client.event.impl;

import dev.xylonity.knightlib.api.client.armor.KnightLibArmorModel;
import dev.xylonity.knightlib.api.event.impl.client.ArmorModelRegistrationEvent;
import dev.xylonity.knightlib.client.armor.KnightLibArmorModels;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_630;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ArmorModelRegistrationEventFabric extends ArmorModelRegistrationEvent {

    @Override
    public void register(class_2960 modelId, class_5601 layer, Supplier<class_5607> layerDefinition, Function<class_630, KnightLibArmorModel> modelFactory, class_2960 texture) {
        KnightLibArmorModels.register(modelId, layer, modelFactory, texture);
        EntityModelLayerRegistry.registerModelLayer(layer, layerDefinition::get);
    }

}
