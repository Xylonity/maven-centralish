package dev.xylonity.knightlib.client.animation.renderer;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.KnightLibAnimationSource;
import dev.xylonity.knightlib.client.animation.KnightLibAnimator;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibEmissiveLayer;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibOverlayLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.client.texture.KnightLibAnimatedTextures;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.minecraft.class_922;

/**
 * Base renderer for entities animated through KnightLib
 */
public abstract class KnightLibEntityRenderer<T extends class_1297 & KnightLibAnimatable> extends class_897<T> {

    private final List<KnightLibRenderLayer<T>> layers = new ArrayList<>();
    private final KnightLibModelSource.InstanceCache modelCache = new KnightLibModelSource.InstanceCache();

    protected KnightLibEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    /**
     * Geometry file or method reference
     */
    protected abstract KnightLibModelSource defineModel(T entity);

    /**
     * Animation file or method reference
     */
    protected KnightLibAnimationSource defineAnimations(T entity) {
        return KnightLibAnimationSource.none();
    }

    /**
     * Packed ARGB multiplier, evaluated once immediately before the entity is drawn
     */
    protected int getRenderColor(T entity, float partialTicks, int packedLight) {
        return KnightLibColor.WHITE_ARGB;
    }

    /**
     * Calculates scale and ARGB together once for the complete render pass
     */
    protected KnightLibRenderState getRenderState(T entity, float partialTicks, int packedLight) {
        return KnightLibRenderState.of(getScale(entity), getRenderColor(entity, partialTicks, packedLight));
    }

    /**
     * Render type of the base texture pass
     */
    protected class_1921 getRenderType(T entity, class_2960 texture) {
        return class_1921.method_23578(texture);
    }

    protected class_1921 getRenderType(T entity, class_2960 texture, int renderColor) {
        return KnightLibColor.fromArgb(renderColor).isTranslucent()
                ? class_1921.method_23580(texture)
                : getRenderType(entity, texture);
    }

    protected float getScale(T entity) {
        return 1f;
    }

    /**
     * Extra culling margin in blocks
     */
    protected double getCullingInflation(T entity) {
        return 0.5;
    }

    protected final void addEmissiveLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture));
    }

    protected final void addOverlayLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibOverlayLayer<>(texture));
    }

    /**
     * Adds an arbitrary render layer
     */
    protected final void addRenderLayer(KnightLibRenderLayer<T> layer) {
        layers.add(Objects.requireNonNull(layer, "layer"));
    }

    /**
     * Called every frame after animations are applied and before rendering
     */
    protected void setupPose(T entity, KnightLibModel model, float partialTicks) {
        ;;
    }

    /**
     * Called for every bone after animation/pose evaluation and before rendering
     */
    protected void setupBone(T entity, KnightLibModel model, String boneName, float partialTicks) {
        ;;
    }

    @Override
    public void method_3936(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffers, int packedLight) {
        final KnightLibModel model = modelCache.resolve(defineModel(entity));
        final KnightLibAnimationSource animations = defineAnimations(entity);

        final double now = entity.method_37908().method_8510() + partialTicks;
        KnightLibAnimator.animate(entity.getAnimationHandler(), model, animations::get, now);

        setupPose(entity, model, partialTicks);
        model.forEachBone(boneName -> setupBone(entity, model, boneName, partialTicks));

        KnightLibRenderState renderState = getRenderState(entity, partialTicks, packedLight);
        if (renderState == null) {
            renderState = KnightLibRenderState.DEFAULT;
        }

        final float bodyYaw = entity instanceof class_1309 living
                ? class_3532.method_17821(partialTicks, living.field_6220, living.field_6283)
                : class_3532.method_17821(partialTicks, entity.field_5982, entity.method_36454());

        poseStack.method_22903();
        float scale = renderState.scale();
        if (scale != 1f) {
            poseStack.method_22905(scale, scale, scale);
        }

        model.setupRootTransform(poseStack, bodyYaw, true);

        final int packedOverlay = entity instanceof class_1309 living
                ? class_922.method_23622(living, 0f)
                : class_4608.field_21444;

        final class_2960 baseTexture = method_3931(entity);
        actuallyRender(entity, model, baseTexture, partialTicks, poseStack, buffers, packedLight, packedOverlay, renderState.renderColor());

        poseStack.method_22909();

        super.method_3936(entity, entityYaw, partialTicks, poseStack, buffers, packedLight);
    }

    /**
     * Render hook that's derived from the main render call that can alter the actual packed ARGB
     */
    protected void actuallyRender(T entity, KnightLibModel model, class_2960 baseTexture, float partialTicks, class_4587 poseStack, class_4597 buffers, int packedLight, int packedOverlay, int renderColor) {
        final KnightLibColor color = KnightLibColor.fromArgb(renderColor);
        final class_2960 renderTexture = KnightLibAnimatedTextures.resolve(baseTexture);
        model.render(poseStack, buffers.getBuffer(getRenderType(entity, renderTexture, renderColor)), packedLight, packedOverlay, color.red(), color.green(), color.blue(), color.alpha());

        final double renderTime = entity.method_37908().method_8510() + partialTicks;
        final KnightLibRenderLayerContext<T> context = new KnightLibRenderLayerContext<>(
                entity, model, poseStack, buffers, packedLight, packedOverlay, renderColor,
                partialTicks, renderTime, null, false
        );
        for (final KnightLibRenderLayer<T> layer : layers) {
            layer.renderIsolated(context);
        }

    }

    @Override
    public boolean method_3933(T entity, class_4604 frustum, double cameraX, double cameraY, double cameraZ) {
        if (super.method_3933(entity, frustum, cameraX, cameraY, cameraZ)) {
            return true;
        }

        final double inflation = Math.max(0.0, getCullingInflation(entity));
        final class_238 box = entity.method_5830().method_1014(inflation);
        return !box.method_1013() && frustum.method_23093(box);
    }

}