package dev.xylonity.knightlib.common.item.blockitem;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class GreatChaliceBlockItem extends GenericRenderedBlockItem {

    public GreatChaliceBlockItem(class_2248 block, class_1793 properties, class_2960 rendererId) {
        super(block, properties, rendererId);
    }

    @Override
    public void method_7851(@NotNull class_1799 itemStack, @Nullable class_1937 level, @NotNull List<class_2561> lines, @NotNull class_1836 flag) {
        super.method_7851(itemStack, level, lines, flag);
        lines.add(class_2561.method_43471("tooltip.item.knightlib.great_chalice"));
    }

}