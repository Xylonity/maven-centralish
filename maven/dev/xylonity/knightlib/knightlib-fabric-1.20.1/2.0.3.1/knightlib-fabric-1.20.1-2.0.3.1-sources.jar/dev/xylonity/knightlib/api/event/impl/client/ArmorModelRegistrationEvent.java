package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.client.armor.KnightLibArmorModel;
import dev.xylonity.knightlib.api.event.KnightLibEvent;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_630;

/**
 * Registers a vanilla armor model for every armor item created with the same model id
 */
public abstract class ArmorModelRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public abstract void register(class_2960 modelId, class_5601 layer, Supplier<class_5607> layerDefinition, Function<class_630, KnightLibArmorModel> modelFactory, class_2960 texture);

}