package dev.xylonity.knightlib.api.client.armor;

import dev.xylonity.knightlib.client.animation.KnightLibAnimationAssets;
import dev.xylonity.knightlib.client.animation.model.GeoModel;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5602;
import net.minecraft.class_630;

/**
 * Equipped-armor renderer backed by a geo model
 */
public abstract class KnightLibGeoArmorRenderer extends KnightLibArmorRenderer {

    protected abstract class_2960 getGeoModelLocation();

    protected @Nullable String getHeadBone() {
        return "armorHead";
    }

    protected @Nullable String getBodyBone() {
        return "armorBody";
    }

    protected @Nullable String getLeggingsBodyBone() {
        return "armorLeggingsBody";
    }

    protected @Nullable String getRightArmBone() {
        return "armorRightArm";
    }

    protected @Nullable String getLeftArmBone() {
        return "armorLeftArm";
    }

    protected @Nullable String getRightLegBone() {
        return "armorRightLeg";
    }

    protected @Nullable String getLeftLegBone() {
        return "armorLeftLeg";
    }

    protected @Nullable String getRightBootBone() {
        return "armorRightBoot";
    }

    protected @Nullable String getLeftBootBone() {
        return "armorLeftBoot";
    }

    @Override
    protected final KnightLibArmorModel createModel() {
        final class_2960 location = Objects.requireNonNull(getGeoModelLocation(), "geo model location");
        final GeoModel geoModel = new GeoModel(KnightLibAnimationAssets.getModel(location));
        final class_630 humanoidRoot = class_310.method_1551().method_31974().method_32072(class_5602.field_27579);
        return new KnightLibGeoArmorModel(humanoidRoot, geoModel,
                new KnightLibGeoArmorModel.BoneNames(
                        getHeadBone(), getBodyBone(), getLeggingsBodyBone(),
                        getRightArmBone(), getLeftArmBone(),
                        getRightLegBone(), getLeftLegBone(),
                        getRightBootBone(), getLeftBootBone()
                )

        );

    }

    @Override
    protected final int modelGeneration() {
        return KnightLibAnimationAssets.generation();
    }

}