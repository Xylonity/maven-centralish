package dev.xylonity.knightlib.api.entity.hitbox;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.ToDoubleFunction;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/**
 * Manages all bone-attached hitboxes for a single entity.
 * {@link BoneHitboxHolder}
 */
public class BoneHitboxManager {

    /// Server ticks of bone pose history
    private static final int REWIND_TICKS = 5;

    private static final double ATTACK_TOLERANCE = 0.25d;
    private static final int MAX_SWEEP_SAMPLES = 4;
    private static final double MAX_SWEEP_DISTANCE = 10d;

    private final class_1309 owner;
    private final Map<String, BoneHitbox> hitboxes = new LinkedHashMap<>();
    private final Map<String, Long> lastTransformTicks = new HashMap<>();
    private final Map<String, Integer> timedDisables = new HashMap<>();
    private final ArrayDeque<PoseSnapshot> history = new ArrayDeque<>();
    private boolean active = true;
    private int transformTimeoutTicks;

    private @Nullable BiConsumer<BoneHitbox, class_1297> hitCallback;
    private @Nullable BoneHitboxPoseProvider poseProvider;
    private @Nullable BoneHitboxRig rig;
    private ToDoubleFunction<class_1309> modelScale = ignored -> 1d;

    public BoneHitboxManager(class_1309 owner) {
        this.owner = Objects.requireNonNull(owner, "owner");
    }

    /**
     * Registers a bone hitbox (the bone name must be unique within this manager)
     */
    public BoneHitboxManager add(BoneHitbox hitbox) {
        Objects.requireNonNull(hitbox, "hitbox");
        if (hitboxes.putIfAbsent(hitbox.getBoneName(), hitbox) != null) {
            throw new IllegalArgumentException("[KnightLib] Duplicate bone hitbox '" + hitbox.getBoneName() + "'");
        }

        resolveAutoSize(hitbox);

        return this;
    }

    /**
     * Retrieves a hitbox by bone name
     */
    public @Nullable BoneHitbox get(String boneName) {
        return hitboxes.get(boneName);
    }

    /**
     * Returns all registered hitboxes
     */
    public Collection<BoneHitbox> getAll() {
        return Collections.unmodifiableCollection(hitboxes.values());
    }

    /**
     * Sets whether the entire hitbox system is active. When inactive, no collision checks run.
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isActive() {
        return active;
    }

    /**
     * Sets the manager fallback that fires when a hitbox without its own contact behavior collides with an entity.
     *
     * <pre>{@code
     * manager.onHit((hitbox, target) -> {
     *     if (target instanceof LivingEntity living) {
     *         final float damage = hitbox.getBoneName().equals("axe_tip") ? 15 : 8;
     *         living.hurt(damageSources().mobAttack(this), damage);
     *     }
     *
     * });
     * }</pre>
     */
    public BoneHitboxManager onHit(BiConsumer<BoneHitbox, class_1297> callback) {
        this.hitCallback = callback;
        return this;
    }

    /**
     * Updates a world-space bone transform (call this through server tick or use a custom provider)
     */
    public void updateBoneTransform(String boneName, class_243 worldPos, Matrix3f worldRotation) {
        updateBoneTransform(boneName, worldPos, worldRotation, 1f, 1f, 1f);
    }

    /**
     * Transform update including animated bone scale
     */
    public void updateBoneTransform(String boneName, class_243 worldPos, Matrix3f worldRotation, float scaleX, float scaleY, float scaleZ) {
        final BoneHitbox hitbox = hitboxes.get(boneName);
        if (hitbox != null) {
            validateTransform(worldPos, worldRotation, scaleX, scaleY, scaleZ);
            hitbox.applyScale(scaleX, scaleY, scaleZ);
            if (hitbox.updateFromBoneTransform(worldPos, normalizedRotation(worldRotation), scaleX, scaleY, scaleZ)) {
                lastTransformTicks.put(boneName, owner.method_37908().method_8510());
            }

        }

    }

    /**
     * Client mirror of the server pose
     */
    public void updateClientPose(float partialTick) {
        if (!owner.method_37908().field_9236 || rig == null || !active) {
            return;
        }

        for (final BoneHitbox hitbox : hitboxes.values()) {
            resolveAutoSize(hitbox);
        }

        final double scale = modelScale.applyAsDouble(owner);
        if (!Double.isFinite(scale) || scale <= 0d || scale > Float.MAX_VALUE) {
            return;
        }

        final float clampedPartial = Math.max(0f, Math.min(1f, partialTick));
        final class_243 position = new class_243(
                class_3532.method_16436(clampedPartial, owner.field_6014, owner.method_23317()),
                class_3532.method_16436(clampedPartial, owner.field_6036, owner.method_23318()),
                class_3532.method_16436(clampedPartial, owner.field_5969, owner.method_23321())
        );
        final float bodyYaw = class_3532.method_17821(clampedPartial, owner.field_6220, owner.field_6283);

        rig.updatePose(owner, getTrackedBoneNames(), (float) scale, this::updateBoneTransform, position, bodyYaw, owner.method_37908().method_8510() + clampedPartial);
    }

    /**
     * Installs a custom pose provider
     */
    public BoneHitboxManager poseProvider(BoneHitboxPoseProvider provider) {
        this.poseProvider = Objects.requireNonNull(provider, "provider");
        return this;
    }

    public void clearPoseProvider() {
        this.poseProvider = null;
    }

    public BoneHitboxManager rig(BoneHitboxRig rig) {
        this.rig = Objects.requireNonNull(rig, "rig");
        for (final BoneHitbox hitbox : hitboxes.values()) {
            hitbox.clearAutoSize();
            resolveAutoSize(hitbox);
        }

        return this;
    }

    public BoneHitboxManager geo(class_2960 geometry, class_2960 animations) {
        return rig(BoneHitboxRigs.geo(geometry, animations));
    }

    public BoneHitboxManager geo(class_2960 geometry) {
        return rig(BoneHitboxRigs.geo(geometry));
    }

    public void clearRig() {
        this.rig = null;
        hitboxes.values().forEach(BoneHitbox::clearAutoSize);
    }

    public BoneHitboxManager modelScale(double scale) {
        if (!Double.isFinite(scale) || scale <= 0d) {
            throw new IllegalArgumentException("modelScale must be finite and positive");
        }

        this.modelScale = ignored -> scale;

        return this;
    }

    public BoneHitboxManager modelScale(ToDoubleFunction<class_1309> scale) {
        this.modelScale = Objects.requireNonNull(scale, "scale");
        return this;
    }

    public void tick() {
        if (!active || owner.method_37908().field_9236) {
            return;
        }

        tickTimedEnables();

        if (rig != null) {
            for (final BoneHitbox hitbox : hitboxes.values()) {
                resolveAutoSize(hitbox);
            }

            final double scale = modelScale.applyAsDouble(owner);
            if (!Double.isFinite(scale) || scale <= 0d || scale > Float.MAX_VALUE) {
                throw new IllegalStateException("[KnightLib] BoneHitbox modelScale must be finite and positive");
            }

            rig.updatePose(owner, getTrackedBoneNames(), (float) scale, this::updateBoneTransform);
        }

        if (poseProvider != null) {
            poseProvider.updatePose(owner, this::updateBoneTransform);
        }

        recordSnapshot();

        for (final BoneHitbox hitbox : hitboxes.values()) {
            if (!hitbox.reactsOnContact() && hitCallback == null) {
                continue;
            }

            hitbox.tickCooldowns();

            if (!isHitboxActive(hitbox)) {
                continue;
            }

            if (!hasFreshTransform(hitbox.getBoneName())) {
                continue;
            }

            final OBB obb = hitbox.getCurrentOBB();
            if (obb == null) {
                continue;
            }

            // Sweeping between the previous and current tick pose keeps fast bones from tunneling through targets
            final List<OBB> sweep = buildSweepSamples(hitbox.getPreviousOBB(), obb);
            class_238 broadPhase = null;
            for (final OBB sample : sweep) {
                final class_238 sampleBounds = sample.enclosingAABB();
                broadPhase = broadPhase == null ? sampleBounds : broadPhase.method_991(sampleBounds);
            }

            final List<class_1297> entities = owner.method_37908().method_8333(owner, broadPhase, hitbox.getFilter());
            for (final class_1297 entity : entities) {
                if (entity == owner) {
                    continue;
                }
                if (hitbox.isOnCooldown(entity)) {
                    continue;
                }

                for (final OBB sample : sweep) {
                    if (sample.intersects(entity.method_5829())) {
                        hitbox.applyCooldown(entity);

                        if (hitbox.reactsOnContact()) {
                            hitbox.handleContact(owner, entity);
                        }
                        else if (hitCallback != null) {
                            hitCallback.accept(hitbox, entity);
                        }

                        break;
                    }

                }

            }

        }

        for (final BoneHitbox hitbox : hitboxes.values()) {
            hitbox.capturePreviousOBB();
        }

    }

    private boolean isHitboxActive(BoneHitbox hitbox) {
        if (!hitbox.isEnabled() || !hitbox.testCondition()) {
            return false;
        }

        final List<BoneHitbox.ActivationWindow> windows = hitbox.getActivationWindows();
        if (windows.isEmpty()) {
            return true;
        }
        if (rig == null) {
            return false;
        }

        for (final BoneHitbox.ActivationWindow window : windows) {
            if (rig.isAnimationWithin(window.animation(), window.startTick(), window.endTick())) {
                return true;
            }

        }

        return false;
    }

    private void tickTimedEnables() {
        if (timedDisables.isEmpty()) {
            return;
        }

        timedDisables.entrySet().removeIf(entry -> {
            final int remaining = entry.getValue() - 1;
            if (remaining <= 0) {
                final BoneHitbox hitbox = hitboxes.get(entry.getKey());
                if (hitbox != null) {
                    hitbox.setEnabled(false);
                }

                return true;
            }

            entry.setValue(remaining);

            return false;
        });

    }

    private boolean hasFreshTransform(String boneName) {
        final Long lastUpdate = lastTransformTicks.get(boneName);
        return lastUpdate != null && owner.method_37908().method_8510() - lastUpdate <= transformTimeoutTicks;
    }

    private void recordSnapshot() {
        final Map<String, OBB> attackable = new HashMap<>();
        for (final BoneHitbox hitbox : hitboxes.values()) {
            final OBB obb = hitbox.getCurrentOBB();
            if (obb != null && isHitboxActive(hitbox) && hitbox.reactsWhenAttacked() && hasFreshTransform(hitbox.getBoneName())) {
                attackable.put(hitbox.getBoneName(), obb);
            }

        }

        history.addFirst(new PoseSnapshot(owner.method_37908().method_8510(), Map.copyOf(attackable)));
        while (history.size() > REWIND_TICKS) {
            history.removeLast();
        }

    }

    private static List<OBB> buildSweepSamples(@Nullable OBB previous, OBB current) {
        if (previous == null) {
            return List.of(current);
        }

        final double displacement = current.getCenter().method_1022(previous.getCenter());
        final class_243 halfExtents = current.getHalfExtents();
        final double minHalf = Math.max(0.05d, Math.min(halfExtents.field_1352, Math.min(halfExtents.field_1351, halfExtents.field_1350)));
        if (displacement <= minHalf || displacement > MAX_SWEEP_DISTANCE) {
            return List.of(current);
        }

        final int steps = (int) Math.min(MAX_SWEEP_SAMPLES, Math.ceil(displacement / minHalf));
        final List<OBB> samples = new ArrayList<>(steps);
        final Quaternionf from = new Quaternionf().setFromNormalized(previous.toMatrix());
        final Quaternionf to = new Quaternionf().setFromNormalized(current.toMatrix());
        for (int i = 1; i < steps; i++) {
            final float t = (float) i / steps;
            final class_243 center = previous.getCenter().method_35590(current.getCenter(), t);
            final Matrix3f rotation = new Quaternionf(from).slerp(to, t).get(new Matrix3f());
            samples.add(new OBB(center, halfExtents, rotation));
        }

        samples.add(current);

        return samples;
    }

    public @Nullable RayHit rayTraceAttackable(class_243 start, class_243 end) {
        Objects.requireNonNull(start, "start");
        Objects.requireNonNull(end, "end");
        if (!active) {
            return null;
        }

        final class_243 direction = end.method_1020(start);
        final double length = direction.method_1033();
        if (length < 1.0E-8) {
            return null;
        }

        BoneHitbox closestHitbox = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (BoneHitbox hitbox : hitboxes.values()) {
            if (!isHitboxActive(hitbox) || !hitbox.reactsWhenAttacked()) {
                continue;
            }

            final OBB obb = hitbox.getCurrentOBB();
            if (obb == null) {
                continue;
            }

            final double distance = obb.rayIntersects(start, end);
            if (distance >= 0d && distance < closestDistance) {
                closestHitbox = hitbox;
                closestDistance = distance;
            }

        }

        if (closestHitbox == null) {
            return null;
        }

        final class_243 location = start.method_1019(direction.method_1021(closestDistance / length));
        return new RayHit(closestHitbox, location, closestDistance);
    }

    /**
     * Validates and executes an attacked-hitbox behavior on the server
     */
    public boolean handleAttack(String boneName, class_3222 attacker) {
        Objects.requireNonNull(boneName, "boneName");
        Objects.requireNonNull(attacker, "attacker");
        if (!active || owner.method_37908().field_9236 || attacker.method_37908() != owner.method_37908() || attacker.method_7325() || !attacker.method_5805() || !owner.method_5805()) {
            return false;
        }

        final BoneHitbox requested = hitboxes.get(boneName);
        if (requested == null || !requested.reactsWhenAttacked()) {
            return false;
        }

        final double reach = attacker.method_7337() ? 6d : 3d;
        final class_243 start = attacker.method_33571();
        final class_243 view = attacker.method_5828(1f);
        final class_243 end = start.method_1019(view.method_1021(reach));

        final long now = owner.method_37908().method_8510();
        double closestDistance = Double.POSITIVE_INFINITY;
        for (final PoseSnapshot snapshot : history) {
            if (now - snapshot.gameTime() > REWIND_TICKS) {
                break;
            }

            final OBB obb = snapshot.attackableObbs().get(boneName);
            if (obb == null) {
                continue;
            }

            final double distance = obb.inflate(ATTACK_TOLERANCE).rayIntersects(start, end);
            if (distance >= 0d && distance < closestDistance) {
                closestDistance = distance;
            }

        }

        if (!Double.isFinite(closestDistance)) {
            return false;
        }

        final class_243 location = start.method_1019(view.method_1021(closestDistance));
        final class_3965 blockHit = owner.method_37908().method_17742(new class_3959(
                start,
                location,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                attacker
        ));

        if (blockHit.method_17783() != class_239.class_240.field_1333 && blockHit.method_17784().method_1025(start) + 1.0E-6 < location.method_1025(start)) {
            return false;
        }

        requested.handleAttack(owner, attacker);

        return true;
    }

    /**
     * Enables a specific hitbox by bone name
     */
    public void enable(String boneName) {
        final BoneHitbox hitbox = hitboxes.get(boneName);
        if (hitbox != null) {
            timedDisables.remove(boneName);
            hitbox.setEnabled(true);
        }

    }

    /**
     * Enables a hitbox now and automatically disables it {@code ticks} server ticks later
     */
    public void enableFor(String boneName, int ticks) {
        final BoneHitbox hitbox = hitboxes.get(boneName);
        if (hitbox != null && ticks > 0) {
            hitbox.setEnabled(true);
            timedDisables.put(boneName, ticks);
        }

    }

    /**
     * Disables a specific hitbox by bone name
     */
    public void disable(String boneName) {
        final BoneHitbox hitbox = hitboxes.get(boneName);
        if (hitbox != null) {
            timedDisables.remove(boneName);
            hitbox.setEnabled(false);
        }

    }

    /**
     * Disables all hitboxes
     */
    public void disableAll() {
        timedDisables.clear();
        hitboxes.values().forEach(boneHitbox -> boneHitbox.setEnabled(false));
    }

    /**
     * Enables all hitboxes
     */
    public void enableAll() {
        timedDisables.clear();
        hitboxes.values().forEach(boneHitbox -> boneHitbox.setEnabled(true));
    }

    /**
     * Whether any registered hitbox defines an attacked behavior
     */
    public boolean hasAttackableHitboxes() {
        for (final BoneHitbox hitbox : hitboxes.values()) {
            if (hitbox.reactsWhenAttacked()) {
                return true;
            }

        }

        return false;
    }

    public @Nullable class_243 clipAttackable(class_243 start, class_243 end) {
        final RayHit hit = rayTraceAttackable(start, end);
        return hit == null ? null : hit.location();
    }

    /**
     * Clears all cooldowns across all hitboxes
     */
    public void clearAllCooldowns() {
        hitboxes.values().forEach(BoneHitbox::clearCooldowns);
    }

    /**
     * Returns the set of bone names that have registered hitboxes
     */
    public Set<String> getTrackedBoneNames() {
        return Collections.unmodifiableSet(hitboxes.keySet());
    }

    /**
     * Maximum ticks an authoritative transform remains usable without a fresh update
     */
    public BoneHitboxManager transformTimeout(int ticks) {
        this.transformTimeoutTicks = Math.max(0, ticks);
        return this;
    }

    /**
     * Returns the owning entity
     */
    public class_1309 getOwner() {
        return owner;
    }

    private record PoseSnapshot(
            long gameTime,
            Map<String, OBB> attackableObbs
    ) {
        ;;
    }

    public record RayHit(
            BoneHitbox hitbox,
            class_243 location,
            double distance
    ) {

        public RayHit {
            Objects.requireNonNull(hitbox, "hitbox");
            Objects.requireNonNull(location, "location");
            if (!Double.isFinite(distance) || distance < 0d) {
                throw new IllegalArgumentException("distance must be finite and non-negative");
            }

        }

    }

    private void resolveAutoSize(BoneHitbox hitbox) {
        if (rig == null || !hitbox.isAutoSize() || hitbox.getBaseHalfExtents() != null) {
            return;
        }

        final class_243 halfExtents = rig.boneHalfExtents(hitbox.getBoneName());
        if (halfExtents != null && halfExtents.field_1352 > 1.0E-6 && halfExtents.field_1351 > 1.0E-6 && halfExtents.field_1350 > 1.0E-6) {
            hitbox.setBaseHalfExtents(halfExtents);

            final class_243 centerOffset = rig.boneCenterOffset(hitbox.getBoneName());
            hitbox.setAutoCenterOffset(centerOffset == null ? class_243.field_1353 : centerOffset);
        }

    }

    private static void validateTransform(class_243 position, Matrix3f rotation, float scaleX, float scaleY, float scaleZ) {
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(rotation, "rotation");
        if (!Double.isFinite(position.field_1352) || !Double.isFinite(position.field_1351) || !Double.isFinite(position.field_1350) || !Float.isFinite(scaleX) || !Float.isFinite(scaleY) || !Float.isFinite(scaleZ)) {
            throw new IllegalArgumentException("[KnightLib] Bone transform components must be finite");
        }

        final float[] values = {
                rotation.m00, rotation.m01, rotation.m02,
                rotation.m10, rotation.m11, rotation.m12,
                rotation.m20, rotation.m21, rotation.m22
        };
        for (final float value : values) {
            if (!Float.isFinite(value)) {
                throw new IllegalArgumentException("[KnightLib] Bone rotation components must be finite");
            }

        }

    }

    private static Matrix3f normalizedRotation(Matrix3f source) {
        final Vector3f x = source.getColumn(0, new Vector3f());
        final Vector3f y = source.getColumn(1, new Vector3f());
        final Vector3f originalZ = source.getColumn(2, new Vector3f());
        if (x.lengthSquared() < 1.0E-12f || y.lengthSquared() < 1.0E-12f || originalZ.lengthSquared() < 1.0E-12f) {
            throw new IllegalArgumentException("[KnightLib] Bone rotation axes must be non-zero");
        }

        x.normalize();
        y.fma(-x.dot(y), x);
        if (y.lengthSquared() < 1.0E-12f) {
            throw new IllegalArgumentException("[KnightLib] Bone rotation axes must not be parallel");
        }

        y.normalize();
        final Vector3f z = x.cross(y, new Vector3f()).normalize();
        if (z.dot(originalZ) < 0f) {
            z.negate();
        }

        return new Matrix3f().setColumn(0, x).setColumn(1, y).setColumn(2, z);
    }

}