package dev.xylonity.knightlib.api.animation;

import dev.xylonity.knightlib.api.item.KnightLibAnimatedItem;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * Backing store for per-stack animation handlers, although using {@link KnightLibAnimatedItem} methods should be sufficient.
 */
public final class KnightLibItemAnimations {

    static final String TAG = "KnightLibAnimations";
    private static final class_2499 EMPTY_STATE = new class_2499();

    private static final Map<class_1799, CacheEntry> HANDLERS = new WeakHashMap<>();

    private KnightLibItemAnimations() {
        ;;
    }

    public static KnightLibAnimationHandler getAnimationHandler(class_1799 stack, @Nullable class_1937 level) {
        return getAnimationHandler(animatedItem(stack), stack, level, null);
    }

    /**
     * Direct lookup used by {@link KnightLibAnimatedItem}
     */
    public static KnightLibAnimationHandler getAnimationHandler(KnightLibAnimatedItem item, class_1799 stack, @Nullable class_1937 level) {
        return getAnimationHandler(item, stack, level, null);
    }

    /**
     * Context-aware lookup used by the automatic ItemStack tick hook
     */
    public static KnightLibAnimationHandler getAnimationHandler(class_1799 stack, @Nullable class_1937 level, @Nullable class_1297 holder) {
        return getAnimationHandler(animatedItem(stack), stack, level, holder);
    }

    /**
     * Context-aware lookup used by the automatic ItemStack tick hook
     */
    public static KnightLibAnimationHandler getAnimationHandler(KnightLibAnimatedItem item, class_1799 stack, @Nullable class_1937 level, @Nullable class_1297 holder) {
        Objects.requireNonNull(item, "item");
        Objects.requireNonNull(stack, "stack");
        if (item instanceof class_1792 vanillaItem && stack.method_7909() != vanillaItem) {
            throw new IllegalArgumentException("[KnightLib] The ItemStack does not contain the supplied KnightLibAnimatedItem");
        }

        final class_2499 state = state(stack);
        synchronized (HANDLERS) {
            final CacheEntry entry = HANDLERS.get(stack);
            if (entry == null) {
                final KnightLibAnimationHandler handler = KnightLibAnimationHandler.of(item, stack, level);
                handler.updateItemContext(stack, level, holder);
                handler.load(wrap(state));

                HANDLERS.put(stack, new CacheEntry(handler, copy(state)));

                return handler;
            }

            entry.handler.updateItemContext(stack, level, holder);
            if (!entry.state.equals(state)) {
                entry.handler.load(wrap(state));
                entry.state = copy(state);
            }

            return entry.handler;
        }

    }

    /**
     * Whether server ticking is needed to expire a duration-capped animation or remove a completed stop transition.
     */
    public static boolean needsServerTick(class_1799 stack) {
        final class_2487 ownerTag = stack.method_7969();
        if (ownerTag == null || !ownerTag.method_10573(TAG, class_2520.field_33259)) {
            return false;
        }

        final class_2499 controllers = ownerTag.method_10554(TAG, class_2520.field_33260);
        if (controllers.isEmpty()) {
            return true;
        }

        for (int i = 0; i < controllers.size(); i++) {
            final class_2487 controller = controllers.method_10602(i);
            final String animation = controller.method_10558("Animation");
            if (animation.isBlank() || controller.method_10550("Duration") > 0) {
                return true;
            }

        }

        return false;
    }

    /**
     * Clears client-local handlers when the client changes world or disconnects.
     */
    public static void clear() {
        synchronized (HANDLERS) {
            HANDLERS.clear();
        }

    }

    /**
     * Compares held-item state while ignoring only KnightLib's controller snapshot, used for the forge's stub method, so now
     * animations no longer cause a hand pop, while item, count, capability and unrelated NBT changes retain the normal re-equip behavior.
     */
    public static boolean shouldCauseReequipAnimation(class_1799 oldStack, class_1799 newStack) {
        Objects.requireNonNull(oldStack, "oldStack");
        Objects.requireNonNull(newStack, "newStack");
        if (oldStack == newStack) {
            return false;
        }

        return !class_1799.method_7973(withoutAnimationState(oldStack), withoutAnimationState(newStack));
    }

    private static class_1799 withoutAnimationState(class_1799 stack) {
        final class_1799 copy = stack.method_7972();
        final class_2487 tag = copy.method_7969();
        if (tag != null && tag.method_10545(TAG)) {
            tag.method_10551(TAG);
            if (tag.method_33133()) {
                copy.method_7980(null);
            }

        }

        return copy;
    }

    private static class_2499 state(class_1799 stack) {
        final class_2487 ownerTag = stack.method_7969();
        if (ownerTag != null && ownerTag.method_10573(TAG, class_2520.field_33259)) {
            return ownerTag.method_10554(TAG, class_2520.field_33260);
        }

        return EMPTY_STATE;
    }

    private static class_2487 wrap(class_2499 state) {
        final class_2487 ownerTag = new class_2487();
        ownerTag.method_10566(TAG, state);
        return ownerTag;
    }

    private static class_2499 copy(class_2499 state) {
        return state.method_10612();
    }

    private static KnightLibAnimatedItem animatedItem(class_1799 stack) {
        if (stack.method_7909() instanceof KnightLibAnimatedItem item) {
            return item;
        }

        throw new IllegalArgumentException("[KnightLib] Item must implement KnightLibAnimatedItem: " + stack.method_7909());
    }

    private static final class CacheEntry {

        private final KnightLibAnimationHandler handler;
        private class_2499 state;

        private CacheEntry(KnightLibAnimationHandler handler, class_2499 state) {
            this.handler = handler;
            this.state = state;
        }

    }

}