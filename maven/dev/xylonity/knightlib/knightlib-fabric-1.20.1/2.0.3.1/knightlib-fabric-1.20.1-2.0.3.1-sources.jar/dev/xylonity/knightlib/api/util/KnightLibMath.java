package dev.xylonity.knightlib.api.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_5819;

public final class KnightLibMath {

    private static final double TAU = Math.PI * 2.0;
    private static final double DEG_TO_RAD = Math.PI / 180.0;
    private static final double RAD_TO_DEG = 180.0 / Math.PI;
    private static final float EPSILON = 1.0E-6F;

    private KnightLibMath() {
        ;;
    }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public static float clamp01(float value) {
        return clamp(value, 0.0F, 1.0F);
    }

    public static double clamp01(double value) {
        return clamp(value, 0.0, 1.0);
    }

    /**
     * Linear interpolation between {@code a} and {@code b}
     */
    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    /**
     * Returns the {@code t} that produces {@code value} between {@code a} and {@code b}
     */
    public static float inverseLerp(float a, float b, float value) {
        if (Math.abs(b - a) < EPSILON) {
            return 0;
        }

        return (value - a) / (b - a);
    }

    public static double inverseLerp(double a, double b, double value) {
        if (Math.abs(b - a) < EPSILON) {
            return 0;
        }

        return (value - a) / (b - a);
    }

    /**
     * Remaps {@code value} from range [inMin, inMax] to [outMin, outMax]
     */
    public static float remap(float value, float inputMin, float inputMax, float outputMin, float outputMax) {
        final float t = inverseLerp(inputMin, inputMax, value);
        return lerp(outputMin, outputMax, t);
    }

    public static double remap(double value, double inputMin, double inputMax, double outputMin, double outputMax) {
        final double t = inverseLerp(inputMin, inputMax, value);
        return lerp(outputMin, outputMax, t);
    }

    /**
     * Angle of a horizontal offset
     */
    public static float yawAngleOf(class_243 offset) {
        return (float) Math.toDegrees(Math.atan2(-offset.field_1352, offset.field_1350));
    }

    /**
     * Clamped lerp, where {@code t} is clamped to [0, 1] before interpolation
     */
    public static float clampedLerp(float a, float b, float t) {
        return lerp(a, b, clamp01(t));
    }

    public static double clampedLerp(double a, double b, double t) {
        return lerp(a, b, clamp01(t));
    }

    /**
     * Linearly interpolates a Vec3
     */
    public static class_243 lerpVec3(class_243 a, class_243 b, double t) {
        return new class_243(
                lerp(a.field_1352, b.field_1352, t),
                lerp(a.field_1351, b.field_1351, t),
                lerp(a.field_1350, b.field_1350, t)
        );

    }

    public static float toRadians(float degrees) {
        return (float) (degrees * DEG_TO_RAD);
    }

    public static float toDegrees(float radians) {
        return (float) (radians * RAD_TO_DEG);
    }

    public static double toRadians(double degrees) {
        return degrees * DEG_TO_RAD;
    }

    public static double toDegrees(double radians) {
        return radians * RAD_TO_DEG;
    }

    /**
     * Wraps a degree value into [-180, 180)
     */
    public static float wrapDegrees(float degrees) {
        float outputDegrees = degrees % 360F;
        if (outputDegrees >= 180F) {
            outputDegrees -= 360F;
        }
        if (outputDegrees < -180F) {
            outputDegrees += 360F;
        }

        return outputDegrees;
    }

    public static double wrapDegrees(double degrees) {
        double outputDegrees = degrees % 360.0;
        if (outputDegrees >= 180.0) {
            outputDegrees -= 360.0;
        }
        if (outputDegrees < -180.0) {
            outputDegrees += 360.0;
        }

        return outputDegrees;
    }

    /**
     * Shortest signed angle difference between two degree values
     */
    public static float angleDelta(float from, float to) {
        return wrapDegrees(to - from);
    }

    /**
     * Rotates {@code from} towards {@code to} by at most {@code maxStep} degrees
     */
    public static float approachAngle(float from, float to, float maxStep) {
        final float delta = angleDelta(from, to);
        return from + clamp(delta, -maxStep, maxStep);
    }

    /**
     * Lerp between two angles in degrees, taking the shortest path
     */
    public static float lerpAngle(float a, float b, float t) {
        return a + angleDelta(a, b) * t;
    }

    /**
     * Squared distance between two points (avoids sqrt)
     */
    public static double distanceSqr(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double dz = z2 - z1;
        return dx * dx + dy * dy + dz * dz;
    }

    public static double distanceSqr(class_243 a, class_243 b) {
        return distanceSqr(a.field_1352, a.field_1351, a.field_1350, b.field_1352, b.field_1351, b.field_1350);
    }

    public static double distanceSqr(class_2338 a, class_2338 b) {
        return distanceSqr(a.method_10263(), a.method_10264(), a.method_10260(), b.method_10263(), b.method_10264(), b.method_10260());
    }

    /**
     * Euclidean distance between two points
     */
    public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
        return Math.sqrt(distanceSqr(x1, y1, z1, x2, y2, z2));
    }

    public static double distance(class_243 a, class_243 b) {
        return Math.sqrt(distanceSqr(a, b));
    }

    public static double distance(class_2338 a, class_2338 b) {
        return Math.sqrt(distanceSqr(a, b));
    }

    /**
     * 2D (XZ) horizontal distance squared
     */
    public static double horizontalDistanceSqr(double x1, double z1, double x2, double z2) {
        double dx = x2 - x1;
        double dz = z2 - z1;
        return dx * dx + dz * dz;
    }

    public static double horizontalDistanceSqr(class_243 a, class_243 b) {
        return horizontalDistanceSqr(a.field_1352, a.field_1350, b.field_1352, b.field_1350);
    }

    public static double horizontalDistance(class_243 a, class_243 b) {
        return Math.sqrt(horizontalDistanceSqr(a, b));
    }

    /**
     * Returns a normalized direction vector from {@code from} to {@code to}
     */
    public static class_243 direction(class_243 from, class_243 to) {
        final class_243 difference = to.method_1020(from);
        final double length = difference.method_1033();
        return length < EPSILON ? class_243.field_1353 : difference.method_1021(1.0 / length);
    }

    /**
     * Projects a point {@code p} onto the line segment from {@code a} to {@code b}
     */
    public static class_243 projectOntoSegment(class_243 point, class_243 a, class_243 b) {
        final class_243 ab = b.method_1020(a);
        final double lengthSqr = ab.method_1027();
        if (lengthSqr < EPSILON) {
            return a;
        }

        final double t = clamp01(point.method_1020(a).method_1026(ab) / lengthSqr);
        return a.method_1019(ab.method_1021(t));
    }

    /**
     * Rotates a point around the Y axis by {@code angleDeg} degrees relative to {@code center}
     */
    public static class_243 rotateAroundY(class_243 point, class_243 center, double angleDeg) {
        final double rad = toRadians(angleDeg);
        final double cos = Math.cos(rad);
        final double sin = Math.sin(rad);
        final double dx = point.field_1352 - center.field_1352;
        final double dz = point.field_1350 - center.field_1350;
        return new class_243(
                center.field_1352 + dx * cos - dz * sin,
                point.field_1351,
                center.field_1350 + dx * sin + dz * cos
        );

    }

    /**
     *  Random int in [min, max] (inclusive)
     */
    public static int randomInt(final class_5819 random, int min, int max) {
        return min + random.method_43048(max - min + 1);
    }

    public static int randomInt(int min, int max) {
        final Random random = ThreadLocalRandom.current();
        return min + random.nextInt(max - min + 1);
    }

    /**
     * Random float in [min, max)
     */
    public static float randomFloat(final class_5819 random, float min, float max) {
        return min + random.method_43057() * (max - min);
    }

    public static float randomFloat(float min, float max) {
        final Random random = ThreadLocalRandom.current();
        return min + random.nextFloat() * (max - min);
    }

    /**
     * Random double in [min, max)
     */
    public static double randomDouble(final class_5819 random, double min, double max) {
        return min + random.method_43058() * (max - min);
    }

    public static double randomDouble(double min, double max) {
        final Random random = ThreadLocalRandom.current();
        return min + random.nextDouble() * (max - min);
    }

    /**
     * Returns a random point on the unit sphere
     */
    public static class_243 randomOnUnitSphere(final class_5819 random) {
        final double theta = random.method_43058() * TAU;
        final double phi = Math.acos(2.0 * random.method_43058() - 1.0);
        final double sinPhi = Math.sin(phi);
        return new class_243(sinPhi * Math.cos(theta), sinPhi * Math.sin(theta), Math.cos(phi));
    }

    /**
     * Returns a random point inside a sphere of given radius
     */
    public static class_243 randomInSphere(final class_5819 random, double radius) {
        return randomOnUnitSphere(random).method_1021(radius * Math.cbrt(random.method_43058()));
    }

    /**
     * Returns a random horizontal direction (XZ) as a unit Vec3
     */
    public static class_243 randomHorizontalDirection(final class_5819 random) {
        final double angle = random.method_43058() * TAU;
        return new class_243(Math.cos(angle), 0, Math.sin(angle));
    }

    /**
     * Returns true with the given probability [0..1]
     */
    public static boolean chance(final class_5819 random, float probability) {
        return random.method_43057() < probability;
    }

    public static boolean chance(float probability) {
        final Random random = ThreadLocalRandom.current();
        return random.nextFloat() < probability;
    }

    /**
     * Returns 0 if {@code value < edge}, else 1.
     */
    public static float step(float edge, float value) {
        return value < edge ? 0F : 1F;
    }

    /**
     * Returns true if the value is a power of two
     */
    public static boolean isPowerOfTwo(int value) {
        return value > 0 && (value & (value - 1)) == 0;
    }

    /**
     * Maps a tick count + partial tick into a [0, 1] progress over {@code durationTicks}
     */
    public static float tickProgress(int tickCount, float partialTick, int durationTicks) {
        return clamp01((tickCount + partialTick) / durationTicks);
    }

    /**
     * Computes a Hermite spline with the given params
     */
    public static class_243 hermite(class_243 from, class_243 outTangent, class_243 to, class_243 inTangent, float t) {
        final float t2 = t * t;
        final float t3 = t2 * t;

        final float h00 = 2f * t3 - 3f * t2 + 1f;
        final float h10 = t3 - 2f * t2 + t;
        final float h01 = -2f * t3 + 3f * t2;
        final float h11 = t3 - t2;

        return new class_243(
                h00 * from.field_1352 + h10 * outTangent.field_1352 + h01 * to.field_1352 + h11 * inTangent.field_1352,
                h00 * from.field_1351 + h10 * outTangent.field_1351 + h01 * to.field_1351 + h11 * inTangent.field_1351,
                h00 * from.field_1350 + h10 * outTangent.field_1350 + h01 * to.field_1350 + h11 * inTangent.field_1350
        );

    }

}
