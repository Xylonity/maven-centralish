package dev.xylonity.knightlib.platform;

import dev.xylonity.knightlib.api.registrar.ResourceRegistry;
import dev.xylonity.knightlib.common.block.GreatChaliceBlock;
import dev.xylonity.knightlib.common.item.blockitem.GreatChaliceBlockItem;
import dev.xylonity.knightlib.registry.KnightLibBlockEntities;
import dev.xylonity.knightlib.registry.KnightLibBlocks;
import dev.xylonity.knightlib.registry.KnightLibItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_4970;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

@SuppressWarnings("unchecked")
public class KnightLibFabricPlatform implements KnightLibPlatform {

    @Override
    public <T extends class_2396<?>> Supplier<T> createParticle(boolean overrideLimiter) {
        return () -> (T) FabricParticleTypes.simple(overrideLimiter);
    }

    @Override
    public <T extends class_2248> Supplier<T> createBlock(String id, class_4970.class_2251 properties, KnightLibBlocks.BlockType blockType) {
        return switch (blockType) {
            default -> // CHALICE
                    () -> (T) new GreatChaliceBlock(properties);
        };
    }

    @Override
    public <T extends class_1792> Supplier<T> createItem(String id, class_1792.class_1793 properties, KnightLibItems.ItemType itemType) {
        return switch (itemType) {
            default -> // CHALICE
                    () -> (T) new GreatChaliceBlockItem(KnightLibBlocks.GREAT_CHALICE.get(), properties, id);
        };
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> supplier, Supplier<class_2248> block) {
        return class_2591.class_2592.method_20528(supplier::create, block.get()).method_11034(null);
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(ResourceRegistry.BlockEntityFactory<T> supplier, Supplier<class_2248>... blocks) {
        final class_2248[] blocksArray = Arrays.stream(blocks)
                .map(Supplier::get)
                .toArray(class_2248[]::new);

        return class_2591.class_2592.method_20528(supplier::create, blocksArray).method_11034(null);
    }

    @Override
    public <T extends class_1703> class_3917<T> createMenuFactory(ResourceRegistry.MenuFactory<T> supplier) {
        return new ExtendedScreenHandlerType<>(supplier::create);
    }

    @Override
    public <X extends class_1308> class_1792 createSpawnEgg(Supplier<class_1299<X>> entityType, int primaryColor, int secondaryColor, class_1792.class_1793 properties) {
        return new class_1826(entityType.get(), primaryColor, secondaryColor, properties);
    }

    @Override
    public void openMenu(class_3222 player, class_3908 provider, Consumer<class_2540> extraData) {
        player.method_17355(new ExtendedScreenHandlerFactory() {
            @Override
            public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
                extraData.accept(buf);
            }

            @Override
            public @NotNull class_2561 method_5476() {
                return provider.method_5476();
            }

            @Override
            public @Nullable class_1703 createMenu(int syncId, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return provider.createMenu(syncId, inventory, player);
            }

        });

    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isModLoaded(String modid) {
        return FabricLoader.getInstance().isModLoaded(modid);
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    @Override
    public Path resolveConfigFile(String configFileName) {
        return FabricLoader.getInstance().getConfigDir().resolve(configFileName);
    }

    @Override
    public Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir();
    }

    @Override
    public class_1761.class_7913 creativeTabBuilder() {
        return FabricItemGroup.builder();
    }

}
