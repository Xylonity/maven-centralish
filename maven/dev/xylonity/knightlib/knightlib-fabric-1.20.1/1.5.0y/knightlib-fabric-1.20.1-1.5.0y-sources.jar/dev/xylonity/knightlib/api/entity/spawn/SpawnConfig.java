package dev.xylonity.knightlib.api.entity.spawn;

import dev.xylonity.knightlib.api.util.ResourceLocations;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/**
 * Quick wrapper for managing config entries that define an entity's spawn weight and biomes, in a hardcoded string pattern as follows:
 *
 * {@code "weight, minAmount, maxAmount, biomes, and tags..."}
 */
public class SpawnConfig {

    public final List<class_2960> biomes;
    public final List<class_6862<class_1959>> biomeTags;
    public final int weight;
    public final int minCount;
    public final int maxCount;

    private SpawnConfig(int weight, int minCount, int maxCount, List<class_2960> biomes, List<class_6862<class_1959>> biomeTags) {
        this.weight = weight;
        this.minCount = minCount;
        this.maxCount = maxCount;
        this.biomes = biomes;
        this.biomeTags = biomeTags;
    }

    public static SpawnConfig parse(String configLine) {
        final String[] parts = configLine.split("\\s*,\\s*");
        final int weight = Integer.parseInt(parts[0]);
        final int min = Integer.parseInt(parts[1]);
        final int max = Integer.parseInt(parts[2]);

        final List<class_2960> biomeList = new ArrayList<>();
        final List<class_6862<class_1959>> tagList = new ArrayList<>();

        for (int i = 3; i < parts.length; i++) {
            final String part = parts[i];
            if (part.startsWith("#")) {
                final class_2960 tagId = ResourceLocations.parse(part.substring(1));
                tagList.add(class_6862.method_40092(class_7924.field_41236, tagId));
            }
            else {
                biomeList.add(ResourceLocations.parse(part));
            }

        }

        return new SpawnConfig(weight, min, max, biomeList, tagList);
    }

    public boolean matches(class_6880<class_1959> biomeHolder) {
        final class_2960 biomeName = getBiomeName(biomeHolder);
        if (biomeName == null) {
            return false;
        }

        if (biomes.contains(biomeName)) {
            return true;
        }

        for (final class_6862<class_1959> tag : biomeTags) {
            if (biomeHolder.method_40220(tag)) {
                return true;
            }

        }

        return false;
    }

    private static class_2960 getBiomeName(class_6880<class_1959> biomeHolder) {
        return biomeHolder.method_40229().map(class_5321::method_29177, noKey -> null);
    }

}
