package dev.xylonity.knightlib.api.event.impl.client;

import dev.xylonity.knightlib.api.util.ResourceLocations;
import net.minecraft.class_2960;
import dev.xylonity.knightlib.api.event.KnightLibEvent;

/**
 * Event to register additional models that must be loaded. Useful for items that use custom models or items that do not
 * have an associated block.
 */
public abstract class AdditionalModelsRegistrationEvent extends KnightLibEvent {

    @Override
    public boolean isSticky() {
        return true;
    }

    public void registerItemModel(String modid, String path) {
        register(ResourceLocations.of(modid, "item/" + path));
    }

    public void registerBlockModel(String modid, String path) {
        register(ResourceLocations.of(modid, "block/" + path));
    }

    /**
     * Registers and loads an additional model.
     *
     * @param modelLocation the path of the model (ResourceLocation(mod_id, "item/custom_model"))
     */
    public abstract void register(class_2960 modelLocation);

}
