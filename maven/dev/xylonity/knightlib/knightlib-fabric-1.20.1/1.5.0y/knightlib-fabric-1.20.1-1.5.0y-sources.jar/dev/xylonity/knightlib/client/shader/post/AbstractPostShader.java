package dev.xylonity.knightlib.client.shader.post;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderSettings;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1060;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_280;
import net.minecraft.class_284;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_8251;

/**
 * Base class for post-processing shaders.
 * Provides a "safe" PostChain execution that restores framebuffer, viewport
 * and the common GL state, as well as lifecycle management for GPU resources.
 */
public abstract class AbstractPostShader<PSS extends PostShaderSettings> implements PostShader<PSS> {

    /**
     * Blend modes used by {@link #compositeOverMain(class_276, CompositeBlend)} when drawing a
     * shader output target on top of the main render target.
     */
    public enum CompositeBlend {
        /** Source already multiplied by its alpha: {@code out = src + dst * (1 - srcA)}. */
        PREMULTIPLIED_ALPHA,
        /** Classic alpha blending: {@code out = src * srcA + dst * (1 - srcA)}. */
        STRAIGHT_ALPHA,
        /** Pure additive: {@code out = src + dst}. */
        ADDITIVE
    }

    private final Map<class_279, Long> chainSizeCache = new WeakHashMap<>();

    @Override
    public void initOrReload(class_1060 textures, class_3300 resources, class_276 target) {
        chainSizeCache.clear();
    }

    /**
     * Releases GPU resources held by the given chain.
     * Subclasses that hold a {@link class_279} field should override {@link #dispose()}
     * and call {@code closeChain(myChain)} there.
     */
    protected final void closeChain(class_279 chain) {
        if (chain != null) {
            chain.close();
            chainSizeCache.remove(chain);
        }

    }

    /**
     * Called when this shader is unregistered or replaced.
     * Subclasses must override this to close their PostChain(s).
     */
    @Override
    public void dispose() {
        chainSizeCache.clear();
    }

    /**
     * Runs a PostChain safely, binding the main render target before and after,
     * restoring the viewport and the common render state.
     */
    protected final void process(class_279 chain, float partialTicks, Runnable beforeProcess) {
        if (chain == null) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_276 mainRenderTarget = minecraft.method_1522();

        // Save projection (copy, as the RenderSystem may mutate the instance later)
        final Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());

        // Identity model-view for full-screen quad space
        final class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        modelViewStack.method_34426();
        RenderSystem.applyModelViewMatrix();

        try {
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            if (beforeProcess != null) {
                beforeProcess.run();
            }

            chain.method_1258(partialTicks);
        }
        finally {
            // Restores model-view
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();

            // Restores projection
            RenderSystem.setProjectionMatrix(savedProjection, class_8251.field_43360);

            // Rebinds main and restore viewport
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            // Restores the common render state
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.resetTextureMatrix();
        }

    }

    /**
     * Draws {@code source}'s color texture as a full-screen quad on top of {@code minecraft:main}
     * using the given blend mode.
     *
     * Unlike letting a {@link class_279} write to {@code minecraft:main} directly (which clears the
     * main target before drawing), this composites additively/over the existing scene, so the world
     * is never wiped. It also keeps the effect independent from the main color/depth buffers, which
     * is what makes it survive Fabulous graphics.
     */
    protected final void compositeOverMain(class_276 source, CompositeBlend blend) {
        if (source == null) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_276 main = minecraft.method_1522();

        final int width = main.field_1482;
        final int height = main.field_1481;

        // Save projection so the rest of the pipeline is undisturbed
        final Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());

        final class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        modelViewStack.method_34426();
        modelViewStack.method_22904(0.0, 0.0, -2000.0);
        RenderSystem.applyModelViewMatrix();

        try {
            main.method_1235(false);
            RenderSystem.viewport(0, 0, width, height);

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            applyCompositeBlend(blend);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

            // Top-left origin orthographic space, matching vanilla full-screen blits
            final Matrix4f ortho = new Matrix4f().setOrtho(0f, width, height, 0f, 1000f, 3000f);
            RenderSystem.setProjectionMatrix(ortho, class_8251.field_43361);

            RenderSystem.setShaderTexture(0, source.method_30277());
            RenderSystem.setShader(class_757::method_34542);

            final float u = source.field_1482 == 0 ? 1f : (float) source.field_1480 / (float) source.field_1482;
            final float v = source.field_1481 == 0 ? 1f : (float) source.field_1477 / (float) source.field_1481;

            final class_289 tesselator = RenderSystem.renderThreadTesselator();
            final class_287 buffer = tesselator.method_1349();
            buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
            buffer.method_22912(0.0, height, 0.0).method_22913(0f, 0f).method_1344();
            buffer.method_22912(width, height, 0.0).method_22913(u, 0f).method_1344();
            buffer.method_22912(width, 0.0, 0.0).method_22913(u, v).method_1344();
            buffer.method_22912(0.0, 0.0, 0.0).method_22913(0f, v).method_1344();
            class_286.method_43437(buffer.method_1326());
        }
        finally {
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();

            RenderSystem.setProjectionMatrix(savedProjection, class_8251.field_43360);

            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

            main.method_1235(true);
            RenderSystem.viewport(0, 0, width, height);
        }

    }

    private static void applyCompositeBlend(CompositeBlend blend) {
        if (blend == CompositeBlend.STRAIGHT_ALPHA) {
            RenderSystem.blendFuncSeparate(
                    GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA,
                    GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        }
        else if (blend == CompositeBlend.ADDITIVE) {
            RenderSystem.blendFuncSeparate(
                    GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE,
                    GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE);
        }
        else {
            RenderSystem.blendFuncSeparate(
                    GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA,
                    GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        }

    }

    /**
     * Resizes the shader depending on the window size. Must be called before processing the shader
     */
    protected final void ensureSized(class_279 chain) {
        ensureSizedChanged(chain);
    }

    /**
     * Same as ensureSized, but returns whether a resize actually happened
     */
    protected final boolean ensureSizedChanged(class_279 chain) {
        if (chain == null) {
            return false;
        }

        final class_310 minecraft = class_310.method_1551();
        final int width = minecraft.method_22683().method_4489();
        final int height = minecraft.method_22683().method_4506();

        final long current = ((long) width << 32) | (height & 0xFFFFFFFFL);
        final Long previous = chainSizeCache.get(chain);

        if (previous == null || previous != current) {
            chain.method_1259(width, height);
            chainSizeCache.put(chain, current);
            return true;
        }

        return false;
    }

    protected final void setUniformInt(class_280 effectInstance, String name, int value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_35649(value);
        }

    }

    protected final void setUniformFloat(class_280 effectInstance, String name, float value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1251(value);
        }

    }

    protected final void setUniformVec2(class_280 effectInstance, String name, float x, float y) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1255(x, y);
        }

    }

    protected final void setUniformVec3(class_280 effectInstance, String name, class_243 vector) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1249((float) vector.field_1352, (float) vector.field_1351, (float) vector.field_1350);
        }

    }

    protected final void setUniformMat4(class_280 effectInstance, String name, Matrix4f matrix) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1250(matrix);
        }

    }

}