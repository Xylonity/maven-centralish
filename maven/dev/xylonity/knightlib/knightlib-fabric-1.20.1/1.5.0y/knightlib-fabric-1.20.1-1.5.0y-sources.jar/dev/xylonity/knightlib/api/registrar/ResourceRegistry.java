package dev.xylonity.knightlib.api.registrar;

import dev.xylonity.knightlib.KnightLib;
import dev.xylonity.knightlib.api.util.ResourceLocations;
import javax.annotation.Nullable;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3917;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Generic registry interface that queues up the registry factories, and then
 * later dispatches them in the loader specific abstractions
 * Example usage:
 * <pre>
 * {@code
 * public static final ResourceRegistry<Block> BLOCKS = ResourceDispatcher.create(ResourceType.BLOCKS, KnightLibCommon.MOD_ID);
 * }
 * </pre>
 */
public interface ResourceRegistry<T> {

    /**
     * Queues a new entry (object, item, etc.) under the given name and instancing
     */
    <I extends T> ResourceEntry<I> register(String name, Supplier<? extends I> object);

    /**
     * Entity registrar helper.
     *
     * @param name name of the entity
     * @param entity entity to register
     * @param category category of the entity
     * @param width width of the entity's bb
     * @param height height of the entity's bb
     * @param properties extra properties of the entity (fire inmmunity, client tracking, etc.)
     * @return the encapsulated instance of the entity
     */
    @SuppressWarnings("unchecked")
    default <X extends class_1297> ResourceEntry<class_1299<X>> registerEntity(String name, class_1299.class_4049<X> entity, class_1311 category, float width, float height, @Nullable List<Consumer<class_1299.class_1300<X>>> properties) {
        return ((ResourceRegistry<class_1299<X>>) this).register(name, () -> {
            class_1299.class_1300<X> builder = class_1299.class_1300.method_5903(entity, category).method_17687(width, height);

            if (properties != null) {
                for (Consumer<class_1299.class_1300<X>> property : properties) {
                    property.accept(builder);
                }
            }

            return builder.method_5905(ResourceLocations.of(getNamespace(), name).toString());
        });

    }

    default <X extends class_1297> ResourceEntry<class_1299<X>> registerEntity(String name, class_1299.class_4049<X> entity, class_1311 category, float width, float height) {
        return this.registerEntity(name, entity, category, width, height, null);
    }

    /**
     * Menu registrar helper.
     *
     * @param name registry name
     * @param factory menu constructor (syncId, playerInv, buf)
     * @return the encapsulated MenuType entry
     */
    @SuppressWarnings("unchecked")
    default <M extends class_1703> ResourceEntry<class_3917<M>> registerMenu(String name, MenuFactory<M> factory) {
        return ((ResourceRegistry<class_3917<M>>) this).register(name, () ->
                KnightLib.PLATFORM.createMenuFactory(factory)
        );

    }

    /**
     * BlockEntity registrar helper.
     *
     * @param name registry name
     * @param factory factory of the BlockEntity to register
     * @param block block linked to that BlockEntity
     * @return the encapsulated BlockEntityType
     */
    @SuppressWarnings("unchecked")
    default <BE extends class_2586> ResourceEntry<class_2591<BE>> registerBlockEntity(String name, ResourceRegistry.BlockEntityFactory<BE> factory, Supplier<class_2248> block) {
        return ((ResourceRegistry<class_2591<BE>>) this).register(name, () ->
                KnightLib.PLATFORM.createBlockEntityType(factory, block)
        );

    }

    /**
     * BlockEntity registrar helper.
     *
     * @param name registry name
     * @param factory factory of the BlockEntity to register
     * @param blocks blocks linked to that BlockEntity
     * @return the encapsulated BlockEntityType
     */
    @SuppressWarnings("unchecked")
    default <BE extends class_2586> ResourceEntry<class_2591<BE>> registerBlockEntity(String name, ResourceRegistry.BlockEntityFactory<BE> factory, Supplier<class_2248>... blocks) {
        return ((ResourceRegistry<class_2591<BE>>) this).register(name, () ->
                KnightLib.PLATFORM.createBlockEntityType(factory, blocks)
        );

    }

    /**
     * Block registrar helper that also registers an associated BlockItem.
     *
     * @param name registry name
     * @param block block supplier
     * @param itemRegistry the item ResourceRegistry to register the BlockItem in
     * @param itemFactory creates the item given the resolved block
     * @return the encapsulated Block entry
     */
    @SuppressWarnings("unchecked")
    default <B extends class_2248> ResourceEntry<B> registerBlock(String name, Supplier<? extends B> block, ResourceRegistry<class_1792> itemRegistry, Function<B, ? extends class_1792> itemFactory) {
        final ResourceEntry<B> blockEntry = ((ResourceRegistry<B>) this).register(name, block);
        itemRegistry.register(name, () -> itemFactory.apply(blockEntry.get()));
        return blockEntry;
    }

    /**
     * Spawn Egg item registrar helper. IMPORTANT: ensure that the entity registry is created before the items, as the fabric spawn egg abstraction
     * assumes that the entity in this context is already registered
     *
     * @param name registry name
     * @param entityType supplier of the entity type (not deferred-safe on fabric)
     * @param primaryColor primary egg color (0xRRGGBB)
     * @param secondaryColor secondary egg color (0xRRGGBB)
     * @param properties item properties
     * @return the encapsulated Item entry
     */
    @SuppressWarnings("unchecked")
    default <X extends class_1308> ResourceEntry<class_1792> registerSpawnEgg(String name, Supplier<class_1299<X>> entityType, int primaryColor, int secondaryColor, class_1792.class_1793 properties) {
        return ((ResourceRegistry<class_1792>) this).register(name, () ->
                KnightLib.PLATFORM.createSpawnEgg(entityType, primaryColor, secondaryColor, properties)
        );
        
    }

    @FunctionalInterface
    interface MenuFactory<M extends class_1703> {
        M create(int syncId, class_1661 playerInv, class_2540 buf);
    }

    @FunctionalInterface
    interface BlockEntityFactory<BE extends class_2586> {
        BE create(class_2338 pos, class_2680 state);
    }

    /**
     * Used internally to dispatch all the entries
     * @return all pending entries in this registry
     */
    Collection<ResourceEntry<T>> getEntries();

    /**
     * Stream of the entry registered once successfully created
     */
    default Stream<T> stream() {
        return getEntries().stream().map(ResourceEntry::get);
    }

    String getNamespace();

    void init();
}
