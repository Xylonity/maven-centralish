package dev.xylonity.knightlib.client.shader.post;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.xylonity.knightlib.client.shader.post.interop.PostShaderSettings;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1060;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_280;
import net.minecraft.class_284;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4587;
import net.minecraft.class_8251;

/**
 * Base class for post-processing shaders.
 * Provides a "safe" PostChain execution that restores framebuffer, viewport
 * and the common GL state, as well as lifecycle management for GPU resources.
 */
public abstract class AbstractPostShader<PSS extends PostShaderSettings> implements PostShader<PSS> {

    private final Map<class_279, Long> chainSizeCache = new WeakHashMap<>();

    @Override
    public void initOrReload(class_1060 textures, class_3300 resources, class_276 target) {
        chainSizeCache.clear();
    }

    /**
     * Releases GPU resources held by the given chain.
     * Subclasses that hold a {@link class_279} field should override {@link #dispose()}
     * and call {@code closeChain(myChain)} there.
     */
    protected final void closeChain(class_279 chain) {
        if (chain != null) {
            chain.close();
            chainSizeCache.remove(chain);
        }

    }

    /**
     * Called when this shader is unregistered or replaced.
     * Subclasses must override this to close their PostChain(s).
     */
    @Override
    public void dispose() {
        chainSizeCache.clear();
    }

    /**
     * Runs a PostChain safely, restoring the framebuffer, viewport and common render state.
     */
    protected final void process(class_279 chain, float partialTicks, Runnable beforeProcess) {
        if (chain == null) {
            return;
        }

        final class_310 minecraft = class_310.method_1551();
        final class_276 mainRenderTarget = minecraft.method_1522();
        final FramebufferState framebufferState = FramebufferState.capture();

        // Save projection (copy, as the RenderSystem may mutate the instance later)
        final Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());

        // Identity model-view for full-screen quad space
        final class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        modelViewStack.method_34426();
        RenderSystem.applyModelViewMatrix();

        try {
            mainRenderTarget.method_1235(true);
            RenderSystem.viewport(0, 0, mainRenderTarget.field_1482, mainRenderTarget.field_1481);

            if (beforeProcess != null) {
                beforeProcess.run();
            }

            chain.method_1258(partialTicks);
        }
        finally {
            // Restores model-view
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();

            // Restores projection
            RenderSystem.setProjectionMatrix(savedProjection, class_8251.field_43360);

            framebufferState.restore();

            // Restores the common render state
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.resetTextureMatrix();
        }

    }

    /**
     * Resizes the shader depending on the window size. Must be called before processing the shader
     */
    protected final void ensureSized(class_279 chain) {
        ensureSizedChanged(chain);
    }

    /**
     * Same as ensureSized, but returns whether a resize actually happened
     */
    protected final boolean ensureSizedChanged(class_279 chain) {
        if (chain == null) {
            return false;
        }

        final class_310 minecraft = class_310.method_1551();
        final int width = minecraft.method_22683().method_4489();
        final int height = minecraft.method_22683().method_4506();

        final long current = ((long) width << 32) | (height & 0xFFFFFFFFL);
        final Long previous = chainSizeCache.get(chain);

        if (previous == null || previous != current) {
            chain.method_1259(width, height);
            chainSizeCache.put(chain, current);
            return true;
        }

        return false;
    }

    protected final void setUniformInt(class_280 effectInstance, String name, int value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_35649(value);
        }

    }

    protected final void setUniformFloat(class_280 effectInstance, String name, float value) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1251(value);
        }

    }

    protected final void setUniformVec2(class_280 effectInstance, String name, float x, float y) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1255(x, y);
        }

    }

    protected final void setUniformVec3(class_280 effectInstance, String name, class_243 vector) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1249((float) vector.field_1352, (float) vector.field_1351, (float) vector.field_1350);
        }

    }

    protected final void setUniformMat4(class_280 effectInstance, String name, Matrix4f matrix) {
        final class_284 uniform = effectInstance.method_1271(name);
        if (uniform != null) {
            uniform.method_1250(matrix);
        }

    }

}
