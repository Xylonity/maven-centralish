package dev.xylonity.knightlib.api.registrar;

import dev.xylonity.knightlib.KnightLib;
import javax.annotation.Nullable;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Generic registry interface that queues up the registry factories, and then
 * later dispatches them in the loader specific abstractions
 * Example usage:
 * <pre>
 * {@code
 * public static final ResourceRegistry<Block> BLOCKS = ResourceDispatcher.create(ResourceType.BLOCKS, KnightLibCommon.MOD_ID);
 * }
 * </pre>
 */
public interface ResourceRegistry<T> {

    /**
     * Queues a new entry (object, item, etc.) under the given name and instancing
     */
    <I extends T> ResourceEntry<I> register(String name, Supplier<? extends I> object);

    /**
     * Entity registrar helper.
     *
     * @param name name of the entity
     * @param entity entity to register
     * @param category category of the entity
     * @param width width of the entity's bb
     * @param height height of the entity's bb
     * @param properties extra properties of the entity (fire inmmunity, client tracking, etc.)
     * @return the encapsulated instance of the entity
     */
    @SuppressWarnings("unchecked")
    default <X extends class_1297> ResourceEntry<class_1299<X>> registerEntity(String name, class_1299.class_4049<X> entity, class_1311 category, float width, float height, @Nullable List<Consumer<class_1299.class_1300<X>>> properties) {
        return ((ResourceRegistry<class_1299<X>>) this).register(name, () -> {
            class_1299.class_1300<X> builder = class_1299.class_1300.method_5903(entity, category).method_17687(width, height);

            if (properties != null) {
                for (Consumer<class_1299.class_1300<X>> property : properties) {
                    property.accept(builder);
                }
            }

            return builder.method_5905(new class_2960(getNamespace(), name).toString());
        });

    }

    default <X extends class_1297> ResourceEntry<class_1299<X>> registerEntity(String name, class_1299.class_4049<X> entity, class_1311 category, float width, float height) {
        return this.registerEntity(name, entity, category, width, height, null);
    }

    /**
     * Menu registrar helper.
     *
     * @param name registry name
     * @param factory menu constructor (syncId, playerInv, buf)
     * @return the encapsulated MenuType entry
     */
    @SuppressWarnings("unchecked")
    default <M extends class_1703> ResourceEntry<class_3917<M>> registerMenu(String name, MenuFactory<M> factory) {
        return ((ResourceRegistry<class_3917<M>>) this).register(name, () ->
                KnightLib.PLATFORM.createMenuFactory(factory)
        );

    }

    @FunctionalInterface
    interface MenuFactory<M extends class_1703> {
        M create(int syncId, class_1661 playerInv, class_2540 buf);
    }

    /**
     * Used internally to dispatch all the entries
     * @return all pending entries in this registry
     */
    Collection<ResourceEntry<T>> getEntries();

    /**
     * Stream of the entry registered once successfully created
     */
    default Stream<T> stream() {
        return getEntries().stream().map(ResourceEntry::get);
    }

    String getNamespace();

    void init();
}