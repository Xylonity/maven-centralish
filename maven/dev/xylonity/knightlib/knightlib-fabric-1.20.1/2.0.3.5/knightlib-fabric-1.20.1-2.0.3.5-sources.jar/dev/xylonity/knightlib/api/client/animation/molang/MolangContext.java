package dev.xylonity.knightlib.api.client.animation.molang;

import dev.xylonity.knightlib.KnightLib;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3532;

/**
 * Values exposed to Molang while an animation is being sampled.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/core/src/main/java/software/bernie/geckolib/core/molang/MolangQueries.java
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/model/GeoModel.java
 */
public final class MolangContext {

    private static final Set<String> WARNED = ConcurrentHashMap.newKeySet();

    private float animTime;
    private float totalAnimTime;
    private float controllerSpeed = 1f;
    private class_1297 entity;
    private class_1937 level;
    private double now;
    private float actorCount;
    private float distanceFromCamera;

    /**
     * Speed-scaled seconds within the current animation loop
     */
    public void setAnimTime(float animTime) {
        this.animTime = animTime;
    }

    /**
     * Speed-scaled seconds since the animation started (doesn't take into account looping)
     */
    public void setTotalAnimTime(float totalAnimTime) {
        this.totalAnimTime = totalAnimTime;
    }

    /**
     * Playback multiplier of the controller currently being sampled
     */
    public void setControllerSpeed(float controllerSpeed) {
        this.controllerSpeed = Float.isFinite(controllerSpeed) ? controllerSpeed : 1f;
    }

    public void setEntity(class_1297 entity) {
        this.entity = entity;
        if (entity != null) {
            this.level = entity.method_37908();
        }

    }

    /**
     * World sampled by world-level queries when no entity is available
     */
    public void setLevel(class_1937 level) {
        this.level = level;
    }

    public void setActorCount(float actorCount) {
        this.actorCount = Float.isFinite(actorCount) ? actorCount : 0f;
    }

    public void setDistanceFromCamera(float distanceFromCamera) {
        this.distanceFromCamera = Float.isFinite(distanceFromCamera) ? distanceFromCamera : 0f;
    }

    /**
     * Client game time in ticks, including the partial tick
     */
    public void setNow(double now) {
        this.now = now;
    }

    public float query(String name) {
        return switch (name) {
            case "anim_time" -> animTime;
            case "total_anim_time" -> totalAnimTime;
            case "life_time" -> entity != null ? (entity.field_6012 + partialTick()) / 20f : (float) (now / 20.0);
            case "controller_speed" -> controllerSpeed;
            case "actor_count" -> actorCount;
            case "time_of_day" -> level == null ? 0f : level.method_8532() / 24000f;
            case "moon_phase" -> level == null ? 0f : level.method_30273();
            case "ground_speed" -> entity == null ? 0f : (float) entity.method_18798().method_37267();
            case "vertical_speed" -> entity == null ? 0f : (float) entity.method_18798().method_10214() * 20f;
            case "yaw_speed" -> entity instanceof class_1309 living ? class_3532.method_15393(living.method_5791() - living.field_6259) : entity == null ? 0f : class_3532.method_15393(entity.method_36454() - entity.field_5982);
            case "body_y_rotation" -> entity instanceof class_1309 living ? living.field_6283 : entity == null ? 0f : entity.method_36454();
            case "head_y_rotation" -> entity instanceof class_1309 living ? living.method_5791() : entity == null ? 0f : entity.method_36454();
            case "pitch", "head_x_rotation" -> entity == null ? 0f : entity.method_36455();
            case "limb_swing" -> entity instanceof class_1309 living ? living.field_42108.method_48572(partialTick()) : 0f;
            case "limb_swing_amount" -> entity instanceof class_1309 living ? living.field_42108.method_48570(partialTick()) : 0f;
            case "is_moving" -> entity != null && entity.method_18798().method_37268() > 1.0E-5 ? 1f : 0f;
            case "is_on_ground" -> entity != null && entity.method_24828() ? 1f : 0f;
            case "is_in_water" -> entity != null && entity.method_5799() ? 1f : 0f;
            case "is_in_water_or_rain" -> entity != null && entity.method_5721() ? 1f : 0f;
            case "is_on_fire" -> entity != null && entity.method_5809() ? 1f : 0f;
            case "is_in_lava" -> entity != null && entity.method_5771() ? 1f : 0f;
            case "is_sneaking" -> entity != null && entity.method_18276() ? 1f : 0f;
            case "is_sprinting" -> entity != null && entity.method_5624() ? 1f : 0f;
            case "is_alive" -> entity != null && entity.method_5805() ? 1f : 0f;
            case "is_riding" -> entity != null && entity.method_5765() ? 1f : 0f;
            case "is_swimming" -> entity instanceof class_1309 living && living.method_20232() ? 1f : 0f;
            case "is_using_item" -> entity instanceof class_1309 living && living.method_6115() ? 1f : 0f;
            case "is_fall_flying" -> entity instanceof class_1309 living && living.method_6128() ? 1f : 0f;
            case "is_sleeping" -> entity instanceof class_1309 living && living.method_6113() ? 1f : 0f;
            case "is_baby" -> entity instanceof class_1309 living && living.method_6109() ? 1f : 0f;
            case "health" -> entity instanceof class_1309 living ? living.method_6032() : 0f;
            case "max_health" -> entity instanceof class_1309 living ? living.method_6063() : 0f;
            case "hurt_time" -> entity instanceof class_1309 living ? living.field_6235 : 0f;
            case "distance_from_camera" -> distanceFromCamera;
            default -> {
                if (WARNED.add(name)) {
                    KnightLib.LOGGER.warn("[KnightLib] Unsupported molang query '{}', evaluating as 0", name);
                }

                yield 0f;
            }

        };

    }

    private float partialTick() {
        return (float) (now - Math.floor(now));
    }

}