package dev.xylonity.knightlib.client.animation.model;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/**
 * One mutable bone in the geo geometry. Its rest transform comes from the parsed model and its public transform
 * fields are rewritten by the animator every frame.
 *
 * Positions use model units (16ths of a block) relative to the parent pivot.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/object/GeoBone.java
 */
public final class GeoBone {

    public final String name;

    private final float restX;
    private final float restY;
    private final float restZ;
    private final float restRotX;
    private final float restRotY;
    private final float restRotZ;
    private final boolean restVisible;

    public float x;
    public float y;
    public float z;
    public float rotX;
    public float rotY;
    public float rotZ;
    public float scaleX = 1f;
    public float scaleY = 1f;
    public float scaleZ = 1f;
    public boolean visible = true;

    private final List<GeoCube> cubes;
    private final List<GeoBone> children = new ArrayList<>();

    public GeoBone(String name, float restX, float restY, float restZ, float restRotX, float restRotY, float restRotZ, boolean restVisible, List<GeoCube> cubes) {
        this.name = name;
        this.restX = restX;
        this.restY = restY;
        this.restZ = restZ;
        this.restRotX = restRotX;
        this.restRotY = restRotY;
        this.restRotZ = restRotZ;
        this.restVisible = restVisible;
        this.cubes = cubes;

        reset();
    }

    public void addChild(GeoBone child) {
        children.add(child);
    }

    void forEachBone(Consumer<String> visitor) {
        visitor.accept(name);
        for (final GeoBone child : children) {
            child.forEachBone(visitor);
        }

    }

    public List<GeoBone> children() {
        return Collections.unmodifiableList(children);
    }

    public List<GeoCube> cubes() {
        return Collections.unmodifiableList(cubes);
    }

    public class_243 halfExtents() {
        double x = 0;
        double y = 0;
        double z = 0;
        for (final GeoCube cube : cubes) {
            final class_243 extents = cube.absoluteExtents();
            x = Math.max(x, extents.field_1352);
            y = Math.max(y, extents.field_1351);
            z = Math.max(z, extents.field_1350);
        }

        return cubes.isEmpty() ? new class_243(0.1, 0.1, 0.1) : new class_243(x, y, z);
    }

    public void reset() {
        x = restX;
        y = restY;
        z = restZ;
        rotX = restRotX;
        rotY = restRotY;
        rotZ = restRotZ;
        scaleX = 1f;
        scaleY = 1f;
        scaleZ = 1f;
        visible = restVisible;
    }

    public void render(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        if (!visible) {
            return;
        }

        poseStack.method_22903();
        poseStack.method_46416(x / 16f, y / 16f, z / 16f);
        if (rotX != 0f || rotY != 0f || rotZ != 0f) {
            poseStack.method_22907(new Quaternionf().rotationZYX(
                    (float) Math.toRadians(rotZ),
                    (float) Math.toRadians(rotY),
                    (float) Math.toRadians(rotX)
            ));

        }

        if (scaleX != 1f || scaleY != 1f || scaleZ != 1f) {
            poseStack.method_22905(scaleX, scaleY, scaleZ);
        }

        for (final GeoCube cube : cubes) {
            cube.render(poseStack, consumer, packedLight, packedOverlay, r, g, b, a);
        }

        for (final GeoBone child : children) {
            child.render(poseStack, consumer, packedLight, packedOverlay, r, g, b, a);
        }

        poseStack.method_22909();
    }

    public void visit(class_4587 poseStack, Set<String> names, KnightLibModel.BoneVisitor visitor) {
        if (!visible) {
            return;
        }

        poseStack.method_22903();
        poseStack.method_46416(x / 16f, y / 16f, z / 16f);
        if (rotX != 0f || rotY != 0f || rotZ != 0f) {
            poseStack.method_22907(new Quaternionf().rotationZYX(
                    (float) Math.toRadians(rotZ),
                    (float) Math.toRadians(rotY),
                    (float) Math.toRadians(rotX)
            ));

        }
        if (scaleX != 1f || scaleY != 1f || scaleZ != 1f) {
            poseStack.method_22905(scaleX, scaleY, scaleZ);
        }

        if (names.contains(name)) {
            visitor.visit(name, new Matrix4f(poseStack.method_23760().method_23761()), new Matrix3f(poseStack.method_23760().method_23762()));
        }
        for (final GeoBone child : children) {
            child.visit(poseStack, names, visitor);
        }

        poseStack.method_22909();
    }

}