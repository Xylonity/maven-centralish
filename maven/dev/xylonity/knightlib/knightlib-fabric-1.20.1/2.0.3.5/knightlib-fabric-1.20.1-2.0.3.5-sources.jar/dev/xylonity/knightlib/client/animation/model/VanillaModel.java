package dev.xylonity.knightlib.client.animation.model;

import dev.xylonity.knightlib.client.animation.KnightLibPose;
import dev.xylonity.knightlib.mixin.ModelPartAccessor;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import net.minecraft.class_7833;

/**
 * {@link class_630} implementation of the KnightLib model API.
 */
public final class VanillaModel extends KnightLibModel {

    public static final String ROOT = "__root";

    private final class_630 root;
    private final Map<String, class_630> bones = new LinkedHashMap<>();
    private final Set<class_630> allParts = new LinkedHashSet<>();
    private final Map<class_630, Boolean> initialVisibility = new LinkedHashMap<>();
    private final Map<class_630, Boolean> initialSkipDraw = new LinkedHashMap<>();
    private final Set<String> boneNames;

    public VanillaModel(class_630 root) {
        this.root = root;
        bones.put(ROOT, root);
        allParts.add(root);
        index(root);
        for (final class_630 part : allParts) {
            initialVisibility.put(part, part.field_3665);
            initialSkipDraw.put(part, part.field_38456);
        }

        boneNames = Set.copyOf(bones.keySet());
    }

    private void index(class_630 part) {
        for (final Map.Entry<String, class_630> child : ((ModelPartAccessor) (Object) part).knightlib$getChildren().entrySet()) {
            allParts.add(child.getValue());
            bones.putIfAbsent(child.getKey(), child.getValue());
            index(child.getValue());
        }

    }

    @Override
    public Set<String> boneNames() {
        return boneNames;
    }

    @Override
    protected void visitEachBone(Consumer<String> visitor) {
        visitChildren(root, visitor, new HashSet<>());
    }

    private static void visitChildren(class_630 parent, Consumer<String> visitor, Set<String> visited) {
        for (final Map.Entry<String, class_630> child : ((ModelPartAccessor) (Object) parent).knightlib$getChildren().entrySet()) {
            if (visited.add(child.getKey())) {
                visitor.accept(child.getKey());
            }

            visitChildren(child.getValue(), visitor, visited);
        }

    }

    @Override
    public boolean hasBone(String name) {
        return bones.containsKey(name);
    }

    @Override
    public void resetPose() {
        for (final class_630 part : allParts) {
            part.method_41923();
            part.field_3665 = initialVisibility.getOrDefault(part, true);
            part.field_38456 = initialSkipDraw.getOrDefault(part, false);
        }

    }

    @Override
    public void applyPosition(String bone, float x, float y, float z) {
        final class_630 part = bones.get(bone);
        if (part == null) {
            return;
        }

        part.field_3657 += x;
        part.field_3656 += -y;
        part.field_3655 += z;
    }

    @Override
    public void applyRotation(String bone, float xDeg, float yDeg, float zDeg) {
        final class_630 part = bones.get(bone);
        if (part == null) {
            return;
        }

        part.field_3654 += (float) Math.toRadians(xDeg);
        part.field_3675 += (float) Math.toRadians(yDeg);
        part.field_3674 += (float) Math.toRadians(zDeg);
    }

    @Override
    public void applyScale(String bone, float x, float y, float z) {
        final class_630 part = bones.get(bone);
        if (part == null) {
            return;
        }

        part.field_37938 *= x;
        part.field_37939 *= y;
        part.field_37940 *= z;
    }

    @Override
    public void setBoneVisible(String bone, boolean visible) {
        final class_630 part = bones.get(bone);
        if (part == null) {
            return;
        }

        part.field_3665 = visible;
    }

    @Override
    public KnightLibPose capturePose() {
        final KnightLibPose pose = new KnightLibPose();
        for (final Map.Entry<String, class_630> entry : bones.entrySet()) {
            final class_630 part = entry.getValue();
            final float[] values = pose.bone(entry.getKey());
            values[0] = part.field_3657;
            values[1] = part.field_3656;
            values[2] = part.field_3655;
            values[3] = part.field_3654;
            values[4] = part.field_3675;
            values[5] = part.field_3674;
            values[6] = part.field_37938;
            values[7] = part.field_37939;
            values[8] = part.field_37940;
        }

        return pose;
    }

    @Override
    public void applyPose(KnightLibPose pose) {
        for (final Map.Entry<String, class_630> entry : bones.entrySet()) {
            final float[] values = pose.get(entry.getKey());
            if (values == null) {
                continue;
            }

            final class_630 part = entry.getValue();
            part.field_3657 = values[0];
            part.field_3656 = values[1];
            part.field_3655 = values[2];
            part.field_3654 = values[3];
            part.field_3675 = values[4];
            part.field_3674 = values[5];
            part.field_37938 = values[6];
            part.field_37939 = values[7];
            part.field_37940 = values[8];
        }

    }

    @Override
    public void applyPoseDelta(KnightLibPose layer, KnightLibPose rest) {
        for (final String name : layer.boneNames()) {
            final class_630 part = bones.get(name);
            final float[] values = layer.get(name);
            final float[] base = rest.get(name);
            if (part == null || values == null || base == null) {
                continue;
            }

            part.field_3657 += values[0] - base[0];
            part.field_3656 += values[1] - base[1];
            part.field_3655 += values[2] - base[2];
            part.field_3654 += values[3] - base[3];
            part.field_3675 += values[4] - base[4];
            part.field_3674 += values[5] - base[5];
            part.field_37938 *= scaleRatio(values[6], base[6]);
            part.field_37939 *= scaleRatio(values[7], base[7]);
            part.field_37940 *= scaleRatio(values[8], base[8]);
        }

    }

    private static float scaleRatio(float value, float rest) {
        return Math.abs(rest) < 1.0E-6f ? 1f : value / rest;
    }

    @Override
    public void blendFromPose(KnightLibPose from, float currentWeight) {
        for (final Map.Entry<String, class_630> entry : bones.entrySet()) {
            final float[] values = from.get(entry.getKey());
            if (values == null) {
                continue;
            }

            final class_630 part = entry.getValue();
            part.field_3657 = class_3532.method_16439(currentWeight, values[0], part.field_3657);
            part.field_3656 = class_3532.method_16439(currentWeight, values[1], part.field_3656);
            part.field_3655 = class_3532.method_16439(currentWeight, values[2], part.field_3655);
            part.field_3654 = lerpRadians(currentWeight, values[3], part.field_3654);
            part.field_3675 = lerpRadians(currentWeight, values[4], part.field_3675);
            part.field_3674 = lerpRadians(currentWeight, values[5], part.field_3674);
            part.field_37938 = class_3532.method_16439(currentWeight, values[6], part.field_37938);
            part.field_37939 = class_3532.method_16439(currentWeight, values[7], part.field_37939);
            part.field_37940 = class_3532.method_16439(currentWeight, values[8], part.field_37940);
        }

    }

    private static float lerpRadians(float weight, float from, float to) {
        final float delta = (float) Math.atan2(Math.sin(to - from), Math.cos(to - from));
        return from + delta * weight;
    }

    @Override
    public void setupRootTransform(class_4587 poseStack, float bodyYawDegrees, boolean entityContext) {
        if (entityContext) {
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(180f - bodyYawDegrees));
            poseStack.method_22905(-1f, -1f, 1f);
            poseStack.method_46416(0f, -1.501f, 0f);
        }

    }

    @Override
    public void render(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        root.method_22699(poseStack, consumer, packedLight, packedOverlay, r, g, b, a);
    }

    @Override
    public void visitBones(class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        visitPart(ROOT, root, poseStack, names, visitor);
    }

    private void visitPart(String name, class_630 part, class_4587 poseStack, Set<String> names, BoneVisitor visitor) {
        if (!part.field_3665) {
            return;
        }

        poseStack.method_22903();

        part.method_22703(poseStack);
        if (names.contains(name) && (ROOT.equals(name) || bones.get(name) == part)) {
            visitor.visit(name, new org.joml.Matrix4f(poseStack.method_23760().method_23761()), new org.joml.Matrix3f(poseStack.method_23760().method_23762()));
        }

        for (final Map.Entry<String, class_630> child : ((ModelPartAccessor) (Object) part).knightlib$getChildren().entrySet()) {
            visitPart(child.getKey(), child.getValue(), poseStack, names, visitor);
        }

        poseStack.method_22909();
    }

    @Override
    public class_243 boneHalfExtents(String name) {
        final class_630 part = bones.get(name);
        if (part == null) {
            return new class_243(0.1, 0.1, 0.1);
        }

        double x = 0;
        double y = 0;
        double z = 0;
        for (final class_630.class_628 cube : ((ModelPartAccessor) (Object) part).knightlib$getCubes()) {
            x = Math.max(x, Math.max(Math.abs(cube.field_3645), Math.abs(cube.field_3648)) / 16.0);
            y = Math.max(y, Math.max(Math.abs(cube.field_3644), Math.abs(cube.field_3647)) / 16.0);
            z = Math.max(z, Math.max(Math.abs(cube.field_3643), Math.abs(cube.field_3646)) / 16.0);
        }

        return new class_243(Math.max(x, 0.1), Math.max(y, 0.1), Math.max(z, 0.1));
    }

}