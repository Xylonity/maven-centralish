package dev.xylonity.knightlib.client.animation.renderer;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.KnightLibAnimationSource;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibEmissiveLayer;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibOverlayLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayer;
import dev.xylonity.knightlib.client.animation.model.KnightLibLivingModel;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.client.texture.KnightLibAnimatedTextures;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_922;

/**
 * KnightLib renderer built directly on vanilla's {@link class_922}
 */
public abstract class KnightLibLivingEntityRenderer<T extends class_1309 & KnightLibAnimatable> extends class_922<T, KnightLibLivingModel<T>> {

    private KnightLibRenderState activeRenderState = KnightLibRenderState.DEFAULT;

    protected KnightLibLivingEntityRenderer(class_5617.class_5618 context, float shadowRadius) {
        super(context, new KnightLibLivingModel<>(), shadowRadius);
        this.field_4737.configure(this::defineModel, this::defineAnimations, this::setupModelPose);
        this.field_4737.configureAttachments(this::getHeadBone, this::getArmBone);
        this.field_4737.configureRenderColor((entity, partialTick) -> activeRenderState.color());
    }

    protected KnightLibLivingEntityRenderer(class_5617.class_5618 context) {
        this(context, 0.5f);
    }

    /**
     * Geometry file or method reference
     */
    protected abstract KnightLibModelSource defineModel(T entity);

    /**
     * Animation file or method reference
     */
    protected KnightLibAnimationSource defineAnimations(T entity) {
        return KnightLibAnimationSource.none();
    }

    /**
     * Packed ARGB multiplier, evaluated once immediately before the entity is drawn
     */
    protected int getRenderColor(T entity, float partialTick, int packedLight) {
        return KnightLibColor.WHITE_ARGB;
    }

    /**
     * Calculates scale and ARGB together once for the complete render pass
     */
    protected KnightLibRenderState getRenderState(T entity, float partialTick, int packedLight) {
        return KnightLibRenderState.of(getScale(entity), getRenderColor(entity, partialTick, packedLight));
    }

    /**
     * Render type of the base texture pass
     */
    protected class_1921 getRenderType(T entity, class_2960 texture) {
        return class_1921.method_23578(texture);
    }

    protected class_1921 getRenderType(T entity, class_2960 texture, int renderColor) {
        return KnightLibColor.fromArgb(renderColor).isTranslucent()
                ? class_1921.method_23580(texture)
                : getRenderType(entity, texture);
    }

    protected float getScale(T entity) {
        return 1f;
    }

    /**
     * Extra culling margin in blocks
     */
    protected double getCullingInflation(T entity) {
        return 0.5;
    }

    protected String getHeadBone(T entity) {
        return "head";
    }

    protected String getArmBone(T entity, class_1306 arm) {
        return arm == class_1306.field_6182 ? "left_arm" : "right_arm";
    }

    protected void setupPose(T entity, KnightLibModel model, float partialTick) {
        ;;
    }

    /**
     * Called every frame after animations are applied and before rendering
     */
    protected void setupPose(T entity, KnightLibModel model, float limbSwing, float limbSwingAmount, float partialTick, float netHeadYaw, float headPitch) {
        setupPose(entity, model, partialTick);
    }

    /**
     * Called for every bone after animation/pose evaluation and before rendering
     */
    protected void setupBone(T entity, KnightLibModel model, String boneName, float partialTick) {
        ;;
    }

    /**
     * Called immediately before the complete vanilla living-entity render pass
     */
    protected void beforeRender(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffers, int packedLight) {
        ;;
    }

    /**
     * Called after vanilla has rendered the entity and all its layers
     */
    protected void afterRender(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffers, int packedLight) {
        ;;
    }

    private void setupModelPose(T entity, KnightLibModel model, float limbSwing, float limbSwingAmount, float partialTick, float netHeadYaw, float headPitch) {
        setupPose(entity, model, limbSwing, limbSwingAmount, partialTick, netHeadYaw, headPitch);
        model.forEachBone(boneName -> setupBone(entity, model, boneName, partialTick));
    }

    protected final void addEmissiveLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture));
    }

    protected final void addEmissiveLayer(Function<T, class_2960> texture, KnightLibEmissiveLayer.AnimatedTint<T> animatedTint) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture, animatedTint));
    }

    protected final void addOverlayLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibOverlayLayer<>(texture));
    }

    /**
     * Adds an arbitrary render layer
     */
    protected final void addRenderLayer(KnightLibRenderLayer<T> layer) {
        method_4046(new KnightLibLivingRenderLayer<>(this, Objects.requireNonNull(layer, "layer")));
    }

    /**
     * Prefer the before/after hooks when possible.
     */
    @Override
    public void method_4054(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffers, int packedLight) {
        final KnightLibRenderState previousState = activeRenderState;
        final KnightLibRenderState renderState = getRenderState(entity, partialTick, packedLight);
        activeRenderState = renderState == null ? KnightLibRenderState.DEFAULT : renderState;
        try {
            actuallyRender(entity, entityYaw, partialTick, poseStack, buffers, packedLight, activeRenderState.renderColor());
        }
        finally {
            activeRenderState = previousState;
        }

    }

    /**
     * Executes the complete vanilla living render pipeline
     */
    protected void actuallyRender(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffers, int packedLight, int renderColor) {
        final KnightLibRenderState previousState = activeRenderState;
        activeRenderState = previousState.withRenderColor(renderColor);
        try {
            beforeRender(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
            super.method_4054(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
            afterRender(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
        }
        finally {
            activeRenderState = previousState;
        }

    }

    @Override
    protected class_1921 method_24302(T entity, boolean bodyVisible, boolean translucent, boolean glowing) {
        final class_2960 texture = KnightLibAnimatedTextures.resolve(method_3931(entity));
        if (translucent) {
            return class_1921.method_29379(texture);
        }
        if (bodyVisible) {
            return getRenderType(entity, texture, activeRenderState.renderColor());
        }
        if (glowing) {
            return class_1921.method_23287(texture);
        }

        return null;
    }

    @Override
    protected void method_4042(T entity, class_4587 poseStack, float partialTick) {
        super.method_4042(entity, poseStack, partialTick);
        final float scale = activeRenderState.scale();
        if (scale != 1f) {
            poseStack.method_22905(scale, scale, scale);
        }

    }

    @Override
    public boolean shouldRender(T entity, class_4604 frustum, double cameraX, double cameraY, double cameraZ) {
        if (super.method_3933(entity, frustum, cameraX, cameraY, cameraZ)) {
            return true;
        }

        final class_238 box = entity.method_5830().method_1014(Math.max(0.0, getCullingInflation(entity)));
        return !box.method_1013() && frustum.method_23093(box);
    }

}
