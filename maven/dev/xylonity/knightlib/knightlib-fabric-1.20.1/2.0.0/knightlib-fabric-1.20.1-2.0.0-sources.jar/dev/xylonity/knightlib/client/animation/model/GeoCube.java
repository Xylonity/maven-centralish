package dev.xylonity.knightlib.client.animation.model;

import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Immutable baked cube geometry. By the time a cube gets here means it's ready for rendering as almost every pass is applied.
 *
 * Based off GeckoLib implementation
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/object/GeoCube.java
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/object/GeoQuad.java
 * https://github.com/bernie-g/geckolib/blob/1.20.1/Forge/src/main/java/software/bernie/geckolib/cache/object/GeoVertex.java
 */
public final class GeoCube {

    private final Face[] faces;
    private final class_243 absoluteExtents;
    private final boolean flatX;
    private final boolean flatY;
    private final boolean flatZ;

    public GeoCube(Face[] faces) {
        this(faces, 1f, 1f, 1f);
    }

    public GeoCube(Face[] faces, float authoredSizeX, float authoredSizeY, float authoredSizeZ) {
        this.faces = faces;
        this.flatX = authoredSizeX == 0f;
        this.flatY = authoredSizeY == 0f;
        this.flatZ = authoredSizeZ == 0f;
        double x = 0;
        double y = 0;
        double z = 0;
        for (final Face face : faces) {
            for (final Vertex vertex : face.vertices()) {
                final Vector3f point = vertex.position();
                x = Math.max(x, Math.abs(point.x()));
                y = Math.max(y, Math.abs(point.y()));
                z = Math.max(z, Math.abs(point.z()));
            }

        }

        this.absoluteExtents = new class_243(x, y, z);
    }

    public class_243 absoluteExtents() {
        return absoluteExtents;
    }

    public void render(class_4587 poseStack, class_4588 consumer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        final Matrix4f pose = poseStack.method_23760().method_23761();
        final Matrix3f normalMatrix = poseStack.method_23760().method_23762();
        final Vector3f scratch = new Vector3f();

        for (final Face face : faces) {
            final Vector3f normal = normalMatrix.transform(face.normal().x(), face.normal().y(), face.normal().z(), scratch);
            fixInvertedFlatNormal(normal);

            for (final Vertex vertex : face.vertices()) {
                final Vector3f position = vertex.position();
                consumer.method_22918(pose, position.x(), position.y(), position.z());
                consumer.method_22915(r, g, b, a);
                consumer.method_22913(vertex.u(), vertex.v());
                consumer.method_22922(packedOverlay);
                consumer.method_22916(packedLight);
                consumer.method_22914(normal.x(), normal.y(), normal.z());
                consumer.method_1344();
            }

        }

    }

    /**
     * Lighting correction for zero-thickness cubes
     */
    void fixInvertedFlatNormal(Vector3f normal) {
        if (normal.x() < 0f && (flatY || flatZ)) {
            normal.mul(-1f, 1f, 1f);
        }
        if (normal.y() < 0f && (flatX || flatZ)) {
            normal.mul(1f, -1f, 1f);
        }
        if (normal.z() < 0f && (flatX || flatY)) {
            normal.mul(1f, 1f, -1f);
        }

    }

    public record Face(
            Vector3f normal,
            Vertex[] vertices
    ) {
        ;;
    }

    public record Vertex(
            Vector3f position,
            float u,
            float v
    ) {
        ;;
    }

}