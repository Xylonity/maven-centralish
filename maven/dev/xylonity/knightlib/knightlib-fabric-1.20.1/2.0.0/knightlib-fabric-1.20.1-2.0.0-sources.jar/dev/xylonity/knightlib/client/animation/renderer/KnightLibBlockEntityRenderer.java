package dev.xylonity.knightlib.client.animation.renderer;

import dev.xylonity.knightlib.api.animation.KnightLibAnimatable;
import dev.xylonity.knightlib.api.util.KnightLibColor;
import dev.xylonity.knightlib.client.animation.KnightLibAnimationSource;
import dev.xylonity.knightlib.client.animation.KnightLibAnimator;
import dev.xylonity.knightlib.client.animation.KnightLibKeyframeEvents;
import dev.xylonity.knightlib.client.animation.KnightLibModelSource;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibEmissiveLayer;
import dev.xylonity.knightlib.client.animation.layer.impl.KnightLibOverlayLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayer;
import dev.xylonity.knightlib.client.animation.layer.KnightLibRenderLayerContext;
import dev.xylonity.knightlib.client.animation.model.KnightLibModel;
import dev.xylonity.knightlib.client.texture.KnightLibAnimatedTextures;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_827;

/**
 * Base renderer for block entities animated through KnightLib.
 */
public abstract class KnightLibBlockEntityRenderer<T extends class_2586 & KnightLibAnimatable> implements class_827<T> {

    private final List<KnightLibRenderLayer<T>> layers = new ArrayList<>();
    private final KnightLibModelSource.InstanceCache modelCache = new KnightLibModelSource.InstanceCache();

    protected KnightLibBlockEntityRenderer() {
        ;;
    }

    /**
     * Geometry file or method reference
     */
    protected abstract KnightLibModelSource defineModel(T blockEntity);

    /**
     * Animation file or method reference
     */
    protected KnightLibAnimationSource defineAnimations(T blockEntity) {
        return KnightLibAnimationSource.none();
    }

    /**
     * Packed ARGB multiplier, evaluated once immediately before drawing
     */
    protected int getRenderColor(T blockEntity, float partialTicks, int packedLight) {
        return KnightLibColor.WHITE_ARGB;
    }

    /**
     * Calculates scale and ARGB together once for the complete render pass
     */
    protected KnightLibRenderState getRenderState(T blockEntity, float partialTicks, int packedLight) {
        return KnightLibRenderState.of(getScale(blockEntity), getRenderColor(blockEntity, partialTicks, packedLight));
    }

    /**
     * Texture source for this block entity
     */
    public abstract class_2960 getTextureLocation(T blockEntity);

    protected class_1921 getRenderType(T blockEntity, class_2960 texture) {
        return class_1921.method_23578(texture);
    }

    protected class_1921 getRenderType(T blockEntity, class_2960 texture, int renderColor) {
        return KnightLibColor.fromArgb(renderColor).isTranslucent()
                ? class_1921.method_23580(texture)
                : getRenderType(blockEntity, texture);
    }

    /**
     * Optional atlas sprite backing the returned texture (no need to override this at all)
     */
    protected class_1058 getTextureSprite(T blockEntity, class_2960 texture) {
        return null;
    }

    protected float getScale(T blockEntity) {
        return 1f;
    }

    /**
     * Whether the model rotates with the block state's horizontal facing property
     */
    protected boolean rotateByBlockFacing() {
        return false;
    }

    protected final void addEmissiveLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture));
    }

    protected final void addEmissiveLayer(Function<T, class_2960> texture, KnightLibEmissiveLayer.AnimatedTint<T> animatedTint) {
        addRenderLayer(new KnightLibEmissiveLayer<>(texture, animatedTint));
    }

    protected final void addOverlayLayer(Function<T, class_2960> texture) {
        addRenderLayer(new KnightLibOverlayLayer<>(texture));
    }

    /**
     * Adds an arbitrary render layer
     */
    protected final void addRenderLayer(KnightLibRenderLayer<T> layer) {
        layers.add(Objects.requireNonNull(layer, "layer"));
    }

    /**
     * Called every frame after animations are applied and before rendering
     */
    protected void setupPose(T blockEntity, KnightLibModel model, float partialTicks) {
        ;;
    }

    /**
     * Called for every bone after animation/pose evaluation and before rendering
     */
    protected void setupBone(T blockEntity, KnightLibModel model, String boneName, float partialTicks) {
        ;;
    }

    @Override
    public void method_3569(T blockEntity, float partialTicks, class_4587 poseStack, class_4597 buffers, int packedLight, int packedOverlay) {
        final KnightLibModel model = modelCache.resolve(defineModel(blockEntity));
        final KnightLibAnimationSource animations = defineAnimations(blockEntity);

        // Level-less block entities (JEI previews and similar) still render at rest pose
        final double now = blockEntity.method_10997() != null ? blockEntity.method_10997().method_8510() + partialTicks : partialTicks;
        final KnightLibAnimator.DeferredEvents keyframeEvents;
        if (blockEntity.method_10997() == null) {
            KnightLibAnimator.animate(blockEntity.getAnimationHandler(), model, animations::get, now);
            keyframeEvents = null;
        }
        else {
            keyframeEvents = KnightLibAnimator.animateDeferred(blockEntity.getAnimationHandler(), model, animations::get, now);
        }

        setupPose(blockEntity, model, partialTicks);
        model.forEachBone(boneName -> setupBone(blockEntity, model, boneName, partialTicks));

        KnightLibRenderState renderState = getRenderState(blockEntity, partialTicks, packedLight);
        if (renderState == null) {
            renderState = KnightLibRenderState.DEFAULT;
        }

        poseStack.method_22903();
        poseStack.method_22904(0.5, 0.0, 0.5);

        if (rotateByBlockFacing()) {
            final class_2680 state = blockEntity.method_11010();
            if (state.method_28498(class_2741.field_12481)) {
                final class_2350 facing = state.method_11654(class_2741.field_12481);
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(-facing.method_10144()));
            }

        }

        final float scale = renderState.scale();
        if (scale != 1f) {
            poseStack.method_22905(scale, scale, scale);
        }

        model.setupRootTransform(poseStack, 0f, false);
        if (keyframeEvents != null) {
            KnightLibKeyframeEvents.dispatch(blockEntity.getAnimationHandler(), keyframeEvents, model, poseStack, false);
        }

        final class_2960 baseTexture = getTextureLocation(blockEntity);
        final class_1058 baseSprite = getTextureSprite(blockEntity, baseTexture);
        actuallyRender(blockEntity, model, baseTexture, baseSprite, partialTicks, poseStack, buffers, packedLight, packedOverlay, renderState.renderColor());

        poseStack.method_22909();
    }

    /**
     * Render hook that's derived from the main render call that can alter the actual packed ARGB
     */
    protected void actuallyRender(T blockEntity, KnightLibModel model, class_2960 baseTexture, class_1058 baseSprite, float partialTicks, class_4587 poseStack, class_4597 buffers, int packedLight, int packedOverlay, int renderColor) {
        final KnightLibColor color = KnightLibColor.fromArgb(renderColor);
        final class_2960 renderTexture = baseSprite == null ? KnightLibAnimatedTextures.resolve(baseTexture) : baseSprite.method_45852();

        class_4588 baseConsumer = buffers.getBuffer(getRenderType(blockEntity, renderTexture, renderColor));
        if (baseSprite != null) {
            baseConsumer = baseSprite.method_24108(baseConsumer);
        }

        model.render(poseStack, baseConsumer, packedLight, packedOverlay, color.red(), color.green(), color.blue(), color.alpha());

        final double renderTime = blockEntity.method_10997() != null ? blockEntity.method_10997().method_8510() + partialTicks : partialTicks;
        final KnightLibRenderLayerContext<T> context = new KnightLibRenderLayerContext<>(blockEntity, model, poseStack, buffers, packedLight, packedOverlay, renderColor, partialTicks, renderTime, null, false);
        for (final KnightLibRenderLayer<T> layer : layers) {
            layer.renderIsolated(context);
        }

    }

}
